export const environment = {
  production: false,
  apiUrl: 'https://henrrypulgarin.com',
};
