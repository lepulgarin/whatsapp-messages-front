export const environment = {
  production: false,
  apiUrl: '/api',
  googleClientId: '937982561300-lp3ea9lonrfe22n3auqfaqng61kco2l3.apps.googleusercontent.com',
};
