export interface Clients {
  name?: string | null;
  phone?: string | null;
  email?: string | null;
  date?: string | null;
  value?: string | null;
  paymentValue?: string | null;
  contractValue?: string | null;
  var1?: string | null;
  var2?: string | null;
  var3?: string | null;
  id?: string | null;
  send?: boolean | null;
}
