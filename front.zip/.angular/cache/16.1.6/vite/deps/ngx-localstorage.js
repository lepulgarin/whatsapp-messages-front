import {
  DOCUMENT
} from "./chunk-MIRZRLCI.js";
import {
  Directive,
  ElementRef,
  EventEmitter,
  Inject,
  Injectable,
  InjectionToken,
  Input,
  Output,
  inject,
  makeEnvironmentProviders,
  setClassMetadata,
  ɵɵdefineDirective,
  ɵɵdefineInjectable,
  ɵɵdirectiveInject,
  ɵɵinject
} from "./chunk-SPBZRJHT.js";
import "./chunk-IXJD77KS.js";
import {
  fromEvent
} from "./chunk-QCYGWUBY.js";
import {
  Observable,
  Subscription,
  debounceTime,
  filter
} from "./chunk-37TWHRPH.js";
import "./chunk-4BJ7XQX3.js";
import "./chunk-GKWPUQBP.js";

// node_modules/ngx-localstorage/fesm2020/ngx-localstorage.mjs
var NGX_LOCAL_STORAGE_DEFAULT_CONFIG = () => {
  return {
    allowNull: true,
    storageType: "localStorage",
    delimiter: "_"
  };
};
var NGX_LOCAL_STORAGE_CONFIG = new InjectionToken("NgxLocalstorageConfiguration", {
  providedIn: "root",
  factory: NGX_LOCAL_STORAGE_DEFAULT_CONFIG
});
var DefaultSerializer = class {
  /**
   * @inheritdoc
   */
  serialize(value) {
    return JSON.stringify(value);
  }
  /**
   * @inheritdoc
   */
  deserialize(storedValue) {
    return JSON.parse(storedValue);
  }
};
DefaultSerializer.ɵfac = function DefaultSerializer_Factory(t) {
  return new (t || DefaultSerializer)();
};
DefaultSerializer.ɵprov = ɵɵdefineInjectable({
  token: DefaultSerializer,
  factory: DefaultSerializer.ɵfac
});
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DefaultSerializer, [{
    type: Injectable
  }], null, null);
})();
var NGX_LOCAL_STORAGE_SERIALIZER = new InjectionToken("StorageSerializer", {
  providedIn: "root",
  factory: () => new DefaultSerializer()
});
var WINDOW = new InjectionToken("Abstraction token for global window access", {
  factory: () => {
    const {
      defaultView
    } = inject(DOCUMENT);
    if (!defaultView) {
      throw new Error("Window is not available");
    }
    return defaultView;
  }
});
var LOCALSTORAGE_SUPPORT = new InjectionToken("Token providing information if localStorage is available", {
  factory: () => !!inject(LOCALSTORAGE)
});
var LOCALSTORAGE = new InjectionToken("Token for accessing localStorage", {
  factory: () => inject(WINDOW).localStorage
});
var SESSIONSTORAGE_SUPPORT = new InjectionToken("Token providing information if sessionStorage is available", {
  factory: () => !!inject(SESSIONSTORAGE)
});
var SESSIONSTORAGE = new InjectionToken("Token for accessing sessionStorage", {
  factory: () => inject(WINDOW).sessionStorage
});
var STORAGE_SUPPORT = new InjectionToken("Token providing information is choosen storage is available", {
  factory: () => {
    const {
      storageType
    } = inject(NGX_LOCAL_STORAGE_CONFIG);
    return storageType === "sessionStorage" ? inject(SESSIONSTORAGE_SUPPORT) : inject(LOCALSTORAGE_SUPPORT);
  }
});
var STORAGE = new InjectionToken("Token providing choosen storage", {
  factory: () => {
    const {
      storageType
    } = inject(NGX_LOCAL_STORAGE_CONFIG);
    return storageType === "sessionStorage" ? inject(SESSIONSTORAGE) : inject(LOCALSTORAGE);
  }
});
var constructKey = (key, prefix, configuredPrefix, delimiter) => {
  const prefixToUse = prefix || configuredPrefix;
  if (prefixToUse) {
    return `${prefixToUse}${delimiter || ""}${key}`;
  }
  return key;
};
var defaultConfig = NGX_LOCAL_STORAGE_DEFAULT_CONFIG();
var LocalStorageService = class extends Observable {
  /**
   * Creates a new instance.
   */
  constructor(_config) {
    super((subscriber) => {
      var _a;
      if (!this.storageSupport) {
        subscriber.error(new Error(`Choosen storage '${(_a = this.config) == null ? void 0 : _a.storageType}' is not available`));
      }
      if (this.window) {
        this.subscriptions.add(fromEvent(this.window, "storage").pipe(filter((event) => !!event)).subscribe((event) => subscriber.next(event)));
      }
      this.subscriptions.add(this.onError.subscribe((error) => subscriber.error(error)));
    });
    this.onError = new EventEmitter();
    this.subscriptions = new Subscription();
    this.serializer = inject(NGX_LOCAL_STORAGE_SERIALIZER);
    this.storageSupport = inject(STORAGE_SUPPORT);
    this.storage = inject(STORAGE, {
      optional: true
    });
    this.window = inject(WINDOW, {
      optional: true
    });
    this.config = {
      ...defaultConfig,
      ..._config
    };
  }
  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
  /**
   * Gets the number of entries in the applications storage.
   */
  count() {
    var _a;
    try {
      return (_a = this.storage) == null ? void 0 : _a.length;
    } catch (error) {
      this.error(error);
      return void 0;
    }
  }
  /**
   * Returns the nth (defined by the index parameter) key in the storage.
   * The order of keys is user-agent defined, so you should not rely on it.
   * @param index An integer representing the number of the key you want to get the name of. This is a zero-based index.
   */
  getKey(index) {
    var _a;
    if (index < 0) {
      this.error(new Error("index has to be 0 or greater"));
    }
    try {
      return (_a = this.storage) == null ? void 0 : _a.key(index);
    } catch (error) {
      this.error(error);
      return void 0;
    }
  }
  /**
   * Adds the value with the given key or updates an existing entry.
   * @param key Key identifying the wanted entry.
   * @param value Value to store.
   * @param options Options for overwriting configuration with the following properties:
   * * `prefix`: (Optional) Prefix to overwrite the configured one.
   * * `serializer`: (Optional) Serializer to overwrite the configured one.
   */
  set(key, value, options) {
    var _a;
    const [prefix, storageSerializer] = [options == null ? void 0 : options.prefix, (options == null ? void 0 : options.serializer) || this.serializer];
    if (this.config.allowNull || !this.config.allowNull && `${value}` !== "null" && value !== null && value !== void 0) {
      (_a = this.storage) == null ? void 0 : _a.setItem(constructKey(key, prefix, this.config.prefix, this.config.delimiter), storageSerializer.serialize(value));
    } else {
      this.remove(key, prefix);
    }
  }
  /**
   * Gets the entry specified by the given key if existing - otherwise `null`.
   * @param key Key identifying the wanted entry.
   * @param options Options for overwriting configuration with the following properties:
   * * `prefix`: (Optional) Prefix to overwrite the configured one.
   * * `serializer`: (Optional) Serializer to overwrite the configured one.
   */
  get(key, options) {
    var _a;
    const [prefix, storageSerializer] = [options == null ? void 0 : options.prefix, (options == null ? void 0 : options.serializer) || this.serializer];
    try {
      const constructedKey = constructKey(key, prefix, this.config.prefix, this.config.delimiter);
      const storageItem = (_a = this.storage) == null ? void 0 : _a.getItem(constructedKey);
      return storageItem ? storageSerializer.deserialize(storageItem) : null;
    } catch (error) {
      this.error(error);
      return null;
    }
  }
  /**
   * Removes the entry specified by the given key.
   * @param key Key identifying the entry to remove.
   * @param prefix Optional prefix to overwrite the configured one.
   */
  remove(key, prefix) {
    var _a;
    try {
      (_a = this.storage) == null ? void 0 : _a.removeItem(constructKey(key, prefix, this.config.prefix, this.config.delimiter));
    } catch (error) {
      this.error(error);
    }
  }
  /**
   * Clears all entries of the applications local storage.
   */
  clear() {
    var _a;
    try {
      (_a = this.storage) == null ? void 0 : _a.clear();
    } catch (error) {
      this.error(error);
    }
  }
  /**
   * Triggers the service to emit the given error.
   * @param error Error to emit through the service.
   */
  error(error) {
    this.onError.emit(error);
  }
  processServiceOptions(options) {
    return [options == null ? void 0 : options.prefix, (options == null ? void 0 : options.serializer) || this.serializer];
  }
};
LocalStorageService.ɵfac = function LocalStorageService_Factory(t) {
  return new (t || LocalStorageService)(ɵɵinject(NGX_LOCAL_STORAGE_CONFIG));
};
LocalStorageService.ɵprov = ɵɵdefineInjectable({
  token: LocalStorageService,
  factory: LocalStorageService.ɵfac,
  providedIn: "root"
});
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalStorageService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], function() {
    return [{
      type: void 0,
      decorators: [{
        type: Inject,
        args: [NGX_LOCAL_STORAGE_CONFIG]
      }]
    }];
  }, null);
})();
var isString = (value) => {
  return typeof value === "string";
};
var getPropByPath = (object, path) => {
  const checkProperty = (o, key) => typeof o === "object" ? o[key] : void 0;
  return path.slice(0).reduce((prev, curr, _i, arr) => {
    if (prev === void 0) {
      arr.splice(1);
    }
    return checkProperty(prev, curr);
  }, object);
};
var setPropByPath = (object, path, value, falsyTransformer) => {
  const checkProperty = (o, key) => typeof o === "object" ? o[key] : void 0;
  path.slice(0).reduce((prev, curr, i, arr) => {
    if (prev === void 0) {
      arr.splice(1);
    }
    if (i === path.length - 1) {
      object[curr] = (!value || isString(value) && value === "false") && !!falsyTransformer ? falsyTransformer() : value;
      arr.splice(1);
    }
    return checkProperty(prev, curr);
  }, object);
};
var LocalStorageDirective = class {
  /**
   * Creates a new instance.
   */
  constructor(elementRef, storageService) {
    this.elementRef = elementRef;
    this.storageService = storageService;
    this.key = "";
    this.storageDebounce = 0;
    this.storedValue = new EventEmitter();
    this.subscriptions = new Subscription();
    this._valuePath = [];
    this._initFromStorage = false;
  }
  /**
   * Flag if the bound elements value should be initialized from storage.
   */
  set initFromStorage(value) {
    this._initFromStorage = value != null && `${value}` !== "false";
  }
  get initFromStorage() {
    return this._initFromStorage;
  }
  /**
   * Provides a path to access the bound elements value property.
   */
  set valuePath(path) {
    if (path != null) {
      this._valuePath = Array.isArray(path) ? path : path.split(",");
    } else {
      this._valuePath = [];
    }
  }
  /**
   * AfterViewInit lifecycle hook.
   */
  ngAfterViewInit() {
    this.initKey();
    this.subscriptions.add(this.storageService.pipe(
      // TODO: filter should be more accurate
      filter((ev) => !!ev.key && ev.key.indexOf(this.key) >= 0)
    ).subscribe((ev) => {
      setPropByPath(this.elementRef.nativeElement, this.getValuePath(), ev.newValue, this.falsyTransformer);
    }));
    this.checkInitFromStorage();
    this.hookToEvent();
  }
  /**
   * Unsubscribe from event observable.
   */
  ngOnDestroy() {
    this.subscriptions.unsubscribe();
  }
  /**
   * Initalizes the from either the given value or the elements id or name property.
   */
  initKey() {
    if (!this.key) {
      if (!this.elementRef.nativeElement.id && !this.elementRef.nativeElement.name) {
        this.storageService.error(new Error("No key or element id or name supplied!"));
      }
      this.key = this.elementRef.nativeElement.id || this.elementRef.nativeElement.name;
    }
  }
  /**
   * Hooks onto the elements given event to perform storage write on value changes.
   */
  hookToEvent() {
    if (this.forEvent) {
      this.subscriptions.add(fromEvent(this.elementRef.nativeElement, this.forEvent).pipe(debounceTime(this.storageDebounce)).subscribe(() => {
        const propertyValue = getPropByPath(this.elementRef.nativeElement, this.getValuePath());
        this.storageService.set(this.key, propertyValue, {
          prefix: this.prefix
        });
        this.storedValue.emit(propertyValue);
      }));
    }
  }
  /**
   * Initializes the elements value from storage.
   */
  checkInitFromStorage() {
    if (this.initFromStorage) {
      const storedValue = this.storageService.get(this.key, {
        prefix: this.prefix
      });
      try {
        setPropByPath(this.elementRef.nativeElement, this.getValuePath(), storedValue, this.falsyTransformer);
      } catch (error) {
        this.storageService.error(error);
      }
    }
  }
  getValuePath() {
    return this._valuePath.length ? this._valuePath : ["value"];
  }
};
LocalStorageDirective.ɵfac = function LocalStorageDirective_Factory(t) {
  return new (t || LocalStorageDirective)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(LocalStorageService));
};
LocalStorageDirective.ɵdir = ɵɵdefineDirective({
  type: LocalStorageDirective,
  selectors: [["", "ngxLocalStorage", ""]],
  inputs: {
    key: ["ngxLocalStorage", "key"],
    prefix: "prefix",
    forEvent: "forEvent",
    storageDebounce: "storageDebounce",
    initFromStorage: "initFromStorage",
    falsyTransformer: "falsyTransformer",
    valuePath: "valuePath"
  },
  outputs: {
    storedValue: "storedValue"
  },
  standalone: true
});
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LocalStorageDirective, [{
    type: Directive,
    args: [{
      selector: "[ngxLocalStorage]",
      standalone: true
    }]
  }], function() {
    return [{
      type: ElementRef
    }, {
      type: LocalStorageService
    }];
  }, {
    key: [{
      type: Input,
      args: ["ngxLocalStorage"]
    }],
    prefix: [{
      type: Input
    }],
    forEvent: [{
      type: Input
    }],
    storageDebounce: [{
      type: Input
    }],
    initFromStorage: [{
      type: Input
    }],
    falsyTransformer: [{
      type: Input
    }],
    valuePath: [{
      type: Input
    }],
    storedValue: [{
      type: Output
    }]
  });
})();
var FeatureKind;
(function(FeatureKind2) {
  FeatureKind2[FeatureKind2["Serializer"] = 0] = "Serializer";
})(FeatureKind || (FeatureKind = {}));
var provideNgxLocalstorage = (configuration, ...features) => {
  var _a;
  if (((_a = features == null ? void 0 : features.filter((feature) => feature.kind === FeatureKind.Serializer)) == null ? void 0 : _a.length) > 1) {
    throw new Error("Only one serializer feature is allowed!");
  }
  return makeEnvironmentProviders([{
    provide: NGX_LOCAL_STORAGE_CONFIG,
    useValue: configuration
  }, features == null ? void 0 : features.map((feature) => feature.providers)]);
};
var withSerializer = (serializer) => ({
  kind: FeatureKind.Serializer,
  providers: [{
    provide: NGX_LOCAL_STORAGE_SERIALIZER,
    useClass: serializer
  }]
});
export {
  LocalStorageDirective,
  LocalStorageService,
  NGX_LOCAL_STORAGE_CONFIG,
  NGX_LOCAL_STORAGE_SERIALIZER,
  STORAGE_SUPPORT,
  provideNgxLocalstorage,
  withSerializer
};
//# sourceMappingURL=ngx-localstorage.js.map
