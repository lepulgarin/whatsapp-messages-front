import {
  InputNumber,
  InputNumberModule
} from "./chunk-DW7I2UOV.js";
import {
  AngleRightIcon,
  ChevronDownIcon,
  ChevronRightIcon
} from "./chunk-QLW4XV5J.js";
import "./chunk-Z6RSJ3DK.js";
import {
  InputText,
  InputTextModule
} from "./chunk-KHRDRQSF.js";
import {
  Tooltip,
  TooltipModule
} from "./chunk-EXFNDU4R.js";
import {
  ButtonDirective,
  ButtonModule,
  SpinnerIcon
} from "./chunk-EVZ3PBLH.js";
import {
  CheckIcon
} from "./chunk-JYL5AXZN.js";
import {
  FormsModule,
  NG_VALUE_ACCESSOR,
  NgControlStatus,
  NgModel
} from "./chunk-UKH2O2A3.js";
import {
  Ripple,
  RippleModule
} from "./chunk-ZFEZZYMT.js";
import {
  TimesIcon
} from "./chunk-CYTHTHVV.js";
import {
  BaseIcon
} from "./chunk-TQCROI5M.js";
import {
  ConnectedOverlayScrollHandler,
  DomHandler
} from "./chunk-N3XAYJ3A.js";
import {
  FilterMatchMode,
  FilterOperator,
  FilterService,
  ObjectUtils,
  OverlayService,
  PrimeNGConfig,
  PrimeTemplate,
  SharedModule,
  TranslationKeys,
  UniqueComponentId,
  zindexutils
} from "./chunk-X6HTJCNQ.js";
import {
  animate,
  animation,
  state,
  style,
  transition,
  trigger,
  useAnimation
} from "./chunk-GA7SZJ22.js";
import {
  CommonModule,
  DOCUMENT,
  NgClass,
  NgForOf,
  NgIf,
  NgStyle,
  NgSwitch,
  NgSwitchCase,
  NgTemplateOutlet,
  isPlatformBrowser
} from "./chunk-MIRZRLCI.js";
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ContentChild,
  ContentChildren,
  Directive,
  ElementRef,
  EventEmitter,
  HostListener,
  Inject,
  Injectable,
  Input,
  NgModule,
  NgZone,
  Optional,
  Output,
  PLATFORM_ID,
  Renderer2,
  ViewChild,
  ViewEncapsulation$1,
  forwardRef,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵNgOnChangesFeature,
  ɵɵProvidersFeature,
  ɵɵStandaloneFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵclassProp,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineDirective,
  ɵɵdefineInjectable,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵprojection,
  ɵɵprojectionDef,
  ɵɵproperty,
  ɵɵpureFunction0,
  ɵɵpureFunction1,
  ɵɵpureFunction2,
  ɵɵpureFunction3,
  ɵɵpureFunction4,
  ɵɵpureFunction5,
  ɵɵpureFunction6,
  ɵɵpureFunction7,
  ɵɵpureFunctionV,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵstyleMap,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate1,
  ɵɵtextInterpolate2,
  ɵɵviewQuery
} from "./chunk-SPBZRJHT.js";
import "./chunk-IXJD77KS.js";
import "./chunk-QCYGWUBY.js";
import {
  Subject
} from "./chunk-37TWHRPH.js";
import "./chunk-4BJ7XQX3.js";
import {
  __publicField
} from "./chunk-GKWPUQBP.js";

// node_modules/primeng/fesm2022/primeng-icons-chevronleft.mjs
var _ChevronLeftIcon = class extends BaseIcon {
};
var ChevronLeftIcon = _ChevronLeftIcon;
__publicField(ChevronLeftIcon, "ɵfac", function() {
  let ɵChevronLeftIcon_BaseFactory;
  return function ChevronLeftIcon_Factory(t) {
    return (ɵChevronLeftIcon_BaseFactory || (ɵChevronLeftIcon_BaseFactory = ɵɵgetInheritedFactory(_ChevronLeftIcon)))(t || _ChevronLeftIcon);
  };
}());
__publicField(ChevronLeftIcon, "ɵcmp", ɵɵdefineComponent({
  type: _ChevronLeftIcon,
  selectors: [["ChevronLeftIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 2,
  vars: 5,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M9.61296 13C9.50997 13.0005 9.40792 12.9804 9.3128 12.9409C9.21767 12.9014 9.13139 12.8433 9.05902 12.7701L3.83313 7.54416C3.68634 7.39718 3.60388 7.19795 3.60388 6.99022C3.60388 6.78249 3.68634 6.58325 3.83313 6.43628L9.05902 1.21039C9.20762 1.07192 9.40416 0.996539 9.60724 1.00012C9.81032 1.00371 10.0041 1.08597 10.1477 1.22959C10.2913 1.37322 10.3736 1.56698 10.3772 1.77005C10.3808 1.97313 10.3054 2.16968 10.1669 2.31827L5.49496 6.99022L10.1669 11.6622C10.3137 11.8091 10.3962 12.0084 10.3962 12.2161C10.3962 12.4238 10.3137 12.6231 10.1669 12.7701C10.0945 12.8433 10.0083 12.9014 9.91313 12.9409C9.81801 12.9804 9.71596 13.0005 9.61296 13Z", "fill", "currentColor"]],
  template: function ChevronLeftIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0);
      ɵɵelement(1, "path", 1);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ChevronLeftIcon, [{
    type: Component,
    args: [{
      selector: "ChevronLeftIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <path
                d="M9.61296 13C9.50997 13.0005 9.40792 12.9804 9.3128 12.9409C9.21767 12.9014 9.13139 12.8433 9.05902 12.7701L3.83313 7.54416C3.68634 7.39718 3.60388 7.19795 3.60388 6.99022C3.60388 6.78249 3.68634 6.58325 3.83313 6.43628L9.05902 1.21039C9.20762 1.07192 9.40416 0.996539 9.60724 1.00012C9.81032 1.00371 10.0041 1.08597 10.1477 1.22959C10.2913 1.37322 10.3736 1.56698 10.3772 1.77005C10.3808 1.97313 10.3054 2.16968 10.1669 2.31827L5.49496 6.99022L10.1669 11.6622C10.3137 11.8091 10.3962 12.0084 10.3962 12.2161C10.3962 12.4238 10.3137 12.6231 10.1669 12.7701C10.0945 12.8433 10.0083 12.9014 9.91313 12.9409C9.81801 12.9804 9.71596 13.0005 9.61296 13Z"
                fill="currentColor"
            />
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-chevronup.mjs
var _ChevronUpIcon = class extends BaseIcon {
};
var ChevronUpIcon = _ChevronUpIcon;
__publicField(ChevronUpIcon, "ɵfac", function() {
  let ɵChevronUpIcon_BaseFactory;
  return function ChevronUpIcon_Factory(t) {
    return (ɵChevronUpIcon_BaseFactory || (ɵChevronUpIcon_BaseFactory = ɵɵgetInheritedFactory(_ChevronUpIcon)))(t || _ChevronUpIcon);
  };
}());
__publicField(ChevronUpIcon, "ɵcmp", ɵɵdefineComponent({
  type: _ChevronUpIcon,
  selectors: [["ChevronUpIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 2,
  vars: 5,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M12.2097 10.4113C12.1057 10.4118 12.0027 10.3915 11.9067 10.3516C11.8107 10.3118 11.7237 10.2532 11.6506 10.1792L6.93602 5.46461L2.22139 10.1476C2.07272 10.244 1.89599 10.2877 1.71953 10.2717C1.54307 10.2556 1.3771 10.1808 1.24822 10.0593C1.11933 9.93766 1.035 9.77633 1.00874 9.6011C0.982477 9.42587 1.0158 9.2469 1.10338 9.09287L6.37701 3.81923C6.52533 3.6711 6.72639 3.58789 6.93602 3.58789C7.14565 3.58789 7.3467 3.6711 7.49502 3.81923L12.7687 9.09287C12.9168 9.24119 13 9.44225 13 9.65187C13 9.8615 12.9168 10.0626 12.7687 10.2109C12.616 10.3487 12.4151 10.4207 12.2097 10.4113Z", "fill", "currentColor"]],
  template: function ChevronUpIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0);
      ɵɵelement(1, "path", 1);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ChevronUpIcon, [{
    type: Component,
    args: [{
      selector: "ChevronUpIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <path
                d="M12.2097 10.4113C12.1057 10.4118 12.0027 10.3915 11.9067 10.3516C11.8107 10.3118 11.7237 10.2532 11.6506 10.1792L6.93602 5.46461L2.22139 10.1476C2.07272 10.244 1.89599 10.2877 1.71953 10.2717C1.54307 10.2556 1.3771 10.1808 1.24822 10.0593C1.11933 9.93766 1.035 9.77633 1.00874 9.6011C0.982477 9.42587 1.0158 9.2469 1.10338 9.09287L6.37701 3.81923C6.52533 3.6711 6.72639 3.58789 6.93602 3.58789C7.14565 3.58789 7.3467 3.6711 7.49502 3.81923L12.7687 9.09287C12.9168 9.24119 13 9.44225 13 9.65187C13 9.8615 12.9168 10.0626 12.7687 10.2109C12.616 10.3487 12.4151 10.4207 12.2097 10.4113Z"
                fill="currentColor"
            />
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-calendar.mjs
var _CalendarIcon = class extends BaseIcon {
};
var CalendarIcon = _CalendarIcon;
__publicField(CalendarIcon, "ɵfac", function() {
  let ɵCalendarIcon_BaseFactory;
  return function CalendarIcon_Factory(t) {
    return (ɵCalendarIcon_BaseFactory || (ɵCalendarIcon_BaseFactory = ɵɵgetInheritedFactory(_CalendarIcon)))(t || _CalendarIcon);
  };
}());
__publicField(CalendarIcon, "ɵcmp", ɵɵdefineComponent({
  type: _CalendarIcon,
  selectors: [["CalendarIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 2,
  vars: 5,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M10.7838 1.51351H9.83783V0.567568C9.83783 0.417039 9.77804 0.272676 9.6716 0.166237C9.56516 0.0597971 9.42079 0 9.27027 0C9.11974 0 8.97538 0.0597971 8.86894 0.166237C8.7625 0.272676 8.7027 0.417039 8.7027 0.567568V1.51351H5.29729V0.567568C5.29729 0.417039 5.2375 0.272676 5.13106 0.166237C5.02462 0.0597971 4.88025 0 4.72973 0C4.5792 0 4.43484 0.0597971 4.3284 0.166237C4.22196 0.272676 4.16216 0.417039 4.16216 0.567568V1.51351H3.21621C2.66428 1.51351 2.13494 1.73277 1.74467 2.12305C1.35439 2.51333 1.13513 3.04266 1.13513 3.59459V11.9189C1.13513 12.4709 1.35439 13.0002 1.74467 13.3905C2.13494 13.7807 2.66428 14 3.21621 14H10.7838C11.3357 14 11.865 13.7807 12.2553 13.3905C12.6456 13.0002 12.8649 12.4709 12.8649 11.9189V3.59459C12.8649 3.04266 12.6456 2.51333 12.2553 2.12305C11.865 1.73277 11.3357 1.51351 10.7838 1.51351ZM3.21621 2.64865H4.16216V3.59459C4.16216 3.74512 4.22196 3.88949 4.3284 3.99593C4.43484 4.10237 4.5792 4.16216 4.72973 4.16216C4.88025 4.16216 5.02462 4.10237 5.13106 3.99593C5.2375 3.88949 5.29729 3.74512 5.29729 3.59459V2.64865H8.7027V3.59459C8.7027 3.74512 8.7625 3.88949 8.86894 3.99593C8.97538 4.10237 9.11974 4.16216 9.27027 4.16216C9.42079 4.16216 9.56516 4.10237 9.6716 3.99593C9.77804 3.88949 9.83783 3.74512 9.83783 3.59459V2.64865H10.7838C11.0347 2.64865 11.2753 2.74831 11.4527 2.92571C11.6301 3.10311 11.7297 3.34371 11.7297 3.59459V5.67568H2.27027V3.59459C2.27027 3.34371 2.36993 3.10311 2.54733 2.92571C2.72473 2.74831 2.96533 2.64865 3.21621 2.64865ZM10.7838 12.8649H3.21621C2.96533 12.8649 2.72473 12.7652 2.54733 12.5878C2.36993 12.4104 2.27027 12.1698 2.27027 11.9189V6.81081H11.7297V11.9189C11.7297 12.1698 11.6301 12.4104 11.4527 12.5878C11.2753 12.7652 11.0347 12.8649 10.7838 12.8649Z", "fill", "currentColor"]],
  template: function CalendarIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0);
      ɵɵelement(1, "path", 1);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CalendarIcon, [{
    type: Component,
    args: [{
      selector: "CalendarIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <path
                d="M10.7838 1.51351H9.83783V0.567568C9.83783 0.417039 9.77804 0.272676 9.6716 0.166237C9.56516 0.0597971 9.42079 0 9.27027 0C9.11974 0 8.97538 0.0597971 8.86894 0.166237C8.7625 0.272676 8.7027 0.417039 8.7027 0.567568V1.51351H5.29729V0.567568C5.29729 0.417039 5.2375 0.272676 5.13106 0.166237C5.02462 0.0597971 4.88025 0 4.72973 0C4.5792 0 4.43484 0.0597971 4.3284 0.166237C4.22196 0.272676 4.16216 0.417039 4.16216 0.567568V1.51351H3.21621C2.66428 1.51351 2.13494 1.73277 1.74467 2.12305C1.35439 2.51333 1.13513 3.04266 1.13513 3.59459V11.9189C1.13513 12.4709 1.35439 13.0002 1.74467 13.3905C2.13494 13.7807 2.66428 14 3.21621 14H10.7838C11.3357 14 11.865 13.7807 12.2553 13.3905C12.6456 13.0002 12.8649 12.4709 12.8649 11.9189V3.59459C12.8649 3.04266 12.6456 2.51333 12.2553 2.12305C11.865 1.73277 11.3357 1.51351 10.7838 1.51351ZM3.21621 2.64865H4.16216V3.59459C4.16216 3.74512 4.22196 3.88949 4.3284 3.99593C4.43484 4.10237 4.5792 4.16216 4.72973 4.16216C4.88025 4.16216 5.02462 4.10237 5.13106 3.99593C5.2375 3.88949 5.29729 3.74512 5.29729 3.59459V2.64865H8.7027V3.59459C8.7027 3.74512 8.7625 3.88949 8.86894 3.99593C8.97538 4.10237 9.11974 4.16216 9.27027 4.16216C9.42079 4.16216 9.56516 4.10237 9.6716 3.99593C9.77804 3.88949 9.83783 3.74512 9.83783 3.59459V2.64865H10.7838C11.0347 2.64865 11.2753 2.74831 11.4527 2.92571C11.6301 3.10311 11.7297 3.34371 11.7297 3.59459V5.67568H2.27027V3.59459C2.27027 3.34371 2.36993 3.10311 2.54733 2.92571C2.72473 2.74831 2.96533 2.64865 3.21621 2.64865ZM10.7838 12.8649H3.21621C2.96533 12.8649 2.72473 12.7652 2.54733 12.5878C2.36993 12.4104 2.27027 12.1698 2.27027 11.9189V6.81081H11.7297V11.9189C11.7297 12.1698 11.6301 12.4104 11.4527 12.5878C11.2753 12.7652 11.0347 12.8649 10.7838 12.8649Z"
                fill="currentColor"
            />
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-calendar.mjs
var _c0 = ["container"];
var _c1 = ["inputfield"];
var _c2 = ["contentWrapper"];
function Calendar_ng_template_2_ng_container_2_TimesIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "TimesIcon", 10);
    ɵɵlistener("click", function Calendar_ng_template_2_ng_container_2_TimesIcon_1_Template_TimesIcon_click_0_listener() {
      ɵɵrestoreView(_r9);
      const ctx_r8 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r8.clear());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-calendar-clear-icon");
  }
}
function Calendar_ng_template_2_ng_container_2_span_2_1_ng_template_0_Template(rf, ctx) {
}
function Calendar_ng_template_2_ng_container_2_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_ng_template_2_ng_container_2_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_ng_template_2_ng_container_2_span_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "span", 11);
    ɵɵlistener("click", function Calendar_ng_template_2_ng_container_2_span_2_Template_span_click_0_listener() {
      ɵɵrestoreView(_r13);
      const ctx_r12 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r12.clear());
    });
    ɵɵtemplate(1, Calendar_ng_template_2_ng_container_2_span_2_1_Template, 1, 0, null, 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r7 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r7.clearIconTemplate);
  }
}
function Calendar_ng_template_2_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Calendar_ng_template_2_ng_container_2_TimesIcon_1_Template, 1, 1, "TimesIcon", 8);
    ɵɵtemplate(2, Calendar_ng_template_2_ng_container_2_span_2_Template, 2, 1, "span", 9);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r4.clearIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r4.clearIconTemplate);
  }
}
function Calendar_ng_template_2_button_3_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 15);
  }
  if (rf & 2) {
    const ctx_r14 = ɵɵnextContext(3);
    ɵɵproperty("ngClass", ctx_r14.icon);
  }
}
function Calendar_ng_template_2_button_3_ng_container_2_CalendarIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "CalendarIcon");
  }
}
function Calendar_ng_template_2_button_3_ng_container_2_2_ng_template_0_Template(rf, ctx) {
}
function Calendar_ng_template_2_button_3_ng_container_2_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_ng_template_2_button_3_ng_container_2_2_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_ng_template_2_button_3_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Calendar_ng_template_2_button_3_ng_container_2_CalendarIcon_1_Template, 1, 0, "CalendarIcon", 6);
    ɵɵtemplate(2, Calendar_ng_template_2_button_3_ng_container_2_2_Template, 1, 0, null, 12);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r15 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r15.triggerIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r15.triggerIconTemplate);
  }
}
function Calendar_ng_template_2_button_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 13);
    ɵɵlistener("click", function Calendar_ng_template_2_button_3_Template_button_click_0_listener($event) {
      ɵɵrestoreView(_r20);
      ɵɵnextContext();
      const _r3 = ɵɵreference(1);
      const ctx_r19 = ɵɵnextContext();
      return ɵɵresetView(ctx_r19.onButtonClick($event, _r3));
    });
    ɵɵtemplate(1, Calendar_ng_template_2_button_3_span_1_Template, 1, 1, "span", 14);
    ɵɵtemplate(2, Calendar_ng_template_2_button_3_ng_container_2_Template, 3, 2, "ng-container", 6);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r5 = ɵɵnextContext(2);
    ɵɵproperty("disabled", ctx_r5.disabled);
    ɵɵattribute("aria-label", ctx_r5.iconAriaLabel);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.icon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r5.icon);
  }
}
function Calendar_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r22 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "input", 4, 5);
    ɵɵlistener("focus", function Calendar_ng_template_2_Template_input_focus_0_listener($event) {
      ɵɵrestoreView(_r22);
      const ctx_r21 = ɵɵnextContext();
      return ɵɵresetView(ctx_r21.onInputFocus($event));
    })("keydown", function Calendar_ng_template_2_Template_input_keydown_0_listener($event) {
      ɵɵrestoreView(_r22);
      const ctx_r23 = ɵɵnextContext();
      return ɵɵresetView(ctx_r23.onInputKeydown($event));
    })("click", function Calendar_ng_template_2_Template_input_click_0_listener() {
      ɵɵrestoreView(_r22);
      const ctx_r24 = ɵɵnextContext();
      return ɵɵresetView(ctx_r24.onInputClick());
    })("blur", function Calendar_ng_template_2_Template_input_blur_0_listener($event) {
      ɵɵrestoreView(_r22);
      const ctx_r25 = ɵɵnextContext();
      return ɵɵresetView(ctx_r25.onInputBlur($event));
    })("input", function Calendar_ng_template_2_Template_input_input_0_listener($event) {
      ɵɵrestoreView(_r22);
      const ctx_r26 = ɵɵnextContext();
      return ɵɵresetView(ctx_r26.onUserInput($event));
    });
    ɵɵelementEnd();
    ɵɵtemplate(2, Calendar_ng_template_2_ng_container_2_Template, 3, 2, "ng-container", 6);
    ɵɵtemplate(3, Calendar_ng_template_2_button_3_Template, 3, 4, "button", 7);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵclassMap(ctx_r1.inputStyleClass);
    ɵɵproperty("value", ctx_r1.inputFieldValue)("readonly", ctx_r1.readonlyInput)("ngStyle", ctx_r1.inputStyle)("placeholder", ctx_r1.placeholder || "")("disabled", ctx_r1.disabled)("ngClass", "p-inputtext p-component");
    ɵɵattribute("id", ctx_r1.inputId)("name", ctx_r1.name)("required", ctx_r1.required)("aria-required", ctx_r1.required)("tabindex", ctx_r1.tabindex)("inputmode", ctx_r1.touchUI ? "off" : null)("aria-labelledby", ctx_r1.ariaLabelledBy);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r1.showClear && !ctx_r1.disabled && ctx_r1.value != null);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r1.showIcon);
  }
}
function Calendar_div_3_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Calendar_div_3_ng_container_4_div_2_button_2_ChevronLeftIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronLeftIcon", 37);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-datepicker-prev-icon");
  }
}
function Calendar_div_3_ng_container_4_div_2_button_2_span_2_1_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_ng_container_4_div_2_button_2_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_ng_container_4_div_2_button_2_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_ng_container_4_div_2_button_2_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 38);
    ɵɵtemplate(1, Calendar_div_3_ng_container_4_div_2_button_2_span_2_1_Template, 1, 0, null, 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r46 = ɵɵnextContext(5);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r46.previousIconTemplate);
  }
}
function Calendar_div_3_ng_container_4_div_2_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r50 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 35);
    ɵɵlistener("keydown", function Calendar_div_3_ng_container_4_div_2_button_2_Template_button_keydown_0_listener($event) {
      ɵɵrestoreView(_r50);
      const ctx_r49 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r49.onContainerButtonKeydown($event));
    })("click", function Calendar_div_3_ng_container_4_div_2_button_2_Template_button_click_0_listener($event) {
      ɵɵrestoreView(_r50);
      const ctx_r51 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r51.onPrevButtonClick($event));
    });
    ɵɵtemplate(1, Calendar_div_3_ng_container_4_div_2_button_2_ChevronLeftIcon_1_Template, 1, 1, "ChevronLeftIcon", 32);
    ɵɵtemplate(2, Calendar_div_3_ng_container_4_div_2_button_2_span_2_Template, 2, 1, "span", 36);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r38 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r38.previousIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r38.previousIconTemplate);
  }
}
function Calendar_div_3_ng_container_4_div_2_button_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r53 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 39);
    ɵɵlistener("click", function Calendar_div_3_ng_container_4_div_2_button_4_Template_button_click_0_listener($event) {
      ɵɵrestoreView(_r53);
      const ctx_r52 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r52.switchToMonthView($event));
    })("keydown", function Calendar_div_3_ng_container_4_div_2_button_4_Template_button_keydown_0_listener($event) {
      ɵɵrestoreView(_r53);
      const ctx_r54 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r54.onContainerButtonKeydown($event));
    });
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const month_r36 = ɵɵnextContext().$implicit;
    const ctx_r39 = ɵɵnextContext(3);
    ɵɵproperty("disabled", ctx_r39.switchViewButtonDisabled());
    ɵɵadvance(1);
    ɵɵtextInterpolate1(" ", ctx_r39.getMonthName(month_r36.month), " ");
  }
}
function Calendar_div_3_ng_container_4_div_2_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r57 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 40);
    ɵɵlistener("click", function Calendar_div_3_ng_container_4_div_2_button_5_Template_button_click_0_listener($event) {
      ɵɵrestoreView(_r57);
      const ctx_r56 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r56.switchToYearView($event));
    })("keydown", function Calendar_div_3_ng_container_4_div_2_button_5_Template_button_keydown_0_listener($event) {
      ɵɵrestoreView(_r57);
      const ctx_r58 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r58.onContainerButtonKeydown($event));
    });
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const month_r36 = ɵɵnextContext().$implicit;
    const ctx_r40 = ɵɵnextContext(3);
    ɵɵproperty("disabled", ctx_r40.switchViewButtonDisabled());
    ɵɵadvance(1);
    ɵɵtextInterpolate1(" ", ctx_r40.getYear(month_r36), " ");
  }
}
function Calendar_div_3_ng_container_4_div_2_span_6_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r60 = ɵɵnextContext(5);
    ɵɵadvance(1);
    ɵɵtextInterpolate2("", ctx_r60.yearPickerValues()[0], " - ", ctx_r60.yearPickerValues()[ctx_r60.yearPickerValues().length - 1], "");
  }
}
function Calendar_div_3_ng_container_4_div_2_span_6_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c3 = function(a0) {
  return {
    $implicit: a0
  };
};
function Calendar_div_3_ng_container_4_div_2_span_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 41);
    ɵɵtemplate(1, Calendar_div_3_ng_container_4_div_2_span_6_ng_container_1_Template, 2, 2, "ng-container", 6);
    ɵɵtemplate(2, Calendar_div_3_ng_container_4_div_2_span_6_ng_container_2_Template, 1, 0, "ng-container", 42);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r41 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r41.decadeTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r41.decadeTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(3, _c3, ctx_r41.yearPickerValues));
  }
}
function Calendar_div_3_ng_container_4_div_2_ChevronRightIcon_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronRightIcon", 37);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-datepicker-next-icon");
  }
}
function Calendar_div_3_ng_container_4_div_2_span_9_1_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_ng_container_4_div_2_span_9_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_ng_container_4_div_2_span_9_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_ng_container_4_div_2_span_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 43);
    ɵɵtemplate(1, Calendar_div_3_ng_container_4_div_2_span_9_1_Template, 1, 0, null, 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r43 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r43.nextIconTemplate);
  }
}
function Calendar_div_3_ng_container_4_div_2_div_10_th_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "th", 49)(1, "span");
    ɵɵtext(2);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r64 = ɵɵnextContext(5);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ctx_r64.getTranslation("weekHeader"));
  }
}
function Calendar_div_3_ng_container_4_div_2_div_10_th_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "th", 50)(1, "span");
    ɵɵtext(2);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const weekDay_r67 = ctx.$implicit;
    ɵɵadvance(2);
    ɵɵtextInterpolate(weekDay_r67);
  }
}
function Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "td", 53)(1, "span", 54);
    ɵɵtext(2);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const j_r71 = ɵɵnextContext().index;
    const month_r36 = ɵɵnextContext(2).$implicit;
    ɵɵadvance(2);
    ɵɵtextInterpolate1(" ", month_r36.weekNumbers[j_r71], " ");
  }
}
function Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_ng_container_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const date_r76 = ɵɵnextContext(2).$implicit;
    ɵɵadvance(1);
    ɵɵtextInterpolate(date_r76.day);
  }
}
function Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_ng_container_1_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c4 = function(a0, a1) {
  return {
    "p-highlight": a0,
    "p-disabled": a1
  };
};
function Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r83 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "span", 55);
    ɵɵlistener("click", function Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_ng_container_1_Template_span_click_1_listener($event) {
      ɵɵrestoreView(_r83);
      const date_r76 = ɵɵnextContext().$implicit;
      const ctx_r81 = ɵɵnextContext(6);
      return ɵɵresetView(ctx_r81.onDateSelect($event, date_r76));
    })("keydown", function Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_ng_container_1_Template_span_keydown_1_listener($event) {
      ɵɵrestoreView(_r83);
      const date_r76 = ɵɵnextContext().$implicit;
      const i_r37 = ɵɵnextContext(3).index;
      const ctx_r84 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r84.onDateCellKeydown($event, date_r76, i_r37));
    });
    ɵɵtemplate(2, Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_ng_container_1_ng_container_2_Template, 2, 1, "ng-container", 6);
    ɵɵtemplate(3, Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_ng_container_1_ng_container_3_Template, 1, 0, "ng-container", 42);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const date_r76 = ɵɵnextContext().$implicit;
    const ctx_r77 = ɵɵnextContext(6);
    ɵɵadvance(1);
    ɵɵproperty("ngClass", ɵɵpureFunction2(4, _c4, ctx_r77.isSelected(date_r76), !date_r76.selectable));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r77.dateTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r77.dateTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(7, _c3, date_r76));
  }
}
var _c5 = function(a0, a1) {
  return {
    "p-datepicker-other-month": a0,
    "p-datepicker-today": a1
  };
};
function Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "td", 15);
    ɵɵtemplate(1, Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_ng_container_1_Template, 4, 9, "ng-container", 6);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const date_r76 = ctx.$implicit;
    const ctx_r73 = ɵɵnextContext(6);
    ɵɵproperty("ngClass", ɵɵpureFunction2(2, _c5, date_r76.otherMonth, date_r76.today));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", date_r76.otherMonth ? ctx_r73.showOtherMonths : true);
  }
}
function Calendar_div_3_ng_container_4_div_2_div_10_tr_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "tr");
    ɵɵtemplate(1, Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_1_Template, 3, 1, "td", 51);
    ɵɵtemplate(2, Calendar_div_3_ng_container_4_div_2_div_10_tr_7_td_2_Template, 2, 5, "td", 52);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const week_r70 = ctx.$implicit;
    const ctx_r66 = ɵɵnextContext(5);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r66.showWeek);
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", week_r70);
  }
}
function Calendar_div_3_ng_container_4_div_2_div_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 44)(1, "table", 45)(2, "thead")(3, "tr");
    ɵɵtemplate(4, Calendar_div_3_ng_container_4_div_2_div_10_th_4_Template, 3, 1, "th", 46);
    ɵɵtemplate(5, Calendar_div_3_ng_container_4_div_2_div_10_th_5_Template, 3, 1, "th", 47);
    ɵɵelementEnd()();
    ɵɵelementStart(6, "tbody");
    ɵɵtemplate(7, Calendar_div_3_ng_container_4_div_2_div_10_tr_7_Template, 3, 2, "tr", 48);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const month_r36 = ɵɵnextContext().$implicit;
    const ctx_r44 = ɵɵnextContext(3);
    ɵɵadvance(4);
    ɵɵproperty("ngIf", ctx_r44.showWeek);
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r44.weekDays);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", month_r36.dates);
  }
}
function Calendar_div_3_ng_container_4_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r90 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 24)(1, "div", 25);
    ɵɵtemplate(2, Calendar_div_3_ng_container_4_div_2_button_2_Template, 3, 2, "button", 26);
    ɵɵelementStart(3, "div", 27);
    ɵɵtemplate(4, Calendar_div_3_ng_container_4_div_2_button_4_Template, 2, 2, "button", 28);
    ɵɵtemplate(5, Calendar_div_3_ng_container_4_div_2_button_5_Template, 2, 2, "button", 29);
    ɵɵtemplate(6, Calendar_div_3_ng_container_4_div_2_span_6_Template, 3, 5, "span", 30);
    ɵɵelementEnd();
    ɵɵelementStart(7, "button", 31);
    ɵɵlistener("keydown", function Calendar_div_3_ng_container_4_div_2_Template_button_keydown_7_listener($event) {
      ɵɵrestoreView(_r90);
      const ctx_r89 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r89.onContainerButtonKeydown($event));
    })("click", function Calendar_div_3_ng_container_4_div_2_Template_button_click_7_listener($event) {
      ɵɵrestoreView(_r90);
      const ctx_r91 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r91.onNextButtonClick($event));
    });
    ɵɵtemplate(8, Calendar_div_3_ng_container_4_div_2_ChevronRightIcon_8_Template, 1, 1, "ChevronRightIcon", 32);
    ɵɵtemplate(9, Calendar_div_3_ng_container_4_div_2_span_9_Template, 2, 1, "span", 33);
    ɵɵelementEnd()();
    ɵɵtemplate(10, Calendar_div_3_ng_container_4_div_2_div_10_Template, 8, 3, "div", 34);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const i_r37 = ctx.index;
    const ctx_r33 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", i_r37 === 0);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r33.currentView === "date");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r33.currentView !== "year");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r33.currentView === "year");
    ɵɵadvance(1);
    ɵɵstyleProp("display", ctx_r33.numberOfMonths === 1 ? "inline-flex" : i_r37 === ctx_r33.numberOfMonths - 1 ? "inline-flex" : "none");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r33.nextIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r33.nextIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r33.currentView === "date");
  }
}
function Calendar_div_3_ng_container_4_div_3_span_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r96 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "span", 58);
    ɵɵlistener("click", function Calendar_div_3_ng_container_4_div_3_span_1_Template_span_click_0_listener($event) {
      const restoredCtx = ɵɵrestoreView(_r96);
      const i_r94 = restoredCtx.index;
      const ctx_r95 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r95.onMonthSelect($event, i_r94));
    })("keydown", function Calendar_div_3_ng_container_4_div_3_span_1_Template_span_keydown_0_listener($event) {
      const restoredCtx = ɵɵrestoreView(_r96);
      const i_r94 = restoredCtx.index;
      const ctx_r97 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r97.onMonthCellKeydown($event, i_r94));
    });
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const m_r93 = ctx.$implicit;
    const i_r94 = ctx.index;
    const ctx_r92 = ɵɵnextContext(4);
    ɵɵproperty("ngClass", ɵɵpureFunction2(2, _c4, ctx_r92.isMonthSelected(i_r94), ctx_r92.isMonthDisabled(i_r94)));
    ɵɵadvance(1);
    ɵɵtextInterpolate1(" ", m_r93, " ");
  }
}
function Calendar_div_3_ng_container_4_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 56);
    ɵɵtemplate(1, Calendar_div_3_ng_container_4_div_3_span_1_Template, 2, 5, "span", 57);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r34 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r34.monthPickerValues());
  }
}
var _c6 = function(a0) {
  return {
    "p-highlight": a0
  };
};
function Calendar_div_3_ng_container_4_div_4_span_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r101 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "span", 61);
    ɵɵlistener("click", function Calendar_div_3_ng_container_4_div_4_span_1_Template_span_click_0_listener($event) {
      const restoredCtx = ɵɵrestoreView(_r101);
      const y_r99 = restoredCtx.$implicit;
      const ctx_r100 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r100.onYearSelect($event, y_r99));
    })("keydown", function Calendar_div_3_ng_container_4_div_4_span_1_Template_span_keydown_0_listener($event) {
      const restoredCtx = ɵɵrestoreView(_r101);
      const y_r99 = restoredCtx.$implicit;
      const ctx_r102 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r102.onYearCellKeydown($event, y_r99));
    });
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const y_r99 = ctx.$implicit;
    const ctx_r98 = ɵɵnextContext(4);
    ɵɵproperty("ngClass", ɵɵpureFunction1(2, _c6, ctx_r98.isYearSelected(y_r99)));
    ɵɵadvance(1);
    ɵɵtextInterpolate1(" ", y_r99, " ");
  }
}
function Calendar_div_3_ng_container_4_div_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 59);
    ɵɵtemplate(1, Calendar_div_3_ng_container_4_div_4_span_1_Template, 2, 4, "span", 60);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r35 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r35.yearPickerValues());
  }
}
function Calendar_div_3_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 20);
    ɵɵtemplate(2, Calendar_div_3_ng_container_4_div_2_Template, 11, 9, "div", 21);
    ɵɵelementEnd();
    ɵɵtemplate(3, Calendar_div_3_ng_container_4_div_3_Template, 2, 1, "div", 22);
    ɵɵtemplate(4, Calendar_div_3_ng_container_4_div_4_Template, 2, 1, "div", 23);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r29 = ɵɵnextContext(2);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", ctx_r29.months);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r29.currentView === "month");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r29.currentView === "year");
  }
}
function Calendar_div_3_div_5_ChevronUpIcon_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronUpIcon");
  }
}
function Calendar_div_3_div_5_4_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_div_5_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_div_5_4_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_div_5_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1, "0");
    ɵɵelementContainerEnd();
  }
}
function Calendar_div_3_div_5_ChevronDownIcon_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronDownIcon");
  }
}
function Calendar_div_3_div_5_10_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_div_5_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_div_5_10_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_div_5_ChevronUpIcon_16_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronUpIcon");
  }
}
function Calendar_div_3_div_5_17_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_div_5_17_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_div_5_17_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_div_5_ng_container_19_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1, "0");
    ɵɵelementContainerEnd();
  }
}
function Calendar_div_3_div_5_ChevronDownIcon_22_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronDownIcon");
  }
}
function Calendar_div_3_div_5_23_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_div_5_23_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_div_5_23_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_div_5_div_24_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 65)(1, "span");
    ɵɵtext(2);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r113 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ctx_r113.timeSeparator);
  }
}
function Calendar_div_3_div_5_div_25_ChevronUpIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronUpIcon");
  }
}
function Calendar_div_3_div_5_div_25_3_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_div_5_div_25_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_div_5_div_25_3_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_div_5_div_25_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1, "0");
    ɵɵelementContainerEnd();
  }
}
function Calendar_div_3_div_5_div_25_ChevronDownIcon_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronDownIcon");
  }
}
function Calendar_div_3_div_5_div_25_9_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_div_5_div_25_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_div_5_div_25_9_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_div_5_div_25_Template(rf, ctx) {
  if (rf & 1) {
    const _r128 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 70)(1, "button", 64);
    ɵɵlistener("keydown", function Calendar_div_3_div_5_div_25_Template_button_keydown_1_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r127 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r127.onContainerButtonKeydown($event));
    })("keydown.enter", function Calendar_div_3_div_5_div_25_Template_button_keydown_enter_1_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r129 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r129.incrementSecond($event));
    })("keydown.space", function Calendar_div_3_div_5_div_25_Template_button_keydown_space_1_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r130 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r130.incrementSecond($event));
    })("mousedown", function Calendar_div_3_div_5_div_25_Template_button_mousedown_1_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r131 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r131.onTimePickerElementMouseDown($event, 2, 1));
    })("mouseup", function Calendar_div_3_div_5_div_25_Template_button_mouseup_1_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r132 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r132.onTimePickerElementMouseUp($event));
    })("keyup.enter", function Calendar_div_3_div_5_div_25_Template_button_keyup_enter_1_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r133 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r133.onTimePickerElementMouseUp($event));
    })("keyup.space", function Calendar_div_3_div_5_div_25_Template_button_keyup_space_1_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r134 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r134.onTimePickerElementMouseUp($event));
    })("mouseleave", function Calendar_div_3_div_5_div_25_Template_button_mouseleave_1_listener() {
      ɵɵrestoreView(_r128);
      const ctx_r135 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r135.onTimePickerElementMouseLeave());
    });
    ɵɵtemplate(2, Calendar_div_3_div_5_div_25_ChevronUpIcon_2_Template, 1, 0, "ChevronUpIcon", 6);
    ɵɵtemplate(3, Calendar_div_3_div_5_div_25_3_Template, 1, 0, null, 12);
    ɵɵelementEnd();
    ɵɵelementStart(4, "span");
    ɵɵtemplate(5, Calendar_div_3_div_5_div_25_ng_container_5_Template, 2, 0, "ng-container", 6);
    ɵɵtext(6);
    ɵɵelementEnd();
    ɵɵelementStart(7, "button", 64);
    ɵɵlistener("keydown", function Calendar_div_3_div_5_div_25_Template_button_keydown_7_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r136 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r136.onContainerButtonKeydown($event));
    })("keydown.enter", function Calendar_div_3_div_5_div_25_Template_button_keydown_enter_7_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r137 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r137.decrementSecond($event));
    })("keydown.space", function Calendar_div_3_div_5_div_25_Template_button_keydown_space_7_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r138 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r138.decrementSecond($event));
    })("mousedown", function Calendar_div_3_div_5_div_25_Template_button_mousedown_7_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r139 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r139.onTimePickerElementMouseDown($event, 2, -1));
    })("mouseup", function Calendar_div_3_div_5_div_25_Template_button_mouseup_7_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r140 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r140.onTimePickerElementMouseUp($event));
    })("keyup.enter", function Calendar_div_3_div_5_div_25_Template_button_keyup_enter_7_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r141 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r141.onTimePickerElementMouseUp($event));
    })("keyup.space", function Calendar_div_3_div_5_div_25_Template_button_keyup_space_7_listener($event) {
      ɵɵrestoreView(_r128);
      const ctx_r142 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r142.onTimePickerElementMouseUp($event));
    })("mouseleave", function Calendar_div_3_div_5_div_25_Template_button_mouseleave_7_listener() {
      ɵɵrestoreView(_r128);
      const ctx_r143 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r143.onTimePickerElementMouseLeave());
    });
    ɵɵtemplate(8, Calendar_div_3_div_5_div_25_ChevronDownIcon_8_Template, 1, 0, "ChevronDownIcon", 6);
    ɵɵtemplate(9, Calendar_div_3_div_5_div_25_9_Template, 1, 0, null, 12);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r114 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r114.incrementIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r114.incrementIconTemplate);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r114.currentSecond < 10);
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r114.currentSecond);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r114.decrementIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r114.decrementIconTemplate);
  }
}
function Calendar_div_3_div_5_div_26_ChevronUpIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronUpIcon");
  }
}
function Calendar_div_3_div_5_div_26_3_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_div_5_div_26_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_div_5_div_26_3_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_div_5_div_26_ChevronDownIcon_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronDownIcon");
  }
}
function Calendar_div_3_div_5_div_26_8_ng_template_0_Template(rf, ctx) {
}
function Calendar_div_3_div_5_div_26_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Calendar_div_3_div_5_div_26_8_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Calendar_div_3_div_5_div_26_Template(rf, ctx) {
  if (rf & 1) {
    const _r151 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 71)(1, "button", 72);
    ɵɵlistener("keydown", function Calendar_div_3_div_5_div_26_Template_button_keydown_1_listener($event) {
      ɵɵrestoreView(_r151);
      const ctx_r150 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r150.onContainerButtonKeydown($event));
    })("click", function Calendar_div_3_div_5_div_26_Template_button_click_1_listener($event) {
      ɵɵrestoreView(_r151);
      const ctx_r152 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r152.toggleAMPM($event));
    })("keydown.enter", function Calendar_div_3_div_5_div_26_Template_button_keydown_enter_1_listener($event) {
      ɵɵrestoreView(_r151);
      const ctx_r153 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r153.toggleAMPM($event));
    });
    ɵɵtemplate(2, Calendar_div_3_div_5_div_26_ChevronUpIcon_2_Template, 1, 0, "ChevronUpIcon", 6);
    ɵɵtemplate(3, Calendar_div_3_div_5_div_26_3_Template, 1, 0, null, 12);
    ɵɵelementEnd();
    ɵɵelementStart(4, "span");
    ɵɵtext(5);
    ɵɵelementEnd();
    ɵɵelementStart(6, "button", 72);
    ɵɵlistener("keydown", function Calendar_div_3_div_5_div_26_Template_button_keydown_6_listener($event) {
      ɵɵrestoreView(_r151);
      const ctx_r154 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r154.onContainerButtonKeydown($event));
    })("click", function Calendar_div_3_div_5_div_26_Template_button_click_6_listener($event) {
      ɵɵrestoreView(_r151);
      const ctx_r155 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r155.toggleAMPM($event));
    })("keydown.enter", function Calendar_div_3_div_5_div_26_Template_button_keydown_enter_6_listener($event) {
      ɵɵrestoreView(_r151);
      const ctx_r156 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r156.toggleAMPM($event));
    });
    ɵɵtemplate(7, Calendar_div_3_div_5_div_26_ChevronDownIcon_7_Template, 1, 0, "ChevronDownIcon", 6);
    ɵɵtemplate(8, Calendar_div_3_div_5_div_26_8_Template, 1, 0, null, 12);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r115 = ɵɵnextContext(3);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r115.incrementIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r115.incrementIconTemplate);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ctx_r115.pm ? "PM" : "AM");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r115.decrementIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r115.decrementIconTemplate);
  }
}
function Calendar_div_3_div_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r158 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 62)(1, "div", 63)(2, "button", 64);
    ɵɵlistener("keydown", function Calendar_div_3_div_5_Template_button_keydown_2_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r157 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r157.onContainerButtonKeydown($event));
    })("keydown.enter", function Calendar_div_3_div_5_Template_button_keydown_enter_2_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r159 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r159.incrementHour($event));
    })("keydown.space", function Calendar_div_3_div_5_Template_button_keydown_space_2_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r160 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r160.incrementHour($event));
    })("mousedown", function Calendar_div_3_div_5_Template_button_mousedown_2_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r161 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r161.onTimePickerElementMouseDown($event, 0, 1));
    })("mouseup", function Calendar_div_3_div_5_Template_button_mouseup_2_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r162 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r162.onTimePickerElementMouseUp($event));
    })("keyup.enter", function Calendar_div_3_div_5_Template_button_keyup_enter_2_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r163 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r163.onTimePickerElementMouseUp($event));
    })("keyup.space", function Calendar_div_3_div_5_Template_button_keyup_space_2_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r164 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r164.onTimePickerElementMouseUp($event));
    })("mouseleave", function Calendar_div_3_div_5_Template_button_mouseleave_2_listener() {
      ɵɵrestoreView(_r158);
      const ctx_r165 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r165.onTimePickerElementMouseLeave());
    });
    ɵɵtemplate(3, Calendar_div_3_div_5_ChevronUpIcon_3_Template, 1, 0, "ChevronUpIcon", 6);
    ɵɵtemplate(4, Calendar_div_3_div_5_4_Template, 1, 0, null, 12);
    ɵɵelementEnd();
    ɵɵelementStart(5, "span");
    ɵɵtemplate(6, Calendar_div_3_div_5_ng_container_6_Template, 2, 0, "ng-container", 6);
    ɵɵtext(7);
    ɵɵelementEnd();
    ɵɵelementStart(8, "button", 64);
    ɵɵlistener("keydown", function Calendar_div_3_div_5_Template_button_keydown_8_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r166 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r166.onContainerButtonKeydown($event));
    })("keydown.enter", function Calendar_div_3_div_5_Template_button_keydown_enter_8_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r167 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r167.decrementHour($event));
    })("keydown.space", function Calendar_div_3_div_5_Template_button_keydown_space_8_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r168 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r168.decrementHour($event));
    })("mousedown", function Calendar_div_3_div_5_Template_button_mousedown_8_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r169 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r169.onTimePickerElementMouseDown($event, 0, -1));
    })("mouseup", function Calendar_div_3_div_5_Template_button_mouseup_8_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r170 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r170.onTimePickerElementMouseUp($event));
    })("keyup.enter", function Calendar_div_3_div_5_Template_button_keyup_enter_8_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r171 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r171.onTimePickerElementMouseUp($event));
    })("keyup.space", function Calendar_div_3_div_5_Template_button_keyup_space_8_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r172 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r172.onTimePickerElementMouseUp($event));
    })("mouseleave", function Calendar_div_3_div_5_Template_button_mouseleave_8_listener() {
      ɵɵrestoreView(_r158);
      const ctx_r173 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r173.onTimePickerElementMouseLeave());
    });
    ɵɵtemplate(9, Calendar_div_3_div_5_ChevronDownIcon_9_Template, 1, 0, "ChevronDownIcon", 6);
    ɵɵtemplate(10, Calendar_div_3_div_5_10_Template, 1, 0, null, 12);
    ɵɵelementEnd()();
    ɵɵelementStart(11, "div", 65)(12, "span");
    ɵɵtext(13);
    ɵɵelementEnd()();
    ɵɵelementStart(14, "div", 66)(15, "button", 64);
    ɵɵlistener("keydown", function Calendar_div_3_div_5_Template_button_keydown_15_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r174 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r174.onContainerButtonKeydown($event));
    })("keydown.enter", function Calendar_div_3_div_5_Template_button_keydown_enter_15_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r175 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r175.incrementMinute($event));
    })("keydown.space", function Calendar_div_3_div_5_Template_button_keydown_space_15_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r176 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r176.incrementMinute($event));
    })("mousedown", function Calendar_div_3_div_5_Template_button_mousedown_15_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r177 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r177.onTimePickerElementMouseDown($event, 1, 1));
    })("mouseup", function Calendar_div_3_div_5_Template_button_mouseup_15_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r178 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r178.onTimePickerElementMouseUp($event));
    })("keyup.enter", function Calendar_div_3_div_5_Template_button_keyup_enter_15_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r179 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r179.onTimePickerElementMouseUp($event));
    })("keyup.space", function Calendar_div_3_div_5_Template_button_keyup_space_15_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r180 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r180.onTimePickerElementMouseUp($event));
    })("mouseleave", function Calendar_div_3_div_5_Template_button_mouseleave_15_listener() {
      ɵɵrestoreView(_r158);
      const ctx_r181 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r181.onTimePickerElementMouseLeave());
    });
    ɵɵtemplate(16, Calendar_div_3_div_5_ChevronUpIcon_16_Template, 1, 0, "ChevronUpIcon", 6);
    ɵɵtemplate(17, Calendar_div_3_div_5_17_Template, 1, 0, null, 12);
    ɵɵelementEnd();
    ɵɵelementStart(18, "span");
    ɵɵtemplate(19, Calendar_div_3_div_5_ng_container_19_Template, 2, 0, "ng-container", 6);
    ɵɵtext(20);
    ɵɵelementEnd();
    ɵɵelementStart(21, "button", 64);
    ɵɵlistener("keydown", function Calendar_div_3_div_5_Template_button_keydown_21_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r182 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r182.onContainerButtonKeydown($event));
    })("keydown.enter", function Calendar_div_3_div_5_Template_button_keydown_enter_21_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r183 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r183.decrementMinute($event));
    })("keydown.space", function Calendar_div_3_div_5_Template_button_keydown_space_21_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r184 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r184.decrementMinute($event));
    })("mousedown", function Calendar_div_3_div_5_Template_button_mousedown_21_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r185 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r185.onTimePickerElementMouseDown($event, 1, -1));
    })("mouseup", function Calendar_div_3_div_5_Template_button_mouseup_21_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r186 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r186.onTimePickerElementMouseUp($event));
    })("keyup.enter", function Calendar_div_3_div_5_Template_button_keyup_enter_21_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r187 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r187.onTimePickerElementMouseUp($event));
    })("keyup.space", function Calendar_div_3_div_5_Template_button_keyup_space_21_listener($event) {
      ɵɵrestoreView(_r158);
      const ctx_r188 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r188.onTimePickerElementMouseUp($event));
    })("mouseleave", function Calendar_div_3_div_5_Template_button_mouseleave_21_listener() {
      ɵɵrestoreView(_r158);
      const ctx_r189 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r189.onTimePickerElementMouseLeave());
    });
    ɵɵtemplate(22, Calendar_div_3_div_5_ChevronDownIcon_22_Template, 1, 0, "ChevronDownIcon", 6);
    ɵɵtemplate(23, Calendar_div_3_div_5_23_Template, 1, 0, null, 12);
    ɵɵelementEnd()();
    ɵɵtemplate(24, Calendar_div_3_div_5_div_24_Template, 3, 1, "div", 67);
    ɵɵtemplate(25, Calendar_div_3_div_5_div_25_Template, 10, 6, "div", 68);
    ɵɵtemplate(26, Calendar_div_3_div_5_div_26_Template, 9, 5, "div", 69);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r30 = ɵɵnextContext(2);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", !ctx_r30.incrementIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r30.incrementIconTemplate);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r30.currentHour < 10);
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r30.currentHour);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r30.decrementIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r30.decrementIconTemplate);
    ɵɵadvance(3);
    ɵɵtextInterpolate(ctx_r30.timeSeparator);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", !ctx_r30.incrementIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r30.incrementIconTemplate);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r30.currentMinute < 10);
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r30.currentMinute);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r30.decrementIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r30.decrementIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r30.showSeconds);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r30.showSeconds);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r30.hourFormat == "12");
  }
}
var _c7 = function(a0) {
  return [a0];
};
function Calendar_div_3_div_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r191 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 73)(1, "button", 74);
    ɵɵlistener("keydown", function Calendar_div_3_div_6_Template_button_keydown_1_listener($event) {
      ɵɵrestoreView(_r191);
      const ctx_r190 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r190.onContainerButtonKeydown($event));
    })("click", function Calendar_div_3_div_6_Template_button_click_1_listener($event) {
      ɵɵrestoreView(_r191);
      const ctx_r192 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r192.onTodayButtonClick($event));
    });
    ɵɵelementEnd();
    ɵɵelementStart(2, "button", 74);
    ɵɵlistener("keydown", function Calendar_div_3_div_6_Template_button_keydown_2_listener($event) {
      ɵɵrestoreView(_r191);
      const ctx_r193 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r193.onContainerButtonKeydown($event));
    })("click", function Calendar_div_3_div_6_Template_button_click_2_listener($event) {
      ɵɵrestoreView(_r191);
      const ctx_r194 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r194.onClearButtonClick($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r31 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("label", ctx_r31.getTranslation("today"))("ngClass", ɵɵpureFunction1(4, _c7, ctx_r31.todayButtonStyleClass));
    ɵɵadvance(1);
    ɵɵproperty("label", ctx_r31.getTranslation("clear"))("ngClass", ɵɵpureFunction1(6, _c7, ctx_r31.clearButtonStyleClass));
  }
}
function Calendar_div_3_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c8 = function(a1, a2, a3, a4, a5, a6) {
  return {
    "p-datepicker p-component": true,
    "p-datepicker-inline": a1,
    "p-disabled": a2,
    "p-datepicker-timeonly": a3,
    "p-datepicker-multiple-month": a4,
    "p-datepicker-monthpicker": a5,
    "p-datepicker-touch-ui": a6
  };
};
var _c9 = function(a0, a1) {
  return {
    showTransitionParams: a0,
    hideTransitionParams: a1
  };
};
var _c10 = function(a1) {
  return {
    value: "visibleTouchUI",
    params: a1
  };
};
var _c11 = function(a1) {
  return {
    value: "visible",
    params: a1
  };
};
function Calendar_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r196 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 16, 17);
    ɵɵlistener("@overlayAnimation.start", function Calendar_div_3_Template_div_animation_overlayAnimation_start_0_listener($event) {
      ɵɵrestoreView(_r196);
      const ctx_r195 = ɵɵnextContext();
      return ɵɵresetView(ctx_r195.onOverlayAnimationStart($event));
    })("@overlayAnimation.done", function Calendar_div_3_Template_div_animation_overlayAnimation_done_0_listener($event) {
      ɵɵrestoreView(_r196);
      const ctx_r197 = ɵɵnextContext();
      return ɵɵresetView(ctx_r197.onOverlayAnimationDone($event));
    })("click", function Calendar_div_3_Template_div_click_0_listener($event) {
      ɵɵrestoreView(_r196);
      const ctx_r198 = ɵɵnextContext();
      return ɵɵresetView(ctx_r198.onOverlayClick($event));
    });
    ɵɵprojection(2);
    ɵɵtemplate(3, Calendar_div_3_ng_container_3_Template, 1, 0, "ng-container", 12);
    ɵɵtemplate(4, Calendar_div_3_ng_container_4_Template, 5, 3, "ng-container", 6);
    ɵɵtemplate(5, Calendar_div_3_div_5_Template, 27, 16, "div", 18);
    ɵɵtemplate(6, Calendar_div_3_div_6_Template, 3, 8, "div", 19);
    ɵɵprojection(7, 1);
    ɵɵtemplate(8, Calendar_div_3_ng_container_8_Template, 1, 0, "ng-container", 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵclassMap(ctx_r2.panelStyleClass);
    ɵɵproperty("ngStyle", ctx_r2.panelStyle)("ngClass", ɵɵpureFunction6(11, _c8, ctx_r2.inline, ctx_r2.disabled, ctx_r2.timeOnly, ctx_r2.numberOfMonths > 1, ctx_r2.view === "month", ctx_r2.touchUI))("@overlayAnimation", ctx_r2.touchUI ? ɵɵpureFunction1(21, _c10, ɵɵpureFunction2(18, _c9, ctx_r2.showTransitionOptions, ctx_r2.hideTransitionOptions)) : ɵɵpureFunction1(26, _c11, ɵɵpureFunction2(23, _c9, ctx_r2.showTransitionOptions, ctx_r2.hideTransitionOptions)))("@.disabled", ctx_r2.inline === true);
    ɵɵadvance(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r2.headerTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r2.timeOnly);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", (ctx_r2.showTime || ctx_r2.timeOnly) && ctx_r2.currentView === "date");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r2.showButtonBar);
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", ctx_r2.footerTemplate);
  }
}
var _c12 = [[["p-header"]], [["p-footer"]]];
var _c13 = function(a1, a2, a3, a4) {
  return {
    "p-calendar": true,
    "p-calendar-w-btn": a1,
    "p-calendar-timeonly": a2,
    "p-calendar-disabled": a3,
    "p-focus": a4
  };
};
var _c14 = ["p-header", "p-footer"];
var CALENDAR_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => Calendar),
  multi: true
};
var _Calendar = class {
  constructor(document, el, renderer, cd, zone, config, overlayService) {
    __publicField(this, "document");
    __publicField(this, "el");
    __publicField(this, "renderer");
    __publicField(this, "cd");
    __publicField(this, "zone");
    __publicField(this, "config");
    __publicField(this, "overlayService");
    /**
     * Inline style of the component.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Style class of the component.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Inline style of the input field.
     * @group Props
     */
    __publicField(this, "inputStyle");
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    __publicField(this, "inputId");
    /**
     * Name of the input element.
     * @group Props
     */
    __publicField(this, "name");
    /**
     * Style class of the input field.
     * @group Props
     */
    __publicField(this, "inputStyleClass");
    /**
     * Placeholder text for the input.
     * @group Props
     */
    __publicField(this, "placeholder");
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    __publicField(this, "ariaLabelledBy");
    /**
     * Defines a string that labels the icon button for accessibility.
     * @group Props
     */
    __publicField(this, "iconAriaLabel");
    /**
     * When specified, disables the component.
     * @group Props
     */
    __publicField(this, "disabled");
    /**
     * Format of the date which can also be defined at locale settings.
     * @group Props
     */
    __publicField(this, "dateFormat");
    /**
     * Separator for multiple selection mode.
     * @group Props
     */
    __publicField(this, "multipleSeparator", ",");
    /**
     * Separator for joining start and end dates on range selection mode.
     * @group Props
     */
    __publicField(this, "rangeSeparator", "-");
    /**
     * When enabled, displays the calendar as inline. Default is false for popup mode.
     * @group Props
     */
    __publicField(this, "inline", false);
    /**
     * Whether to display dates in other months (non-selectable) at the start or end of the current month. To make these days selectable use the selectOtherMonths option.
     * @group Props
     */
    __publicField(this, "showOtherMonths", true);
    /**
     * Whether days in other months shown before or after the current month are selectable. This only applies if the showOtherMonths option is set to true.
     * @group Props
     */
    __publicField(this, "selectOtherMonths");
    /**
     * When enabled, displays a button with icon next to input.
     * @group Props
     */
    __publicField(this, "showIcon");
    /**
     * Icon of the calendar button.
     * @group Props
     */
    __publicField(this, "icon");
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having#mydiv as variable name).
     * @group Props
     */
    __publicField(this, "appendTo");
    /**
     * When specified, prevents entering the date manually with keyboard.
     * @group Props
     */
    __publicField(this, "readonlyInput");
    /**
     * The cutoff year for determining the century for a date.
     * @group Props
     */
    __publicField(this, "shortYearCutoff", "+10");
    /**
     * Whether the month should be rendered as a dropdown instead of text.
     * @group Props
     * @deprecated Navigator is always on.
     */
    __publicField(this, "monthNavigator");
    /**
     * Whether the year should be rendered as a dropdown instead of text.
     * @group Props
     * @deprecated  Navigator is always on.
     */
    __publicField(this, "yearNavigator");
    /**
     * Specifies 12 or 24 hour format.
     * @group Props
     */
    __publicField(this, "hourFormat", "24");
    /**
     * Whether to display timepicker only.
     * @group Props
     */
    __publicField(this, "timeOnly");
    /**
     * Hours to change per step.
     * @group Props
     */
    __publicField(this, "stepHour", 1);
    /**
     * Minutes to change per step.
     * @group Props
     */
    __publicField(this, "stepMinute", 1);
    /**
     * Seconds to change per step.
     * @group Props
     */
    __publicField(this, "stepSecond", 1);
    /**
     * Whether to show the seconds in time picker.
     * @group Props
     */
    __publicField(this, "showSeconds", false);
    /**
     * When present, it specifies that an input field must be filled out before submitting the form.
     * @group Props
     */
    __publicField(this, "required");
    /**
     * When disabled, datepicker will not be visible with input focus.
     * @group Props
     */
    __publicField(this, "showOnFocus", true);
    /**
     * When enabled, calendar will show week numbers.
     * @group Props
     */
    __publicField(this, "showWeek", false);
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    __publicField(this, "showClear", false);
    /**
     * Type of the value to write back to ngModel, default is date and alternative is string.
     * @group Props
     */
    __publicField(this, "dataType", "date");
    /**
     * Defines the quantity of the selection, valid values are "single", "multiple" and "range".
     * @group Props
     */
    __publicField(this, "selectionMode", "single");
    /**
     * Maximum number of selectable dates in multiple mode.
     * @group Props
     */
    __publicField(this, "maxDateCount");
    /**
     * Whether to display today and clear buttons at the footer
     * @group Props
     */
    __publicField(this, "showButtonBar");
    /**
     * Style class of the today button.
     * @group Props
     */
    __publicField(this, "todayButtonStyleClass", "p-button-text");
    /**
     * Style class of the clear button.
     * @group Props
     */
    __publicField(this, "clearButtonStyleClass", "p-button-text");
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    __publicField(this, "autoZIndex", true);
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    __publicField(this, "baseZIndex", 0);
    /**
     * Style class of the datetimepicker container element.
     * @group Props
     */
    __publicField(this, "panelStyleClass");
    /**
     * Inline style of the datetimepicker container element.
     * @group Props
     */
    __publicField(this, "panelStyle");
    /**
     * Keep invalid value when input blur.
     * @group Props
     */
    __publicField(this, "keepInvalid", false);
    /**
     * Whether to hide the overlay on date selection.
     * @group Props
     */
    __publicField(this, "hideOnDateTimeSelect", true);
    /**
     * When enabled, calendar overlay is displayed as optimized for touch devices.
     * @group Props
     */
    __publicField(this, "touchUI");
    /**
     * Separator of time selector.
     * @group Props
     */
    __publicField(this, "timeSeparator", ":");
    /**
     * When enabled, can only focus on elements inside the calendar.
     * @group Props
     */
    __publicField(this, "focusTrap", true);
    /**
     * Transition options of the show animation.
     * @group Props
     */
    __publicField(this, "showTransitionOptions", ".12s cubic-bezier(0, 0, 0.2, 1)");
    /**
     * Transition options of the hide animation.
     * @group Props
     */
    __publicField(this, "hideTransitionOptions", ".1s linear");
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    __publicField(this, "tabindex");
    /**
     * Callback to invoke on focus of input field.
     * @param {Event} event - browser event.
     * @group Emits
     */
    __publicField(this, "onFocus", new EventEmitter());
    /**
     * Callback to invoke on blur of input field.
     * @param {Event} event - browser event.
     * @group Emits
     */
    __publicField(this, "onBlur", new EventEmitter());
    /**
     * Callback to invoke when date panel closed.
     * @param {Event} event - Mouse event
     * @group Emits
     */
    __publicField(this, "onClose", new EventEmitter());
    /**
     * Callback to invoke on date select.
     * @param {Date} date - date value.
     * @group Emits
     */
    __publicField(this, "onSelect", new EventEmitter());
    /**
     * Callback to invoke when input field cleared.
     * @group Emits
     */
    __publicField(this, "onClear", new EventEmitter());
    /**
     * Callback to invoke when input field is being typed.
     * @param {Event} event - browser event
     * @group Emits
     */
    __publicField(this, "onInput", new EventEmitter());
    /**
     * Callback to invoke when today button is clicked.
     * @param {Date} date - today as a date instance.
     * @group Emits
     */
    __publicField(this, "onTodayClick", new EventEmitter());
    /**
     * Callback to invoke when clear button is clicked.
     * @param {Event} event - browser event.
     * @group Emits
     */
    __publicField(this, "onClearClick", new EventEmitter());
    /**
     * Callback to invoke when a month is changed using the navigators.
     * @param {CalendarMonthChangeEvent} event - custom month change event.
     * @group Emits
     */
    __publicField(this, "onMonthChange", new EventEmitter());
    /**
     * Callback to invoke when a year is changed using the navigators.
     * @param {CalendarYearChangeEvent} event - custom year change event.
     * @group Emits
     */
    __publicField(this, "onYearChange", new EventEmitter());
    /**
     * Callback to invoke when clicked outside of the date panel.
     * @group Emits
     */
    __publicField(this, "onClickOutside", new EventEmitter());
    /**
     * Callback to invoke when datepicker panel is shown.
     * @group Emits
     */
    __publicField(this, "onShow", new EventEmitter());
    __publicField(this, "templates");
    __publicField(this, "containerViewChild");
    __publicField(this, "inputfieldViewChild");
    __publicField(this, "contentViewChild");
    __publicField(this, "value");
    __publicField(this, "dates");
    __publicField(this, "months");
    __publicField(this, "weekDays");
    __publicField(this, "currentMonth");
    __publicField(this, "currentYear");
    __publicField(this, "currentHour");
    __publicField(this, "currentMinute");
    __publicField(this, "currentSecond");
    __publicField(this, "pm");
    __publicField(this, "mask");
    __publicField(this, "maskClickListener");
    __publicField(this, "overlay");
    __publicField(this, "responsiveStyleElement");
    __publicField(this, "overlayVisible");
    __publicField(this, "onModelChange", () => {
    });
    __publicField(this, "onModelTouched", () => {
    });
    __publicField(this, "calendarElement");
    __publicField(this, "timePickerTimer");
    __publicField(this, "documentClickListener");
    __publicField(this, "animationEndListener");
    __publicField(this, "ticksTo1970");
    __publicField(this, "yearOptions");
    __publicField(this, "focus");
    __publicField(this, "isKeydown");
    __publicField(this, "filled");
    __publicField(this, "inputFieldValue", null);
    __publicField(this, "_minDate");
    __publicField(this, "_maxDate");
    __publicField(this, "_showTime");
    __publicField(this, "_yearRange");
    __publicField(this, "preventDocumentListener");
    __publicField(this, "dateTemplate");
    __publicField(this, "headerTemplate");
    __publicField(this, "footerTemplate");
    __publicField(this, "disabledDateTemplate");
    __publicField(this, "decadeTemplate");
    __publicField(this, "previousIconTemplate");
    __publicField(this, "nextIconTemplate");
    __publicField(this, "triggerIconTemplate");
    __publicField(this, "clearIconTemplate");
    __publicField(this, "decrementIconTemplate");
    __publicField(this, "incrementIconTemplate");
    __publicField(this, "_disabledDates");
    __publicField(this, "_disabledDays");
    __publicField(this, "selectElement");
    __publicField(this, "todayElement");
    __publicField(this, "focusElement");
    __publicField(this, "scrollHandler");
    __publicField(this, "documentResizeListener");
    __publicField(this, "navigationState", null);
    __publicField(this, "isMonthNavigate");
    __publicField(this, "initialized");
    __publicField(this, "translationSubscription");
    __publicField(this, "_locale");
    __publicField(this, "_responsiveOptions");
    __publicField(this, "currentView");
    __publicField(this, "attributeSelector");
    __publicField(this, "_numberOfMonths", 1);
    __publicField(this, "_firstDayOfWeek");
    __publicField(this, "_view", "date");
    __publicField(this, "preventFocus");
    __publicField(this, "_defaultDate");
    __publicField(this, "window");
    __publicField(this, "convertTo24Hour", function(hours, pm) {
      if (this.hourFormat == "12") {
        if (hours === 12) {
          return pm ? 12 : 0;
        } else {
          return pm ? hours + 12 : hours;
        }
      }
      return hours;
    });
    this.document = document;
    this.el = el;
    this.renderer = renderer;
    this.cd = cd;
    this.zone = zone;
    this.config = config;
    this.overlayService = overlayService;
    this.window = this.document.defaultView;
  }
  /**
   * The minimum selectable date.
   * @group Props
   */
  get minDate() {
    return this._minDate;
  }
  set minDate(date) {
    this._minDate = date;
    if (this.currentMonth != void 0 && this.currentMonth != null && this.currentYear) {
      this.createMonths(this.currentMonth, this.currentYear);
    }
  }
  /**
   * The maximum selectable date.
   * @group Props
   */
  get maxDate() {
    return this._maxDate;
  }
  set maxDate(date) {
    this._maxDate = date;
    if (this.currentMonth != void 0 && this.currentMonth != null && this.currentYear) {
      this.createMonths(this.currentMonth, this.currentYear);
    }
  }
  /**
   * Array with dates that should be disabled (not selectable).
   * @group Props
   */
  get disabledDates() {
    return this._disabledDates;
  }
  set disabledDates(disabledDates) {
    this._disabledDates = disabledDates;
    if (this.currentMonth != void 0 && this.currentMonth != null && this.currentYear) {
      this.createMonths(this.currentMonth, this.currentYear);
    }
  }
  /**
   * Array with weekday numbers that should be disabled (not selectable).
   * @group Props
   */
  get disabledDays() {
    return this._disabledDays;
  }
  set disabledDays(disabledDays) {
    this._disabledDays = disabledDays;
    if (this.currentMonth != void 0 && this.currentMonth != null && this.currentYear) {
      this.createMonths(this.currentMonth, this.currentYear);
    }
  }
  /**
   * The range of years displayed in the year drop-down in (nnnn:nnnn) format such as (2000:2020).
   * @group Props
   * @deprecated Years are based on decades by default.
   */
  get yearRange() {
    return this._yearRange;
  }
  set yearRange(yearRange) {
    this._yearRange = yearRange;
    if (yearRange) {
      const years = yearRange.split(":");
      const yearStart = parseInt(years[0]);
      const yearEnd = parseInt(years[1]);
      this.populateYearOptions(yearStart, yearEnd);
    }
  }
  /**
   * Whether to display timepicker.
   * @group Props
   */
  get showTime() {
    return this._showTime;
  }
  set showTime(showTime) {
    this._showTime = showTime;
    if (this.currentHour === void 0) {
      this.initTime(this.value || /* @__PURE__ */ new Date());
    }
    this.updateInputfield();
  }
  /**
   * An array of options for responsive design.
   * @group Props
   */
  get responsiveOptions() {
    return this._responsiveOptions;
  }
  set responsiveOptions(responsiveOptions) {
    this._responsiveOptions = responsiveOptions;
    this.destroyResponsiveStyleElement();
    this.createResponsiveStyle();
  }
  /**
   * Number of months to display.
   * @group Props
   */
  get numberOfMonths() {
    return this._numberOfMonths;
  }
  set numberOfMonths(numberOfMonths) {
    this._numberOfMonths = numberOfMonths;
    this.destroyResponsiveStyleElement();
    this.createResponsiveStyle();
  }
  /**
   * Defines the first of the week for various date calculations.
   * @group Props
   */
  get firstDayOfWeek() {
    return this._firstDayOfWeek;
  }
  set firstDayOfWeek(firstDayOfWeek) {
    this._firstDayOfWeek = firstDayOfWeek;
    this.createWeekDays();
  }
  /**
   * Option to set calendar locale.
   * @group Props
   * @deprecated Locale property has no effect, use new i18n API instead.
   */
  set locale(newLocale) {
    console.warn("Locale property has no effect, use new i18n API instead.");
  }
  /**
   * Type of view to display, valid values are "date" for datepicker and "month" for month picker.
   * @group Props
   */
  get view() {
    return this._view;
  }
  set view(view) {
    this._view = view;
    this.currentView = this._view;
  }
  /**
   * Set the date to highlight on first opening if the field is blank.
   * @group Props
   */
  get defaultDate() {
    return this._defaultDate;
  }
  set defaultDate(defaultDate) {
    this._defaultDate = defaultDate;
    if (this.initialized) {
      const date = defaultDate || /* @__PURE__ */ new Date();
      this.currentMonth = date.getMonth();
      this.currentYear = date.getFullYear();
      this.initTime(date);
      this.createMonths(this.currentMonth, this.currentYear);
    }
  }
  set content(content) {
    this.contentViewChild = content;
    if (this.contentViewChild) {
      if (this.isMonthNavigate) {
        Promise.resolve(null).then(() => this.updateFocus());
        this.isMonthNavigate = false;
      } else {
        if (!this.focus) {
          this.initFocusableCell();
        }
      }
    }
  }
  get locale() {
    return this._locale;
  }
  ngOnInit() {
    this.attributeSelector = UniqueComponentId();
    const date = this.defaultDate || /* @__PURE__ */ new Date();
    this.createResponsiveStyle();
    this.currentMonth = date.getMonth();
    this.currentYear = date.getFullYear();
    this.currentView = this.view;
    if (this.view === "date") {
      this.createWeekDays();
      this.initTime(date);
      this.createMonths(this.currentMonth, this.currentYear);
      this.ticksTo1970 = ((1970 - 1) * 365 + Math.floor(1970 / 4) - Math.floor(1970 / 100) + Math.floor(1970 / 400)) * 24 * 60 * 60 * 1e7;
    }
    this.translationSubscription = this.config.translationObserver.subscribe(() => {
      this.createWeekDays();
      this.cd.markForCheck();
    });
    this.initialized = true;
  }
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "date":
          this.dateTemplate = item.template;
          break;
        case "decade":
          this.decadeTemplate = item.template;
          break;
        case "disabledDate":
          this.disabledDateTemplate = item.template;
          break;
        case "header":
          this.headerTemplate = item.template;
          break;
        case "previousicon":
          this.previousIconTemplate = item.template;
          break;
        case "nexticon":
          this.nextIconTemplate = item.template;
          break;
        case "triggericon":
          this.triggerIconTemplate = item.template;
          break;
        case "clearicon":
          this.clearIconTemplate = item.template;
          break;
        case "decrementicon":
          this.decrementIconTemplate = item.template;
          break;
        case "incrementicon":
          this.incrementIconTemplate = item.template;
          break;
        case "footer":
          this.footerTemplate = item.template;
          break;
        default:
          this.dateTemplate = item.template;
          break;
      }
    });
  }
  ngAfterViewInit() {
    var _a;
    if (this.inline) {
      this.contentViewChild && this.contentViewChild.nativeElement.setAttribute(this.attributeSelector, "");
      if (!this.disabled) {
        this.initFocusableCell();
        if (this.numberOfMonths === 1) {
          this.contentViewChild.nativeElement.style.width = DomHandler.getOuterWidth((_a = this.containerViewChild) == null ? void 0 : _a.nativeElement) + "px";
        }
      }
    }
  }
  getTranslation(option) {
    return this.config.getTranslation(option);
  }
  populateYearOptions(start, end) {
    this.yearOptions = [];
    for (let i = start; i <= end; i++) {
      this.yearOptions.push(i);
    }
  }
  createWeekDays() {
    this.weekDays = [];
    let dayIndex = this.getFirstDateOfWeek();
    let dayLabels = this.getTranslation(TranslationKeys.DAY_NAMES_MIN);
    for (let i = 0; i < 7; i++) {
      this.weekDays.push(dayLabels[dayIndex]);
      dayIndex = dayIndex == 6 ? 0 : ++dayIndex;
    }
  }
  monthPickerValues() {
    let monthPickerValues = [];
    for (let i = 0; i <= 11; i++) {
      monthPickerValues.push(this.config.getTranslation("monthNamesShort")[i]);
    }
    return monthPickerValues;
  }
  yearPickerValues() {
    let yearPickerValues = [];
    let base = this.currentYear - this.currentYear % 10;
    for (let i = 0; i < 10; i++) {
      yearPickerValues.push(base + i);
    }
    return yearPickerValues;
  }
  createMonths(month, year) {
    this.months = this.months = [];
    for (let i = 0; i < this.numberOfMonths; i++) {
      let m = month + i;
      let y = year;
      if (m > 11) {
        m = m % 11 - 1;
        y = year + 1;
      }
      this.months.push(this.createMonth(m, y));
    }
  }
  getWeekNumber(date) {
    let checkDate = new Date(date.getTime());
    checkDate.setDate(checkDate.getDate() + 4 - (checkDate.getDay() || 7));
    let time = checkDate.getTime();
    checkDate.setMonth(0);
    checkDate.setDate(1);
    return Math.floor(Math.round((time - checkDate.getTime()) / 864e5) / 7) + 1;
  }
  createMonth(month, year) {
    let dates = [];
    let firstDay = this.getFirstDayOfMonthIndex(month, year);
    let daysLength = this.getDaysCountInMonth(month, year);
    let prevMonthDaysLength = this.getDaysCountInPrevMonth(month, year);
    let dayNo = 1;
    let today = /* @__PURE__ */ new Date();
    let weekNumbers = [];
    let monthRows = Math.ceil((daysLength + firstDay) / 7);
    for (let i = 0; i < monthRows; i++) {
      let week = [];
      if (i == 0) {
        for (let j = prevMonthDaysLength - firstDay + 1; j <= prevMonthDaysLength; j++) {
          let prev = this.getPreviousMonthAndYear(month, year);
          week.push({
            day: j,
            month: prev.month,
            year: prev.year,
            otherMonth: true,
            today: this.isToday(today, j, prev.month, prev.year),
            selectable: this.isSelectable(j, prev.month, prev.year, true)
          });
        }
        let remainingDaysLength = 7 - week.length;
        for (let j = 0; j < remainingDaysLength; j++) {
          week.push({
            day: dayNo,
            month,
            year,
            today: this.isToday(today, dayNo, month, year),
            selectable: this.isSelectable(dayNo, month, year, false)
          });
          dayNo++;
        }
      } else {
        for (let j = 0; j < 7; j++) {
          if (dayNo > daysLength) {
            let next = this.getNextMonthAndYear(month, year);
            week.push({
              day: dayNo - daysLength,
              month: next.month,
              year: next.year,
              otherMonth: true,
              today: this.isToday(today, dayNo - daysLength, next.month, next.year),
              selectable: this.isSelectable(dayNo - daysLength, next.month, next.year, true)
            });
          } else {
            week.push({
              day: dayNo,
              month,
              year,
              today: this.isToday(today, dayNo, month, year),
              selectable: this.isSelectable(dayNo, month, year, false)
            });
          }
          dayNo++;
        }
      }
      if (this.showWeek) {
        weekNumbers.push(this.getWeekNumber(new Date(week[0].year, week[0].month, week[0].day)));
      }
      dates.push(week);
    }
    return {
      month,
      year,
      dates,
      weekNumbers
    };
  }
  initTime(date) {
    this.pm = date.getHours() > 11;
    if (this.showTime) {
      this.currentMinute = date.getMinutes();
      this.currentSecond = date.getSeconds();
      this.setCurrentHourPM(date.getHours());
    } else if (this.timeOnly) {
      this.currentMinute = 0;
      this.currentHour = 0;
      this.currentSecond = 0;
    }
  }
  navBackward(event2) {
    if (this.disabled) {
      event2.preventDefault();
      return;
    }
    this.isMonthNavigate = true;
    if (this.currentView === "month") {
      this.decrementYear();
      setTimeout(() => {
        this.updateFocus();
      }, 1);
    } else if (this.currentView === "year") {
      this.decrementDecade();
      setTimeout(() => {
        this.updateFocus();
      }, 1);
    } else {
      if (this.currentMonth === 0) {
        this.currentMonth = 11;
        this.decrementYear();
      } else {
        this.currentMonth--;
      }
      this.onMonthChange.emit({
        month: this.currentMonth + 1,
        year: this.currentYear
      });
      this.createMonths(this.currentMonth, this.currentYear);
    }
  }
  navForward(event2) {
    if (this.disabled) {
      event2.preventDefault();
      return;
    }
    this.isMonthNavigate = true;
    if (this.currentView === "month") {
      this.incrementYear();
      setTimeout(() => {
        this.updateFocus();
      }, 1);
    } else if (this.currentView === "year") {
      this.incrementDecade();
      setTimeout(() => {
        this.updateFocus();
      }, 1);
    } else {
      if (this.currentMonth === 11) {
        this.currentMonth = 0;
        this.incrementYear();
      } else {
        this.currentMonth++;
      }
      this.onMonthChange.emit({
        month: this.currentMonth + 1,
        year: this.currentYear
      });
      this.createMonths(this.currentMonth, this.currentYear);
    }
  }
  decrementYear() {
    this.currentYear--;
    let _yearOptions = this.yearOptions;
    if (this.yearNavigator && this.currentYear < _yearOptions[0]) {
      let difference = _yearOptions[_yearOptions.length - 1] - _yearOptions[0];
      this.populateYearOptions(_yearOptions[0] - difference, _yearOptions[_yearOptions.length - 1] - difference);
    }
  }
  decrementDecade() {
    this.currentYear = this.currentYear - 10;
  }
  incrementDecade() {
    this.currentYear = this.currentYear + 10;
  }
  incrementYear() {
    this.currentYear++;
    let _yearOptions = this.yearOptions;
    if (this.yearNavigator && this.currentYear > _yearOptions[_yearOptions.length - 1]) {
      let difference = _yearOptions[_yearOptions.length - 1] - _yearOptions[0];
      this.populateYearOptions(_yearOptions[0] + difference, _yearOptions[_yearOptions.length - 1] + difference);
    }
  }
  switchToMonthView(event2) {
    this.setCurrentView("month");
    event2.preventDefault();
  }
  switchToYearView(event2) {
    this.setCurrentView("year");
    event2.preventDefault();
  }
  onDateSelect(event2, dateMeta) {
    if (this.disabled || !dateMeta.selectable) {
      event2.preventDefault();
      return;
    }
    if (this.isMultipleSelection() && this.isSelected(dateMeta)) {
      this.value = this.value.filter((date, i) => {
        return !this.isDateEquals(date, dateMeta);
      });
      if (this.value.length === 0) {
        this.value = null;
      }
      this.updateModel(this.value);
    } else {
      if (this.shouldSelectDate(dateMeta)) {
        this.selectDate(dateMeta);
      }
    }
    if (this.isSingleSelection() && this.hideOnDateTimeSelect) {
      setTimeout(() => {
        event2.preventDefault();
        this.hideOverlay();
        if (this.mask) {
          this.disableModality();
        }
        this.cd.markForCheck();
      }, 150);
    }
    this.updateInputfield();
    event2.preventDefault();
  }
  shouldSelectDate(dateMeta) {
    if (this.isMultipleSelection())
      return this.maxDateCount != null ? this.maxDateCount > (this.value ? this.value.length : 0) : true;
    else
      return true;
  }
  onMonthSelect(event2, index) {
    if (this.view === "month") {
      this.onDateSelect(event2, {
        year: this.currentYear,
        month: index,
        day: 1,
        selectable: true
      });
    } else {
      this.currentMonth = index;
      this.createMonths(this.currentMonth, this.currentYear);
      this.setCurrentView("date");
      this.onMonthChange.emit({
        month: this.currentMonth + 1,
        year: this.currentYear
      });
    }
  }
  onYearSelect(event2, year) {
    if (this.view === "year") {
      this.onDateSelect(event2, {
        year,
        month: 0,
        day: 1,
        selectable: true
      });
    } else {
      this.currentYear = year;
      this.setCurrentView("month");
      this.onYearChange.emit({
        month: this.currentMonth + 1,
        year: this.currentYear
      });
    }
  }
  updateInputfield() {
    let formattedValue = "";
    if (this.value) {
      if (this.isSingleSelection()) {
        formattedValue = this.formatDateTime(this.value);
      } else if (this.isMultipleSelection()) {
        for (let i = 0; i < this.value.length; i++) {
          let dateAsString = this.formatDateTime(this.value[i]);
          formattedValue += dateAsString;
          if (i !== this.value.length - 1) {
            formattedValue += this.multipleSeparator + " ";
          }
        }
      } else if (this.isRangeSelection()) {
        if (this.value && this.value.length) {
          let startDate = this.value[0];
          let endDate = this.value[1];
          formattedValue = this.formatDateTime(startDate);
          if (endDate) {
            formattedValue += " " + this.rangeSeparator + " " + this.formatDateTime(endDate);
          }
        }
      }
    }
    this.inputFieldValue = formattedValue;
    this.updateFilledState();
    if (this.inputfieldViewChild && this.inputfieldViewChild.nativeElement) {
      this.inputfieldViewChild.nativeElement.value = this.inputFieldValue;
    }
  }
  formatDateTime(date) {
    let formattedValue = this.keepInvalid ? date : null;
    if (this.isValidDate(date)) {
      if (this.timeOnly) {
        formattedValue = this.formatTime(date);
      } else {
        formattedValue = this.formatDate(date, this.getDateFormat());
        if (this.showTime) {
          formattedValue += " " + this.formatTime(date);
        }
      }
    }
    return formattedValue;
  }
  setCurrentHourPM(hours) {
    if (this.hourFormat == "12") {
      this.pm = hours > 11;
      if (hours >= 12) {
        this.currentHour = hours == 12 ? 12 : hours - 12;
      } else {
        this.currentHour = hours == 0 ? 12 : hours;
      }
    } else {
      this.currentHour = hours;
    }
  }
  setCurrentView(currentView) {
    this.currentView = currentView;
    this.cd.detectChanges();
    this.alignOverlay();
  }
  selectDate(dateMeta) {
    let date = new Date(dateMeta.year, dateMeta.month, dateMeta.day);
    if (this.showTime) {
      if (this.hourFormat == "12") {
        if (this.currentHour === 12)
          date.setHours(this.pm ? 12 : 0);
        else
          date.setHours(this.pm ? this.currentHour + 12 : this.currentHour);
      } else {
        date.setHours(this.currentHour);
      }
      date.setMinutes(this.currentMinute);
      date.setSeconds(this.currentSecond);
    }
    if (this.minDate && this.minDate > date) {
      date = this.minDate;
      this.setCurrentHourPM(date.getHours());
      this.currentMinute = date.getMinutes();
      this.currentSecond = date.getSeconds();
    }
    if (this.maxDate && this.maxDate < date) {
      date = this.maxDate;
      this.setCurrentHourPM(date.getHours());
      this.currentMinute = date.getMinutes();
      this.currentSecond = date.getSeconds();
    }
    if (this.isSingleSelection()) {
      this.updateModel(date);
    } else if (this.isMultipleSelection()) {
      this.updateModel(this.value ? [...this.value, date] : [date]);
    } else if (this.isRangeSelection()) {
      if (this.value && this.value.length) {
        let startDate = this.value[0];
        let endDate = this.value[1];
        if (!endDate && date.getTime() >= startDate.getTime()) {
          endDate = date;
        } else {
          startDate = date;
          endDate = null;
        }
        this.updateModel([startDate, endDate]);
      } else {
        this.updateModel([date, null]);
      }
    }
    this.onSelect.emit(date);
  }
  updateModel(value) {
    this.value = value;
    if (this.dataType == "date") {
      this.onModelChange(this.value);
    } else if (this.dataType == "string") {
      if (this.isSingleSelection()) {
        this.onModelChange(this.formatDateTime(this.value));
      } else {
        let stringArrValue = null;
        if (this.value) {
          stringArrValue = this.value.map((date) => this.formatDateTime(date));
        }
        this.onModelChange(stringArrValue);
      }
    }
  }
  getFirstDayOfMonthIndex(month, year) {
    let day = /* @__PURE__ */ new Date();
    day.setDate(1);
    day.setMonth(month);
    day.setFullYear(year);
    let dayIndex = day.getDay() + this.getSundayIndex();
    return dayIndex >= 7 ? dayIndex - 7 : dayIndex;
  }
  getDaysCountInMonth(month, year) {
    return 32 - this.daylightSavingAdjust(new Date(year, month, 32)).getDate();
  }
  getDaysCountInPrevMonth(month, year) {
    let prev = this.getPreviousMonthAndYear(month, year);
    return this.getDaysCountInMonth(prev.month, prev.year);
  }
  getPreviousMonthAndYear(month, year) {
    let m, y;
    if (month === 0) {
      m = 11;
      y = year - 1;
    } else {
      m = month - 1;
      y = year;
    }
    return {
      month: m,
      year: y
    };
  }
  getNextMonthAndYear(month, year) {
    let m, y;
    if (month === 11) {
      m = 0;
      y = year + 1;
    } else {
      m = month + 1;
      y = year;
    }
    return {
      month: m,
      year: y
    };
  }
  getSundayIndex() {
    let firstDayOfWeek = this.getFirstDateOfWeek();
    return firstDayOfWeek > 0 ? 7 - firstDayOfWeek : 0;
  }
  isSelected(dateMeta) {
    if (this.value) {
      if (this.isSingleSelection()) {
        return this.isDateEquals(this.value, dateMeta);
      } else if (this.isMultipleSelection()) {
        let selected = false;
        for (let date of this.value) {
          selected = this.isDateEquals(date, dateMeta);
          if (selected) {
            break;
          }
        }
        return selected;
      } else if (this.isRangeSelection()) {
        if (this.value[1])
          return this.isDateEquals(this.value[0], dateMeta) || this.isDateEquals(this.value[1], dateMeta) || this.isDateBetween(this.value[0], this.value[1], dateMeta);
        else
          return this.isDateEquals(this.value[0], dateMeta);
      }
    } else {
      return false;
    }
  }
  isComparable() {
    return this.value != null && typeof this.value !== "string";
  }
  isMonthSelected(month) {
    if (this.isComparable() && !this.isMultipleSelection()) {
      const [start, end] = this.isRangeSelection() ? this.value : [this.value, this.value];
      const selected = new Date(this.currentYear, month, 1);
      return selected >= start && selected <= (end ?? start);
    }
    return false;
  }
  isMonthDisabled(month) {
    for (let day = 1; day < this.getDaysCountInMonth(month, this.currentYear) + 1; day++) {
      if (this.isSelectable(day, month, this.currentYear, false)) {
        return false;
      }
    }
    return true;
  }
  isYearSelected(year) {
    if (this.isComparable()) {
      let value = this.isRangeSelection() ? this.value[0] : this.value;
      return !this.isMultipleSelection() ? value.getFullYear() === year : false;
    }
    return false;
  }
  isDateEquals(value, dateMeta) {
    if (value && ObjectUtils.isDate(value))
      return value.getDate() === dateMeta.day && value.getMonth() === dateMeta.month && value.getFullYear() === dateMeta.year;
    else
      return false;
  }
  isDateBetween(start, end, dateMeta) {
    let between = false;
    if (start && end) {
      let date = new Date(dateMeta.year, dateMeta.month, dateMeta.day);
      return start.getTime() <= date.getTime() && end.getTime() >= date.getTime();
    }
    return between;
  }
  isSingleSelection() {
    return this.selectionMode === "single";
  }
  isRangeSelection() {
    return this.selectionMode === "range";
  }
  isMultipleSelection() {
    return this.selectionMode === "multiple";
  }
  isToday(today, day, month, year) {
    return today.getDate() === day && today.getMonth() === month && today.getFullYear() === year;
  }
  isSelectable(day, month, year, otherMonth) {
    let validMin = true;
    let validMax = true;
    let validDate = true;
    let validDay = true;
    if (otherMonth && !this.selectOtherMonths) {
      return false;
    }
    if (this.minDate) {
      if (this.minDate.getFullYear() > year) {
        validMin = false;
      } else if (this.minDate.getFullYear() === year) {
        if (this.minDate.getMonth() > month) {
          validMin = false;
        } else if (this.minDate.getMonth() === month) {
          if (this.minDate.getDate() > day) {
            validMin = false;
          }
        }
      }
    }
    if (this.maxDate) {
      if (this.maxDate.getFullYear() < year) {
        validMax = false;
      } else if (this.maxDate.getFullYear() === year) {
        if (this.maxDate.getMonth() < month) {
          validMax = false;
        } else if (this.maxDate.getMonth() === month) {
          if (this.maxDate.getDate() < day) {
            validMax = false;
          }
        }
      }
    }
    if (this.disabledDates) {
      validDate = !this.isDateDisabled(day, month, year);
    }
    if (this.disabledDays) {
      validDay = !this.isDayDisabled(day, month, year);
    }
    return validMin && validMax && validDate && validDay;
  }
  isDateDisabled(day, month, year) {
    if (this.disabledDates) {
      for (let disabledDate of this.disabledDates) {
        if (disabledDate.getFullYear() === year && disabledDate.getMonth() === month && disabledDate.getDate() === day) {
          return true;
        }
      }
    }
    return false;
  }
  isDayDisabled(day, month, year) {
    if (this.disabledDays) {
      let weekday = new Date(year, month, day);
      let weekdayNumber = weekday.getDay();
      return this.disabledDays.indexOf(weekdayNumber) !== -1;
    }
    return false;
  }
  onInputFocus(event2) {
    this.focus = true;
    if (this.showOnFocus) {
      this.showOverlay();
    }
    this.onFocus.emit(event2);
  }
  onInputClick() {
    if (this.showOnFocus && !this.overlayVisible) {
      this.showOverlay();
    }
  }
  onInputBlur(event2) {
    this.focus = false;
    this.onBlur.emit(event2);
    if (!this.keepInvalid) {
      this.updateInputfield();
    }
    this.onModelTouched();
  }
  onButtonClick(event2, inputfield) {
    if (!this.overlayVisible) {
      inputfield.focus();
      this.showOverlay();
    } else {
      this.hideOverlay();
    }
  }
  clear() {
    this.inputFieldValue = null;
    this.value = null;
    this.onModelChange(this.value);
    this.onClear.emit();
  }
  onOverlayClick(event2) {
    this.overlayService.add({
      originalEvent: event2,
      target: this.el.nativeElement
    });
  }
  getMonthName(index) {
    return this.config.getTranslation("monthNames")[index];
  }
  getYear(month) {
    return this.currentView === "month" ? this.currentYear : month.year;
  }
  switchViewButtonDisabled() {
    return this.numberOfMonths > 1 || this.disabled;
  }
  onPrevButtonClick(event2) {
    this.navigationState = {
      backward: true,
      button: true
    };
    this.navBackward(event2);
  }
  onNextButtonClick(event2) {
    this.navigationState = {
      backward: false,
      button: true
    };
    this.navForward(event2);
  }
  onContainerButtonKeydown(event2) {
    switch (event2.which) {
      case 9:
        if (!this.inline) {
          this.trapFocus(event2);
        }
        break;
      case 27:
        this.overlayVisible = false;
        event2.preventDefault();
        break;
      default:
        break;
    }
  }
  onInputKeydown(event2) {
    this.isKeydown = true;
    if (event2.keyCode === 40 && this.contentViewChild) {
      this.trapFocus(event2);
    } else if (event2.keyCode === 27) {
      if (this.overlayVisible) {
        this.overlayVisible = false;
        event2.preventDefault();
      }
    } else if (event2.keyCode === 13) {
      if (this.overlayVisible) {
        this.overlayVisible = false;
        event2.preventDefault();
      }
    } else if (event2.keyCode === 9 && this.contentViewChild) {
      DomHandler.getFocusableElements(this.contentViewChild.nativeElement).forEach((el) => el.tabIndex = "-1");
      if (this.overlayVisible) {
        this.overlayVisible = false;
      }
    }
  }
  onDateCellKeydown(event2, date, groupIndex) {
    const cellContent = event2.currentTarget;
    const cell = cellContent.parentElement;
    switch (event2.which) {
      case 40: {
        cellContent.tabIndex = "-1";
        let cellIndex = DomHandler.index(cell);
        let nextRow = cell.parentElement.nextElementSibling;
        if (nextRow) {
          let focusCell = nextRow.children[cellIndex].children[0];
          if (DomHandler.hasClass(focusCell, "p-disabled")) {
            this.navigationState = {
              backward: false
            };
            this.navForward(event2);
          } else {
            nextRow.children[cellIndex].children[0].tabIndex = "0";
            nextRow.children[cellIndex].children[0].focus();
          }
        } else {
          this.navigationState = {
            backward: false
          };
          this.navForward(event2);
        }
        event2.preventDefault();
        break;
      }
      case 38: {
        cellContent.tabIndex = "-1";
        let cellIndex = DomHandler.index(cell);
        let prevRow = cell.parentElement.previousElementSibling;
        if (prevRow) {
          let focusCell = prevRow.children[cellIndex].children[0];
          if (DomHandler.hasClass(focusCell, "p-disabled")) {
            this.navigationState = {
              backward: true
            };
            this.navBackward(event2);
          } else {
            focusCell.tabIndex = "0";
            focusCell.focus();
          }
        } else {
          this.navigationState = {
            backward: true
          };
          this.navBackward(event2);
        }
        event2.preventDefault();
        break;
      }
      case 37: {
        cellContent.tabIndex = "-1";
        let prevCell = cell.previousElementSibling;
        if (prevCell) {
          let focusCell = prevCell.children[0];
          if (DomHandler.hasClass(focusCell, "p-disabled") || DomHandler.hasClass(focusCell.parentElement, "p-datepicker-weeknumber")) {
            this.navigateToMonth(true, groupIndex);
          } else {
            focusCell.tabIndex = "0";
            focusCell.focus();
          }
        } else {
          this.navigateToMonth(true, groupIndex);
        }
        event2.preventDefault();
        break;
      }
      case 39: {
        cellContent.tabIndex = "-1";
        let nextCell = cell.nextElementSibling;
        if (nextCell) {
          let focusCell = nextCell.children[0];
          if (DomHandler.hasClass(focusCell, "p-disabled")) {
            this.navigateToMonth(false, groupIndex);
          } else {
            focusCell.tabIndex = "0";
            focusCell.focus();
          }
        } else {
          this.navigateToMonth(false, groupIndex);
        }
        event2.preventDefault();
        break;
      }
      case 13:
      case 32: {
        this.onDateSelect(event2, date);
        event2.preventDefault();
        break;
      }
      case 27: {
        this.overlayVisible = false;
        event2.preventDefault();
        break;
      }
      case 9: {
        if (!this.inline) {
          this.trapFocus(event2);
        }
        break;
      }
      default:
        break;
    }
  }
  onMonthCellKeydown(event2, index) {
    const cell = event2.currentTarget;
    switch (event2.which) {
      case 38:
      case 40: {
        cell.tabIndex = "-1";
        var cells = cell.parentElement.children;
        var cellIndex = DomHandler.index(cell);
        let nextCell = cells[event2.which === 40 ? cellIndex + 3 : cellIndex - 3];
        if (nextCell) {
          nextCell.tabIndex = "0";
          nextCell.focus();
        }
        event2.preventDefault();
        break;
      }
      case 37: {
        cell.tabIndex = "-1";
        let prevCell = cell.previousElementSibling;
        if (prevCell) {
          prevCell.tabIndex = "0";
          prevCell.focus();
        } else {
          this.navigationState = {
            backward: true
          };
          this.navBackward(event2);
        }
        event2.preventDefault();
        break;
      }
      case 39: {
        cell.tabIndex = "-1";
        let nextCell = cell.nextElementSibling;
        if (nextCell) {
          nextCell.tabIndex = "0";
          nextCell.focus();
        } else {
          this.navigationState = {
            backward: false
          };
          this.navForward(event2);
        }
        event2.preventDefault();
        break;
      }
      case 13: {
        this.onMonthSelect(event2, index);
        event2.preventDefault();
        break;
      }
      case 13:
      case 32: {
        this.overlayVisible = false;
        event2.preventDefault();
        break;
      }
      case 27: {
        this.overlayVisible = false;
        event2.preventDefault();
        break;
      }
      case 9: {
        if (!this.inline) {
          this.trapFocus(event2);
        }
        break;
      }
      default:
        break;
    }
  }
  onYearCellKeydown(event2, index) {
    const cell = event2.currentTarget;
    switch (event2.which) {
      case 38:
      case 40: {
        cell.tabIndex = "-1";
        var cells = cell.parentElement.children;
        var cellIndex = DomHandler.index(cell);
        let nextCell = cells[event2.which === 40 ? cellIndex + 2 : cellIndex - 2];
        if (nextCell) {
          nextCell.tabIndex = "0";
          nextCell.focus();
        }
        event2.preventDefault();
        break;
      }
      case 37: {
        cell.tabIndex = "-1";
        let prevCell = cell.previousElementSibling;
        if (prevCell) {
          prevCell.tabIndex = "0";
          prevCell.focus();
        } else {
          this.navigationState = {
            backward: true
          };
          this.navBackward(event2);
        }
        event2.preventDefault();
        break;
      }
      case 39: {
        cell.tabIndex = "-1";
        let nextCell = cell.nextElementSibling;
        if (nextCell) {
          nextCell.tabIndex = "0";
          nextCell.focus();
        } else {
          this.navigationState = {
            backward: false
          };
          this.navForward(event2);
        }
        event2.preventDefault();
        break;
      }
      case 13:
      case 32: {
        this.onYearSelect(event2, index);
        event2.preventDefault();
        break;
      }
      case 27: {
        this.overlayVisible = false;
        event2.preventDefault();
        break;
      }
      case 9: {
        this.trapFocus(event2);
        break;
      }
      default:
        break;
    }
  }
  navigateToMonth(prev, groupIndex) {
    if (prev) {
      if (this.numberOfMonths === 1 || groupIndex === 0) {
        this.navigationState = {
          backward: true
        };
        this.navBackward(event);
      } else {
        let prevMonthContainer = this.contentViewChild.nativeElement.children[groupIndex - 1];
        let cells = DomHandler.find(prevMonthContainer, ".p-datepicker-calendar td span:not(.p-disabled):not(.p-ink)");
        let focusCell = cells[cells.length - 1];
        focusCell.tabIndex = "0";
        focusCell.focus();
      }
    } else {
      if (this.numberOfMonths === 1 || groupIndex === this.numberOfMonths - 1) {
        this.navigationState = {
          backward: false
        };
        this.navForward(event);
      } else {
        let nextMonthContainer = this.contentViewChild.nativeElement.children[groupIndex + 1];
        let focusCell = DomHandler.findSingle(nextMonthContainer, ".p-datepicker-calendar td span:not(.p-disabled):not(.p-ink)");
        focusCell.tabIndex = "0";
        focusCell.focus();
      }
    }
  }
  updateFocus() {
    let cell;
    if (this.navigationState) {
      if (this.navigationState.button) {
        this.initFocusableCell();
        if (this.navigationState.backward)
          DomHandler.findSingle(this.contentViewChild.nativeElement, ".p-datepicker-prev").focus();
        else
          DomHandler.findSingle(this.contentViewChild.nativeElement, ".p-datepicker-next").focus();
      } else {
        if (this.navigationState.backward) {
          let cells;
          if (this.currentView === "month") {
            cells = DomHandler.find(this.contentViewChild.nativeElement, ".p-monthpicker .p-monthpicker-month:not(.p-disabled)");
          } else if (this.currentView === "year") {
            cells = DomHandler.find(this.contentViewChild.nativeElement, ".p-yearpicker .p-yearpicker-year:not(.p-disabled)");
          } else {
            cells = DomHandler.find(this.contentViewChild.nativeElement, ".p-datepicker-calendar td span:not(.p-disabled):not(.p-ink)");
          }
          if (cells && cells.length > 0) {
            cell = cells[cells.length - 1];
          }
        } else {
          if (this.currentView === "month") {
            cell = DomHandler.findSingle(this.contentViewChild.nativeElement, ".p-monthpicker .p-monthpicker-month:not(.p-disabled)");
          } else if (this.currentView === "year") {
            cell = DomHandler.findSingle(this.contentViewChild.nativeElement, ".p-yearpicker .p-yearpicker-year:not(.p-disabled)");
          } else {
            cell = DomHandler.findSingle(this.contentViewChild.nativeElement, ".p-datepicker-calendar td span:not(.p-disabled):not(.p-ink)");
          }
        }
        if (cell) {
          cell.tabIndex = "0";
          cell.focus();
        }
      }
      this.navigationState = null;
    } else {
      this.initFocusableCell();
    }
  }
  initFocusableCell() {
    var _a;
    const contentEl = (_a = this.contentViewChild) == null ? void 0 : _a.nativeElement;
    let cell;
    if (this.currentView === "month") {
      let cells = DomHandler.find(contentEl, ".p-monthpicker .p-monthpicker-month:not(.p-disabled)");
      let selectedCell = DomHandler.findSingle(contentEl, ".p-monthpicker .p-monthpicker-month.p-highlight");
      cells.forEach((cell2) => cell2.tabIndex = -1);
      cell = selectedCell || cells[0];
      if (cells.length === 0) {
        let disabledCells = DomHandler.find(contentEl, '.p-monthpicker .p-monthpicker-month.p-disabled[tabindex = "0"]');
        disabledCells.forEach((cell2) => cell2.tabIndex = -1);
      }
    } else if (this.currentView === "year") {
      let cells = DomHandler.find(contentEl, ".p-yearpicker .p-yearpicker-year:not(.p-disabled)");
      let selectedCell = DomHandler.findSingle(contentEl, ".p-yearpicker .p-yearpicker-year.p-highlight");
      cells.forEach((cell2) => cell2.tabIndex = -1);
      cell = selectedCell || cells[0];
      if (cells.length === 0) {
        let disabledCells = DomHandler.find(contentEl, '.p-yearpicker .p-yearpicker-year.p-disabled[tabindex = "0"]');
        disabledCells.forEach((cell2) => cell2.tabIndex = -1);
      }
    } else {
      cell = DomHandler.findSingle(contentEl, "span.p-highlight");
      if (!cell) {
        let todayCell = DomHandler.findSingle(contentEl, "td.p-datepicker-today span:not(.p-disabled):not(.p-ink)");
        if (todayCell)
          cell = todayCell;
        else
          cell = DomHandler.findSingle(contentEl, ".p-datepicker-calendar td span:not(.p-disabled):not(.p-ink)");
      }
    }
    if (cell) {
      cell.tabIndex = "0";
      if (!this.preventFocus && (!this.navigationState || !this.navigationState.button)) {
        setTimeout(() => {
          if (!this.disabled) {
            cell.focus();
          }
        }, 1);
      }
      this.preventFocus = false;
    }
  }
  trapFocus(event2) {
    let focusableElements = DomHandler.getFocusableElements(this.contentViewChild.nativeElement);
    if (focusableElements && focusableElements.length > 0) {
      if (!focusableElements[0].ownerDocument.activeElement) {
        focusableElements[0].focus();
      } else {
        let focusedIndex = focusableElements.indexOf(focusableElements[0].ownerDocument.activeElement);
        if (event2.shiftKey) {
          if (focusedIndex == -1 || focusedIndex === 0) {
            if (this.focusTrap) {
              focusableElements[focusableElements.length - 1].focus();
            } else {
              if (focusedIndex === -1)
                return this.hideOverlay();
              else if (focusedIndex === 0)
                return;
            }
          } else {
            focusableElements[focusedIndex - 1].focus();
          }
        } else {
          if (focusedIndex == -1 || focusedIndex === focusableElements.length - 1) {
            if (!this.focusTrap && focusedIndex != -1)
              return this.hideOverlay();
            else
              focusableElements[0].focus();
          } else {
            focusableElements[focusedIndex + 1].focus();
          }
        }
      }
    }
    event2.preventDefault();
  }
  onMonthDropdownChange(m) {
    this.currentMonth = parseInt(m);
    this.onMonthChange.emit({
      month: this.currentMonth + 1,
      year: this.currentYear
    });
    this.createMonths(this.currentMonth, this.currentYear);
  }
  onYearDropdownChange(y) {
    this.currentYear = parseInt(y);
    this.onYearChange.emit({
      month: this.currentMonth + 1,
      year: this.currentYear
    });
    this.createMonths(this.currentMonth, this.currentYear);
  }
  validateTime(hour, minute, second, pm) {
    let value = this.value;
    const convertedHour = this.convertTo24Hour(hour, pm);
    if (this.isRangeSelection()) {
      value = this.value[1] || this.value[0];
    }
    if (this.isMultipleSelection()) {
      value = this.value[this.value.length - 1];
    }
    const valueDateString = value ? value.toDateString() : null;
    if (this.minDate && valueDateString && this.minDate.toDateString() === valueDateString) {
      if (this.minDate.getHours() > convertedHour) {
        return false;
      }
      if (this.minDate.getHours() === convertedHour) {
        if (this.minDate.getMinutes() > minute) {
          return false;
        }
        if (this.minDate.getMinutes() === minute) {
          if (this.minDate.getSeconds() > second) {
            return false;
          }
        }
      }
    }
    if (this.maxDate && valueDateString && this.maxDate.toDateString() === valueDateString) {
      if (this.maxDate.getHours() < convertedHour) {
        return false;
      }
      if (this.maxDate.getHours() === convertedHour) {
        if (this.maxDate.getMinutes() < minute) {
          return false;
        }
        if (this.maxDate.getMinutes() === minute) {
          if (this.maxDate.getSeconds() < second) {
            return false;
          }
        }
      }
    }
    return true;
  }
  incrementHour(event2) {
    const prevHour = this.currentHour;
    let newHour = this.currentHour + this.stepHour;
    let newPM = this.pm;
    if (this.hourFormat == "24")
      newHour = newHour >= 24 ? newHour - 24 : newHour;
    else if (this.hourFormat == "12") {
      if (prevHour < 12 && newHour > 11) {
        newPM = !this.pm;
      }
      newHour = newHour >= 13 ? newHour - 12 : newHour;
    }
    if (this.validateTime(newHour, this.currentMinute, this.currentSecond, newPM)) {
      this.currentHour = newHour;
      this.pm = newPM;
    }
    event2.preventDefault();
  }
  onTimePickerElementMouseDown(event2, type, direction) {
    if (!this.disabled) {
      this.repeat(event2, null, type, direction);
      event2.preventDefault();
    }
  }
  onTimePickerElementMouseUp(event2) {
    if (!this.disabled) {
      this.clearTimePickerTimer();
      this.updateTime();
    }
  }
  onTimePickerElementMouseLeave() {
    if (!this.disabled && this.timePickerTimer) {
      this.clearTimePickerTimer();
      this.updateTime();
    }
  }
  repeat(event2, interval, type, direction) {
    let i = interval || 500;
    this.clearTimePickerTimer();
    this.timePickerTimer = setTimeout(() => {
      this.repeat(event2, 100, type, direction);
      this.cd.markForCheck();
    }, i);
    switch (type) {
      case 0:
        if (direction === 1)
          this.incrementHour(event2);
        else
          this.decrementHour(event2);
        break;
      case 1:
        if (direction === 1)
          this.incrementMinute(event2);
        else
          this.decrementMinute(event2);
        break;
      case 2:
        if (direction === 1)
          this.incrementSecond(event2);
        else
          this.decrementSecond(event2);
        break;
    }
    this.updateInputfield();
  }
  clearTimePickerTimer() {
    if (this.timePickerTimer) {
      clearTimeout(this.timePickerTimer);
      this.timePickerTimer = null;
    }
  }
  decrementHour(event2) {
    let newHour = this.currentHour - this.stepHour;
    let newPM = this.pm;
    if (this.hourFormat == "24")
      newHour = newHour < 0 ? 24 + newHour : newHour;
    else if (this.hourFormat == "12") {
      if (this.currentHour === 12) {
        newPM = !this.pm;
      }
      newHour = newHour <= 0 ? 12 + newHour : newHour;
    }
    if (this.validateTime(newHour, this.currentMinute, this.currentSecond, newPM)) {
      this.currentHour = newHour;
      this.pm = newPM;
    }
    event2.preventDefault();
  }
  incrementMinute(event2) {
    let newMinute = this.currentMinute + this.stepMinute;
    newMinute = newMinute > 59 ? newMinute - 60 : newMinute;
    if (this.validateTime(this.currentHour, newMinute, this.currentSecond, this.pm)) {
      this.currentMinute = newMinute;
    }
    event2.preventDefault();
  }
  decrementMinute(event2) {
    let newMinute = this.currentMinute - this.stepMinute;
    newMinute = newMinute < 0 ? 60 + newMinute : newMinute;
    if (this.validateTime(this.currentHour, newMinute, this.currentSecond, this.pm)) {
      this.currentMinute = newMinute;
    }
    event2.preventDefault();
  }
  incrementSecond(event2) {
    let newSecond = this.currentSecond + this.stepSecond;
    newSecond = newSecond > 59 ? newSecond - 60 : newSecond;
    if (this.validateTime(this.currentHour, this.currentMinute, newSecond, this.pm)) {
      this.currentSecond = newSecond;
    }
    event2.preventDefault();
  }
  decrementSecond(event2) {
    let newSecond = this.currentSecond - this.stepSecond;
    newSecond = newSecond < 0 ? 60 + newSecond : newSecond;
    if (this.validateTime(this.currentHour, this.currentMinute, newSecond, this.pm)) {
      this.currentSecond = newSecond;
    }
    event2.preventDefault();
  }
  updateTime() {
    let value = this.value;
    if (this.isRangeSelection()) {
      value = this.value[1] || this.value[0];
    }
    if (this.isMultipleSelection()) {
      value = this.value[this.value.length - 1];
    }
    value = value ? new Date(value.getTime()) : /* @__PURE__ */ new Date();
    if (this.hourFormat == "12") {
      if (this.currentHour === 12)
        value.setHours(this.pm ? 12 : 0);
      else
        value.setHours(this.pm ? this.currentHour + 12 : this.currentHour);
    } else {
      value.setHours(this.currentHour);
    }
    value.setMinutes(this.currentMinute);
    value.setSeconds(this.currentSecond);
    if (this.isRangeSelection()) {
      if (this.value[1])
        value = [this.value[0], value];
      else
        value = [value, null];
    }
    if (this.isMultipleSelection()) {
      value = [...this.value.slice(0, -1), value];
    }
    this.updateModel(value);
    this.onSelect.emit(value);
    this.updateInputfield();
  }
  toggleAMPM(event2) {
    const newPM = !this.pm;
    if (this.validateTime(this.currentHour, this.currentMinute, this.currentSecond, newPM)) {
      this.pm = newPM;
      this.updateTime();
    }
    event2.preventDefault();
  }
  onUserInput(event2) {
    if (!this.isKeydown) {
      return;
    }
    this.isKeydown = false;
    let val = event2.target.value;
    try {
      let value = this.parseValueFromString(val);
      if (this.isValidSelection(value)) {
        this.updateModel(value);
        this.updateUI();
      }
    } catch (err) {
      let value = this.keepInvalid ? val : null;
      this.updateModel(value);
    }
    this.filled = val != null && val.length;
    this.onInput.emit(event2);
  }
  isValidSelection(value) {
    let isValid = true;
    if (this.isSingleSelection()) {
      if (!this.isSelectable(value.getDate(), value.getMonth(), value.getFullYear(), false)) {
        isValid = false;
      }
    } else if (value.every((v) => this.isSelectable(v.getDate(), v.getMonth(), v.getFullYear(), false))) {
      if (this.isRangeSelection()) {
        isValid = value.length > 1 && value[1] > value[0] ? true : false;
      }
    }
    return isValid;
  }
  parseValueFromString(text) {
    if (!text || text.trim().length === 0) {
      return null;
    }
    let value;
    if (this.isSingleSelection()) {
      value = this.parseDateTime(text);
    } else if (this.isMultipleSelection()) {
      let tokens = text.split(this.multipleSeparator);
      value = [];
      for (let token of tokens) {
        value.push(this.parseDateTime(token.trim()));
      }
    } else if (this.isRangeSelection()) {
      let tokens = text.split(" " + this.rangeSeparator + " ");
      value = [];
      for (let i = 0; i < tokens.length; i++) {
        value[i] = this.parseDateTime(tokens[i].trim());
      }
    }
    return value;
  }
  parseDateTime(text) {
    let date;
    let parts = text.split(" ");
    if (this.timeOnly) {
      date = /* @__PURE__ */ new Date();
      this.populateTime(date, parts[0], parts[1]);
    } else {
      const dateFormat = this.getDateFormat();
      if (this.showTime) {
        let ampm = this.hourFormat == "12" ? parts.pop() : null;
        let timeString = parts.pop();
        date = this.parseDate(parts.join(" "), dateFormat);
        this.populateTime(date, timeString, ampm);
      } else {
        date = this.parseDate(text, dateFormat);
      }
    }
    return date;
  }
  populateTime(value, timeString, ampm) {
    if (this.hourFormat == "12" && !ampm) {
      throw "Invalid Time";
    }
    this.pm = ampm === "PM" || ampm === "pm";
    let time = this.parseTime(timeString);
    value.setHours(time.hour);
    value.setMinutes(time.minute);
    value.setSeconds(time.second);
  }
  isValidDate(date) {
    return ObjectUtils.isDate(date) && ObjectUtils.isNotEmpty(date);
  }
  updateUI() {
    let propValue = this.value;
    if (Array.isArray(propValue)) {
      propValue = propValue[0];
    }
    let val = this.defaultDate && this.isValidDate(this.defaultDate) && !this.value ? this.defaultDate : propValue && this.isValidDate(propValue) ? propValue : /* @__PURE__ */ new Date();
    this.currentMonth = val.getMonth();
    this.currentYear = val.getFullYear();
    this.createMonths(this.currentMonth, this.currentYear);
    if (this.showTime || this.timeOnly) {
      this.setCurrentHourPM(val.getHours());
      this.currentMinute = val.getMinutes();
      this.currentSecond = val.getSeconds();
    }
  }
  showOverlay() {
    if (!this.overlayVisible) {
      this.updateUI();
      if (!this.touchUI) {
        this.preventFocus = true;
      }
      this.overlayVisible = true;
    }
  }
  hideOverlay() {
    this.overlayVisible = false;
    this.clearTimePickerTimer();
    if (this.touchUI) {
      this.disableModality();
    }
    this.cd.markForCheck();
  }
  toggle() {
    var _a;
    if (!this.inline) {
      if (!this.overlayVisible) {
        this.showOverlay();
        (_a = this.inputfieldViewChild) == null ? void 0 : _a.nativeElement.focus();
      } else {
        this.hideOverlay();
      }
    }
  }
  onOverlayAnimationStart(event2) {
    var _a;
    switch (event2.toState) {
      case "visible":
      case "visibleTouchUI":
        if (!this.inline) {
          this.overlay = event2.element;
          (_a = this.overlay) == null ? void 0 : _a.setAttribute(this.attributeSelector, "");
          this.appendOverlay();
          this.updateFocus();
          if (this.autoZIndex) {
            if (this.touchUI)
              zindexutils.set("modal", this.overlay, this.baseZIndex || this.config.zIndex.modal);
            else
              zindexutils.set("overlay", this.overlay, this.baseZIndex || this.config.zIndex.overlay);
          }
          this.alignOverlay();
          this.onShow.emit(event2);
        }
        break;
      case "void":
        this.onOverlayHide();
        this.onClose.emit(event2);
        break;
    }
  }
  onOverlayAnimationDone(event2) {
    switch (event2.toState) {
      case "visible":
      case "visibleTouchUI":
        if (!this.inline) {
          this.bindDocumentClickListener();
          this.bindDocumentResizeListener();
          this.bindScrollListener();
        }
        break;
      case "void":
        if (this.autoZIndex) {
          zindexutils.clear(event2.element);
        }
        break;
    }
  }
  appendOverlay() {
    if (this.appendTo) {
      if (this.appendTo === "body")
        this.document.body.appendChild(this.overlay);
      else
        DomHandler.appendChild(this.overlay, this.appendTo);
    }
  }
  restoreOverlayAppend() {
    if (this.overlay && this.appendTo) {
      this.el.nativeElement.appendChild(this.overlay);
    }
  }
  alignOverlay() {
    var _a, _b, _c, _d;
    if (this.touchUI) {
      this.enableModality(this.overlay);
    } else if (this.overlay) {
      if (this.appendTo) {
        if (this.view === "date") {
          this.overlay.style.width = DomHandler.getOuterWidth(this.overlay) + "px";
          this.overlay.style.minWidth = DomHandler.getOuterWidth((_a = this.inputfieldViewChild) == null ? void 0 : _a.nativeElement) + "px";
        } else {
          this.overlay.style.width = DomHandler.getOuterWidth((_b = this.inputfieldViewChild) == null ? void 0 : _b.nativeElement) + "px";
        }
        DomHandler.absolutePosition(this.overlay, (_c = this.inputfieldViewChild) == null ? void 0 : _c.nativeElement);
      } else {
        DomHandler.relativePosition(this.overlay, (_d = this.inputfieldViewChild) == null ? void 0 : _d.nativeElement);
      }
    }
  }
  enableModality(element) {
    if (!this.mask && this.touchUI) {
      this.mask = this.renderer.createElement("div");
      this.renderer.setStyle(this.mask, "zIndex", String(parseInt(element.style.zIndex) - 1));
      let maskStyleClass = "p-component-overlay p-datepicker-mask p-datepicker-mask-scrollblocker p-component-overlay p-component-overlay-enter";
      DomHandler.addMultipleClasses(this.mask, maskStyleClass);
      this.maskClickListener = this.renderer.listen(this.mask, "click", (event2) => {
        this.disableModality();
      });
      this.renderer.appendChild(this.document.body, this.mask);
      DomHandler.addClass(this.document.body, "p-overflow-hidden");
    }
  }
  disableModality() {
    if (this.mask) {
      DomHandler.addClass(this.mask, "p-component-overlay-leave");
      if (!this.animationEndListener) {
        this.animationEndListener = this.renderer.listen(this.mask, "animationend", this.destroyMask.bind(this));
      }
    }
  }
  destroyMask() {
    if (!this.mask) {
      return;
    }
    this.renderer.removeChild(this.document.body, this.mask);
    let bodyChildren = this.document.body.children;
    let hasBlockerMasks;
    for (let i = 0; i < bodyChildren.length; i++) {
      let bodyChild = bodyChildren[i];
      if (DomHandler.hasClass(bodyChild, "p-datepicker-mask-scrollblocker")) {
        hasBlockerMasks = true;
        break;
      }
    }
    if (!hasBlockerMasks) {
      DomHandler.removeClass(this.document.body, "p-overflow-hidden");
    }
    this.unbindAnimationEndListener();
    this.unbindMaskClickListener();
    this.mask = null;
  }
  unbindMaskClickListener() {
    if (this.maskClickListener) {
      this.maskClickListener();
      this.maskClickListener = null;
    }
  }
  unbindAnimationEndListener() {
    if (this.animationEndListener && this.mask) {
      this.animationEndListener();
      this.animationEndListener = null;
    }
  }
  writeValue(value) {
    this.value = value;
    if (this.value && typeof this.value === "string") {
      try {
        this.value = this.parseValueFromString(this.value);
      } catch {
        if (this.keepInvalid) {
          this.value = value;
        }
      }
    }
    this.updateInputfield();
    this.updateUI();
    this.cd.markForCheck();
  }
  registerOnChange(fn) {
    this.onModelChange = fn;
  }
  registerOnTouched(fn) {
    this.onModelTouched = fn;
  }
  setDisabledState(val) {
    this.disabled = val;
    this.cd.markForCheck();
  }
  getDateFormat() {
    return this.dateFormat || this.getTranslation("dateFormat");
  }
  getFirstDateOfWeek() {
    return this._firstDayOfWeek || this.getTranslation(TranslationKeys.FIRST_DAY_OF_WEEK);
  }
  // Ported from jquery-ui datepicker formatDate
  formatDate(date, format) {
    if (!date) {
      return "";
    }
    let iFormat;
    const lookAhead = (match) => {
      const matches = iFormat + 1 < format.length && format.charAt(iFormat + 1) === match;
      if (matches) {
        iFormat++;
      }
      return matches;
    }, formatNumber = (match, value, len) => {
      let num = "" + value;
      if (lookAhead(match)) {
        while (num.length < len) {
          num = "0" + num;
        }
      }
      return num;
    }, formatName = (match, value, shortNames, longNames) => {
      return lookAhead(match) ? longNames[value] : shortNames[value];
    };
    let output = "";
    let literal = false;
    if (date) {
      for (iFormat = 0; iFormat < format.length; iFormat++) {
        if (literal) {
          if (format.charAt(iFormat) === "'" && !lookAhead("'")) {
            literal = false;
          } else {
            output += format.charAt(iFormat);
          }
        } else {
          switch (format.charAt(iFormat)) {
            case "d":
              output += formatNumber("d", date.getDate(), 2);
              break;
            case "D":
              output += formatName("D", date.getDay(), this.getTranslation(TranslationKeys.DAY_NAMES_SHORT), this.getTranslation(TranslationKeys.DAY_NAMES));
              break;
            case "o":
              output += formatNumber("o", Math.round((new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime() - new Date(date.getFullYear(), 0, 0).getTime()) / 864e5), 3);
              break;
            case "m":
              output += formatNumber("m", date.getMonth() + 1, 2);
              break;
            case "M":
              output += formatName("M", date.getMonth(), this.getTranslation(TranslationKeys.MONTH_NAMES_SHORT), this.getTranslation(TranslationKeys.MONTH_NAMES));
              break;
            case "y":
              output += lookAhead("y") ? date.getFullYear() : (date.getFullYear() % 100 < 10 ? "0" : "") + date.getFullYear() % 100;
              break;
            case "@":
              output += date.getTime();
              break;
            case "!":
              output += date.getTime() * 1e4 + this.ticksTo1970;
              break;
            case "'":
              if (lookAhead("'")) {
                output += "'";
              } else {
                literal = true;
              }
              break;
            default:
              output += format.charAt(iFormat);
          }
        }
      }
    }
    return output;
  }
  formatTime(date) {
    if (!date) {
      return "";
    }
    let output = "";
    let hours = date.getHours();
    let minutes = date.getMinutes();
    let seconds = date.getSeconds();
    if (this.hourFormat == "12" && hours > 11 && hours != 12) {
      hours -= 12;
    }
    if (this.hourFormat == "12") {
      output += hours === 0 ? 12 : hours < 10 ? "0" + hours : hours;
    } else {
      output += hours < 10 ? "0" + hours : hours;
    }
    output += ":";
    output += minutes < 10 ? "0" + minutes : minutes;
    if (this.showSeconds) {
      output += ":";
      output += seconds < 10 ? "0" + seconds : seconds;
    }
    if (this.hourFormat == "12") {
      output += date.getHours() > 11 ? " PM" : " AM";
    }
    return output;
  }
  parseTime(value) {
    let tokens = value.split(":");
    let validTokenLength = this.showSeconds ? 3 : 2;
    if (tokens.length !== validTokenLength) {
      throw "Invalid time";
    }
    let h = parseInt(tokens[0]);
    let m = parseInt(tokens[1]);
    let s = this.showSeconds ? parseInt(tokens[2]) : null;
    if (isNaN(h) || isNaN(m) || h > 23 || m > 59 || this.hourFormat == "12" && h > 12 || this.showSeconds && (isNaN(s) || s > 59)) {
      throw "Invalid time";
    } else {
      if (this.hourFormat == "12") {
        if (h !== 12 && this.pm) {
          h += 12;
        } else if (!this.pm && h === 12) {
          h -= 12;
        }
      }
      return {
        hour: h,
        minute: m,
        second: s
      };
    }
  }
  // Ported from jquery-ui datepicker parseDate
  parseDate(value, format) {
    if (format == null || value == null) {
      throw "Invalid arguments";
    }
    value = typeof value === "object" ? value.toString() : value + "";
    if (value === "") {
      return null;
    }
    let iFormat, dim, extra, iValue = 0, shortYearCutoff = typeof this.shortYearCutoff !== "string" ? this.shortYearCutoff : (/* @__PURE__ */ new Date()).getFullYear() % 100 + parseInt(this.shortYearCutoff, 10), year = -1, month = -1, day = -1, doy = -1, literal = false, date, lookAhead = (match) => {
      let matches = iFormat + 1 < format.length && format.charAt(iFormat + 1) === match;
      if (matches) {
        iFormat++;
      }
      return matches;
    }, getNumber = (match) => {
      let isDoubled = lookAhead(match), size = match === "@" ? 14 : match === "!" ? 20 : match === "y" && isDoubled ? 4 : match === "o" ? 3 : 2, minSize = match === "y" ? size : 1, digits = new RegExp("^\\d{" + minSize + "," + size + "}"), num = value.substring(iValue).match(digits);
      if (!num) {
        throw "Missing number at position " + iValue;
      }
      iValue += num[0].length;
      return parseInt(num[0], 10);
    }, getName = (match, shortNames, longNames) => {
      let index = -1;
      let arr = lookAhead(match) ? longNames : shortNames;
      let names = [];
      for (let i = 0; i < arr.length; i++) {
        names.push([i, arr[i]]);
      }
      names.sort((a, b) => {
        return -(a[1].length - b[1].length);
      });
      for (let i = 0; i < names.length; i++) {
        let name = names[i][1];
        if (value.substr(iValue, name.length).toLowerCase() === name.toLowerCase()) {
          index = names[i][0];
          iValue += name.length;
          break;
        }
      }
      if (index !== -1) {
        return index + 1;
      } else {
        throw "Unknown name at position " + iValue;
      }
    }, checkLiteral = () => {
      if (value.charAt(iValue) !== format.charAt(iFormat)) {
        throw "Unexpected literal at position " + iValue;
      }
      iValue++;
    };
    if (this.view === "month") {
      day = 1;
    }
    for (iFormat = 0; iFormat < format.length; iFormat++) {
      if (literal) {
        if (format.charAt(iFormat) === "'" && !lookAhead("'")) {
          literal = false;
        } else {
          checkLiteral();
        }
      } else {
        switch (format.charAt(iFormat)) {
          case "d":
            day = getNumber("d");
            break;
          case "D":
            getName("D", this.getTranslation(TranslationKeys.DAY_NAMES_SHORT), this.getTranslation(TranslationKeys.DAY_NAMES));
            break;
          case "o":
            doy = getNumber("o");
            break;
          case "m":
            month = getNumber("m");
            break;
          case "M":
            month = getName("M", this.getTranslation(TranslationKeys.MONTH_NAMES_SHORT), this.getTranslation(TranslationKeys.MONTH_NAMES));
            break;
          case "y":
            year = getNumber("y");
            break;
          case "@":
            date = new Date(getNumber("@"));
            year = date.getFullYear();
            month = date.getMonth() + 1;
            day = date.getDate();
            break;
          case "!":
            date = new Date((getNumber("!") - this.ticksTo1970) / 1e4);
            year = date.getFullYear();
            month = date.getMonth() + 1;
            day = date.getDate();
            break;
          case "'":
            if (lookAhead("'")) {
              checkLiteral();
            } else {
              literal = true;
            }
            break;
          default:
            checkLiteral();
        }
      }
    }
    if (iValue < value.length) {
      extra = value.substr(iValue);
      if (!/^\s+/.test(extra)) {
        throw "Extra/unparsed characters found in date: " + extra;
      }
    }
    if (year === -1) {
      year = (/* @__PURE__ */ new Date()).getFullYear();
    } else if (year < 100) {
      year += (/* @__PURE__ */ new Date()).getFullYear() - (/* @__PURE__ */ new Date()).getFullYear() % 100 + (year <= shortYearCutoff ? 0 : -100);
    }
    if (doy > -1) {
      month = 1;
      day = doy;
      do {
        dim = this.getDaysCountInMonth(year, month - 1);
        if (day <= dim) {
          break;
        }
        month++;
        day -= dim;
      } while (true);
    }
    if (this.view === "year") {
      month = month === -1 ? 1 : month;
      day = day === -1 ? 1 : day;
    }
    date = this.daylightSavingAdjust(new Date(year, month - 1, day));
    if (date.getFullYear() !== year || date.getMonth() + 1 !== month || date.getDate() !== day) {
      throw "Invalid date";
    }
    return date;
  }
  daylightSavingAdjust(date) {
    if (!date) {
      return null;
    }
    date.setHours(date.getHours() > 12 ? date.getHours() + 2 : 0);
    return date;
  }
  updateFilledState() {
    this.filled = this.inputFieldValue && this.inputFieldValue != "";
  }
  onTodayButtonClick(event2) {
    let date = /* @__PURE__ */ new Date();
    let dateMeta = {
      day: date.getDate(),
      month: date.getMonth(),
      year: date.getFullYear(),
      otherMonth: date.getMonth() !== this.currentMonth || date.getFullYear() !== this.currentYear,
      today: true,
      selectable: true
    };
    this.onDateSelect(event2, dateMeta);
    this.onTodayClick.emit(event2);
  }
  onClearButtonClick(event2) {
    this.updateModel(null);
    this.updateInputfield();
    this.hideOverlay();
    this.onClearClick.emit(event2);
  }
  createResponsiveStyle() {
    if (this.numberOfMonths > 1 && this.responsiveOptions) {
      if (!this.responsiveStyleElement) {
        this.responsiveStyleElement = this.renderer.createElement("style");
        this.responsiveStyleElement.type = "text/css";
        this.renderer.appendChild(this.document.body, this.responsiveStyleElement);
      }
      let innerHTML = "";
      if (this.responsiveOptions) {
        let responsiveOptions = [...this.responsiveOptions].filter((o) => !!(o.breakpoint && o.numMonths)).sort((o1, o2) => -1 * o1.breakpoint.localeCompare(o2.breakpoint, void 0, {
          numeric: true
        }));
        for (let i = 0; i < responsiveOptions.length; i++) {
          let {
            breakpoint,
            numMonths
          } = responsiveOptions[i];
          let styles = `
                        .p-datepicker[${this.attributeSelector}] .p-datepicker-group:nth-child(${numMonths}) .p-datepicker-next {
                            display: inline-flex !important;
                        }
                    `;
          for (let j = numMonths; j < this.numberOfMonths; j++) {
            styles += `
                            .p-datepicker[${this.attributeSelector}] .p-datepicker-group:nth-child(${j + 1}) {
                                display: none !important;
                            }
                        `;
          }
          innerHTML += `
                        @media screen and (max-width: ${breakpoint}) {
                            ${styles}
                        }
                    `;
        }
      }
      this.responsiveStyleElement.innerHTML = innerHTML;
    }
  }
  destroyResponsiveStyleElement() {
    if (this.responsiveStyleElement) {
      this.responsiveStyleElement.remove();
      this.responsiveStyleElement = null;
    }
  }
  bindDocumentClickListener() {
    if (!this.documentClickListener) {
      this.zone.runOutsideAngular(() => {
        const documentTarget = this.el ? this.el.nativeElement.ownerDocument : this.document;
        this.documentClickListener = this.renderer.listen(documentTarget, "mousedown", (event2) => {
          if (this.isOutsideClicked(event2) && this.overlayVisible) {
            this.zone.run(() => {
              this.hideOverlay();
              this.onClickOutside.emit(event2);
              this.cd.markForCheck();
            });
          }
        });
      });
    }
  }
  unbindDocumentClickListener() {
    if (this.documentClickListener) {
      this.documentClickListener();
      this.documentClickListener = null;
    }
  }
  bindDocumentResizeListener() {
    if (!this.documentResizeListener && !this.touchUI) {
      this.documentResizeListener = this.renderer.listen(this.window, "resize", this.onWindowResize.bind(this));
    }
  }
  unbindDocumentResizeListener() {
    if (this.documentResizeListener) {
      this.documentResizeListener();
      this.documentResizeListener = null;
    }
  }
  bindScrollListener() {
    var _a;
    if (!this.scrollHandler) {
      this.scrollHandler = new ConnectedOverlayScrollHandler((_a = this.containerViewChild) == null ? void 0 : _a.nativeElement, () => {
        if (this.overlayVisible) {
          this.hideOverlay();
        }
      });
    }
    this.scrollHandler.bindScrollListener();
  }
  unbindScrollListener() {
    if (this.scrollHandler) {
      this.scrollHandler.unbindScrollListener();
    }
  }
  isOutsideClicked(event2) {
    return !(this.el.nativeElement.isSameNode(event2.target) || this.isNavIconClicked(event2) || this.el.nativeElement.contains(event2.target) || this.overlay && this.overlay.contains(event2.target));
  }
  isNavIconClicked(event2) {
    return DomHandler.hasClass(event2.target, "p-datepicker-prev") || DomHandler.hasClass(event2.target, "p-datepicker-prev-icon") || DomHandler.hasClass(event2.target, "p-datepicker-next") || DomHandler.hasClass(event2.target, "p-datepicker-next-icon");
  }
  onWindowResize() {
    if (this.overlayVisible && !DomHandler.isTouchDevice()) {
      this.hideOverlay();
    }
  }
  onOverlayHide() {
    this.currentView = this.view;
    if (this.mask) {
      this.destroyMask();
    }
    this.unbindDocumentClickListener();
    this.unbindDocumentResizeListener();
    this.unbindScrollListener();
    this.overlay = null;
    this.onModelTouched();
  }
  ngOnDestroy() {
    if (this.scrollHandler) {
      this.scrollHandler.destroy();
      this.scrollHandler = null;
    }
    if (this.translationSubscription) {
      this.translationSubscription.unsubscribe();
    }
    if (this.overlay && this.autoZIndex) {
      zindexutils.clear(this.overlay);
    }
    this.destroyResponsiveStyleElement();
    this.clearTimePickerTimer();
    this.restoreOverlayAppend();
    this.onOverlayHide();
  }
};
var Calendar = _Calendar;
__publicField(Calendar, "ɵfac", function Calendar_Factory(t) {
  return new (t || _Calendar)(ɵɵdirectiveInject(DOCUMENT), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(NgZone), ɵɵdirectiveInject(PrimeNGConfig), ɵɵdirectiveInject(OverlayService));
});
__publicField(Calendar, "ɵcmp", ɵɵdefineComponent({
  type: _Calendar,
  selectors: [["p-calendar"]],
  contentQueries: function Calendar_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  viewQuery: function Calendar_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c0, 5);
      ɵɵviewQuery(_c1, 5);
      ɵɵviewQuery(_c2, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.containerViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.inputfieldViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.content = _t.first);
    }
  },
  hostAttrs: [1, "p-element", "p-inputwrapper"],
  hostVars: 6,
  hostBindings: function Calendar_HostBindings(rf, ctx) {
    if (rf & 2) {
      ɵɵclassProp("p-inputwrapper-filled", ctx.filled)("p-inputwrapper-focus", ctx.focus)("p-calendar-clearable", ctx.showClear && !ctx.disabled);
    }
  },
  inputs: {
    style: "style",
    styleClass: "styleClass",
    inputStyle: "inputStyle",
    inputId: "inputId",
    name: "name",
    inputStyleClass: "inputStyleClass",
    placeholder: "placeholder",
    ariaLabelledBy: "ariaLabelledBy",
    iconAriaLabel: "iconAriaLabel",
    disabled: "disabled",
    dateFormat: "dateFormat",
    multipleSeparator: "multipleSeparator",
    rangeSeparator: "rangeSeparator",
    inline: "inline",
    showOtherMonths: "showOtherMonths",
    selectOtherMonths: "selectOtherMonths",
    showIcon: "showIcon",
    icon: "icon",
    appendTo: "appendTo",
    readonlyInput: "readonlyInput",
    shortYearCutoff: "shortYearCutoff",
    monthNavigator: "monthNavigator",
    yearNavigator: "yearNavigator",
    hourFormat: "hourFormat",
    timeOnly: "timeOnly",
    stepHour: "stepHour",
    stepMinute: "stepMinute",
    stepSecond: "stepSecond",
    showSeconds: "showSeconds",
    required: "required",
    showOnFocus: "showOnFocus",
    showWeek: "showWeek",
    showClear: "showClear",
    dataType: "dataType",
    selectionMode: "selectionMode",
    maxDateCount: "maxDateCount",
    showButtonBar: "showButtonBar",
    todayButtonStyleClass: "todayButtonStyleClass",
    clearButtonStyleClass: "clearButtonStyleClass",
    autoZIndex: "autoZIndex",
    baseZIndex: "baseZIndex",
    panelStyleClass: "panelStyleClass",
    panelStyle: "panelStyle",
    keepInvalid: "keepInvalid",
    hideOnDateTimeSelect: "hideOnDateTimeSelect",
    touchUI: "touchUI",
    timeSeparator: "timeSeparator",
    focusTrap: "focusTrap",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions",
    tabindex: "tabindex",
    minDate: "minDate",
    maxDate: "maxDate",
    disabledDates: "disabledDates",
    disabledDays: "disabledDays",
    yearRange: "yearRange",
    showTime: "showTime",
    responsiveOptions: "responsiveOptions",
    numberOfMonths: "numberOfMonths",
    firstDayOfWeek: "firstDayOfWeek",
    locale: "locale",
    view: "view",
    defaultDate: "defaultDate"
  },
  outputs: {
    onFocus: "onFocus",
    onBlur: "onBlur",
    onClose: "onClose",
    onSelect: "onSelect",
    onClear: "onClear",
    onInput: "onInput",
    onTodayClick: "onTodayClick",
    onClearClick: "onClearClick",
    onMonthChange: "onMonthChange",
    onYearChange: "onYearChange",
    onClickOutside: "onClickOutside",
    onShow: "onShow"
  },
  features: [ɵɵProvidersFeature([CALENDAR_VALUE_ACCESSOR])],
  ngContentSelectors: _c14,
  decls: 4,
  vars: 11,
  consts: [[3, "ngClass", "ngStyle"], ["container", ""], [3, "ngIf"], [3, "class", "ngStyle", "ngClass", "click", 4, "ngIf"], ["type", "text", "autocomplete", "off", 3, "value", "readonly", "ngStyle", "placeholder", "disabled", "ngClass", "focus", "keydown", "click", "blur", "input"], ["inputfield", ""], [4, "ngIf"], ["type", "button", "pButton", "", "pRipple", "", "class", "p-datepicker-trigger p-button-icon-only", "tabindex", "0", 3, "disabled", "click", 4, "ngIf"], [3, "styleClass", "click", 4, "ngIf"], ["class", "p-calendar-clear-icon", 3, "click", 4, "ngIf"], [3, "styleClass", "click"], [1, "p-calendar-clear-icon", 3, "click"], [4, "ngTemplateOutlet"], ["type", "button", "pButton", "", "pRipple", "", "tabindex", "0", 1, "p-datepicker-trigger", "p-button-icon-only", 3, "disabled", "click"], [3, "ngClass", 4, "ngIf"], [3, "ngClass"], [3, "ngStyle", "ngClass", "click"], ["contentWrapper", ""], ["class", "p-timepicker", 4, "ngIf"], ["class", "p-datepicker-buttonbar", 4, "ngIf"], [1, "p-datepicker-group-container"], ["class", "p-datepicker-group", 4, "ngFor", "ngForOf"], ["class", "p-monthpicker", 4, "ngIf"], ["class", "p-yearpicker", 4, "ngIf"], [1, "p-datepicker-group"], [1, "p-datepicker-header"], ["class", "p-datepicker-prev p-link", "type", "button", "pRipple", "", 3, "keydown", "click", 4, "ngIf"], [1, "p-datepicker-title"], ["type", "button", "class", "p-datepicker-month p-link", 3, "disabled", "click", "keydown", 4, "ngIf"], ["type", "button", "class", "p-datepicker-year p-link", 3, "disabled", "click", "keydown", 4, "ngIf"], ["class", "p-datepicker-decade", 4, "ngIf"], ["type", "button", "pRipple", "", 1, "p-datepicker-next", "p-link", 3, "keydown", "click"], [3, "styleClass", 4, "ngIf"], ["class", "p-datepicker-next-icon", 4, "ngIf"], ["class", "p-datepicker-calendar-container", 4, "ngIf"], ["type", "button", "pRipple", "", 1, "p-datepicker-prev", "p-link", 3, "keydown", "click"], ["class", "p-datepicker-prev-icon", 4, "ngIf"], [3, "styleClass"], [1, "p-datepicker-prev-icon"], ["type", "button", 1, "p-datepicker-month", "p-link", 3, "disabled", "click", "keydown"], ["type", "button", 1, "p-datepicker-year", "p-link", 3, "disabled", "click", "keydown"], [1, "p-datepicker-decade"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "p-datepicker-next-icon"], [1, "p-datepicker-calendar-container"], [1, "p-datepicker-calendar"], ["class", "p-datepicker-weekheader p-disabled", 4, "ngIf"], ["scope", "col", 4, "ngFor", "ngForOf"], [4, "ngFor", "ngForOf"], [1, "p-datepicker-weekheader", "p-disabled"], ["scope", "col"], ["class", "p-datepicker-weeknumber", 4, "ngIf"], [3, "ngClass", 4, "ngFor", "ngForOf"], [1, "p-datepicker-weeknumber"], [1, "p-disabled"], ["draggable", "false", "pRipple", "", 3, "ngClass", "click", "keydown"], [1, "p-monthpicker"], ["class", "p-monthpicker-month", "pRipple", "", 3, "ngClass", "click", "keydown", 4, "ngFor", "ngForOf"], ["pRipple", "", 1, "p-monthpicker-month", 3, "ngClass", "click", "keydown"], [1, "p-yearpicker"], ["class", "p-yearpicker-year", "pRipple", "", 3, "ngClass", "click", "keydown", 4, "ngFor", "ngForOf"], ["pRipple", "", 1, "p-yearpicker-year", 3, "ngClass", "click", "keydown"], [1, "p-timepicker"], [1, "p-hour-picker"], ["type", "button", "pRipple", "", 1, "p-link", 3, "keydown", "keydown.enter", "keydown.space", "mousedown", "mouseup", "keyup.enter", "keyup.space", "mouseleave"], [1, "p-separator"], [1, "p-minute-picker"], ["class", "p-separator", 4, "ngIf"], ["class", "p-second-picker", 4, "ngIf"], ["class", "p-ampm-picker", 4, "ngIf"], [1, "p-second-picker"], [1, "p-ampm-picker"], ["type", "button", "pRipple", "", 1, "p-link", 3, "keydown", "click", "keydown.enter"], [1, "p-datepicker-buttonbar"], ["type", "button", "pButton", "", "pRipple", "", 3, "label", "ngClass", "keydown", "click"]],
  template: function Calendar_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵprojectionDef(_c12);
      ɵɵelementStart(0, "span", 0, 1);
      ɵɵtemplate(2, Calendar_ng_template_2_Template, 4, 17, "ng-template", 2);
      ɵɵtemplate(3, Calendar_div_3_Template, 9, 28, "div", 3);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.styleClass);
      ɵɵproperty("ngClass", ɵɵpureFunction4(6, _c13, ctx.showIcon, ctx.timeOnly, ctx.disabled, ctx.focus))("ngStyle", ctx.style);
      ɵɵadvance(2);
      ɵɵproperty("ngIf", !ctx.inline);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.inline || ctx.overlayVisible);
    }
  },
  dependencies: function() {
    return [NgClass, NgForOf, NgIf, NgTemplateOutlet, NgStyle, ButtonDirective, Ripple, ChevronLeftIcon, ChevronRightIcon, ChevronUpIcon, ChevronDownIcon, TimesIcon, CalendarIcon];
  },
  styles: [".p-calendar{position:relative;display:inline-flex;max-width:100%}.p-calendar .p-inputtext{flex:1 1 auto;width:1%}.p-calendar-w-btn .p-inputtext{border-top-right-radius:0;border-bottom-right-radius:0}.p-calendar-w-btn .p-datepicker-trigger{border-top-left-radius:0;border-bottom-left-radius:0}.p-fluid .p-calendar{display:flex}.p-fluid .p-calendar .p-inputtext{width:1%}.p-calendar .p-datepicker{min-width:100%}.p-datepicker{width:auto;position:absolute;top:0;left:0}.p-datepicker-inline{display:inline-block;position:static;overflow-x:auto}.p-datepicker-header{display:flex;align-items:center;justify-content:space-between}.p-datepicker-header .p-datepicker-title{margin:0 auto}.p-datepicker-prev,.p-datepicker-next{cursor:pointer;display:inline-flex;justify-content:center;align-items:center;overflow:hidden;position:relative}.p-datepicker-multiple-month .p-datepicker-group-container .p-datepicker-group{flex:1 1 auto}.p-datepicker-multiple-month .p-datepicker-group-container{display:flex}.p-datepicker table{width:100%;border-collapse:collapse}.p-datepicker td>span{display:flex;justify-content:center;align-items:center;cursor:pointer;margin:0 auto;overflow:hidden;position:relative}.p-monthpicker-month{width:33.3%;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;overflow:hidden;position:relative}.p-datepicker-buttonbar{display:flex;justify-content:space-between;align-items:center}.p-timepicker{display:flex;justify-content:center;align-items:center}.p-timepicker button{display:flex;align-items:center;justify-content:center;cursor:pointer;overflow:hidden;position:relative}.p-timepicker>div{display:flex;align-items:center;flex-direction:column}.p-datepicker-touch-ui,.p-calendar .p-datepicker-touch-ui{position:fixed;top:50%;left:50%;min-width:80vw;transform:translate(-50%,-50%)}.p-yearpicker-year{width:50%;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;overflow:hidden;position:relative}.p-calendar-clear-icon{position:absolute;top:50%;margin-top:-.5rem;cursor:pointer}.p-calendar-clearable{position:relative}\n"],
  encapsulation: 2,
  data: {
    animation: [trigger("overlayAnimation", [state("visibleTouchUI", style({
      transform: "translate(-50%,-50%)",
      opacity: 1
    })), transition("void => visible", [style({
      opacity: 0,
      transform: "scaleY(0.8)"
    }), animate("{{showTransitionParams}}", style({
      opacity: 1,
      transform: "*"
    }))]), transition("visible => void", [animate("{{hideTransitionParams}}", style({
      opacity: 0
    }))]), transition("void => visibleTouchUI", [style({
      opacity: 0,
      transform: "translate3d(-50%, -40%, 0) scale(0.9)"
    }), animate("{{showTransitionParams}}")]), transition("visibleTouchUI => void", [animate("{{hideTransitionParams}}", style({
      opacity: 0,
      transform: "translate3d(-50%, -40%, 0) scale(0.9)"
    }))])])]
  },
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Calendar, [{
    type: Component,
    args: [{
      selector: "p-calendar",
      template: `
        <span #container [ngClass]="{ 'p-calendar': true, 'p-calendar-w-btn': showIcon, 'p-calendar-timeonly': timeOnly, 'p-calendar-disabled': disabled, 'p-focus': focus }" [ngStyle]="style" [class]="styleClass">
            <ng-template [ngIf]="!inline">
                <input
                    #inputfield
                    type="text"
                    [attr.id]="inputId"
                    [attr.name]="name"
                    [attr.required]="required"
                    [attr.aria-required]="required"
                    [value]="inputFieldValue"
                    (focus)="onInputFocus($event)"
                    (keydown)="onInputKeydown($event)"
                    (click)="onInputClick()"
                    (blur)="onInputBlur($event)"
                    [readonly]="readonlyInput"
                    (input)="onUserInput($event)"
                    [ngStyle]="inputStyle"
                    [class]="inputStyleClass"
                    [placeholder]="placeholder || ''"
                    [disabled]="disabled"
                    [attr.tabindex]="tabindex"
                    [attr.inputmode]="touchUI ? 'off' : null"
                    [ngClass]="'p-inputtext p-component'"
                    autocomplete="off"
                    [attr.aria-labelledby]="ariaLabelledBy"
                />
                <ng-container *ngIf="showClear && !disabled && value != null">
                    <TimesIcon *ngIf="!clearIconTemplate" [styleClass]="'p-calendar-clear-icon'" (click)="clear()" />
                    <span *ngIf="clearIconTemplate" class="p-calendar-clear-icon" (click)="clear()">
                        <ng-template *ngTemplateOutlet="clearIconTemplate"></ng-template>
                    </span>
                </ng-container>
                <button type="button" [attr.aria-label]="iconAriaLabel" pButton pRipple *ngIf="showIcon" (click)="onButtonClick($event, inputfield)" class="p-datepicker-trigger p-button-icon-only" [disabled]="disabled" tabindex="0">
                    <span *ngIf="icon" [ngClass]="icon"></span>
                    <ng-container *ngIf="!icon">
                        <CalendarIcon *ngIf="!triggerIconTemplate" />
                        <ng-template *ngTemplateOutlet="triggerIconTemplate"></ng-template>
                    </ng-container>
                </button>
            </ng-template>
            <div
                #contentWrapper
                [class]="panelStyleClass"
                [ngStyle]="panelStyle"
                [ngClass]="{
                    'p-datepicker p-component': true,
                    'p-datepicker-inline': inline,
                    'p-disabled': disabled,
                    'p-datepicker-timeonly': timeOnly,
                    'p-datepicker-multiple-month': this.numberOfMonths > 1,
                    'p-datepicker-monthpicker': view === 'month',
                    'p-datepicker-touch-ui': touchUI
                }"
                [@overlayAnimation]="
                    touchUI
                        ? { value: 'visibleTouchUI', params: { showTransitionParams: showTransitionOptions, hideTransitionParams: hideTransitionOptions } }
                        : { value: 'visible', params: { showTransitionParams: showTransitionOptions, hideTransitionParams: hideTransitionOptions } }
                "
                [@.disabled]="inline === true"
                (@overlayAnimation.start)="onOverlayAnimationStart($event)"
                (@overlayAnimation.done)="onOverlayAnimationDone($event)"
                (click)="onOverlayClick($event)"
                *ngIf="inline || overlayVisible"
            >
                <ng-content select="p-header"></ng-content>
                <ng-container *ngTemplateOutlet="headerTemplate"></ng-container>
                <ng-container *ngIf="!timeOnly">
                    <div class="p-datepicker-group-container">
                        <div class="p-datepicker-group" *ngFor="let month of months; let i = index">
                            <div class="p-datepicker-header">
                                <button (keydown)="onContainerButtonKeydown($event)" class="p-datepicker-prev p-link" (click)="onPrevButtonClick($event)" *ngIf="i === 0" type="button" pRipple>
                                    <ChevronLeftIcon [styleClass]="'p-datepicker-prev-icon'" *ngIf="!previousIconTemplate" />
                                    <span *ngIf="previousIconTemplate" class="p-datepicker-prev-icon">
                                        <ng-template *ngTemplateOutlet="previousIconTemplate"></ng-template>
                                    </span>
                                </button>
                                <div class="p-datepicker-title">
                                    <button type="button" (click)="switchToMonthView($event)" (keydown)="onContainerButtonKeydown($event)" *ngIf="currentView === 'date'" class="p-datepicker-month p-link" [disabled]="switchViewButtonDisabled()">
                                        {{ getMonthName(month.month) }}
                                    </button>
                                    <button type="button" (click)="switchToYearView($event)" (keydown)="onContainerButtonKeydown($event)" *ngIf="currentView !== 'year'" class="p-datepicker-year p-link" [disabled]="switchViewButtonDisabled()">
                                        {{ getYear(month) }}
                                    </button>
                                    <span class="p-datepicker-decade" *ngIf="currentView === 'year'">
                                        <ng-container *ngIf="!decadeTemplate">{{ yearPickerValues()[0] }} - {{ yearPickerValues()[yearPickerValues().length - 1] }}</ng-container>
                                        <ng-container *ngTemplateOutlet="decadeTemplate; context: { $implicit: yearPickerValues }"></ng-container>
                                    </span>
                                </div>
                                <button
                                    (keydown)="onContainerButtonKeydown($event)"
                                    class="p-datepicker-next p-link"
                                    (click)="onNextButtonClick($event)"
                                    [style.display]="numberOfMonths === 1 ? 'inline-flex' : i === numberOfMonths - 1 ? 'inline-flex' : 'none'"
                                    type="button"
                                    pRipple
                                >
                                    <ChevronRightIcon [styleClass]="'p-datepicker-next-icon'" *ngIf="!nextIconTemplate" />
                                    <span *ngIf="nextIconTemplate" class="p-datepicker-next-icon">
                                        <ng-template *ngTemplateOutlet="nextIconTemplate"></ng-template>
                                    </span>
                                </button>
                            </div>
                            <div class="p-datepicker-calendar-container" *ngIf="currentView === 'date'">
                                <table class="p-datepicker-calendar">
                                    <thead>
                                        <tr>
                                            <th *ngIf="showWeek" class="p-datepicker-weekheader p-disabled">
                                                <span>{{ getTranslation('weekHeader') }}</span>
                                            </th>
                                            <th scope="col" *ngFor="let weekDay of weekDays; let begin = first; let end = last">
                                                <span>{{ weekDay }}</span>
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr *ngFor="let week of month.dates; let j = index">
                                            <td *ngIf="showWeek" class="p-datepicker-weeknumber">
                                                <span class="p-disabled">
                                                    {{ month.weekNumbers[j] }}
                                                </span>
                                            </td>
                                            <td *ngFor="let date of week" [ngClass]="{ 'p-datepicker-other-month': date.otherMonth, 'p-datepicker-today': date.today }">
                                                <ng-container *ngIf="date.otherMonth ? showOtherMonths : true">
                                                    <span [ngClass]="{ 'p-highlight': isSelected(date), 'p-disabled': !date.selectable }" (click)="onDateSelect($event, date)" draggable="false" (keydown)="onDateCellKeydown($event, date, i)" pRipple>
                                                        <ng-container *ngIf="!dateTemplate">{{ date.day }}</ng-container>
                                                        <ng-container *ngTemplateOutlet="dateTemplate; context: { $implicit: date }"></ng-container>
                                                    </span>
                                                </ng-container>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="p-monthpicker" *ngIf="currentView === 'month'">
                        <span
                            *ngFor="let m of monthPickerValues(); let i = index"
                            (click)="onMonthSelect($event, i)"
                            (keydown)="onMonthCellKeydown($event, i)"
                            class="p-monthpicker-month"
                            [ngClass]="{ 'p-highlight': isMonthSelected(i), 'p-disabled': isMonthDisabled(i) }"
                            pRipple
                        >
                            {{ m }}
                        </span>
                    </div>
                    <div class="p-yearpicker" *ngIf="currentView === 'year'">
                        <span *ngFor="let y of yearPickerValues()" (click)="onYearSelect($event, y)" (keydown)="onYearCellKeydown($event, y)" class="p-yearpicker-year" [ngClass]="{ 'p-highlight': isYearSelected(y) }" pRipple>
                            {{ y }}
                        </span>
                    </div>
                </ng-container>
                <div class="p-timepicker" *ngIf="(showTime || timeOnly) && currentView === 'date'">
                    <div class="p-hour-picker">
                        <button
                            class="p-link"
                            type="button"
                            (keydown)="onContainerButtonKeydown($event)"
                            (keydown.enter)="incrementHour($event)"
                            (keydown.space)="incrementHour($event)"
                            (mousedown)="onTimePickerElementMouseDown($event, 0, 1)"
                            (mouseup)="onTimePickerElementMouseUp($event)"
                            (keyup.enter)="onTimePickerElementMouseUp($event)"
                            (keyup.space)="onTimePickerElementMouseUp($event)"
                            (mouseleave)="onTimePickerElementMouseLeave()"
                            pRipple
                        >
                            <ChevronUpIcon *ngIf="!incrementIconTemplate" />
                            <ng-template *ngTemplateOutlet="incrementIconTemplate"></ng-template>
                        </button>
                        <span><ng-container *ngIf="currentHour < 10">0</ng-container>{{ currentHour }}</span>
                        <button
                            class="p-link"
                            type="button"
                            (keydown)="onContainerButtonKeydown($event)"
                            (keydown.enter)="decrementHour($event)"
                            (keydown.space)="decrementHour($event)"
                            (mousedown)="onTimePickerElementMouseDown($event, 0, -1)"
                            (mouseup)="onTimePickerElementMouseUp($event)"
                            (keyup.enter)="onTimePickerElementMouseUp($event)"
                            (keyup.space)="onTimePickerElementMouseUp($event)"
                            (mouseleave)="onTimePickerElementMouseLeave()"
                            pRipple
                        >
                            <ChevronDownIcon *ngIf="!decrementIconTemplate" />
                            <ng-template *ngTemplateOutlet="decrementIconTemplate"></ng-template>
                        </button>
                    </div>
                    <div class="p-separator">
                        <span>{{ timeSeparator }}</span>
                    </div>
                    <div class="p-minute-picker">
                        <button
                            class="p-link"
                            type="button"
                            (keydown)="onContainerButtonKeydown($event)"
                            (keydown.enter)="incrementMinute($event)"
                            (keydown.space)="incrementMinute($event)"
                            (mousedown)="onTimePickerElementMouseDown($event, 1, 1)"
                            (mouseup)="onTimePickerElementMouseUp($event)"
                            (keyup.enter)="onTimePickerElementMouseUp($event)"
                            (keyup.space)="onTimePickerElementMouseUp($event)"
                            (mouseleave)="onTimePickerElementMouseLeave()"
                            pRipple
                        >
                            <ChevronUpIcon *ngIf="!incrementIconTemplate" />
                            <ng-template *ngTemplateOutlet="incrementIconTemplate"></ng-template>
                        </button>
                        <span><ng-container *ngIf="currentMinute < 10">0</ng-container>{{ currentMinute }}</span>
                        <button
                            class="p-link"
                            type="button"
                            (keydown)="onContainerButtonKeydown($event)"
                            (keydown.enter)="decrementMinute($event)"
                            (keydown.space)="decrementMinute($event)"
                            (mousedown)="onTimePickerElementMouseDown($event, 1, -1)"
                            (mouseup)="onTimePickerElementMouseUp($event)"
                            (keyup.enter)="onTimePickerElementMouseUp($event)"
                            (keyup.space)="onTimePickerElementMouseUp($event)"
                            (mouseleave)="onTimePickerElementMouseLeave()"
                            pRipple
                        >
                            <ChevronDownIcon *ngIf="!decrementIconTemplate" />
                            <ng-template *ngTemplateOutlet="decrementIconTemplate"></ng-template>
                        </button>
                    </div>
                    <div class="p-separator" *ngIf="showSeconds">
                        <span>{{ timeSeparator }}</span>
                    </div>
                    <div class="p-second-picker" *ngIf="showSeconds">
                        <button
                            class="p-link"
                            type="button"
                            (keydown)="onContainerButtonKeydown($event)"
                            (keydown.enter)="incrementSecond($event)"
                            (keydown.space)="incrementSecond($event)"
                            (mousedown)="onTimePickerElementMouseDown($event, 2, 1)"
                            (mouseup)="onTimePickerElementMouseUp($event)"
                            (keyup.enter)="onTimePickerElementMouseUp($event)"
                            (keyup.space)="onTimePickerElementMouseUp($event)"
                            (mouseleave)="onTimePickerElementMouseLeave()"
                            pRipple
                        >
                            <ChevronUpIcon *ngIf="!incrementIconTemplate" />
                            <ng-template *ngTemplateOutlet="incrementIconTemplate"></ng-template>
                        </button>
                        <span><ng-container *ngIf="currentSecond < 10">0</ng-container>{{ currentSecond }}</span>
                        <button
                            class="p-link"
                            type="button"
                            (keydown)="onContainerButtonKeydown($event)"
                            (keydown.enter)="decrementSecond($event)"
                            (keydown.space)="decrementSecond($event)"
                            (mousedown)="onTimePickerElementMouseDown($event, 2, -1)"
                            (mouseup)="onTimePickerElementMouseUp($event)"
                            (keyup.enter)="onTimePickerElementMouseUp($event)"
                            (keyup.space)="onTimePickerElementMouseUp($event)"
                            (mouseleave)="onTimePickerElementMouseLeave()"
                            pRipple
                        >
                            <ChevronDownIcon *ngIf="!decrementIconTemplate" />
                            <ng-template *ngTemplateOutlet="decrementIconTemplate"></ng-template>
                        </button>
                    </div>
                    <div class="p-ampm-picker" *ngIf="hourFormat == '12'">
                        <button class="p-link" type="button" (keydown)="onContainerButtonKeydown($event)" (click)="toggleAMPM($event)" (keydown.enter)="toggleAMPM($event)" pRipple>
                            <ChevronUpIcon *ngIf="!incrementIconTemplate" />
                            <ng-template *ngTemplateOutlet="incrementIconTemplate"></ng-template>
                        </button>
                        <span>{{ pm ? 'PM' : 'AM' }}</span>
                        <button class="p-link" type="button" (keydown)="onContainerButtonKeydown($event)" (click)="toggleAMPM($event)" (keydown.enter)="toggleAMPM($event)" pRipple>
                            <ChevronDownIcon *ngIf="!decrementIconTemplate" />
                            <ng-template *ngTemplateOutlet="decrementIconTemplate"></ng-template>
                        </button>
                    </div>
                </div>
                <div class="p-datepicker-buttonbar" *ngIf="showButtonBar">
                    <button type="button" [label]="getTranslation('today')" (keydown)="onContainerButtonKeydown($event)" (click)="onTodayButtonClick($event)" pButton pRipple [ngClass]="[todayButtonStyleClass]"></button>
                    <button type="button" [label]="getTranslation('clear')" (keydown)="onContainerButtonKeydown($event)" (click)="onClearButtonClick($event)" pButton pRipple [ngClass]="[clearButtonStyleClass]"></button>
                </div>
                <ng-content select="p-footer"></ng-content>
                <ng-container *ngTemplateOutlet="footerTemplate"></ng-container>
            </div>
        </span>
    `,
      animations: [trigger("overlayAnimation", [state("visibleTouchUI", style({
        transform: "translate(-50%,-50%)",
        opacity: 1
      })), transition("void => visible", [style({
        opacity: 0,
        transform: "scaleY(0.8)"
      }), animate("{{showTransitionParams}}", style({
        opacity: 1,
        transform: "*"
      }))]), transition("visible => void", [animate("{{hideTransitionParams}}", style({
        opacity: 0
      }))]), transition("void => visibleTouchUI", [style({
        opacity: 0,
        transform: "translate3d(-50%, -40%, 0) scale(0.9)"
      }), animate("{{showTransitionParams}}")]), transition("visibleTouchUI => void", [animate("{{hideTransitionParams}}", style({
        opacity: 0,
        transform: "translate3d(-50%, -40%, 0) scale(0.9)"
      }))])])],
      host: {
        class: "p-element p-inputwrapper",
        "[class.p-inputwrapper-filled]": "filled",
        "[class.p-inputwrapper-focus]": "focus",
        "[class.p-calendar-clearable]": "showClear && !disabled"
      },
      providers: [CALENDAR_VALUE_ACCESSOR],
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      styles: [".p-calendar{position:relative;display:inline-flex;max-width:100%}.p-calendar .p-inputtext{flex:1 1 auto;width:1%}.p-calendar-w-btn .p-inputtext{border-top-right-radius:0;border-bottom-right-radius:0}.p-calendar-w-btn .p-datepicker-trigger{border-top-left-radius:0;border-bottom-left-radius:0}.p-fluid .p-calendar{display:flex}.p-fluid .p-calendar .p-inputtext{width:1%}.p-calendar .p-datepicker{min-width:100%}.p-datepicker{width:auto;position:absolute;top:0;left:0}.p-datepicker-inline{display:inline-block;position:static;overflow-x:auto}.p-datepicker-header{display:flex;align-items:center;justify-content:space-between}.p-datepicker-header .p-datepicker-title{margin:0 auto}.p-datepicker-prev,.p-datepicker-next{cursor:pointer;display:inline-flex;justify-content:center;align-items:center;overflow:hidden;position:relative}.p-datepicker-multiple-month .p-datepicker-group-container .p-datepicker-group{flex:1 1 auto}.p-datepicker-multiple-month .p-datepicker-group-container{display:flex}.p-datepicker table{width:100%;border-collapse:collapse}.p-datepicker td>span{display:flex;justify-content:center;align-items:center;cursor:pointer;margin:0 auto;overflow:hidden;position:relative}.p-monthpicker-month{width:33.3%;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;overflow:hidden;position:relative}.p-datepicker-buttonbar{display:flex;justify-content:space-between;align-items:center}.p-timepicker{display:flex;justify-content:center;align-items:center}.p-timepicker button{display:flex;align-items:center;justify-content:center;cursor:pointer;overflow:hidden;position:relative}.p-timepicker>div{display:flex;align-items:center;flex-direction:column}.p-datepicker-touch-ui,.p-calendar .p-datepicker-touch-ui{position:fixed;top:50%;left:50%;min-width:80vw;transform:translate(-50%,-50%)}.p-yearpicker-year{width:50%;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;overflow:hidden;position:relative}.p-calendar-clear-icon{position:absolute;top:50%;margin-top:-.5rem;cursor:pointer}.p-calendar-clearable{position:relative}\n"]
    }]
  }], function() {
    return [{
      type: Document,
      decorators: [{
        type: Inject,
        args: [DOCUMENT]
      }]
    }, {
      type: ElementRef
    }, {
      type: Renderer2
    }, {
      type: ChangeDetectorRef
    }, {
      type: NgZone
    }, {
      type: PrimeNGConfig
    }, {
      type: OverlayService
    }];
  }, {
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    inputStyle: [{
      type: Input
    }],
    inputId: [{
      type: Input
    }],
    name: [{
      type: Input
    }],
    inputStyleClass: [{
      type: Input
    }],
    placeholder: [{
      type: Input
    }],
    ariaLabelledBy: [{
      type: Input
    }],
    iconAriaLabel: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    dateFormat: [{
      type: Input
    }],
    multipleSeparator: [{
      type: Input
    }],
    rangeSeparator: [{
      type: Input
    }],
    inline: [{
      type: Input
    }],
    showOtherMonths: [{
      type: Input
    }],
    selectOtherMonths: [{
      type: Input
    }],
    showIcon: [{
      type: Input
    }],
    icon: [{
      type: Input
    }],
    appendTo: [{
      type: Input
    }],
    readonlyInput: [{
      type: Input
    }],
    shortYearCutoff: [{
      type: Input
    }],
    monthNavigator: [{
      type: Input
    }],
    yearNavigator: [{
      type: Input
    }],
    hourFormat: [{
      type: Input
    }],
    timeOnly: [{
      type: Input
    }],
    stepHour: [{
      type: Input
    }],
    stepMinute: [{
      type: Input
    }],
    stepSecond: [{
      type: Input
    }],
    showSeconds: [{
      type: Input
    }],
    required: [{
      type: Input
    }],
    showOnFocus: [{
      type: Input
    }],
    showWeek: [{
      type: Input
    }],
    showClear: [{
      type: Input
    }],
    dataType: [{
      type: Input
    }],
    selectionMode: [{
      type: Input
    }],
    maxDateCount: [{
      type: Input
    }],
    showButtonBar: [{
      type: Input
    }],
    todayButtonStyleClass: [{
      type: Input
    }],
    clearButtonStyleClass: [{
      type: Input
    }],
    autoZIndex: [{
      type: Input
    }],
    baseZIndex: [{
      type: Input
    }],
    panelStyleClass: [{
      type: Input
    }],
    panelStyle: [{
      type: Input
    }],
    keepInvalid: [{
      type: Input
    }],
    hideOnDateTimeSelect: [{
      type: Input
    }],
    touchUI: [{
      type: Input
    }],
    timeSeparator: [{
      type: Input
    }],
    focusTrap: [{
      type: Input
    }],
    showTransitionOptions: [{
      type: Input
    }],
    hideTransitionOptions: [{
      type: Input
    }],
    tabindex: [{
      type: Input
    }],
    minDate: [{
      type: Input
    }],
    maxDate: [{
      type: Input
    }],
    disabledDates: [{
      type: Input
    }],
    disabledDays: [{
      type: Input
    }],
    yearRange: [{
      type: Input
    }],
    showTime: [{
      type: Input
    }],
    responsiveOptions: [{
      type: Input
    }],
    numberOfMonths: [{
      type: Input
    }],
    firstDayOfWeek: [{
      type: Input
    }],
    locale: [{
      type: Input
    }],
    view: [{
      type: Input
    }],
    defaultDate: [{
      type: Input
    }],
    onFocus: [{
      type: Output
    }],
    onBlur: [{
      type: Output
    }],
    onClose: [{
      type: Output
    }],
    onSelect: [{
      type: Output
    }],
    onClear: [{
      type: Output
    }],
    onInput: [{
      type: Output
    }],
    onTodayClick: [{
      type: Output
    }],
    onClearClick: [{
      type: Output
    }],
    onMonthChange: [{
      type: Output
    }],
    onYearChange: [{
      type: Output
    }],
    onClickOutside: [{
      type: Output
    }],
    onShow: [{
      type: Output
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }],
    containerViewChild: [{
      type: ViewChild,
      args: ["container", {
        static: false
      }]
    }],
    inputfieldViewChild: [{
      type: ViewChild,
      args: ["inputfield", {
        static: false
      }]
    }],
    content: [{
      type: ViewChild,
      args: ["contentWrapper", {
        static: false
      }]
    }]
  });
})();
var _CalendarModule = class {
};
var CalendarModule = _CalendarModule;
__publicField(CalendarModule, "ɵfac", function CalendarModule_Factory(t) {
  return new (t || _CalendarModule)();
});
__publicField(CalendarModule, "ɵmod", ɵɵdefineNgModule({
  type: _CalendarModule,
  declarations: [Calendar],
  imports: [CommonModule, ButtonModule, SharedModule, RippleModule, ChevronLeftIcon, ChevronRightIcon, ChevronUpIcon, ChevronDownIcon, TimesIcon, CalendarIcon],
  exports: [Calendar, ButtonModule, SharedModule]
}));
__publicField(CalendarModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, ButtonModule, SharedModule, RippleModule, ChevronLeftIcon, ChevronRightIcon, ChevronUpIcon, ChevronDownIcon, TimesIcon, CalendarIcon, ButtonModule, SharedModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CalendarModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, ButtonModule, SharedModule, RippleModule, ChevronLeftIcon, ChevronRightIcon, ChevronUpIcon, ChevronDownIcon, TimesIcon, CalendarIcon],
      exports: [Calendar, ButtonModule, SharedModule],
      declarations: [Calendar]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-autofocus.mjs
var _AutoFocus = class {
  constructor(host) {
    __publicField(this, "host");
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    __publicField(this, "autofocus");
    __publicField(this, "focused", false);
    this.host = host;
  }
  ngAfterContentChecked() {
    if (!this.focused) {
      if (this.autofocus) {
        const focusableElements = DomHandler.getFocusableElements(this.host.nativeElement);
        if (focusableElements.length === 0) {
          this.host.nativeElement.focus();
        }
        if (focusableElements.length > 0) {
          focusableElements[0].focus();
        }
        this.focused = true;
      }
    }
  }
};
var AutoFocus = _AutoFocus;
__publicField(AutoFocus, "ɵfac", function AutoFocus_Factory(t) {
  return new (t || _AutoFocus)(ɵɵdirectiveInject(ElementRef));
});
__publicField(AutoFocus, "ɵdir", ɵɵdefineDirective({
  type: _AutoFocus,
  selectors: [["", "pAutoFocus", ""]],
  hostAttrs: [1, "p-element"],
  inputs: {
    autofocus: "autofocus"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AutoFocus, [{
    type: Directive,
    args: [{
      selector: "[pAutoFocus]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: ElementRef
    }];
  }, {
    autofocus: [{
      type: Input
    }]
  });
})();
var _AutoFocusModule = class {
};
var AutoFocusModule = _AutoFocusModule;
__publicField(AutoFocusModule, "ɵfac", function AutoFocusModule_Factory(t) {
  return new (t || _AutoFocusModule)();
});
__publicField(AutoFocusModule, "ɵmod", ɵɵdefineNgModule({
  type: _AutoFocusModule,
  declarations: [AutoFocus],
  imports: [CommonModule],
  exports: [AutoFocus]
}));
__publicField(AutoFocusModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AutoFocusModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule],
      exports: [AutoFocus],
      declarations: [AutoFocus]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-overlay.mjs
var _c02 = ["overlay"];
var _c15 = ["content"];
function Overlay_div_0_div_2_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c22 = function(a0, a1, a2) {
  return {
    showTransitionParams: a0,
    hideTransitionParams: a1,
    transform: a2
  };
};
var _c32 = function(a1) {
  return {
    value: "visible",
    params: a1
  };
};
var _c42 = function(a0) {
  return {
    mode: a0
  };
};
var _c52 = function(a0) {
  return {
    $implicit: a0
  };
};
function Overlay_div_0_div_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r6 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 1, 3);
    ɵɵlistener("click", function Overlay_div_0_div_2_Template_div_click_0_listener($event) {
      ɵɵrestoreView(_r6);
      const ctx_r5 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r5.onOverlayContentClick($event));
    })("@overlayContentAnimation.start", function Overlay_div_0_div_2_Template_div_animation_overlayContentAnimation_start_0_listener($event) {
      ɵɵrestoreView(_r6);
      const ctx_r7 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r7.onOverlayContentAnimationStart($event));
    })("@overlayContentAnimation.done", function Overlay_div_0_div_2_Template_div_animation_overlayContentAnimation_done_0_listener($event) {
      ɵɵrestoreView(_r6);
      const ctx_r8 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r8.onOverlayContentAnimationDone($event));
    });
    ɵɵprojection(2);
    ɵɵtemplate(3, Overlay_div_0_div_2_ng_container_3_Template, 1, 0, "ng-container", 4);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵclassMap(ctx_r2.contentStyleClass);
    ɵɵproperty("ngStyle", ctx_r2.contentStyle)("ngClass", "p-overlay-content")("@overlayContentAnimation", ɵɵpureFunction1(11, _c32, ɵɵpureFunction3(7, _c22, ctx_r2.showTransitionOptions, ctx_r2.hideTransitionOptions, ctx_r2.transformOptions[ctx_r2.modal ? ctx_r2.overlayResponsiveDirection : "default"])));
    ɵɵadvance(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r2.contentTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(15, _c52, ɵɵpureFunction1(13, _c42, ctx_r2.overlayMode)));
  }
}
var _c62 = function(a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14) {
  return {
    "p-overlay p-component": true,
    "p-overlay-modal p-component-overlay p-component-overlay-enter": a1,
    "p-overlay-center": a2,
    "p-overlay-top": a3,
    "p-overlay-top-start": a4,
    "p-overlay-top-end": a5,
    "p-overlay-bottom": a6,
    "p-overlay-bottom-start": a7,
    "p-overlay-bottom-end": a8,
    "p-overlay-left": a9,
    "p-overlay-left-start": a10,
    "p-overlay-left-end": a11,
    "p-overlay-right": a12,
    "p-overlay-right-start": a13,
    "p-overlay-right-end": a14
  };
};
function Overlay_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 1, 2);
    ɵɵlistener("click", function Overlay_div_0_Template_div_click_0_listener($event) {
      ɵɵrestoreView(_r10);
      const ctx_r9 = ɵɵnextContext();
      return ɵɵresetView(ctx_r9.onOverlayClick($event));
    });
    ɵɵtemplate(2, Overlay_div_0_div_2_Template, 4, 17, "div", 0);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵclassMap(ctx_r0.styleClass);
    ɵɵproperty("ngStyle", ctx_r0.style)("ngClass", ɵɵpureFunctionV(5, _c62, [ctx_r0.modal, ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "center", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "top", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "top-start", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "top-end", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "bottom", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "bottom-start", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "bottom-end", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "left", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "left-start", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "left-end", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "right", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "right-start", ctx_r0.modal && ctx_r0.overlayResponsiveDirection === "right-end"]));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r0.visible);
  }
}
var _c72 = ["*"];
var OVERLAY_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => Overlay),
  multi: true
};
var showOverlayContentAnimation = animation([style({
  transform: "{{transform}}",
  opacity: 0
}), animate("{{showTransitionParams}}")]);
var hideOverlayContentAnimation = animation([animate("{{hideTransitionParams}}", style({
  transform: "{{transform}}",
  opacity: 0
}))]);
var _Overlay = class {
  constructor(document, platformId, el, renderer, config, overlayService, zone) {
    __publicField(this, "document");
    __publicField(this, "platformId");
    __publicField(this, "el");
    __publicField(this, "renderer");
    __publicField(this, "config");
    __publicField(this, "overlayService");
    __publicField(this, "zone");
    /**
     * This EventEmitter is used to notify changes in the visibility state of a component.
     * @param {Boolean} boolean - Value of visibility as boolean.
     * @group Emits
     */
    __publicField(this, "visibleChange", new EventEmitter());
    /**
     * Callback to invoke before the overlay is shown.
     * @param {OverlayOnBeforeShowEvent} event - Custom overlay before show event.
     * @group Emits
     */
    __publicField(this, "onBeforeShow", new EventEmitter());
    /**
     * Callback to invoke when the overlay is shown.
     * @param {OverlayOnShowEvent} event - Custom overlay show event.
     * @group Emits
     */
    __publicField(this, "onShow", new EventEmitter());
    /**
     * Callback to invoke before the overlay is hidden.
     * @param {OverlayOnBeforeHideEvent} event - Custom overlay before hide event.
     * @group Emits
     */
    __publicField(this, "onBeforeHide", new EventEmitter());
    /**
     * Callback to invoke when the overlay is hidden
     * @param {OverlayOnHideEvent} event - Custom hide event.
     * @group Emits
     */
    __publicField(this, "onHide", new EventEmitter());
    /**
     * Callback to invoke when the animation is started.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    __publicField(this, "onAnimationStart", new EventEmitter());
    /**
     * Callback to invoke when the animation is done.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    __publicField(this, "onAnimationDone", new EventEmitter());
    __publicField(this, "templates");
    __publicField(this, "overlayViewChild");
    __publicField(this, "contentViewChild");
    __publicField(this, "contentTemplate");
    __publicField(this, "_visible", false);
    __publicField(this, "_mode");
    __publicField(this, "_style");
    __publicField(this, "_styleClass");
    __publicField(this, "_contentStyle");
    __publicField(this, "_contentStyleClass");
    __publicField(this, "_target");
    __publicField(this, "_appendTo");
    __publicField(this, "_autoZIndex");
    __publicField(this, "_baseZIndex");
    __publicField(this, "_showTransitionOptions");
    __publicField(this, "_hideTransitionOptions");
    __publicField(this, "_listener");
    __publicField(this, "_responsive");
    __publicField(this, "_options");
    __publicField(this, "modalVisible", false);
    __publicField(this, "isOverlayClicked", false);
    __publicField(this, "isOverlayContentClicked", false);
    __publicField(this, "scrollHandler");
    __publicField(this, "documentClickListener");
    __publicField(this, "documentResizeListener");
    __publicField(this, "documentKeyboardListener");
    __publicField(this, "window");
    __publicField(this, "transformOptions", {
      default: "scaleY(0.8)",
      center: "scale(0.7)",
      top: "translate3d(0px, -100%, 0px)",
      "top-start": "translate3d(0px, -100%, 0px)",
      "top-end": "translate3d(0px, -100%, 0px)",
      bottom: "translate3d(0px, 100%, 0px)",
      "bottom-start": "translate3d(0px, 100%, 0px)",
      "bottom-end": "translate3d(0px, 100%, 0px)",
      left: "translate3d(-100%, 0px, 0px)",
      "left-start": "translate3d(-100%, 0px, 0px)",
      "left-end": "translate3d(-100%, 0px, 0px)",
      right: "translate3d(100%, 0px, 0px)",
      "right-start": "translate3d(100%, 0px, 0px)",
      "right-end": "translate3d(100%, 0px, 0px)"
    });
    this.document = document;
    this.platformId = platformId;
    this.el = el;
    this.renderer = renderer;
    this.config = config;
    this.overlayService = overlayService;
    this.zone = zone;
    this.window = this.document.defaultView;
  }
  /**
   * The visible property is an input that determines the visibility of the component.
   * @defaultValue false
   * @group Props
   */
  get visible() {
    return this._visible;
  }
  set visible(value) {
    this._visible = value;
    if (this._visible && !this.modalVisible) {
      this.modalVisible = true;
    }
  }
  /**
   * The mode property is an input that determines the overlay mode type or string.
   * @defaultValue null
   * @group Props
   */
  get mode() {
    var _a;
    return this._mode || ((_a = this.overlayOptions) == null ? void 0 : _a.mode);
  }
  set mode(value) {
    this._mode = value;
  }
  /**
   * The style property is an input that determines the style object for the component.
   * @defaultValue null
   * @group Props
   */
  get style() {
    var _a, _b;
    return ObjectUtils.merge(this._style, this.modal ? (_a = this.overlayResponsiveOptions) == null ? void 0 : _a.style : (_b = this.overlayOptions) == null ? void 0 : _b.style);
  }
  set style(value) {
    this._style = value;
  }
  /**
   * The styleClass property is an input that determines the CSS class(es) for the component.
   * @defaultValue null
   * @group Props
   */
  get styleClass() {
    var _a, _b;
    return ObjectUtils.merge(this._styleClass, this.modal ? (_a = this.overlayResponsiveOptions) == null ? void 0 : _a.styleClass : (_b = this.overlayOptions) == null ? void 0 : _b.styleClass);
  }
  set styleClass(value) {
    this._styleClass = value;
  }
  /**
   * The contentStyle property is an input that determines the style object for the content of the component.
   * @defaultValue null
   * @group Props
   */
  get contentStyle() {
    var _a, _b;
    return ObjectUtils.merge(this._contentStyle, this.modal ? (_a = this.overlayResponsiveOptions) == null ? void 0 : _a.contentStyle : (_b = this.overlayOptions) == null ? void 0 : _b.contentStyle);
  }
  set contentStyle(value) {
    this._contentStyle = value;
  }
  /**
   * The contentStyleClass property is an input that determines the CSS class(es) for the content of the component.
   * @defaultValue null
   * @group Props
   */
  get contentStyleClass() {
    var _a, _b;
    return ObjectUtils.merge(this._contentStyleClass, this.modal ? (_a = this.overlayResponsiveOptions) == null ? void 0 : _a.contentStyleClass : (_b = this.overlayOptions) == null ? void 0 : _b.contentStyleClass);
  }
  set contentStyleClass(value) {
    this._contentStyleClass = value;
  }
  /**
   * The target property is an input that specifies the target element or selector for the component.
   * @defaultValue null
   * @group Props
   */
  get target() {
    var _a;
    const value = this._target || ((_a = this.overlayOptions) == null ? void 0 : _a.target);
    return value === void 0 ? "@prev" : value;
  }
  set target(value) {
    this._target = value;
  }
  /**
   * Overlay can be mounted into its location, body or DOM element instance using this option.
   * @defaultValue null
   * @group Props
   */
  get appendTo() {
    var _a;
    return this._appendTo || ((_a = this.overlayOptions) == null ? void 0 : _a.appendTo);
  }
  set appendTo(value) {
    this._appendTo = value;
  }
  /**
   * The autoZIndex determines whether to automatically manage layering. Its default value is 'false'.
   * @defaultValue false
   * @group Props
   */
  get autoZIndex() {
    var _a;
    const value = this._autoZIndex || ((_a = this.overlayOptions) == null ? void 0 : _a.autoZIndex);
    return value === void 0 ? true : value;
  }
  set autoZIndex(value) {
    this._autoZIndex = value;
  }
  /**
   * The baseZIndex is base zIndex value to use in layering.
   * @defaultValue null
   * @group Props
   */
  get baseZIndex() {
    var _a;
    const value = this._baseZIndex || ((_a = this.overlayOptions) == null ? void 0 : _a.baseZIndex);
    return value === void 0 ? 0 : value;
  }
  set baseZIndex(value) {
    this._baseZIndex = value;
  }
  /**
   * Transition options of the show or hide animation.
   * @defaultValue .12s cubic-bezier(0, 0, 0.2, 1)
   * @group Props
   */
  get showTransitionOptions() {
    var _a;
    const value = this._showTransitionOptions || ((_a = this.overlayOptions) == null ? void 0 : _a.showTransitionOptions);
    return value === void 0 ? ".12s cubic-bezier(0, 0, 0.2, 1)" : value;
  }
  set showTransitionOptions(value) {
    this._showTransitionOptions = value;
  }
  /**
   * The hideTransitionOptions property is an input that determines the CSS transition options for hiding the component.
   * @defaultValue .1s linear
   * @group Props
   */
  get hideTransitionOptions() {
    var _a;
    const value = this._hideTransitionOptions || ((_a = this.overlayOptions) == null ? void 0 : _a.hideTransitionOptions);
    return value === void 0 ? ".1s linear" : value;
  }
  set hideTransitionOptions(value) {
    this._hideTransitionOptions = value;
  }
  /**
   * The listener property is an input that specifies the listener object for the component.
   * @defaultValue null
   * @group Props
   */
  get listener() {
    var _a;
    return this._listener || ((_a = this.overlayOptions) == null ? void 0 : _a.listener);
  }
  set listener(value) {
    this._listener = value;
  }
  /**
   * It is the option used to determine in which mode it should appear according to the given media or breakpoint.
   * @defaultValue null
   * @group Props
   */
  get responsive() {
    var _a;
    return this._responsive || ((_a = this.overlayOptions) == null ? void 0 : _a.responsive);
  }
  set responsive(val) {
    this._responsive = val;
  }
  /**
   * The options property is an input that specifies the overlay options for the component.
   * @defaultValue null
   * @group Props
   */
  get options() {
    return this._options;
  }
  set options(val) {
    this._options = val;
  }
  get modal() {
    var _a, _b;
    if (isPlatformBrowser(this.platformId)) {
      return this.mode === "modal" || this.overlayResponsiveOptions && ((_b = this.window) == null ? void 0 : _b.matchMedia(((_a = this.overlayResponsiveOptions.media) == null ? void 0 : _a.replace("@media", "")) || `(max-width: ${this.overlayResponsiveOptions.breakpoint})`).matches);
    }
  }
  get overlayMode() {
    return this.mode || (this.modal ? "modal" : "overlay");
  }
  get overlayOptions() {
    var _a;
    return {
      ...(_a = this.config) == null ? void 0 : _a.overlayOptions,
      ...this.options
    };
  }
  get overlayResponsiveOptions() {
    var _a;
    return {
      ...(_a = this.overlayOptions) == null ? void 0 : _a.responsive,
      ...this.responsive
    };
  }
  get overlayResponsiveDirection() {
    var _a;
    return ((_a = this.overlayResponsiveOptions) == null ? void 0 : _a.direction) || "center";
  }
  get overlayEl() {
    var _a;
    return (_a = this.overlayViewChild) == null ? void 0 : _a.nativeElement;
  }
  get contentEl() {
    var _a;
    return (_a = this.contentViewChild) == null ? void 0 : _a.nativeElement;
  }
  get targetEl() {
    var _a;
    return DomHandler.getTargetElement(this.target, (_a = this.el) == null ? void 0 : _a.nativeElement);
  }
  ngAfterContentInit() {
    var _a;
    (_a = this.templates) == null ? void 0 : _a.forEach((item) => {
      switch (item.getType()) {
        case "content":
          this.contentTemplate = item.template;
          break;
        default:
          this.contentTemplate = item.template;
          break;
      }
    });
  }
  show(overlay, isFocus = false) {
    var _a;
    this.onVisibleChange(true);
    this.handleEvents("onShow", {
      overlay: overlay || this.overlayEl,
      target: this.targetEl,
      mode: this.overlayMode
    });
    isFocus && DomHandler.focus(this.targetEl);
    this.modal && DomHandler.addClass((_a = this.document) == null ? void 0 : _a.body, "p-overflow-hidden");
  }
  hide(overlay, isFocus = false) {
    var _a;
    if (!this.visible) {
      return;
    } else {
      this.onVisibleChange(false);
      this.handleEvents("onHide", {
        overlay: overlay || this.overlayEl,
        target: this.targetEl,
        mode: this.overlayMode
      });
      isFocus && DomHandler.focus(this.targetEl);
      this.modal && DomHandler.removeClass((_a = this.document) == null ? void 0 : _a.body, "p-overflow-hidden");
    }
  }
  alignOverlay() {
    !this.modal && DomHandler.alignOverlay(this.overlayEl, this.targetEl, this.appendTo);
  }
  onVisibleChange(visible) {
    this._visible = visible;
    this.visibleChange.emit(visible);
  }
  onOverlayClick() {
    this.isOverlayClicked = true;
  }
  onOverlayContentClick(event2) {
    this.overlayService.add({
      originalEvent: event2,
      target: this.targetEl
    });
    this.isOverlayContentClicked = true;
  }
  onOverlayContentAnimationStart(event2) {
    var _a;
    switch (event2.toState) {
      case "visible":
        this.handleEvents("onBeforeShow", {
          overlay: this.overlayEl,
          target: this.targetEl,
          mode: this.overlayMode
        });
        if (this.autoZIndex) {
          zindexutils.set(this.overlayMode, this.overlayEl, this.baseZIndex + ((_a = this.config) == null ? void 0 : _a.zIndex[this.overlayMode]));
        }
        DomHandler.appendOverlay(this.overlayEl, this.appendTo === "body" ? this.document.body : this.appendTo, this.appendTo);
        this.alignOverlay();
        break;
      case "void":
        this.handleEvents("onBeforeHide", {
          overlay: this.overlayEl,
          target: this.targetEl,
          mode: this.overlayMode
        });
        this.modal && DomHandler.addClass(this.overlayEl, "p-component-overlay-leave");
        break;
    }
    this.handleEvents("onAnimationStart", event2);
  }
  onOverlayContentAnimationDone(event2) {
    const container = this.overlayEl || event2.element.parentElement;
    switch (event2.toState) {
      case "visible":
        this.show(container, true);
        this.bindListeners();
        break;
      case "void":
        this.hide(container, true);
        this.unbindListeners();
        DomHandler.appendOverlay(this.overlayEl, this.targetEl, this.appendTo);
        zindexutils.clear(container);
        this.modalVisible = false;
        break;
    }
    this.handleEvents("onAnimationDone", event2);
  }
  handleEvents(name, params) {
    var _a, _b, _c;
    this[name].emit(params);
    this.options && this.options[name] && this.options[name](params);
    ((_a = this.config) == null ? void 0 : _a.overlayOptions) && ((_b = this.config) == null ? void 0 : _b.overlayOptions)[name] && ((_c = this.config) == null ? void 0 : _c.overlayOptions)[name](params);
  }
  bindListeners() {
    this.bindScrollListener();
    this.bindDocumentClickListener();
    this.bindDocumentResizeListener();
    this.bindDocumentKeyboardListener();
  }
  unbindListeners() {
    this.unbindScrollListener();
    this.unbindDocumentClickListener();
    this.unbindDocumentResizeListener();
    this.unbindDocumentKeyboardListener();
  }
  bindScrollListener() {
    if (!this.scrollHandler) {
      this.scrollHandler = new ConnectedOverlayScrollHandler(this.targetEl, (event2) => {
        const valid = this.listener ? this.listener(event2, {
          type: "scroll",
          mode: this.overlayMode,
          valid: true
        }) : true;
        valid && this.hide(event2, true);
      });
    }
    this.scrollHandler.bindScrollListener();
  }
  unbindScrollListener() {
    if (this.scrollHandler) {
      this.scrollHandler.unbindScrollListener();
    }
  }
  bindDocumentClickListener() {
    if (!this.documentClickListener) {
      this.documentClickListener = this.renderer.listen(this.document, "click", (event2) => {
        const isTargetClicked = this.targetEl && (this.targetEl.isSameNode(event2.target) || !this.isOverlayClicked && this.targetEl.contains(event2.target));
        const isOutsideClicked = !isTargetClicked && !this.isOverlayContentClicked;
        const valid = this.listener ? this.listener(event2, {
          type: "outside",
          mode: this.overlayMode,
          valid: event2.which !== 3 && isOutsideClicked
        }) : isOutsideClicked;
        valid && this.hide(event2);
        this.isOverlayClicked = this.isOverlayContentClicked = false;
      });
    }
  }
  unbindDocumentClickListener() {
    if (this.documentClickListener) {
      this.documentClickListener();
      this.documentClickListener = null;
    }
  }
  bindDocumentResizeListener() {
    if (!this.documentResizeListener) {
      this.documentResizeListener = this.renderer.listen(this.window, "resize", (event2) => {
        const valid = this.listener ? this.listener(event2, {
          type: "resize",
          mode: this.overlayMode,
          valid: !DomHandler.isTouchDevice()
        }) : !DomHandler.isTouchDevice();
        valid && this.hide(event2, true);
      });
    }
  }
  unbindDocumentResizeListener() {
    if (this.documentResizeListener) {
      this.documentResizeListener();
      this.documentResizeListener = null;
    }
  }
  bindDocumentKeyboardListener() {
    if (this.documentKeyboardListener) {
      return;
    }
    this.zone.runOutsideAngular(() => {
      this.documentKeyboardListener = this.renderer.listen(this.window, "keydown", (event2) => {
        if (!this.overlayOptions.hideOnEscape || event2.keyCode !== 27) {
          return;
        }
        const valid = this.listener ? this.listener(event2, {
          type: "keydown",
          mode: this.overlayMode,
          valid: !DomHandler.isTouchDevice()
        }) : !DomHandler.isTouchDevice();
        if (valid) {
          this.zone.run(() => {
            this.hide(event2, true);
          });
        }
      });
    });
  }
  unbindDocumentKeyboardListener() {
    if (this.documentKeyboardListener) {
      this.documentKeyboardListener();
      this.documentKeyboardListener = null;
    }
  }
  ngOnDestroy() {
    this.hide(this.overlayEl, true);
    if (this.overlayEl) {
      DomHandler.appendOverlay(this.overlayEl, this.targetEl, this.appendTo);
      zindexutils.clear(this.overlayEl);
    }
    if (this.scrollHandler) {
      this.scrollHandler.destroy();
      this.scrollHandler = null;
    }
    this.unbindListeners();
  }
};
var Overlay = _Overlay;
__publicField(Overlay, "ɵfac", function Overlay_Factory(t) {
  return new (t || _Overlay)(ɵɵdirectiveInject(DOCUMENT), ɵɵdirectiveInject(PLATFORM_ID), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(PrimeNGConfig), ɵɵdirectiveInject(OverlayService), ɵɵdirectiveInject(NgZone));
});
__publicField(Overlay, "ɵcmp", ɵɵdefineComponent({
  type: _Overlay,
  selectors: [["p-overlay"]],
  contentQueries: function Overlay_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  viewQuery: function Overlay_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c02, 5);
      ɵɵviewQuery(_c15, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.overlayViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.contentViewChild = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    visible: "visible",
    mode: "mode",
    style: "style",
    styleClass: "styleClass",
    contentStyle: "contentStyle",
    contentStyleClass: "contentStyleClass",
    target: "target",
    appendTo: "appendTo",
    autoZIndex: "autoZIndex",
    baseZIndex: "baseZIndex",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions",
    listener: "listener",
    responsive: "responsive",
    options: "options"
  },
  outputs: {
    visibleChange: "visibleChange",
    onBeforeShow: "onBeforeShow",
    onShow: "onShow",
    onBeforeHide: "onBeforeHide",
    onHide: "onHide",
    onAnimationStart: "onAnimationStart",
    onAnimationDone: "onAnimationDone"
  },
  features: [ɵɵProvidersFeature([OVERLAY_VALUE_ACCESSOR])],
  ngContentSelectors: _c72,
  decls: 1,
  vars: 1,
  consts: [[3, "ngStyle", "class", "ngClass", "click", 4, "ngIf"], [3, "ngStyle", "ngClass", "click"], ["overlay", ""], ["content", ""], [4, "ngTemplateOutlet", "ngTemplateOutletContext"]],
  template: function Overlay_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵprojectionDef();
      ɵɵtemplate(0, Overlay_div_0_Template, 3, 20, "div", 0);
    }
    if (rf & 2) {
      ɵɵproperty("ngIf", ctx.modalVisible);
    }
  },
  dependencies: [NgClass, NgIf, NgTemplateOutlet, NgStyle],
  styles: [".p-overlay{position:absolute;top:0;left:0}.p-overlay-modal{display:flex;align-items:center;justify-content:center;position:fixed;top:0;left:0;width:100%;height:100%}.p-overlay-content{transform-origin:inherit}.p-overlay-modal>.p-overlay-content{z-index:1;width:90%}.p-overlay-top{align-items:flex-start}.p-overlay-top-start{align-items:flex-start;justify-content:flex-start}.p-overlay-top-end{align-items:flex-start;justify-content:flex-end}.p-overlay-bottom{align-items:flex-end}.p-overlay-bottom-start{align-items:flex-end;justify-content:flex-start}.p-overlay-bottom-end{align-items:flex-end;justify-content:flex-end}.p-overlay-left{justify-content:flex-start}.p-overlay-left-start{justify-content:flex-start;align-items:flex-start}.p-overlay-left-end{justify-content:flex-start;align-items:flex-end}.p-overlay-right{justify-content:flex-end}.p-overlay-right-start{justify-content:flex-end;align-items:flex-start}.p-overlay-right-end{justify-content:flex-end;align-items:flex-end}\n"],
  encapsulation: 2,
  data: {
    animation: [trigger("overlayContentAnimation", [transition(":enter", [useAnimation(showOverlayContentAnimation)]), transition(":leave", [useAnimation(hideOverlayContentAnimation)])])]
  },
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Overlay, [{
    type: Component,
    args: [{
      selector: "p-overlay",
      template: `
        <div
            *ngIf="modalVisible"
            #overlay
            [ngStyle]="style"
            [class]="styleClass"
            [ngClass]="{
                'p-overlay p-component': true,
                'p-overlay-modal p-component-overlay p-component-overlay-enter': modal,
                'p-overlay-center': modal && overlayResponsiveDirection === 'center',
                'p-overlay-top': modal && overlayResponsiveDirection === 'top',
                'p-overlay-top-start': modal && overlayResponsiveDirection === 'top-start',
                'p-overlay-top-end': modal && overlayResponsiveDirection === 'top-end',
                'p-overlay-bottom': modal && overlayResponsiveDirection === 'bottom',
                'p-overlay-bottom-start': modal && overlayResponsiveDirection === 'bottom-start',
                'p-overlay-bottom-end': modal && overlayResponsiveDirection === 'bottom-end',
                'p-overlay-left': modal && overlayResponsiveDirection === 'left',
                'p-overlay-left-start': modal && overlayResponsiveDirection === 'left-start',
                'p-overlay-left-end': modal && overlayResponsiveDirection === 'left-end',
                'p-overlay-right': modal && overlayResponsiveDirection === 'right',
                'p-overlay-right-start': modal && overlayResponsiveDirection === 'right-start',
                'p-overlay-right-end': modal && overlayResponsiveDirection === 'right-end'
            }"
            (click)="onOverlayClick($event)"
        >
            <div
                *ngIf="visible"
                #content
                [ngStyle]="contentStyle"
                [class]="contentStyleClass"
                [ngClass]="'p-overlay-content'"
                (click)="onOverlayContentClick($event)"
                [@overlayContentAnimation]="{ value: 'visible', params: { showTransitionParams: showTransitionOptions, hideTransitionParams: hideTransitionOptions, transform: transformOptions[modal ? overlayResponsiveDirection : 'default'] } }"
                (@overlayContentAnimation.start)="onOverlayContentAnimationStart($event)"
                (@overlayContentAnimation.done)="onOverlayContentAnimationDone($event)"
            >
                <ng-content></ng-content>
                <ng-container *ngTemplateOutlet="contentTemplate; context: { $implicit: { mode: overlayMode } }"></ng-container>
            </div>
        </div>
    `,
      animations: [trigger("overlayContentAnimation", [transition(":enter", [useAnimation(showOverlayContentAnimation)]), transition(":leave", [useAnimation(hideOverlayContentAnimation)])])],
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      providers: [OVERLAY_VALUE_ACCESSOR],
      host: {
        class: "p-element"
      },
      styles: [".p-overlay{position:absolute;top:0;left:0}.p-overlay-modal{display:flex;align-items:center;justify-content:center;position:fixed;top:0;left:0;width:100%;height:100%}.p-overlay-content{transform-origin:inherit}.p-overlay-modal>.p-overlay-content{z-index:1;width:90%}.p-overlay-top{align-items:flex-start}.p-overlay-top-start{align-items:flex-start;justify-content:flex-start}.p-overlay-top-end{align-items:flex-start;justify-content:flex-end}.p-overlay-bottom{align-items:flex-end}.p-overlay-bottom-start{align-items:flex-end;justify-content:flex-start}.p-overlay-bottom-end{align-items:flex-end;justify-content:flex-end}.p-overlay-left{justify-content:flex-start}.p-overlay-left-start{justify-content:flex-start;align-items:flex-start}.p-overlay-left-end{justify-content:flex-start;align-items:flex-end}.p-overlay-right{justify-content:flex-end}.p-overlay-right-start{justify-content:flex-end;align-items:flex-start}.p-overlay-right-end{justify-content:flex-end;align-items:flex-end}\n"]
    }]
  }], function() {
    return [{
      type: Document,
      decorators: [{
        type: Inject,
        args: [DOCUMENT]
      }]
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }, {
      type: ElementRef
    }, {
      type: Renderer2
    }, {
      type: PrimeNGConfig
    }, {
      type: OverlayService
    }, {
      type: NgZone
    }];
  }, {
    visible: [{
      type: Input
    }],
    mode: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    contentStyle: [{
      type: Input
    }],
    contentStyleClass: [{
      type: Input
    }],
    target: [{
      type: Input
    }],
    appendTo: [{
      type: Input
    }],
    autoZIndex: [{
      type: Input
    }],
    baseZIndex: [{
      type: Input
    }],
    showTransitionOptions: [{
      type: Input
    }],
    hideTransitionOptions: [{
      type: Input
    }],
    listener: [{
      type: Input
    }],
    responsive: [{
      type: Input
    }],
    options: [{
      type: Input
    }],
    visibleChange: [{
      type: Output
    }],
    onBeforeShow: [{
      type: Output
    }],
    onShow: [{
      type: Output
    }],
    onBeforeHide: [{
      type: Output
    }],
    onHide: [{
      type: Output
    }],
    onAnimationStart: [{
      type: Output
    }],
    onAnimationDone: [{
      type: Output
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }],
    overlayViewChild: [{
      type: ViewChild,
      args: ["overlay"]
    }],
    contentViewChild: [{
      type: ViewChild,
      args: ["content"]
    }]
  });
})();
var _OverlayModule = class {
};
var OverlayModule = _OverlayModule;
__publicField(OverlayModule, "ɵfac", function OverlayModule_Factory(t) {
  return new (t || _OverlayModule)();
});
__publicField(OverlayModule, "ɵmod", ɵɵdefineNgModule({
  type: _OverlayModule,
  declarations: [Overlay],
  imports: [CommonModule, SharedModule],
  exports: [Overlay, SharedModule]
}));
__publicField(OverlayModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, SharedModule, SharedModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(OverlayModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, SharedModule],
      exports: [Overlay, SharedModule],
      declarations: [Overlay]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-scroller.mjs
var _c03 = ["element"];
var _c16 = ["content"];
function Scroller_ng_container_0_ng_container_3_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c23 = function(a0, a1) {
  return {
    $implicit: a0,
    options: a1
  };
};
function Scroller_ng_container_0_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Scroller_ng_container_0_ng_container_3_ng_container_1_Template, 1, 0, "ng-container", 7);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r4.contentTemplate)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c23, ctx_r4.loadedItems, ctx_r4.getContentOptions()));
  }
}
function Scroller_ng_container_0_ng_template_4_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Scroller_ng_container_0_ng_template_4_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Scroller_ng_container_0_ng_template_4_ng_container_2_ng_container_1_Template, 1, 0, "ng-container", 7);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const item_r12 = ctx.$implicit;
    const index_r13 = ctx.index;
    const ctx_r11 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r11.itemTemplate)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c23, item_r12, ctx_r11.getOptions(index_r13)));
  }
}
var _c33 = function(a0) {
  return {
    "p-scroller-loading": a0
  };
};
function Scroller_ng_container_0_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 8, 9);
    ɵɵtemplate(2, Scroller_ng_container_0_ng_template_4_ng_container_2_Template, 2, 5, "ng-container", 10);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r6 = ɵɵnextContext(2);
    ɵɵproperty("ngClass", ɵɵpureFunction1(4, _c33, ctx_r6.d_loading))("ngStyle", ctx_r6.contentStyle);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", ctx_r6.loadedItems)("ngForTrackBy", ctx_r6._trackBy || ctx_r6.index);
  }
}
function Scroller_ng_container_0_div_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div", 11);
  }
  if (rf & 2) {
    const ctx_r7 = ɵɵnextContext(2);
    ɵɵproperty("ngStyle", ctx_r7.spacerStyle);
  }
}
function Scroller_ng_container_0_div_7_ng_container_1_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c43 = function(a0) {
  return {
    numCols: a0
  };
};
var _c53 = function(a0) {
  return {
    options: a0
  };
};
function Scroller_ng_container_0_div_7_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Scroller_ng_container_0_div_7_ng_container_1_ng_container_1_ng_container_1_Template, 1, 0, "ng-container", 7);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const index_r20 = ctx.index;
    const ctx_r18 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r18.loaderTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(4, _c53, ctx_r18.getLoaderOptions(index_r20, ctx_r18.both && ɵɵpureFunction1(2, _c43, ctx_r18._numItemsInViewport.cols))));
  }
}
function Scroller_ng_container_0_div_7_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Scroller_ng_container_0_div_7_ng_container_1_ng_container_1_Template, 2, 6, "ng-container", 14);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r15 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r15.loaderArr);
  }
}
function Scroller_ng_container_0_div_7_ng_template_2_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c63 = function() {
  return {
    styleClass: "p-scroller-loading-icon"
  };
};
function Scroller_ng_container_0_div_7_ng_template_2_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Scroller_ng_container_0_div_7_ng_template_2_ng_container_0_ng_container_1_Template, 1, 0, "ng-container", 7);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r22 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r22.loaderIconTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(3, _c53, ɵɵpureFunction0(2, _c63)));
  }
}
function Scroller_ng_container_0_div_7_ng_template_2_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "SpinnerIcon", 16);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-scroller-loading-icon");
  }
}
function Scroller_ng_container_0_div_7_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Scroller_ng_container_0_div_7_ng_template_2_ng_container_0_Template, 2, 5, "ng-container", 0);
    ɵɵtemplate(1, Scroller_ng_container_0_div_7_ng_template_2_ng_template_1_Template, 1, 1, "ng-template", null, 15, ɵɵtemplateRefExtractor);
  }
  if (rf & 2) {
    const _r23 = ɵɵreference(2);
    const ctx_r17 = ɵɵnextContext(3);
    ɵɵproperty("ngIf", ctx_r17.loaderIconTemplate)("ngIfElse", _r23);
  }
}
var _c73 = function(a0) {
  return {
    "p-component-overlay": a0
  };
};
function Scroller_ng_container_0_div_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 12);
    ɵɵtemplate(1, Scroller_ng_container_0_div_7_ng_container_1_Template, 2, 1, "ng-container", 0);
    ɵɵtemplate(2, Scroller_ng_container_0_div_7_ng_template_2_Template, 3, 2, "ng-template", null, 13, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const _r16 = ɵɵreference(3);
    const ctx_r8 = ɵɵnextContext(2);
    ɵɵproperty("ngClass", ɵɵpureFunction1(3, _c73, !ctx_r8.loaderTemplate));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r8.loaderTemplate)("ngIfElse", _r16);
  }
}
var _c82 = function(a1, a2, a3) {
  return {
    "p-scroller": true,
    "p-scroller-inline": a1,
    "p-both-scroll": a2,
    "p-horizontal-scroll": a3
  };
};
function Scroller_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = ɵɵgetCurrentView();
    ɵɵelementContainerStart(0);
    ɵɵelementStart(1, "div", 2, 3);
    ɵɵlistener("scroll", function Scroller_ng_container_0_Template_div_scroll_1_listener($event) {
      ɵɵrestoreView(_r27);
      const ctx_r26 = ɵɵnextContext();
      return ɵɵresetView(ctx_r26.onContainerScroll($event));
    });
    ɵɵtemplate(3, Scroller_ng_container_0_ng_container_3_Template, 2, 5, "ng-container", 0);
    ɵɵtemplate(4, Scroller_ng_container_0_ng_template_4_Template, 3, 6, "ng-template", null, 4, ɵɵtemplateRefExtractor);
    ɵɵtemplate(6, Scroller_ng_container_0_div_6_Template, 1, 1, "div", 5);
    ɵɵtemplate(7, Scroller_ng_container_0_div_7_Template, 4, 5, "div", 6);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const _r5 = ɵɵreference(5);
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵclassMap(ctx_r0._styleClass);
    ɵɵproperty("ngStyle", ctx_r0._style)("ngClass", ɵɵpureFunction3(10, _c82, ctx_r0.inline, ctx_r0.both, ctx_r0.horizontal));
    ɵɵattribute("id", ctx_r0._id)("tabindex", ctx_r0.tabindex);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r0.contentTemplate)("ngIfElse", _r5);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ctx_r0._showSpacer);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r0.loaderDisabled && ctx_r0._showLoader && ctx_r0.d_loading);
  }
}
function Scroller_ng_template_1_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c92 = function(a0, a1) {
  return {
    rows: a0,
    columns: a1
  };
};
function Scroller_ng_template_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Scroller_ng_template_1_ng_container_1_ng_container_1_Template, 1, 0, "ng-container", 7);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r28 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r28.contentTemplate)("ngTemplateOutletContext", ɵɵpureFunction2(5, _c23, ctx_r28.items, ɵɵpureFunction2(2, _c92, ctx_r28._items, ctx_r28.loadedColumns)));
  }
}
function Scroller_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵprojection(0);
    ɵɵtemplate(1, Scroller_ng_template_1_ng_container_1_Template, 2, 8, "ng-container", 17);
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r2.contentTemplate);
  }
}
var _c102 = ["*"];
var _Scroller = class {
  constructor(document, platformId, renderer, cd, zone) {
    __publicField(this, "document");
    __publicField(this, "platformId");
    __publicField(this, "renderer");
    __publicField(this, "cd");
    __publicField(this, "zone");
    /**
     * Callback to invoke in lazy mode to load new data.
     * @param {ScrollerLazyLoadEvent} event - Custom lazy load event.
     * @group Emits
     */
    __publicField(this, "onLazyLoad", new EventEmitter());
    /**
     * Callback to invoke when scroll position changes.
     * @param {ScrollerScrollEvent} event - Custom scroll event.
     * @group Emits
     */
    __publicField(this, "onScroll", new EventEmitter());
    /**
     * Callback to invoke when scroll position and item's range in view changes.
     * @param {ScrollerScrollEvent} event - Custom scroll index change event.
     * @group Emits
     */
    __publicField(this, "onScrollIndexChange", new EventEmitter());
    __publicField(this, "elementViewChild");
    __publicField(this, "contentViewChild");
    __publicField(this, "templates");
    __publicField(this, "_id");
    __publicField(this, "_style");
    __publicField(this, "_styleClass");
    __publicField(this, "_tabindex", 0);
    __publicField(this, "_items");
    __publicField(this, "_itemSize", 0);
    __publicField(this, "_scrollHeight");
    __publicField(this, "_scrollWidth");
    __publicField(this, "_orientation", "vertical");
    __publicField(this, "_step", 0);
    __publicField(this, "_delay", 0);
    __publicField(this, "_resizeDelay", 10);
    __publicField(this, "_appendOnly", false);
    __publicField(this, "_inline", false);
    __publicField(this, "_lazy", false);
    __publicField(this, "_disabled", false);
    __publicField(this, "_loaderDisabled", false);
    __publicField(this, "_columns");
    __publicField(this, "_showSpacer", true);
    __publicField(this, "_showLoader", false);
    __publicField(this, "_numToleratedItems");
    __publicField(this, "_loading");
    __publicField(this, "_autoSize", false);
    __publicField(this, "_trackBy");
    __publicField(this, "_options");
    __publicField(this, "d_loading", false);
    __publicField(this, "d_numToleratedItems");
    __publicField(this, "contentEl");
    __publicField(this, "contentTemplate");
    __publicField(this, "itemTemplate");
    __publicField(this, "loaderTemplate");
    __publicField(this, "loaderIconTemplate");
    __publicField(this, "first", 0);
    __publicField(this, "last", 0);
    __publicField(this, "page", 0);
    __publicField(this, "isRangeChanged", false);
    __publicField(this, "numItemsInViewport", 0);
    __publicField(this, "lastScrollPos", 0);
    __publicField(this, "lazyLoadState", {});
    __publicField(this, "loaderArr", []);
    __publicField(this, "spacerStyle", {});
    __publicField(this, "contentStyle", {});
    __publicField(this, "scrollTimeout");
    __publicField(this, "resizeTimeout");
    __publicField(this, "initialized", false);
    __publicField(this, "windowResizeListener");
    __publicField(this, "defaultWidth");
    __publicField(this, "defaultHeight");
    __publicField(this, "defaultContentWidth");
    __publicField(this, "defaultContentHeight");
    this.document = document;
    this.platformId = platformId;
    this.renderer = renderer;
    this.cd = cd;
    this.zone = zone;
  }
  /**
   * Unique identifier of the element.
   * @group Props
   */
  get id() {
    return this._id;
  }
  set id(val) {
    this._id = val;
  }
  /**
   * Inline style of the component.
   * @group Props
   */
  get style() {
    return this._style;
  }
  set style(val) {
    this._style = val;
  }
  /**
   * Style class of the element.
   * @group Props
   */
  get styleClass() {
    return this._styleClass;
  }
  set styleClass(val) {
    this._styleClass = val;
  }
  /**
   * Index of the element in tabbing order.
   * @group Props
   */
  get tabindex() {
    return this._tabindex;
  }
  set tabindex(val) {
    this._tabindex = val;
  }
  /**
   * An array of objects to display.
   * @group Props
   */
  get items() {
    return this._items;
  }
  set items(val) {
    this._items = val;
  }
  /**
   * The height/width of item according to orientation.
   * @group Props
   */
  get itemSize() {
    return this._itemSize;
  }
  set itemSize(val) {
    this._itemSize = val;
  }
  /**
   * Height of the scroll viewport.
   * @group Props
   */
  get scrollHeight() {
    return this._scrollHeight;
  }
  set scrollHeight(val) {
    this._scrollHeight = val;
  }
  /**
   * Width of the scroll viewport.
   * @group Props
   */
  get scrollWidth() {
    return this._scrollWidth;
  }
  set scrollWidth(val) {
    this._scrollWidth = val;
  }
  /**
   * The orientation of scrollbar.
   * @group Props
   */
  get orientation() {
    return this._orientation;
  }
  set orientation(val) {
    this._orientation = val;
  }
  /**
   * Used to specify how many items to load in each load method in lazy mode.
   * @group Props
   */
  get step() {
    return this._step;
  }
  set step(val) {
    this._step = val;
  }
  /**
   * Delay in scroll before new data is loaded.
   * @group Props
   */
  get delay() {
    return this._delay;
  }
  set delay(val) {
    this._delay = val;
  }
  /**
   * Delay after window's resize finishes.
   * @group Props
   */
  get resizeDelay() {
    return this._resizeDelay;
  }
  set resizeDelay(val) {
    this._resizeDelay = val;
  }
  /**
   * Used to append each loaded item to top without removing any items from the DOM. Using very large data may cause the browser to crash.
   * @group Props
   */
  get appendOnly() {
    return this._appendOnly;
  }
  set appendOnly(val) {
    this._appendOnly = val;
  }
  /**
   * Specifies whether the scroller should be displayed inline or not.
   * @group Props
   */
  get inline() {
    return this._inline;
  }
  set inline(val) {
    this._inline = val;
  }
  /**
   * Defines if data is loaded and interacted with in lazy manner.
   * @group Props
   */
  get lazy() {
    return this._lazy;
  }
  set lazy(val) {
    this._lazy = val;
  }
  /**
   * If disabled, the scroller feature is eliminated and the content is displayed directly.
   * @group Props
   */
  get disabled() {
    return this._disabled;
  }
  set disabled(val) {
    this._disabled = val;
  }
  /**
   * Used to implement a custom loader instead of using the loader feature in the scroller.
   * @group Props
   */
  get loaderDisabled() {
    return this._loaderDisabled;
  }
  set loaderDisabled(val) {
    this._loaderDisabled = val;
  }
  /**
   * Columns to display.
   * @group Props
   */
  get columns() {
    return this._columns;
  }
  set columns(val) {
    this._columns = val;
  }
  /**
   * Used to implement a custom spacer instead of using the spacer feature in the scroller.
   * @group Props
   */
  get showSpacer() {
    return this._showSpacer;
  }
  set showSpacer(val) {
    this._showSpacer = val;
  }
  /**
   * Defines whether to show loader.
   * @group Props
   */
  get showLoader() {
    return this._showLoader;
  }
  set showLoader(val) {
    this._showLoader = val;
  }
  /**
   * Determines how many additional elements to add to the DOM outside of the view. According to the scrolls made up and down, extra items are added in a certain algorithm in the form of multiples of this number. Default value is half the number of items shown in the view.
   * @group Props
   */
  get numToleratedItems() {
    return this._numToleratedItems;
  }
  set numToleratedItems(val) {
    this._numToleratedItems = val;
  }
  /**
   * Defines whether the data is loaded.
   * @group Props
   */
  get loading() {
    return this._loading;
  }
  set loading(val) {
    this._loading = val;
  }
  /**
   * Defines whether to dynamically change the height or width of scrollable container.
   * @group Props
   */
  get autoSize() {
    return this._autoSize;
  }
  set autoSize(val) {
    this._autoSize = val;
  }
  /**
   * Function to optimize the dom operations by delegating to ngForTrackBy, default algoritm checks for object identity.
   * @group Props
   */
  get trackBy() {
    return this._trackBy;
  }
  set trackBy(val) {
    this._trackBy = val;
  }
  /**
   * Defines whether to use the scroller feature. The properties of scroller component can be used like an object in it.
   * @group Props
   */
  get options() {
    return this._options;
  }
  set options(val) {
    this._options = val;
    if (val && typeof val === "object") {
      Object.entries(val).forEach(([k, v]) => this[`_${k}`] !== v && (this[`_${k}`] = v));
    }
  }
  get vertical() {
    return this._orientation === "vertical";
  }
  get horizontal() {
    return this._orientation === "horizontal";
  }
  get both() {
    return this._orientation === "both";
  }
  get loadedItems() {
    if (this._items && !this.d_loading) {
      if (this.both)
        return this._items.slice(this._appendOnly ? 0 : this.first.rows, this.last.rows).map((item) => this._columns ? item : item.slice(this._appendOnly ? 0 : this.first.cols, this.last.cols));
      else if (this.horizontal && this._columns)
        return this._items;
      else
        return this._items.slice(this._appendOnly ? 0 : this.first, this.last);
    }
    return [];
  }
  get loadedRows() {
    return this.d_loading ? this._loaderDisabled ? this.loaderArr : [] : this.loadedItems;
  }
  get loadedColumns() {
    if (this._columns && (this.both || this.horizontal)) {
      return this.d_loading && this._loaderDisabled ? this.both ? this.loaderArr[0] : this.loaderArr : this._columns.slice(this.both ? this.first.cols : this.first, this.both ? this.last.cols : this.last);
    }
    return this._columns;
  }
  get isPageChanged() {
    return this._step ? this.page !== this.getPageByFirst() : true;
  }
  ngOnInit() {
    this.setInitialState();
  }
  ngOnChanges(simpleChanges) {
    var _a, _b, _c, _d;
    let isLoadingChanged = false;
    if (simpleChanges.loading) {
      const {
        previousValue,
        currentValue
      } = simpleChanges.loading;
      if (this.lazy && previousValue !== currentValue && currentValue !== this.d_loading) {
        this.d_loading = currentValue;
        isLoadingChanged = true;
      }
    }
    if (simpleChanges.orientation) {
      this.lastScrollPos = this.both ? {
        top: 0,
        left: 0
      } : 0;
    }
    if (simpleChanges.numToleratedItems) {
      const {
        previousValue,
        currentValue
      } = simpleChanges.numToleratedItems;
      if (previousValue !== currentValue && currentValue !== this.d_numToleratedItems) {
        this.d_numToleratedItems = currentValue;
      }
    }
    if (simpleChanges.options) {
      const {
        previousValue,
        currentValue
      } = simpleChanges.options;
      if (this.lazy && (previousValue == null ? void 0 : previousValue.loading) !== (currentValue == null ? void 0 : currentValue.loading) && (currentValue == null ? void 0 : currentValue.loading) !== this.d_loading) {
        this.d_loading = currentValue.loading;
        isLoadingChanged = true;
      }
      if ((previousValue == null ? void 0 : previousValue.numToleratedItems) !== (currentValue == null ? void 0 : currentValue.numToleratedItems) && (currentValue == null ? void 0 : currentValue.numToleratedItems) !== this.d_numToleratedItems) {
        this.d_numToleratedItems = currentValue.numToleratedItems;
      }
    }
    if (this.initialized) {
      const isChanged = !isLoadingChanged && (((_b = (_a = simpleChanges.items) == null ? void 0 : _a.previousValue) == null ? void 0 : _b.length) !== ((_d = (_c = simpleChanges.items) == null ? void 0 : _c.currentValue) == null ? void 0 : _d.length) || simpleChanges.itemSize || simpleChanges.scrollHeight || simpleChanges.scrollWidth);
      if (isChanged) {
        this.init();
        this.calculateAutoSize();
      }
    }
  }
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "content":
          this.contentTemplate = item.template;
          break;
        case "item":
          this.itemTemplate = item.template;
          break;
        case "loader":
          this.loaderTemplate = item.template;
          break;
        case "loadericon":
          this.loaderIconTemplate = item.template;
          break;
        default:
          this.itemTemplate = item.template;
          break;
      }
    });
  }
  ngAfterViewInit() {
    Promise.resolve().then(() => {
      this.viewInit();
    });
  }
  ngAfterViewChecked() {
    if (!this.initialized) {
      this.viewInit();
    }
  }
  ngOnDestroy() {
    this.unbindResizeListener();
    this.contentEl = null;
    this.initialized = false;
  }
  viewInit() {
    var _a, _b, _c;
    if (isPlatformBrowser(this.platformId)) {
      if (DomHandler.isVisible((_a = this.elementViewChild) == null ? void 0 : _a.nativeElement)) {
        this.setInitialState();
        this.setContentEl(this.contentEl);
        this.init();
        this.defaultWidth = DomHandler.getWidth((_b = this.elementViewChild) == null ? void 0 : _b.nativeElement);
        this.defaultHeight = DomHandler.getHeight((_c = this.elementViewChild) == null ? void 0 : _c.nativeElement);
        this.defaultContentWidth = DomHandler.getWidth(this.contentEl);
        this.defaultContentHeight = DomHandler.getHeight(this.contentEl);
        this.initialized = true;
      }
    }
  }
  init() {
    if (!this._disabled) {
      this.setSize();
      this.calculateOptions();
      this.setSpacerSize();
      this.bindResizeListener();
      this.cd.detectChanges();
    }
  }
  setContentEl(el) {
    var _a, _b;
    this.contentEl = el || ((_a = this.contentViewChild) == null ? void 0 : _a.nativeElement) || DomHandler.findSingle((_b = this.elementViewChild) == null ? void 0 : _b.nativeElement, ".p-scroller-content");
  }
  setInitialState() {
    this.first = this.both ? {
      rows: 0,
      cols: 0
    } : 0;
    this.last = this.both ? {
      rows: 0,
      cols: 0
    } : 0;
    this.numItemsInViewport = this.both ? {
      rows: 0,
      cols: 0
    } : 0;
    this.lastScrollPos = this.both ? {
      top: 0,
      left: 0
    } : 0;
    this.d_loading = this._loading || false;
    this.d_numToleratedItems = this._numToleratedItems;
    this.loaderArr = [];
    this.spacerStyle = {};
    this.contentStyle = {};
  }
  getElementRef() {
    return this.elementViewChild;
  }
  getPageByFirst() {
    return Math.floor((this.first + this.d_numToleratedItems * 4) / (this._step || 1));
  }
  scrollTo(options) {
    var _a, _b;
    this.lastScrollPos = this.both ? {
      top: 0,
      left: 0
    } : 0;
    (_b = (_a = this.elementViewChild) == null ? void 0 : _a.nativeElement) == null ? void 0 : _b.scrollTo(options);
  }
  scrollToIndex(index, behavior = "auto") {
    const {
      numToleratedItems
    } = this.calculateNumItems();
    const contentPos = this.getContentPosition();
    const calculateFirst = (_index = 0, _numT) => _index <= _numT ? 0 : _index;
    const calculateCoord = (_first, _size, _cpos) => _first * _size + _cpos;
    const scrollTo = (left = 0, top = 0) => this.scrollTo({
      left,
      top,
      behavior
    });
    let newFirst = 0;
    if (this.both) {
      newFirst = {
        rows: calculateFirst(index[0], numToleratedItems[0]),
        cols: calculateFirst(index[1], numToleratedItems[1])
      };
      scrollTo(calculateCoord(newFirst.cols, this._itemSize[1], contentPos.left), calculateCoord(newFirst.rows, this._itemSize[0], contentPos.top));
    } else {
      newFirst = calculateFirst(index, numToleratedItems);
      this.horizontal ? scrollTo(calculateCoord(newFirst, this._itemSize, contentPos.left), 0) : scrollTo(0, calculateCoord(newFirst, this._itemSize, contentPos.top));
    }
    this.isRangeChanged = this.first !== newFirst;
    this.first = newFirst;
  }
  scrollInView(index, to, behavior = "auto") {
    if (to) {
      const {
        first,
        viewport
      } = this.getRenderedRange();
      const scrollTo = (left = 0, top = 0) => this.scrollTo({
        left,
        top,
        behavior
      });
      const isToStart = to === "to-start";
      const isToEnd = to === "to-end";
      if (isToStart) {
        if (this.both) {
          if (viewport.first.rows - first.rows > index[0]) {
            scrollTo(viewport.first.cols * this._itemSize[1], (viewport.first.rows - 1) * this._itemSize[0]);
          } else if (viewport.first.cols - first.cols > index[1]) {
            scrollTo((viewport.first.cols - 1) * this._itemSize[1], viewport.first.rows * this._itemSize[0]);
          }
        } else {
          if (viewport.first - first > index) {
            const pos = (viewport.first - 1) * this._itemSize;
            this.horizontal ? scrollTo(pos, 0) : scrollTo(0, pos);
          }
        }
      } else if (isToEnd) {
        if (this.both) {
          if (viewport.last.rows - first.rows <= index[0] + 1) {
            scrollTo(viewport.first.cols * this._itemSize[1], (viewport.first.rows + 1) * this._itemSize[0]);
          } else if (viewport.last.cols - first.cols <= index[1] + 1) {
            scrollTo((viewport.first.cols + 1) * this._itemSize[1], viewport.first.rows * this._itemSize[0]);
          }
        } else {
          if (viewport.last - first <= index + 1) {
            const pos = (viewport.first + 1) * this._itemSize;
            this.horizontal ? scrollTo(pos, 0) : scrollTo(0, pos);
          }
        }
      }
    } else {
      this.scrollToIndex(index, behavior);
    }
  }
  getRenderedRange() {
    var _a;
    const calculateFirstInViewport = (_pos, _size) => Math.floor(_pos / (_size || _pos));
    let firstInViewport = this.first;
    let lastInViewport = 0;
    if ((_a = this.elementViewChild) == null ? void 0 : _a.nativeElement) {
      const {
        scrollTop,
        scrollLeft
      } = this.elementViewChild.nativeElement;
      if (this.both) {
        firstInViewport = {
          rows: calculateFirstInViewport(scrollTop, this._itemSize[0]),
          cols: calculateFirstInViewport(scrollLeft, this._itemSize[1])
        };
        lastInViewport = {
          rows: firstInViewport.rows + this.numItemsInViewport.rows,
          cols: firstInViewport.cols + this.numItemsInViewport.cols
        };
      } else {
        const scrollPos = this.horizontal ? scrollLeft : scrollTop;
        firstInViewport = calculateFirstInViewport(scrollPos, this._itemSize);
        lastInViewport = firstInViewport + this.numItemsInViewport;
      }
    }
    return {
      first: this.first,
      last: this.last,
      viewport: {
        first: firstInViewport,
        last: lastInViewport
      }
    };
  }
  calculateNumItems() {
    var _a, _b;
    const contentPos = this.getContentPosition();
    const contentWidth = (((_a = this.elementViewChild) == null ? void 0 : _a.nativeElement) ? this.elementViewChild.nativeElement.offsetWidth - contentPos.left : 0) || 0;
    const contentHeight = (((_b = this.elementViewChild) == null ? void 0 : _b.nativeElement) ? this.elementViewChild.nativeElement.offsetHeight - contentPos.top : 0) || 0;
    const calculateNumItemsInViewport = (_contentSize, _itemSize) => Math.ceil(_contentSize / (_itemSize || _contentSize));
    const calculateNumToleratedItems = (_numItems) => Math.ceil(_numItems / 2);
    const numItemsInViewport = this.both ? {
      rows: calculateNumItemsInViewport(contentHeight, this._itemSize[0]),
      cols: calculateNumItemsInViewport(contentWidth, this._itemSize[1])
    } : calculateNumItemsInViewport(this.horizontal ? contentWidth : contentHeight, this._itemSize);
    const numToleratedItems = this.d_numToleratedItems || (this.both ? [calculateNumToleratedItems(numItemsInViewport.rows), calculateNumToleratedItems(numItemsInViewport.cols)] : calculateNumToleratedItems(numItemsInViewport));
    return {
      numItemsInViewport,
      numToleratedItems
    };
  }
  calculateOptions() {
    const {
      numItemsInViewport,
      numToleratedItems
    } = this.calculateNumItems();
    const calculateLast = (_first, _num, _numT, _isCols = false) => this.getLast(_first + _num + (_first < _numT ? 2 : 3) * _numT, _isCols);
    const first = this.first;
    const last = this.both ? {
      rows: calculateLast(this.first.rows, numItemsInViewport.rows, numToleratedItems[0]),
      cols: calculateLast(this.first.cols, numItemsInViewport.cols, numToleratedItems[1], true)
    } : calculateLast(this.first, numItemsInViewport, numToleratedItems);
    this.last = last;
    this.numItemsInViewport = numItemsInViewport;
    this.d_numToleratedItems = numToleratedItems;
    if (this.showLoader) {
      this.loaderArr = this.both ? Array.from({
        length: numItemsInViewport.rows
      }).map(() => Array.from({
        length: numItemsInViewport.cols
      })) : Array.from({
        length: numItemsInViewport
      });
    }
    if (this._lazy) {
      Promise.resolve().then(() => {
        this.lazyLoadState = {
          first: this._step ? this.both ? {
            rows: 0,
            cols: first.cols
          } : 0 : first,
          last: Math.min(this._step ? this._step : this.last, this.items.length)
        };
        this.handleEvents("onLazyLoad", this.lazyLoadState);
      });
    }
  }
  calculateAutoSize() {
    if (this._autoSize && !this.d_loading) {
      Promise.resolve().then(() => {
        if (this.contentEl) {
          this.contentEl.style.minHeight = this.contentEl.style.minWidth = "auto";
          this.contentEl.style.position = "relative";
          this.elementViewChild.nativeElement.style.contain = "none";
          const [contentWidth, contentHeight] = [DomHandler.getWidth(this.contentEl), DomHandler.getHeight(this.contentEl)];
          contentWidth !== this.defaultContentWidth && (this.elementViewChild.nativeElement.style.width = "");
          contentHeight !== this.defaultContentHeight && (this.elementViewChild.nativeElement.style.height = "");
          const [width, height] = [DomHandler.getWidth(this.elementViewChild.nativeElement), DomHandler.getHeight(this.elementViewChild.nativeElement)];
          (this.both || this.horizontal) && (this.elementViewChild.nativeElement.style.width = width < this.defaultWidth ? width + "px" : this._scrollWidth || this.defaultWidth + "px");
          (this.both || this.vertical) && (this.elementViewChild.nativeElement.style.height = height < this.defaultHeight ? height + "px" : this._scrollHeight || this.defaultHeight + "px");
          this.contentEl.style.minHeight = this.contentEl.style.minWidth = "";
          this.contentEl.style.position = "";
          this.elementViewChild.nativeElement.style.contain = "";
        }
      });
    }
  }
  getLast(last = 0, isCols = false) {
    return this._items ? Math.min(isCols ? (this._columns || this._items[0]).length : this._items.length, last) : 0;
  }
  getContentPosition() {
    if (this.contentEl) {
      const style2 = getComputedStyle(this.contentEl);
      const left = parseFloat(style2.paddingLeft) + Math.max(parseFloat(style2.left) || 0, 0);
      const right = parseFloat(style2.paddingRight) + Math.max(parseFloat(style2.right) || 0, 0);
      const top = parseFloat(style2.paddingTop) + Math.max(parseFloat(style2.top) || 0, 0);
      const bottom = parseFloat(style2.paddingBottom) + Math.max(parseFloat(style2.bottom) || 0, 0);
      return {
        left,
        right,
        top,
        bottom,
        x: left + right,
        y: top + bottom
      };
    }
    return {
      left: 0,
      right: 0,
      top: 0,
      bottom: 0,
      x: 0,
      y: 0
    };
  }
  setSize() {
    var _a;
    if ((_a = this.elementViewChild) == null ? void 0 : _a.nativeElement) {
      const parentElement = this.elementViewChild.nativeElement.parentElement.parentElement;
      const width = this._scrollWidth || `${this.elementViewChild.nativeElement.offsetWidth || parentElement.offsetWidth}px`;
      const height = this._scrollHeight || `${this.elementViewChild.nativeElement.offsetHeight || parentElement.offsetHeight}px`;
      const setProp = (_name, _value) => this.elementViewChild.nativeElement.style[_name] = _value;
      if (this.both || this.horizontal) {
        setProp("height", height);
        setProp("width", width);
      } else {
        setProp("height", height);
      }
    }
  }
  setSpacerSize() {
    if (this._items) {
      const contentPos = this.getContentPosition();
      const setProp = (_name, _value, _size, _cpos = 0) => this.spacerStyle = {
        ...this.spacerStyle,
        ...{
          [`${_name}`]: (_value || []).length * _size + _cpos + "px"
        }
      };
      if (this.both) {
        setProp("height", this._items, this._itemSize[0], contentPos.y);
        setProp("width", this._columns || this._items[1], this._itemSize[1], contentPos.x);
      } else {
        this.horizontal ? setProp("width", this._columns || this._items, this._itemSize, contentPos.x) : setProp("height", this._items, this._itemSize, contentPos.y);
      }
    }
  }
  setContentPosition(pos) {
    if (this.contentEl && !this._appendOnly) {
      const first = pos ? pos.first : this.first;
      const calculateTranslateVal = (_first, _size) => _first * _size;
      const setTransform = (_x = 0, _y = 0) => this.contentStyle = {
        ...this.contentStyle,
        ...{
          transform: `translate3d(${_x}px, ${_y}px, 0)`
        }
      };
      if (this.both) {
        setTransform(calculateTranslateVal(first.cols, this._itemSize[1]), calculateTranslateVal(first.rows, this._itemSize[0]));
      } else {
        const translateVal = calculateTranslateVal(first, this._itemSize);
        this.horizontal ? setTransform(translateVal, 0) : setTransform(0, translateVal);
      }
    }
  }
  onScrollPositionChange(event2) {
    const target = event2.target;
    const contentPos = this.getContentPosition();
    const calculateScrollPos = (_pos, _cpos) => _pos ? _pos > _cpos ? _pos - _cpos : _pos : 0;
    const calculateCurrentIndex = (_pos, _size) => Math.floor(_pos / (_size || _pos));
    const calculateTriggerIndex = (_currentIndex, _first, _last, _num, _numT, _isScrollDownOrRight) => {
      return _currentIndex <= _numT ? _numT : _isScrollDownOrRight ? _last - _num - _numT : _first + _numT - 1;
    };
    const calculateFirst = (_currentIndex, _triggerIndex, _first, _last, _num, _numT, _isScrollDownOrRight) => {
      if (_currentIndex <= _numT)
        return 0;
      else
        return Math.max(0, _isScrollDownOrRight ? _currentIndex < _triggerIndex ? _first : _currentIndex - _numT : _currentIndex > _triggerIndex ? _first : _currentIndex - 2 * _numT);
    };
    const calculateLast = (_currentIndex, _first, _last, _num, _numT, _isCols = false) => {
      let lastValue = _first + _num + 2 * _numT;
      if (_currentIndex >= _numT) {
        lastValue += _numT + 1;
      }
      return this.getLast(lastValue, _isCols);
    };
    const scrollTop = calculateScrollPos(target.scrollTop, contentPos.top);
    const scrollLeft = calculateScrollPos(target.scrollLeft, contentPos.left);
    let newFirst = this.both ? {
      rows: 0,
      cols: 0
    } : 0;
    let newLast = this.last;
    let isRangeChanged = false;
    let newScrollPos = this.lastScrollPos;
    if (this.both) {
      const isScrollDown = this.lastScrollPos.top <= scrollTop;
      const isScrollRight = this.lastScrollPos.left <= scrollLeft;
      if (!this._appendOnly || this._appendOnly && (isScrollDown || isScrollRight)) {
        const currentIndex = {
          rows: calculateCurrentIndex(scrollTop, this._itemSize[0]),
          cols: calculateCurrentIndex(scrollLeft, this._itemSize[1])
        };
        const triggerIndex = {
          rows: calculateTriggerIndex(currentIndex.rows, this.first.rows, this.last.rows, this.numItemsInViewport.rows, this.d_numToleratedItems[0], isScrollDown),
          cols: calculateTriggerIndex(currentIndex.cols, this.first.cols, this.last.cols, this.numItemsInViewport.cols, this.d_numToleratedItems[1], isScrollRight)
        };
        newFirst = {
          rows: calculateFirst(currentIndex.rows, triggerIndex.rows, this.first.rows, this.last.rows, this.numItemsInViewport.rows, this.d_numToleratedItems[0], isScrollDown),
          cols: calculateFirst(currentIndex.cols, triggerIndex.cols, this.first.cols, this.last.cols, this.numItemsInViewport.cols, this.d_numToleratedItems[1], isScrollRight)
        };
        newLast = {
          rows: calculateLast(currentIndex.rows, newFirst.rows, this.last.rows, this.numItemsInViewport.rows, this.d_numToleratedItems[0]),
          cols: calculateLast(currentIndex.cols, newFirst.cols, this.last.cols, this.numItemsInViewport.cols, this.d_numToleratedItems[1], true)
        };
        isRangeChanged = newFirst.rows !== this.first.rows || newLast.rows !== this.last.rows || newFirst.cols !== this.first.cols || newLast.cols !== this.last.cols || this.isRangeChanged;
        newScrollPos = {
          top: scrollTop,
          left: scrollLeft
        };
      }
    } else {
      const scrollPos = this.horizontal ? scrollLeft : scrollTop;
      const isScrollDownOrRight = this.lastScrollPos <= scrollPos;
      if (!this._appendOnly || this._appendOnly && isScrollDownOrRight) {
        const currentIndex = calculateCurrentIndex(scrollPos, this._itemSize);
        const triggerIndex = calculateTriggerIndex(currentIndex, this.first, this.last, this.numItemsInViewport, this.d_numToleratedItems, isScrollDownOrRight);
        newFirst = calculateFirst(currentIndex, triggerIndex, this.first, this.last, this.numItemsInViewport, this.d_numToleratedItems, isScrollDownOrRight);
        newLast = calculateLast(currentIndex, newFirst, this.last, this.numItemsInViewport, this.d_numToleratedItems);
        isRangeChanged = newFirst !== this.first || newLast !== this.last || this.isRangeChanged;
        newScrollPos = scrollPos;
      }
    }
    return {
      first: newFirst,
      last: newLast,
      isRangeChanged,
      scrollPos: newScrollPos
    };
  }
  onScrollChange(event2) {
    const {
      first,
      last,
      isRangeChanged,
      scrollPos
    } = this.onScrollPositionChange(event2);
    if (isRangeChanged) {
      const newState = {
        first,
        last
      };
      this.setContentPosition(newState);
      this.first = first;
      this.last = last;
      this.lastScrollPos = scrollPos;
      this.handleEvents("onScrollIndexChange", newState);
      if (this._lazy && this.isPageChanged) {
        const lazyLoadState = {
          first: this._step ? Math.min(this.getPageByFirst() * this._step, this.items.length - this._step) : first,
          last: Math.min(this._step ? (this.getPageByFirst() + 1) * this._step : last, this.items.length)
        };
        const isLazyStateChanged = this.lazyLoadState.first !== lazyLoadState.first || this.lazyLoadState.last !== lazyLoadState.last;
        isLazyStateChanged && this.handleEvents("onLazyLoad", lazyLoadState);
        this.lazyLoadState = lazyLoadState;
      }
    }
  }
  onContainerScroll(event2) {
    this.handleEvents("onScroll", {
      originalEvent: event2
    });
    if (this._delay && this.isPageChanged) {
      if (this.scrollTimeout) {
        clearTimeout(this.scrollTimeout);
      }
      if (!this.d_loading && this.showLoader) {
        const {
          isRangeChanged
        } = this.onScrollPositionChange(event2);
        const changed = isRangeChanged || (this._step ? this.isPageChanged : false);
        if (changed) {
          this.d_loading = true;
          this.cd.detectChanges();
        }
      }
      this.scrollTimeout = setTimeout(() => {
        this.onScrollChange(event2);
        if (this.d_loading && this.showLoader && (!this._lazy || this._loading === void 0)) {
          this.d_loading = false;
          this.page = this.getPageByFirst();
          this.cd.detectChanges();
        }
      }, this._delay);
    } else {
      !this.d_loading && this.onScrollChange(event2);
    }
  }
  bindResizeListener() {
    if (isPlatformBrowser(this.platformId)) {
      if (!this.windowResizeListener) {
        this.zone.runOutsideAngular(() => {
          const window2 = this.document.defaultView;
          const event2 = DomHandler.isTouchDevice() ? "orientationchange" : "resize";
          this.windowResizeListener = this.renderer.listen(window2, event2, this.onWindowResize.bind(this));
        });
      }
    }
  }
  unbindResizeListener() {
    if (this.windowResizeListener) {
      this.windowResizeListener();
      this.windowResizeListener = null;
    }
  }
  onWindowResize() {
    if (this.resizeTimeout) {
      clearTimeout(this.resizeTimeout);
    }
    this.resizeTimeout = setTimeout(() => {
      var _a, _b, _c;
      if (DomHandler.isVisible((_a = this.elementViewChild) == null ? void 0 : _a.nativeElement)) {
        const [width, height] = [DomHandler.getWidth((_b = this.elementViewChild) == null ? void 0 : _b.nativeElement), DomHandler.getHeight((_c = this.elementViewChild) == null ? void 0 : _c.nativeElement)];
        const [isDiffWidth, isDiffHeight] = [width !== this.defaultWidth, height !== this.defaultHeight];
        const reinit = this.both ? isDiffWidth || isDiffHeight : this.horizontal ? isDiffWidth : this.vertical ? isDiffHeight : false;
        reinit && this.zone.run(() => {
          this.d_numToleratedItems = this._numToleratedItems;
          this.defaultWidth = width;
          this.defaultHeight = height;
          this.defaultContentWidth = DomHandler.getWidth(this.contentEl);
          this.defaultContentHeight = DomHandler.getHeight(this.contentEl);
          this.init();
        });
      }
    }, this._resizeDelay);
  }
  handleEvents(name, params) {
    return this.options && this.options[name] ? this.options[name](params) : this[name].emit(params);
  }
  getContentOptions() {
    return {
      contentStyleClass: `p-scroller-content ${this.d_loading ? "p-scroller-loading" : ""}`,
      items: this.loadedItems,
      getItemOptions: (index) => this.getOptions(index),
      loading: this.d_loading,
      getLoaderOptions: (index, options) => this.getLoaderOptions(index, options),
      itemSize: this._itemSize,
      rows: this.loadedRows,
      columns: this.loadedColumns,
      spacerStyle: this.spacerStyle,
      contentStyle: this.contentStyle,
      vertical: this.vertical,
      horizontal: this.horizontal,
      both: this.both
    };
  }
  getOptions(renderedIndex) {
    const count = (this._items || []).length;
    const index = this.both ? this.first.rows + renderedIndex : this.first + renderedIndex;
    return {
      index,
      count,
      first: index === 0,
      last: index === count - 1,
      even: index % 2 === 0,
      odd: index % 2 !== 0
    };
  }
  getLoaderOptions(index, extOptions) {
    const count = this.loaderArr.length;
    return {
      index,
      count,
      first: index === 0,
      last: index === count - 1,
      even: index % 2 === 0,
      odd: index % 2 !== 0,
      ...extOptions
    };
  }
};
var Scroller = _Scroller;
__publicField(Scroller, "ɵfac", function Scroller_Factory(t) {
  return new (t || _Scroller)(ɵɵdirectiveInject(DOCUMENT), ɵɵdirectiveInject(PLATFORM_ID), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(NgZone));
});
__publicField(Scroller, "ɵcmp", ɵɵdefineComponent({
  type: _Scroller,
  selectors: [["p-scroller"]],
  contentQueries: function Scroller_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  viewQuery: function Scroller_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c03, 5);
      ɵɵviewQuery(_c16, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.elementViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.contentViewChild = _t.first);
    }
  },
  hostAttrs: [1, "p-scroller-viewport", "p-element"],
  inputs: {
    id: "id",
    style: "style",
    styleClass: "styleClass",
    tabindex: "tabindex",
    items: "items",
    itemSize: "itemSize",
    scrollHeight: "scrollHeight",
    scrollWidth: "scrollWidth",
    orientation: "orientation",
    step: "step",
    delay: "delay",
    resizeDelay: "resizeDelay",
    appendOnly: "appendOnly",
    inline: "inline",
    lazy: "lazy",
    disabled: "disabled",
    loaderDisabled: "loaderDisabled",
    columns: "columns",
    showSpacer: "showSpacer",
    showLoader: "showLoader",
    numToleratedItems: "numToleratedItems",
    loading: "loading",
    autoSize: "autoSize",
    trackBy: "trackBy",
    options: "options"
  },
  outputs: {
    onLazyLoad: "onLazyLoad",
    onScroll: "onScroll",
    onScrollIndexChange: "onScrollIndexChange"
  },
  features: [ɵɵNgOnChangesFeature],
  ngContentSelectors: _c102,
  decls: 3,
  vars: 2,
  consts: [[4, "ngIf", "ngIfElse"], ["disabledContainer", ""], [3, "ngStyle", "ngClass", "scroll"], ["element", ""], ["buildInContent", ""], ["class", "p-scroller-spacer", 3, "ngStyle", 4, "ngIf"], ["class", "p-scroller-loader", 3, "ngClass", 4, "ngIf"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "p-scroller-content", 3, "ngClass", "ngStyle"], ["content", ""], [4, "ngFor", "ngForOf", "ngForTrackBy"], [1, "p-scroller-spacer", 3, "ngStyle"], [1, "p-scroller-loader", 3, "ngClass"], ["buildInLoader", ""], [4, "ngFor", "ngForOf"], ["buildInLoaderIcon", ""], [3, "styleClass"], [4, "ngIf"]],
  template: function Scroller_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵprojectionDef();
      ɵɵtemplate(0, Scroller_ng_container_0_Template, 8, 14, "ng-container", 0);
      ɵɵtemplate(1, Scroller_ng_template_1_Template, 2, 1, "ng-template", null, 1, ɵɵtemplateRefExtractor);
    }
    if (rf & 2) {
      const _r1 = ɵɵreference(2);
      ɵɵproperty("ngIf", !ctx._disabled)("ngIfElse", _r1);
    }
  },
  dependencies: function() {
    return [NgClass, NgForOf, NgIf, NgTemplateOutlet, NgStyle, SpinnerIcon];
  },
  styles: ["p-scroller{flex:1;outline:0 none}.p-scroller{position:relative;overflow:auto;contain:strict;transform:translateZ(0);will-change:scroll-position;outline:0 none}.p-scroller-content{position:absolute;top:0;left:0;min-height:100%;min-width:100%;will-change:transform}.p-scroller-spacer{position:absolute;top:0;left:0;height:1px;width:1px;transform-origin:0 0;pointer-events:none}.p-scroller-loader{position:sticky;top:0;left:0;width:100%;height:100%}.p-scroller-loader.p-component-overlay{display:flex;align-items:center;justify-content:center}.p-scroller-loading-icon{scale:2}.p-scroller-inline .p-scroller-content{position:static}\n"],
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Scroller, [{
    type: Component,
    args: [{
      selector: "p-scroller",
      template: `
        <ng-container *ngIf="!_disabled; else disabledContainer">
            <div
                #element
                [attr.id]="_id"
                [attr.tabindex]="tabindex"
                [ngStyle]="_style"
                [class]="_styleClass"
                [ngClass]="{ 'p-scroller': true, 'p-scroller-inline': inline, 'p-both-scroll': both, 'p-horizontal-scroll': horizontal }"
                (scroll)="onContainerScroll($event)"
            >
                <ng-container *ngIf="contentTemplate; else buildInContent">
                    <ng-container *ngTemplateOutlet="contentTemplate; context: { $implicit: loadedItems, options: getContentOptions() }"></ng-container>
                </ng-container>
                <ng-template #buildInContent>
                    <div #content class="p-scroller-content" [ngClass]="{ 'p-scroller-loading': d_loading }" [ngStyle]="contentStyle">
                        <ng-container *ngFor="let item of loadedItems; let index = index; trackBy: _trackBy || index">
                            <ng-container *ngTemplateOutlet="itemTemplate; context: { $implicit: item, options: getOptions(index) }"></ng-container>
                        </ng-container>
                    </div>
                </ng-template>
                <div *ngIf="_showSpacer" class="p-scroller-spacer" [ngStyle]="spacerStyle"></div>
                <div *ngIf="!loaderDisabled && _showLoader && d_loading" class="p-scroller-loader" [ngClass]="{ 'p-component-overlay': !loaderTemplate }">
                    <ng-container *ngIf="loaderTemplate; else buildInLoader">
                        <ng-container *ngFor="let item of loaderArr; let index = index">
                            <ng-container *ngTemplateOutlet="loaderTemplate; context: { options: getLoaderOptions(index, both && { numCols: _numItemsInViewport.cols }) }"></ng-container>
                        </ng-container>
                    </ng-container>
                    <ng-template #buildInLoader>
                        <ng-container *ngIf="loaderIconTemplate; else buildInLoaderIcon">
                            <ng-container *ngTemplateOutlet="loaderIconTemplate; context: { options: { styleClass: 'p-scroller-loading-icon' } }"></ng-container>
                        </ng-container>
                        <ng-template #buildInLoaderIcon>
                            <SpinnerIcon [styleClass]="'p-scroller-loading-icon'" />
                        </ng-template>
                    </ng-template>
                </div>
            </div>
        </ng-container>
        <ng-template #disabledContainer>
            <ng-content></ng-content>
            <ng-container *ngIf="contentTemplate">
                <ng-container *ngTemplateOutlet="contentTemplate; context: { $implicit: items, options: { rows: _items, columns: loadedColumns } }"></ng-container>
            </ng-container>
        </ng-template>
    `,
      changeDetection: ChangeDetectionStrategy.Default,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-scroller-viewport p-element"
      },
      styles: ["p-scroller{flex:1;outline:0 none}.p-scroller{position:relative;overflow:auto;contain:strict;transform:translateZ(0);will-change:scroll-position;outline:0 none}.p-scroller-content{position:absolute;top:0;left:0;min-height:100%;min-width:100%;will-change:transform}.p-scroller-spacer{position:absolute;top:0;left:0;height:1px;width:1px;transform-origin:0 0;pointer-events:none}.p-scroller-loader{position:sticky;top:0;left:0;width:100%;height:100%}.p-scroller-loader.p-component-overlay{display:flex;align-items:center;justify-content:center}.p-scroller-loading-icon{scale:2}.p-scroller-inline .p-scroller-content{position:static}\n"]
    }]
  }], function() {
    return [{
      type: Document,
      decorators: [{
        type: Inject,
        args: [DOCUMENT]
      }]
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }, {
      type: Renderer2
    }, {
      type: ChangeDetectorRef
    }, {
      type: NgZone
    }];
  }, {
    id: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    tabindex: [{
      type: Input
    }],
    items: [{
      type: Input
    }],
    itemSize: [{
      type: Input
    }],
    scrollHeight: [{
      type: Input
    }],
    scrollWidth: [{
      type: Input
    }],
    orientation: [{
      type: Input
    }],
    step: [{
      type: Input
    }],
    delay: [{
      type: Input
    }],
    resizeDelay: [{
      type: Input
    }],
    appendOnly: [{
      type: Input
    }],
    inline: [{
      type: Input
    }],
    lazy: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    loaderDisabled: [{
      type: Input
    }],
    columns: [{
      type: Input
    }],
    showSpacer: [{
      type: Input
    }],
    showLoader: [{
      type: Input
    }],
    numToleratedItems: [{
      type: Input
    }],
    loading: [{
      type: Input
    }],
    autoSize: [{
      type: Input
    }],
    trackBy: [{
      type: Input
    }],
    options: [{
      type: Input
    }],
    onLazyLoad: [{
      type: Output
    }],
    onScroll: [{
      type: Output
    }],
    onScrollIndexChange: [{
      type: Output
    }],
    elementViewChild: [{
      type: ViewChild,
      args: ["element"]
    }],
    contentViewChild: [{
      type: ViewChild,
      args: ["content"]
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var _ScrollerModule = class {
};
var ScrollerModule = _ScrollerModule;
__publicField(ScrollerModule, "ɵfac", function ScrollerModule_Factory(t) {
  return new (t || _ScrollerModule)();
});
__publicField(ScrollerModule, "ɵmod", ɵɵdefineNgModule({
  type: _ScrollerModule,
  declarations: [Scroller],
  imports: [CommonModule, SharedModule, SpinnerIcon],
  exports: [Scroller, SharedModule]
}));
__publicField(ScrollerModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, SharedModule, SpinnerIcon, SharedModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ScrollerModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, SharedModule, SpinnerIcon],
      exports: [Scroller, SharedModule],
      declarations: [Scroller]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-search.mjs
var _SearchIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var SearchIcon = _SearchIcon;
__publicField(SearchIcon, "ɵfac", function() {
  let ɵSearchIcon_BaseFactory;
  return function SearchIcon_Factory(t) {
    return (ɵSearchIcon_BaseFactory || (ɵSearchIcon_BaseFactory = ɵɵgetInheritedFactory(_SearchIcon)))(t || _SearchIcon);
  };
}());
__publicField(SearchIcon, "ɵcmp", ɵɵdefineComponent({
  type: _SearchIcon,
  selectors: [["SearchIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 6,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M2.67602 11.0265C3.6661 11.688 4.83011 12.0411 6.02086 12.0411C6.81149 12.0411 7.59438 11.8854 8.32483 11.5828C8.87005 11.357 9.37808 11.0526 9.83317 10.6803L12.9769 13.8241C13.0323 13.8801 13.0983 13.9245 13.171 13.9548C13.2438 13.985 13.3219 14.0003 13.4007 14C13.4795 14.0003 13.5575 13.985 13.6303 13.9548C13.7031 13.9245 13.7691 13.8801 13.8244 13.8241C13.9367 13.7116 13.9998 13.5592 13.9998 13.4003C13.9998 13.2414 13.9367 13.089 13.8244 12.9765L10.6807 9.8328C11.053 9.37773 11.3573 8.86972 11.5831 8.32452C11.8857 7.59408 12.0414 6.81119 12.0414 6.02056C12.0414 4.8298 11.6883 3.66579 11.0268 2.67572C10.3652 1.68564 9.42494 0.913972 8.32483 0.45829C7.22472 0.00260857 6.01418 -0.116618 4.84631 0.115686C3.67844 0.34799 2.60568 0.921393 1.76369 1.76338C0.921698 2.60537 0.348296 3.67813 0.115991 4.84601C-0.116313 6.01388 0.00291375 7.22441 0.458595 8.32452C0.914277 9.42464 1.68595 10.3649 2.67602 11.0265ZM3.35565 2.0158C4.14456 1.48867 5.07206 1.20731 6.02086 1.20731C7.29317 1.20731 8.51338 1.71274 9.41304 2.6124C10.3127 3.51206 10.8181 4.73226 10.8181 6.00457C10.8181 6.95337 10.5368 7.88088 10.0096 8.66978C9.48251 9.45868 8.73328 10.0736 7.85669 10.4367C6.98011 10.7997 6.01554 10.8947 5.08496 10.7096C4.15439 10.5245 3.2996 10.0676 2.62869 9.39674C1.95778 8.72583 1.50089 7.87104 1.31579 6.94046C1.13068 6.00989 1.22568 5.04532 1.58878 4.16874C1.95187 3.29215 2.56675 2.54292 3.35565 2.0158Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function SearchIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1);
      ɵɵelementEnd();
      ɵɵelementStart(3, "defs")(4, "clipPath", 2);
      ɵɵelement(5, "rect", 3);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(3);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SearchIcon, [{
    type: Component,
    args: [{
      selector: "SearchIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M2.67602 11.0265C3.6661 11.688 4.83011 12.0411 6.02086 12.0411C6.81149 12.0411 7.59438 11.8854 8.32483 11.5828C8.87005 11.357 9.37808 11.0526 9.83317 10.6803L12.9769 13.8241C13.0323 13.8801 13.0983 13.9245 13.171 13.9548C13.2438 13.985 13.3219 14.0003 13.4007 14C13.4795 14.0003 13.5575 13.985 13.6303 13.9548C13.7031 13.9245 13.7691 13.8801 13.8244 13.8241C13.9367 13.7116 13.9998 13.5592 13.9998 13.4003C13.9998 13.2414 13.9367 13.089 13.8244 12.9765L10.6807 9.8328C11.053 9.37773 11.3573 8.86972 11.5831 8.32452C11.8857 7.59408 12.0414 6.81119 12.0414 6.02056C12.0414 4.8298 11.6883 3.66579 11.0268 2.67572C10.3652 1.68564 9.42494 0.913972 8.32483 0.45829C7.22472 0.00260857 6.01418 -0.116618 4.84631 0.115686C3.67844 0.34799 2.60568 0.921393 1.76369 1.76338C0.921698 2.60537 0.348296 3.67813 0.115991 4.84601C-0.116313 6.01388 0.00291375 7.22441 0.458595 8.32452C0.914277 9.42464 1.68595 10.3649 2.67602 11.0265ZM3.35565 2.0158C4.14456 1.48867 5.07206 1.20731 6.02086 1.20731C7.29317 1.20731 8.51338 1.71274 9.41304 2.6124C10.3127 3.51206 10.8181 4.73226 10.8181 6.00457C10.8181 6.95337 10.5368 7.88088 10.0096 8.66978C9.48251 9.45868 8.73328 10.0736 7.85669 10.4367C6.98011 10.7997 6.01554 10.8947 5.08496 10.7096C4.15439 10.5245 3.2996 10.0676 2.62869 9.39674C1.95778 8.72583 1.50089 7.87104 1.31579 6.94046C1.13068 6.00989 1.22568 5.04532 1.58878 4.16874C1.95187 3.29215 2.56675 2.54292 3.35565 2.0158Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-dropdown.mjs
function DropdownItem_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    let tmp_0_0;
    ɵɵadvance(1);
    ɵɵtextInterpolate((tmp_0_0 = ctx_r0.label) !== null && tmp_0_0 !== void 0 ? tmp_0_0 : "empty");
  }
}
function DropdownItem_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c04 = function(a0) {
  return {
    height: a0
  };
};
var _c17 = function(a1, a2) {
  return {
    "p-dropdown-item": true,
    "p-highlight": a1,
    "p-disabled": a2
  };
};
var _c24 = function(a0) {
  return {
    $implicit: a0
  };
};
var _c34 = ["container"];
var _c44 = ["filter"];
var _c54 = ["in"];
var _c64 = ["editableInput"];
var _c74 = ["items"];
var _c83 = ["scroller"];
var _c93 = ["overlay"];
function Dropdown_span_5_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r10 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r10.label || "empty");
  }
}
function Dropdown_span_5_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c103 = function(a1) {
  return {
    "p-dropdown-label p-inputtext": true,
    "p-dropdown-label-empty": a1
  };
};
function Dropdown_span_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 14);
    ɵɵtemplate(1, Dropdown_span_5_ng_container_1_Template, 2, 1, "ng-container", 8);
    ɵɵtemplate(2, Dropdown_span_5_ng_container_2_Template, 1, 0, "ng-container", 15);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("ngClass", ɵɵpureFunction1(9, _c103, ctx_r2.label == null || ctx_r2.label.length === 0))("pTooltip", ctx_r2.tooltip)("tooltipPosition", ctx_r2.tooltipPosition)("positionStyle", ctx_r2.tooltipPositionStyle)("tooltipStyleClass", ctx_r2.tooltipStyleClass);
    ɵɵattribute("id", ctx_r2.labelId);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r2.selectedItemTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r2.selectedItemTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(11, _c24, ctx_r2.selectedOption));
  }
}
var _c112 = function(a1) {
  return {
    "p-dropdown-label p-inputtext p-placeholder": true,
    "p-dropdown-label-empty": a1
  };
};
function Dropdown_span_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 16);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    ɵɵproperty("ngClass", ɵɵpureFunction1(2, _c112, ctx_r3.placeholder == null || ctx_r3.placeholder.length === 0));
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r3.placeholder || "empty");
  }
}
function Dropdown_input_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r14 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "input", 17, 18);
    ɵɵlistener("input", function Dropdown_input_7_Template_input_input_0_listener($event) {
      ɵɵrestoreView(_r14);
      const ctx_r13 = ɵɵnextContext();
      return ɵɵresetView(ctx_r13.onEditableInputChange($event));
    })("focus", function Dropdown_input_7_Template_input_focus_0_listener($event) {
      ɵɵrestoreView(_r14);
      const ctx_r15 = ɵɵnextContext();
      return ɵɵresetView(ctx_r15.onEditableInputFocus($event));
    })("blur", function Dropdown_input_7_Template_input_blur_0_listener($event) {
      ɵɵrestoreView(_r14);
      const ctx_r16 = ɵɵnextContext();
      return ɵɵresetView(ctx_r16.onInputBlur($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext();
    ɵɵproperty("disabled", ctx_r4.disabled);
    ɵɵattribute("maxlength", ctx_r4.maxlength)("placeholder", ctx_r4.placeholder)("aria-expanded", ctx_r4.overlayVisible);
  }
}
function Dropdown_ng_container_8_TimesIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "TimesIcon", 21);
    ɵɵlistener("click", function Dropdown_ng_container_8_TimesIcon_1_Template_TimesIcon_click_0_listener($event) {
      ɵɵrestoreView(_r20);
      const ctx_r19 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r19.clear($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-dropdown-clear-icon");
  }
}
function Dropdown_ng_container_8_span_2_1_ng_template_0_Template(rf, ctx) {
}
function Dropdown_ng_container_8_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Dropdown_ng_container_8_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Dropdown_ng_container_8_span_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r24 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "span", 22);
    ɵɵlistener("click", function Dropdown_ng_container_8_span_2_Template_span_click_0_listener($event) {
      ɵɵrestoreView(_r24);
      const ctx_r23 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r23.clear($event));
    });
    ɵɵtemplate(1, Dropdown_ng_container_8_span_2_1_Template, 1, 0, null, 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r18 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r18.clearIconTemplate);
  }
}
function Dropdown_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Dropdown_ng_container_8_TimesIcon_1_Template, 1, 1, "TimesIcon", 19);
    ɵɵtemplate(2, Dropdown_ng_container_8_span_2_Template, 2, 1, "span", 20);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r5 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r5.clearIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.clearIconTemplate);
  }
}
function Dropdown_ng_container_10_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 26);
  }
  if (rf & 2) {
    const ctx_r25 = ɵɵnextContext(2);
    ɵɵproperty("ngClass", ctx_r25.dropdownIcon);
  }
}
function Dropdown_ng_container_10_ChevronDownIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ChevronDownIcon", 27);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-dropdown-trigger-icon");
  }
}
function Dropdown_ng_container_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Dropdown_ng_container_10_span_1_Template, 1, 1, "span", 24);
    ɵɵtemplate(2, Dropdown_ng_container_10_ChevronDownIcon_2_Template, 1, 1, "ChevronDownIcon", 25);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r6 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r6.dropdownIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r6.dropdownIcon);
  }
}
function Dropdown_span_11_1_ng_template_0_Template(rf, ctx) {
}
function Dropdown_span_11_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Dropdown_span_11_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Dropdown_span_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 28);
    ɵɵtemplate(1, Dropdown_span_11_1_Template, 1, 0, null, 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r7 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r7.dropdownIconTemplate);
  }
}
function Dropdown_ng_template_14_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Dropdown_ng_template_14_div_2_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c122 = function(a0) {
  return {
    options: a0
  };
};
function Dropdown_ng_template_14_div_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Dropdown_ng_template_14_div_2_ng_container_1_ng_container_1_Template, 1, 0, "ng-container", 15);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r36 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r36.filterTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c122, ctx_r36.filterOptions));
  }
}
function Dropdown_ng_template_14_div_2_ng_template_2_SearchIcon_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "SearchIcon", 27);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-dropdown-filter-icon");
  }
}
function Dropdown_ng_template_14_div_2_ng_template_2_span_4_1_ng_template_0_Template(rf, ctx) {
}
function Dropdown_ng_template_14_div_2_ng_template_2_span_4_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Dropdown_ng_template_14_div_2_ng_template_2_span_4_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Dropdown_ng_template_14_div_2_ng_template_2_span_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 41);
    ɵɵtemplate(1, Dropdown_ng_template_14_div_2_ng_template_2_span_4_1_Template, 1, 0, null, 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r42 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r42.filterIconTemplate);
  }
}
function Dropdown_ng_template_14_div_2_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r47 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 37)(1, "input", 38, 39);
    ɵɵlistener("keydown.enter", function Dropdown_ng_template_14_div_2_ng_template_2_Template_input_keydown_enter_1_listener($event) {
      return $event.preventDefault();
    })("keydown", function Dropdown_ng_template_14_div_2_ng_template_2_Template_input_keydown_1_listener($event) {
      ɵɵrestoreView(_r47);
      const ctx_r46 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r46.onKeydown($event, false));
    })("input", function Dropdown_ng_template_14_div_2_ng_template_2_Template_input_input_1_listener($event) {
      ɵɵrestoreView(_r47);
      const ctx_r48 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r48.onFilterInputChange($event));
    });
    ɵɵelementEnd();
    ɵɵtemplate(3, Dropdown_ng_template_14_div_2_ng_template_2_SearchIcon_3_Template, 1, 1, "SearchIcon", 25);
    ɵɵtemplate(4, Dropdown_ng_template_14_div_2_ng_template_2_span_4_Template, 2, 1, "span", 40);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r38 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("value", ctx_r38.filterValue || "");
    ɵɵattribute("placeholder", ctx_r38.filterPlaceholder)("aria-label", ctx_r38.ariaFilterLabel)("aria-activedescendant", ctx_r38.overlayVisible ? "p-highlighted-option" : ctx_r38.labelId);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r38.filterIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r38.filterIconTemplate);
  }
}
function Dropdown_ng_template_14_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 34);
    ɵɵlistener("click", function Dropdown_ng_template_14_div_2_Template_div_click_0_listener($event) {
      return $event.stopPropagation();
    });
    ɵɵtemplate(1, Dropdown_ng_template_14_div_2_ng_container_1_Template, 2, 4, "ng-container", 35);
    ɵɵtemplate(2, Dropdown_ng_template_14_div_2_ng_template_2_Template, 5, 6, "ng-template", null, 36, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const _r37 = ɵɵreference(3);
    const ctx_r30 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r30.filterTemplate)("ngIfElse", _r37);
  }
}
function Dropdown_ng_template_14_p_scroller_4_ng_template_2_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c132 = function(a0, a1) {
  return {
    $implicit: a0,
    options: a1
  };
};
function Dropdown_ng_template_14_p_scroller_4_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Dropdown_ng_template_14_p_scroller_4_ng_template_2_ng_container_0_Template, 1, 0, "ng-container", 15);
  }
  if (rf & 2) {
    const items_r53 = ctx.$implicit;
    const scrollerOptions_r54 = ctx.options;
    ɵɵnextContext(2);
    const _r33 = ɵɵreference(7);
    ɵɵproperty("ngTemplateOutlet", _r33)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c132, items_r53, scrollerOptions_r54));
  }
}
function Dropdown_ng_template_14_p_scroller_4_ng_container_3_ng_template_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Dropdown_ng_template_14_p_scroller_4_ng_container_3_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Dropdown_ng_template_14_p_scroller_4_ng_container_3_ng_template_1_ng_container_0_Template, 1, 0, "ng-container", 15);
  }
  if (rf & 2) {
    const scrollerOptions_r57 = ctx.options;
    const ctx_r56 = ɵɵnextContext(4);
    ɵɵproperty("ngTemplateOutlet", ctx_r56.loaderTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c122, scrollerOptions_r57));
  }
}
function Dropdown_ng_template_14_p_scroller_4_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Dropdown_ng_template_14_p_scroller_4_ng_container_3_ng_template_1_Template, 1, 4, "ng-template", 44);
    ɵɵelementContainerEnd();
  }
}
function Dropdown_ng_template_14_p_scroller_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r60 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-scroller", 42, 43);
    ɵɵlistener("onLazyLoad", function Dropdown_ng_template_14_p_scroller_4_Template_p_scroller_onLazyLoad_0_listener($event) {
      ɵɵrestoreView(_r60);
      const ctx_r59 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r59.onLazyLoad.emit($event));
    });
    ɵɵtemplate(2, Dropdown_ng_template_14_p_scroller_4_ng_template_2_Template, 1, 5, "ng-template", 13);
    ɵɵtemplate(3, Dropdown_ng_template_14_p_scroller_4_ng_container_3_Template, 2, 0, "ng-container", 8);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r31 = ɵɵnextContext(2);
    ɵɵstyleMap(ɵɵpureFunction1(8, _c04, ctx_r31.scrollHeight));
    ɵɵproperty("items", ctx_r31.optionsToDisplay)("itemSize", ctx_r31.virtualScrollItemSize || ctx_r31._itemSize)("autoSize", true)("lazy", ctx_r31.lazy)("options", ctx_r31.virtualScrollOptions);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ctx_r31.loaderTemplate);
  }
}
function Dropdown_ng_template_14_ng_container_5_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c142 = function() {
  return {};
};
function Dropdown_ng_template_14_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Dropdown_ng_template_14_ng_container_5_ng_container_1_Template, 1, 0, "ng-container", 15);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    ɵɵnextContext();
    const _r33 = ɵɵreference(7);
    const ctx_r32 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", _r33)("ngTemplateOutletContext", ɵɵpureFunction2(3, _c132, ctx_r32.optionsToDisplay, ɵɵpureFunction0(2, _c142)));
  }
}
function Dropdown_ng_template_14_ng_template_6_ng_container_2_ng_template_1_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const optgroup_r72 = ɵɵnextContext().$implicit;
    const ctx_r73 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r73.getOptionGroupLabel(optgroup_r72) || "empty");
  }
}
function Dropdown_ng_template_14_ng_template_6_ng_container_2_ng_template_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Dropdown_ng_template_14_ng_template_6_ng_container_2_ng_template_1_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c152 = function(a0, a1) {
  return {
    $implicit: a0,
    selectedOption: a1
  };
};
function Dropdown_ng_template_14_ng_template_6_ng_container_2_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "li", 50);
    ɵɵtemplate(1, Dropdown_ng_template_14_ng_template_6_ng_container_2_ng_template_1_span_1_Template, 2, 1, "span", 8);
    ɵɵtemplate(2, Dropdown_ng_template_14_ng_template_6_ng_container_2_ng_template_1_ng_container_2_Template, 1, 0, "ng-container", 15);
    ɵɵelementEnd();
    ɵɵtemplate(3, Dropdown_ng_template_14_ng_template_6_ng_container_2_ng_template_1_ng_container_3_Template, 1, 0, "ng-container", 15);
  }
  if (rf & 2) {
    const optgroup_r72 = ctx.$implicit;
    const scrollerOptions_r63 = ɵɵnextContext(2).options;
    const _r67 = ɵɵreference(5);
    const ctx_r71 = ɵɵnextContext(2);
    ɵɵproperty("ngStyle", ɵɵpureFunction1(6, _c04, scrollerOptions_r63.itemSize + "px"));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r71.groupTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r71.groupTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(8, _c24, optgroup_r72));
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", _r67)("ngTemplateOutletContext", ɵɵpureFunction2(10, _c152, ctx_r71.getOptionGroupChildren(optgroup_r72), ctx_r71.selectedOption));
  }
}
function Dropdown_ng_template_14_ng_template_6_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Dropdown_ng_template_14_ng_template_6_ng_container_2_ng_template_1_Template, 4, 13, "ng-template", 49);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const items_r62 = ɵɵnextContext().$implicit;
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", items_r62);
  }
}
function Dropdown_ng_template_14_ng_template_6_ng_container_3_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Dropdown_ng_template_14_ng_template_6_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Dropdown_ng_template_14_ng_template_6_ng_container_3_ng_container_1_Template, 1, 0, "ng-container", 15);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const items_r62 = ɵɵnextContext().$implicit;
    const _r67 = ɵɵreference(5);
    const ctx_r66 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", _r67)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c152, items_r62, ctx_r66.selectedOption));
  }
}
function Dropdown_ng_template_14_ng_template_6_ng_template_4_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r87 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-dropdownItem", 51);
    ɵɵlistener("onClick", function Dropdown_ng_template_14_ng_template_6_ng_template_4_ng_template_0_Template_p_dropdownItem_onClick_0_listener($event) {
      ɵɵrestoreView(_r87);
      const ctx_r86 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r86.onItemClick($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const option_r84 = ctx.$implicit;
    const selectedOption_r82 = ɵɵnextContext().selectedOption;
    const ctx_r83 = ɵɵnextContext(3);
    ɵɵproperty("option", option_r84)("selected", selectedOption_r82 == option_r84)("label", ctx_r83.getOptionLabel(option_r84))("disabled", ctx_r83.isOptionDisabled(option_r84))("template", ctx_r83.itemTemplate);
  }
}
function Dropdown_ng_template_14_ng_template_6_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Dropdown_ng_template_14_ng_template_6_ng_template_4_ng_template_0_Template, 1, 5, "ng-template", 49);
  }
  if (rf & 2) {
    const options_r81 = ctx.$implicit;
    ɵɵproperty("ngForOf", options_r81);
  }
}
function Dropdown_ng_template_14_ng_template_6_li_6_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r89 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵtextInterpolate1(" ", ctx_r89.emptyFilterMessageLabel, " ");
  }
}
function Dropdown_ng_template_14_ng_template_6_li_6_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0, null, 53);
  }
}
function Dropdown_ng_template_14_ng_template_6_li_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "li", 52);
    ɵɵtemplate(1, Dropdown_ng_template_14_ng_template_6_li_6_ng_container_1_Template, 2, 1, "ng-container", 35);
    ɵɵtemplate(2, Dropdown_ng_template_14_ng_template_6_li_6_ng_container_2_Template, 2, 0, "ng-container", 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const scrollerOptions_r63 = ɵɵnextContext().options;
    const ctx_r69 = ɵɵnextContext(2);
    ɵɵproperty("ngStyle", ɵɵpureFunction1(4, _c04, scrollerOptions_r63.itemSize + "px"));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r69.emptyFilterTemplate && !ctx_r69.emptyTemplate)("ngIfElse", ctx_r69.emptyFilter);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r69.emptyFilterTemplate || ctx_r69.emptyTemplate);
  }
}
function Dropdown_ng_template_14_ng_template_6_li_7_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtext(1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r93 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵtextInterpolate1(" ", ctx_r93.emptyMessageLabel, " ");
  }
}
function Dropdown_ng_template_14_ng_template_6_li_7_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0, null, 54);
  }
}
function Dropdown_ng_template_14_ng_template_6_li_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "li", 52);
    ɵɵtemplate(1, Dropdown_ng_template_14_ng_template_6_li_7_ng_container_1_Template, 2, 1, "ng-container", 35);
    ɵɵtemplate(2, Dropdown_ng_template_14_ng_template_6_li_7_ng_container_2_Template, 2, 0, "ng-container", 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const scrollerOptions_r63 = ɵɵnextContext().options;
    const ctx_r70 = ɵɵnextContext(2);
    ɵɵproperty("ngStyle", ɵɵpureFunction1(4, _c04, scrollerOptions_r63.itemSize + "px"));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r70.emptyTemplate)("ngIfElse", ctx_r70.empty);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r70.emptyTemplate);
  }
}
function Dropdown_ng_template_14_ng_template_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "ul", 45, 46);
    ɵɵtemplate(2, Dropdown_ng_template_14_ng_template_6_ng_container_2_Template, 2, 1, "ng-container", 8);
    ɵɵtemplate(3, Dropdown_ng_template_14_ng_template_6_ng_container_3_Template, 2, 5, "ng-container", 8);
    ɵɵtemplate(4, Dropdown_ng_template_14_ng_template_6_ng_template_4_Template, 1, 1, "ng-template", null, 47, ɵɵtemplateRefExtractor);
    ɵɵtemplate(6, Dropdown_ng_template_14_ng_template_6_li_6_Template, 3, 6, "li", 48);
    ɵɵtemplate(7, Dropdown_ng_template_14_ng_template_6_li_7_Template, 3, 6, "li", 48);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const scrollerOptions_r63 = ctx.options;
    const ctx_r34 = ɵɵnextContext(2);
    ɵɵstyleMap(scrollerOptions_r63.contentStyle);
    ɵɵproperty("ngClass", scrollerOptions_r63.contentStyleClass);
    ɵɵattribute("id", ctx_r34.listId);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r34.group);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r34.group);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ctx_r34.filterValue && ctx_r34.isEmpty());
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r34.filterValue && ctx_r34.isEmpty());
  }
}
function Dropdown_ng_template_14_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Dropdown_ng_template_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 29);
    ɵɵtemplate(1, Dropdown_ng_template_14_ng_container_1_Template, 1, 0, "ng-container", 23);
    ɵɵtemplate(2, Dropdown_ng_template_14_div_2_Template, 4, 2, "div", 30);
    ɵɵelementStart(3, "div", 31);
    ɵɵtemplate(4, Dropdown_ng_template_14_p_scroller_4_Template, 4, 10, "p-scroller", 32);
    ɵɵtemplate(5, Dropdown_ng_template_14_ng_container_5_Template, 2, 6, "ng-container", 8);
    ɵɵtemplate(6, Dropdown_ng_template_14_ng_template_6_Template, 8, 8, "ng-template", null, 33, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
    ɵɵtemplate(8, Dropdown_ng_template_14_ng_container_8_Template, 1, 0, "ng-container", 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r9 = ɵɵnextContext();
    ɵɵclassMap(ctx_r9.panelStyleClass);
    ɵɵproperty("ngClass", "p-dropdown-panel p-component")("ngStyle", ctx_r9.panelStyle);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r9.headerTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r9.filter);
    ɵɵadvance(1);
    ɵɵstyleProp("max-height", ctx_r9.virtualScroll ? "auto" : ctx_r9.scrollHeight || "auto");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r9.virtualScroll);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r9.virtualScroll);
    ɵɵadvance(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r9.footerTemplate);
  }
}
var _c162 = function(a1, a2, a3, a4) {
  return {
    "p-dropdown p-component": true,
    "p-disabled": a1,
    "p-dropdown-open": a2,
    "p-focus": a3,
    "p-dropdown-clearable": a4
  };
};
var DROPDOWN_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => Dropdown),
  multi: true
};
var _DropdownItem = class {
  constructor() {
    __publicField(this, "option");
    __publicField(this, "selected");
    __publicField(this, "label");
    __publicField(this, "disabled");
    __publicField(this, "visible");
    __publicField(this, "itemSize");
    __publicField(this, "template");
    __publicField(this, "onClick", new EventEmitter());
  }
  onOptionClick(event2) {
    this.onClick.emit({
      originalEvent: event2,
      option: this.option
    });
  }
};
var DropdownItem = _DropdownItem;
__publicField(DropdownItem, "ɵfac", function DropdownItem_Factory(t) {
  return new (t || _DropdownItem)();
});
__publicField(DropdownItem, "ɵcmp", ɵɵdefineComponent({
  type: _DropdownItem,
  selectors: [["p-dropdownItem"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    option: "option",
    selected: "selected",
    label: "label",
    disabled: "disabled",
    visible: "visible",
    itemSize: "itemSize",
    template: "template"
  },
  outputs: {
    onClick: "onClick"
  },
  decls: 3,
  vars: 15,
  consts: [["role", "option", "pRipple", "", 3, "ngStyle", "id", "ngClass", "click"], [4, "ngIf"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"]],
  template: function DropdownItem_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "li", 0);
      ɵɵlistener("click", function DropdownItem_Template_li_click_0_listener($event) {
        return ctx.onOptionClick($event);
      });
      ɵɵtemplate(1, DropdownItem_span_1_Template, 2, 1, "span", 1);
      ɵɵtemplate(2, DropdownItem_ng_container_2_Template, 1, 0, "ng-container", 2);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵproperty("ngStyle", ɵɵpureFunction1(8, _c04, ctx.itemSize + "px"))("id", ctx.selected ? "p-highlighted-option" : "")("ngClass", ɵɵpureFunction2(10, _c17, ctx.selected, ctx.disabled));
      ɵɵattribute("aria-label", ctx.label)("aria-selected", ctx.selected);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", !ctx.template);
      ɵɵadvance(1);
      ɵɵproperty("ngTemplateOutlet", ctx.template)("ngTemplateOutletContext", ɵɵpureFunction1(13, _c24, ctx.option));
    }
  },
  dependencies: [NgClass, NgIf, NgTemplateOutlet, NgStyle, Ripple],
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DropdownItem, [{
    type: Component,
    args: [{
      selector: "p-dropdownItem",
      template: `
        <li
            (click)="onOptionClick($event)"
            role="option"
            pRipple
            [attr.aria-label]="label"
            [attr.aria-selected]="selected"
            [ngStyle]="{ height: itemSize + 'px' }"
            [id]="selected ? 'p-highlighted-option' : ''"
            [ngClass]="{ 'p-dropdown-item': true, 'p-highlight': selected, 'p-disabled': disabled }"
        >
            <span *ngIf="!template">{{ label ?? 'empty' }}</span>
            <ng-container *ngTemplateOutlet="template; context: { $implicit: option }"></ng-container>
        </li>
    `,
      host: {
        class: "p-element"
      }
    }]
  }], null, {
    option: [{
      type: Input
    }],
    selected: [{
      type: Input
    }],
    label: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    visible: [{
      type: Input
    }],
    itemSize: [{
      type: Input
    }],
    template: [{
      type: Input
    }],
    onClick: [{
      type: Output
    }]
  });
})();
var _Dropdown = class {
  constructor(el, renderer, cd, zone, filterService, config) {
    __publicField(this, "el");
    __publicField(this, "renderer");
    __publicField(this, "cd");
    __publicField(this, "zone");
    __publicField(this, "filterService");
    __publicField(this, "config");
    /**
     * Height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    __publicField(this, "scrollHeight", "200px");
    /**
     * When specified, displays an input field to filter the items on keyup.
     * @group Props
     */
    __publicField(this, "filter");
    /**
     * Name of the input element.
     * @group Props
     */
    __publicField(this, "name");
    /**
     * Inline style of the element.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Inline style of the overlay panel element.
     * @group Props
     */
    __publicField(this, "panelStyle");
    /**
     * Style class of the element.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Style class of the overlay panel element.
     * @group Props
     */
    __publicField(this, "panelStyleClass");
    /**
     * When present, it specifies that the component cannot be edited.
     * @group Props
     */
    __publicField(this, "readonly");
    /**
     * When present, it specifies that an input field must be filled out before submitting the form.
     * @group Props
     */
    __publicField(this, "required");
    /**
     * When present, custom value instead of predefined options can be entered using the editable input field.
     * @group Props
     */
    __publicField(this, "editable");
    /**
     * Target element to attach the overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @group Props
     */
    __publicField(this, "appendTo");
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    __publicField(this, "tabindex");
    /**
     * Default text to display when no option is selected.
     * @group Props
     */
    __publicField(this, "placeholder");
    /**
     * Placeholder text to show when filter input is empty.
     * @group Props
     */
    __publicField(this, "filterPlaceholder");
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    __publicField(this, "filterLocale");
    /**
     * Identifier of the accessible input element.
     * @group Props
     */
    __publicField(this, "inputId");
    /**
     * No description available.
     * @group Props
     */
    __publicField(this, "selectId");
    /**
     * A property to uniquely identify a value in options.
     * @group Props
     */
    __publicField(this, "dataKey");
    /**
     * When filtering is enabled, filterBy decides which field or fields (comma separated) to search against.
     * @group Props
     */
    __publicField(this, "filterBy");
    /**
     * When present, it specifies that the component should automatically get focus on load.
     * @group Props
     */
    __publicField(this, "autofocus");
    /**
     * Clears the filter value when hiding the dropdown.
     * @group Props
     */
    __publicField(this, "resetFilterOnHide", false);
    /**
     * Icon class of the dropdown icon.
     * @group Props
     */
    __publicField(this, "dropdownIcon");
    /**
     * Name of the label field of an option.
     * @group Props
     */
    __publicField(this, "optionLabel");
    /**
     * Name of the value field of an option.
     * @group Props
     */
    __publicField(this, "optionValue");
    /**
     * Name of the disabled field of an option.
     * @group Props
     */
    __publicField(this, "optionDisabled");
    /**
     * Name of the label field of an option group.
     * @group Props
     */
    __publicField(this, "optionGroupLabel");
    /**
     * Name of the options field of an option group.
     * @group Props
     */
    __publicField(this, "optionGroupChildren", "items");
    /**
     * Whether to display the first item as the label if no placeholder is defined and value is null.
     * @group Props
     */
    __publicField(this, "autoDisplayFirst", true);
    /**
     * Whether to display options as grouped when nested options are provided.
     * @group Props
     */
    __publicField(this, "group");
    /**
     * When enabled, a clear icon is displayed to clear the value.
     * @group Props
     */
    __publicField(this, "showClear");
    /**
     * Text to display when filtering does not return any results. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    __publicField(this, "emptyFilterMessage", "");
    /**
     * Text to display when there is no data. Defaults to global value in i18n translation configuration.
     * @group Props
     */
    __publicField(this, "emptyMessage", "");
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    __publicField(this, "lazy", false);
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    __publicField(this, "virtualScroll");
    /**
     * Height of an item in the list for VirtualScrolling.
     * @group Props
     */
    __publicField(this, "virtualScrollItemSize");
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    __publicField(this, "virtualScrollOptions");
    /**
     * Whether to use overlay API feature. The properties of overlay API can be used like an object in it.
     * @group Props
     */
    __publicField(this, "overlayOptions");
    /**
     * Defines a string that labels the filter input.
     * @group Props
     */
    __publicField(this, "ariaFilterLabel");
    /**
     * Used to define a string that autocomplete attribute the current element.
     * @group Props
     */
    __publicField(this, "ariaLabel");
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    __publicField(this, "ariaLabelledBy");
    /**
     * Defines how the items are filtered.
     * @group Props
     */
    __publicField(this, "filterMatchMode", "contains");
    /**
     * Maximum number of character allows in the editable input field.
     * @group Props
     */
    __publicField(this, "maxlength");
    /**
     * Advisory information to display in a tooltip on hover.
     * @group Props
     */
    __publicField(this, "tooltip", "");
    /**
     * Position of the tooltip.
     * @group Props
     */
    __publicField(this, "tooltipPosition", "right");
    /**
     * Type of CSS position.
     * @group Props
     */
    __publicField(this, "tooltipPositionStyle", "absolute");
    /**
     * Style class of the tooltip.
     * @group Props
     */
    __publicField(this, "tooltipStyleClass");
    /**
     * Applies focus to the filter element when the overlay is shown.
     * @group Props
     */
    __publicField(this, "autofocusFilter", true);
    /**
     * No description available.
     * @group Props
     */
    __publicField(this, "overlayDirection", "end");
    __publicField(this, "_itemSize");
    __publicField(this, "_autoZIndex");
    __publicField(this, "_baseZIndex");
    __publicField(this, "_showTransitionOptions");
    __publicField(this, "_hideTransitionOptions");
    /**
     * Callback to invoke when value of dropdown changes.
     * @param {DropdownChangeEvent} event - custom change event.
     * @group Emits
     */
    __publicField(this, "onChange", new EventEmitter());
    /**
     * Callback to invoke when data is filtered.
     * @param {DropdownFilterEvent} event - custom filter event.
     * @group Emits
     */
    __publicField(this, "onFilter", new EventEmitter());
    /**
     * Callback to invoke when dropdown gets focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    __publicField(this, "onFocus", new EventEmitter());
    /**
     * Callback to invoke when dropdown loses focus.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    __publicField(this, "onBlur", new EventEmitter());
    /**
     * Callback to invoke when component is clicked.
     * @param {MouseEvent} event - Mouse event.
     * @group Emits
     */
    __publicField(this, "onClick", new EventEmitter());
    /**
     * Callback to invoke when dropdown overlay gets visible.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    __publicField(this, "onShow", new EventEmitter());
    /**
     * Callback to invoke when dropdown overlay gets hidden.
     * @param {AnimationEvent} event - Animation event.
     * @group Emits
     */
    __publicField(this, "onHide", new EventEmitter());
    /**
     * Callback to invoke when dropdown clears the value.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    __publicField(this, "onClear", new EventEmitter());
    /**
     * Callback to invoke in lazy mode to load new data.
     * @param {DropdownLazyLoadEvent} event - Lazy load event.
     * @group Emits
     */
    __publicField(this, "onLazyLoad", new EventEmitter());
    __publicField(this, "containerViewChild");
    __publicField(this, "filterViewChild");
    __publicField(this, "accessibleViewChild");
    __publicField(this, "editableInputViewChild");
    __publicField(this, "itemsViewChild");
    __publicField(this, "scroller");
    __publicField(this, "overlayViewChild");
    __publicField(this, "templates");
    __publicField(this, "_disabled");
    __publicField(this, "itemsWrapper");
    __publicField(this, "itemTemplate");
    __publicField(this, "groupTemplate");
    __publicField(this, "loaderTemplate");
    __publicField(this, "selectedItemTemplate");
    __publicField(this, "headerTemplate");
    __publicField(this, "filterTemplate");
    __publicField(this, "footerTemplate");
    __publicField(this, "emptyFilterTemplate");
    __publicField(this, "emptyTemplate");
    __publicField(this, "dropdownIconTemplate");
    __publicField(this, "clearIconTemplate");
    __publicField(this, "filterIconTemplate");
    __publicField(this, "filterOptions");
    __publicField(this, "selectedOption");
    __publicField(this, "_options");
    __publicField(this, "value");
    __publicField(this, "onModelChange", () => {
    });
    __publicField(this, "onModelTouched", () => {
    });
    __publicField(this, "optionsToDisplay");
    __publicField(this, "hover");
    __publicField(this, "focused");
    __publicField(this, "overlayVisible");
    __publicField(this, "optionsChanged");
    __publicField(this, "panel");
    __publicField(this, "dimensionsUpdated");
    __publicField(this, "hoveredItem");
    __publicField(this, "selectedOptionUpdated");
    __publicField(this, "_filterValue");
    __publicField(this, "searchValue");
    __publicField(this, "searchIndex");
    __publicField(this, "searchTimeout");
    __publicField(this, "previousSearchChar");
    __publicField(this, "currentSearchChar");
    __publicField(this, "preventModelTouched");
    __publicField(this, "id", UniqueComponentId());
    __publicField(this, "labelId");
    __publicField(this, "listId");
    this.el = el;
    this.renderer = renderer;
    this.cd = cd;
    this.zone = zone;
    this.filterService = filterService;
    this.config = config;
  }
  /**
   * When present, it specifies that the component should be disabled.
   * @group Props
   */
  get disabled() {
    return this._disabled;
  }
  set disabled(_disabled) {
    if (_disabled) {
      this.focused = false;
      if (this.overlayVisible)
        this.hide();
    }
    this._disabled = _disabled;
    if (!this.cd.destroyed) {
      this.cd.detectChanges();
    }
  }
  /**
   * Item size of item to be virtual scrolled.
   * @group Props
   * @deprecated use virtualScrollItemSize property instead.
   */
  get itemSize() {
    return this._itemSize;
  }
  set itemSize(val) {
    this._itemSize = val;
    console.warn("The itemSize property is deprecated, use virtualScrollItemSize property instead.");
  }
  /**
   * Whether to automatically manage layering.
   * @group Props
   * @deprecated since v14.2.0, use overlayOptions property instead.
   */
  get autoZIndex() {
    return this._autoZIndex;
  }
  set autoZIndex(val) {
    this._autoZIndex = val;
    console.warn("The autoZIndex property is deprecated since v14.2.0, use overlayOptions property instead.");
  }
  /**
   * Base zIndex value to use in layering.
   * @group Props
   * @deprecated since v14.2.0, use overlayOptions property instead.
   */
  get baseZIndex() {
    return this._baseZIndex;
  }
  set baseZIndex(val) {
    this._baseZIndex = val;
    console.warn("The baseZIndex property is deprecated since v14.2.0, use overlayOptions property instead.");
  }
  /**
   * Transition options of the show animation.
   * @group Props
   * @deprecated since v14.2.0, use overlayOptions property instead.
   */
  get showTransitionOptions() {
    return this._showTransitionOptions;
  }
  set showTransitionOptions(val) {
    this._showTransitionOptions = val;
    console.warn("The showTransitionOptions property is deprecated since v14.2.0, use overlayOptions property instead.");
  }
  /**
   * Transition options of the hide animation.
   * @group Props
   * @deprecated since v14.2.0, use overlayOptions property instead.
   */
  get hideTransitionOptions() {
    return this._hideTransitionOptions;
  }
  set hideTransitionOptions(val) {
    this._hideTransitionOptions = val;
    console.warn("The hideTransitionOptions property is deprecated since v14.2.0, use overlayOptions property instead.");
  }
  /**
   * When specified, filter displays with this value.
   * @group Props
   */
  get filterValue() {
    return this._filterValue;
  }
  set filterValue(val) {
    this._filterValue = val;
    this.activateFilter();
  }
  /**
   * An array of objects to display as the available options.
   * @group Props
   */
  get options() {
    return this._options;
  }
  set options(val) {
    this._options = val;
    this.optionsToDisplay = this._options;
    this.updateSelectedOption(this.value);
    this.selectedOption = this.findOption(this.value, this.optionsToDisplay);
    if (!this.selectedOption && ObjectUtils.isNotEmpty(this.value) && !this.editable) {
      this.value = null;
      this.onModelChange(this.value);
    }
    this.optionsChanged = true;
    if (this._filterValue && this._filterValue.length) {
      this.activateFilter();
    }
  }
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "item":
          this.itemTemplate = item.template;
          break;
        case "selectedItem":
          this.selectedItemTemplate = item.template;
          break;
        case "header":
          this.headerTemplate = item.template;
          break;
        case "filter":
          this.filterTemplate = item.template;
          break;
        case "footer":
          this.footerTemplate = item.template;
          break;
        case "emptyfilter":
          this.emptyFilterTemplate = item.template;
          break;
        case "empty":
          this.emptyTemplate = item.template;
          break;
        case "group":
          this.groupTemplate = item.template;
          break;
        case "loader":
          this.loaderTemplate = item.template;
          break;
        case "dropdownicon":
          this.dropdownIconTemplate = item.template;
          break;
        case "clearicon":
          this.clearIconTemplate = item.template;
          break;
        case "filtericon":
          this.filterIconTemplate = item.template;
          break;
        default:
          this.itemTemplate = item.template;
          break;
      }
    });
  }
  ngOnInit() {
    this.optionsToDisplay = this.options;
    this.updateSelectedOption(null);
    this.labelId = this.id + "_label";
    this.listId = this.id + "_list";
    if (this.filterBy) {
      this.filterOptions = {
        filter: (value) => this.onFilterInputChange(value),
        reset: () => this.resetFilter()
      };
    }
  }
  ngAfterViewInit() {
    if (this.editable) {
      this.updateEditableLabel();
    }
  }
  get label() {
    if (typeof this.selectedOption === "number") {
      this.selectedOption = this.selectedOption.toString();
    }
    return this.selectedOption ? this.getOptionLabel(this.selectedOption) : null;
  }
  get emptyMessageLabel() {
    return this.emptyMessage || this.config.getTranslation(TranslationKeys.EMPTY_MESSAGE);
  }
  get emptyFilterMessageLabel() {
    return this.emptyFilterMessage || this.config.getTranslation(TranslationKeys.EMPTY_FILTER_MESSAGE);
  }
  get filled() {
    if (typeof this.value === "string")
      return !!this.value;
    return this.value || this.value != null || this.value != void 0;
  }
  get isVisibleClearIcon() {
    return this.value != null && this.value !== "" && this.showClear && !this.disabled;
  }
  updateEditableLabel() {
    if (this.editableInputViewChild && this.editableInputViewChild.nativeElement) {
      this.editableInputViewChild.nativeElement.value = this.selectedOption ? this.getOptionLabel(this.selectedOption) : this.value || "";
    }
  }
  getOptionLabel(option) {
    return this.optionLabel ? ObjectUtils.resolveFieldData(option, this.optionLabel) : option && option.label !== void 0 ? option.label : option;
  }
  getOptionValue(option) {
    return this.optionValue ? ObjectUtils.resolveFieldData(option, this.optionValue) : !this.optionLabel && option && option.value !== void 0 ? option.value : option;
  }
  isOptionDisabled(option) {
    return this.optionDisabled ? ObjectUtils.resolveFieldData(option, this.optionDisabled) : option && option.disabled !== void 0 ? option.disabled : false;
  }
  getOptionGroupLabel(optionGroup) {
    return this.optionGroupLabel ? ObjectUtils.resolveFieldData(optionGroup, this.optionGroupLabel) : optionGroup && optionGroup.label !== void 0 ? optionGroup.label : optionGroup;
  }
  getOptionGroupChildren(optionGroup) {
    return this.optionGroupChildren ? ObjectUtils.resolveFieldData(optionGroup, this.optionGroupChildren) : optionGroup.items;
  }
  onItemClick(event2) {
    var _a;
    const option = event2.option;
    if (!this.isOptionDisabled(option)) {
      this.selectItem(event2.originalEvent, option);
      (_a = this.accessibleViewChild) == null ? void 0 : _a.nativeElement.focus({
        preventScroll: true
      });
    }
    setTimeout(() => {
      this.hide();
    }, 1);
  }
  selectItem(event2, option) {
    if (this.selectedOption != option) {
      this.selectedOption = option;
      this.value = this.getOptionValue(option);
      this.onModelChange(this.value);
      this.updateEditableLabel();
      this.onChange.emit({
        originalEvent: event2,
        value: this.value
      });
    }
  }
  ngAfterViewChecked() {
    var _a, _b;
    if (this.optionsChanged && this.overlayVisible) {
      this.optionsChanged = false;
      this.zone.runOutsideAngular(() => {
        setTimeout(() => {
          if (this.overlayViewChild) {
            this.overlayViewChild.alignOverlay();
          }
        }, 1);
      });
    }
    if (this.selectedOptionUpdated && this.itemsWrapper) {
      let selectedItem = DomHandler.findSingle((_b = (_a = this.overlayViewChild) == null ? void 0 : _a.overlayViewChild) == null ? void 0 : _b.nativeElement, "li.p-highlight");
      if (selectedItem) {
        DomHandler.scrollInView(this.itemsWrapper, selectedItem);
      }
      this.selectedOptionUpdated = false;
    }
  }
  writeValue(value) {
    if (this.filter) {
      this.resetFilter();
    }
    this.value = value;
    this.updateSelectedOption(value);
    this.updateEditableLabel();
    this.cd.markForCheck();
  }
  /**
   * Callback to invoke on filter reset.
   * @group Method
   */
  resetFilter() {
    this._filterValue = null;
    if (this.filterViewChild && this.filterViewChild.nativeElement) {
      this.filterViewChild.nativeElement.value = "";
    }
    this.optionsToDisplay = this.options;
  }
  updateSelectedOption(val) {
    this.selectedOption = this.findOption(val, this.optionsToDisplay);
    if (this.autoDisplayFirst && !this.placeholder && !this.selectedOption && this.optionsToDisplay && this.optionsToDisplay.length && !this.editable) {
      if (this.group) {
        this.selectedOption = this.getOptionGroupChildren(this.optionsToDisplay[0])[0];
      } else {
        this.selectedOption = this.optionsToDisplay[0];
      }
      this.value = this.getOptionValue(this.selectedOption);
      this.onModelChange(this.value);
    }
    this.selectedOptionUpdated = true;
  }
  registerOnChange(fn) {
    this.onModelChange = fn;
  }
  registerOnTouched(fn) {
    this.onModelTouched = fn;
  }
  setDisabledState(val) {
    this.disabled = val;
    this.cd.markForCheck();
  }
  onMouseclick(event2) {
    var _a;
    if (this.disabled || this.readonly || this.isInputClick(event2)) {
      return;
    }
    this.onClick.emit(event2);
    (_a = this.accessibleViewChild) == null ? void 0 : _a.nativeElement.focus({
      preventScroll: true
    });
    if (this.overlayVisible)
      this.hide();
    else
      this.show();
    this.cd.detectChanges();
  }
  isInputClick(event2) {
    var _a;
    return DomHandler.hasClass(event2.target, "p-dropdown-clear-icon") || event2.target.isSameNode((_a = this.accessibleViewChild) == null ? void 0 : _a.nativeElement) || this.editableInputViewChild && event2.target.isSameNode(this.editableInputViewChild.nativeElement);
  }
  isEmpty() {
    return !this.optionsToDisplay || this.optionsToDisplay && this.optionsToDisplay.length === 0;
  }
  onEditableInputFocus(event2) {
    this.focused = true;
    this.hide();
    this.onFocus.emit(event2);
  }
  onEditableInputChange(event2) {
    this.value = event2.target.value;
    this.updateSelectedOption(this.value);
    this.onModelChange(this.value);
    this.onChange.emit({
      originalEvent: event2,
      value: this.value
    });
  }
  /**
   * Displays the panel.
   * @group Method
   */
  show() {
    this.overlayVisible = true;
    this.cd.markForCheck();
  }
  onOverlayAnimationStart(event2) {
    var _a, _b, _c, _d, _e;
    if (event2.toState === "visible") {
      this.itemsWrapper = DomHandler.findSingle((_b = (_a = this.overlayViewChild) == null ? void 0 : _a.overlayViewChild) == null ? void 0 : _b.nativeElement, this.virtualScroll ? ".p-scroller" : ".p-dropdown-items-wrapper");
      this.virtualScroll && ((_d = this.scroller) == null ? void 0 : _d.setContentEl((_c = this.itemsViewChild) == null ? void 0 : _c.nativeElement));
      if (this.options && this.options.length) {
        if (this.virtualScroll) {
          const selectedIndex = this.selectedOption ? this.findOptionIndex(this.getOptionValue(this.selectedOption), this.optionsToDisplay) : -1;
          if (selectedIndex !== -1) {
            (_e = this.scroller) == null ? void 0 : _e.scrollToIndex(selectedIndex);
          }
        } else {
          let selectedListItem = DomHandler.findSingle(this.itemsWrapper, ".p-dropdown-item.p-highlight");
          if (selectedListItem) {
            selectedListItem.scrollIntoView({
              block: "nearest",
              inline: "center"
            });
          }
        }
      }
      if (this.filterViewChild && this.filterViewChild.nativeElement) {
        this.preventModelTouched = true;
        if (this.autofocusFilter) {
          this.filterViewChild.nativeElement.focus();
        }
      }
      this.onShow.emit(event2);
    }
    if (event2.toState === "void") {
      this.itemsWrapper = null;
      this.onModelTouched();
      this.onHide.emit(event2);
    }
  }
  /**
   * Hides the panel.
   * @group Method
   */
  hide() {
    this.overlayVisible = false;
    if (this.filter && this.resetFilterOnHide) {
      this.resetFilter();
    }
    this.cd.markForCheck();
  }
  onInputFocus(event2) {
    this.focused = true;
    this.onFocus.emit(event2);
  }
  onInputBlur(event2) {
    this.focused = false;
    this.onBlur.emit(event2);
    if (!this.preventModelTouched) {
      this.onModelTouched();
    }
    this.preventModelTouched = false;
  }
  findPrevEnabledOption(index) {
    let prevEnabledOption;
    if (this.optionsToDisplay && this.optionsToDisplay.length) {
      for (let i = index - 1; 0 <= i; i--) {
        let option = this.optionsToDisplay[i];
        if (this.isOptionDisabled(option)) {
          continue;
        } else {
          prevEnabledOption = option;
          break;
        }
      }
      if (!prevEnabledOption) {
        for (let i = this.optionsToDisplay.length - 1; i >= index; i--) {
          let option = this.optionsToDisplay[i];
          if (this.isOptionDisabled(option)) {
            continue;
          } else {
            prevEnabledOption = option;
            break;
          }
        }
      }
    }
    return prevEnabledOption;
  }
  findNextEnabledOption(index) {
    let nextEnabledOption;
    if (this.optionsToDisplay && this.optionsToDisplay.length) {
      for (let i = index + 1; i < this.optionsToDisplay.length; i++) {
        let option = this.optionsToDisplay[i];
        if (this.isOptionDisabled(option)) {
          continue;
        } else {
          nextEnabledOption = option;
          break;
        }
      }
      if (!nextEnabledOption) {
        for (let i = 0; i < index; i++) {
          let option = this.optionsToDisplay[i];
          if (this.isOptionDisabled(option)) {
            continue;
          } else {
            nextEnabledOption = option;
            break;
          }
        }
      }
    }
    return nextEnabledOption;
  }
  onKeydown(event2, search) {
    if (this.readonly || !this.optionsToDisplay || this.optionsToDisplay.length === null) {
      return;
    }
    switch (event2.which) {
      case 40:
        if (!this.overlayVisible && event2.altKey) {
          this.show();
        } else {
          if (this.group) {
            let selectedItemIndex = this.selectedOption ? this.findOptionGroupIndex(this.getOptionValue(this.selectedOption), this.optionsToDisplay) : -1;
            if (selectedItemIndex !== -1) {
              let nextItemIndex = selectedItemIndex.itemIndex + 1;
              if (nextItemIndex < this.getOptionGroupChildren(this.optionsToDisplay[selectedItemIndex.groupIndex]).length) {
                this.selectItem(event2, this.getOptionGroupChildren(this.optionsToDisplay[selectedItemIndex.groupIndex])[nextItemIndex]);
                this.selectedOptionUpdated = true;
              } else if (this.optionsToDisplay[selectedItemIndex.groupIndex + 1]) {
                this.selectItem(event2, this.getOptionGroupChildren(this.optionsToDisplay[selectedItemIndex.groupIndex + 1])[0]);
                this.selectedOptionUpdated = true;
              }
            } else {
              if (this.optionsToDisplay && this.optionsToDisplay.length > 0) {
                this.selectItem(event2, this.getOptionGroupChildren(this.optionsToDisplay[0])[0]);
              }
            }
          } else {
            let selectedItemIndex = this.selectedOption ? this.findOptionIndex(this.getOptionValue(this.selectedOption), this.optionsToDisplay) : -1;
            let nextEnabledOption = this.findNextEnabledOption(selectedItemIndex);
            if (nextEnabledOption) {
              this.selectItem(event2, nextEnabledOption);
              this.selectedOptionUpdated = true;
            }
          }
        }
        event2.preventDefault();
        break;
      case 38:
        if (this.group) {
          let selectedItemIndex = this.selectedOption ? this.findOptionGroupIndex(this.getOptionValue(this.selectedOption), this.optionsToDisplay) : -1;
          if (selectedItemIndex !== -1) {
            let prevItemIndex = selectedItemIndex.itemIndex - 1;
            if (prevItemIndex >= 0) {
              this.selectItem(event2, this.getOptionGroupChildren(this.optionsToDisplay[selectedItemIndex.groupIndex])[prevItemIndex]);
              this.selectedOptionUpdated = true;
            } else if (prevItemIndex < 0) {
              let prevGroup = this.optionsToDisplay[selectedItemIndex.groupIndex - 1];
              if (prevGroup) {
                this.selectItem(event2, this.getOptionGroupChildren(prevGroup)[this.getOptionGroupChildren(prevGroup).length - 1]);
                this.selectedOptionUpdated = true;
              }
            }
          }
        } else {
          let selectedItemIndex = this.selectedOption ? this.findOptionIndex(this.getOptionValue(this.selectedOption), this.optionsToDisplay) : -1;
          let prevEnabledOption = this.findPrevEnabledOption(selectedItemIndex);
          if (prevEnabledOption) {
            this.selectItem(event2, prevEnabledOption);
            this.selectedOptionUpdated = true;
          }
        }
        event2.preventDefault();
        break;
      case 32:
        if (search) {
          if (!this.overlayVisible) {
            this.show();
          } else {
            this.hide();
          }
          event2.preventDefault();
        }
        break;
      case 13:
        if (this.overlayVisible && (!this.filter || this.optionsToDisplay && this.optionsToDisplay.length > 0)) {
          this.hide();
        } else if (!this.overlayVisible) {
          this.show();
        }
        event2.preventDefault();
        break;
      case 27:
      case 9:
        this.hide();
        break;
      default:
        if (search && !event2.metaKey && event2.which !== 17) {
          this.search(event2);
        }
        break;
    }
  }
  search(event2) {
    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout);
    }
    const char = event2.key;
    this.previousSearchChar = this.currentSearchChar;
    this.currentSearchChar = char;
    if (this.previousSearchChar === this.currentSearchChar)
      this.searchValue = this.currentSearchChar;
    else
      this.searchValue = this.searchValue ? this.searchValue + char : char;
    let newOption;
    if (this.group) {
      let searchIndex = this.selectedOption ? this.findOptionGroupIndex(this.getOptionValue(this.selectedOption), this.optionsToDisplay) : {
        groupIndex: 0,
        itemIndex: 0
      };
      newOption = this.searchOptionWithinGroup(searchIndex);
    } else {
      let searchIndex = this.selectedOption ? this.findOptionIndex(this.getOptionValue(this.selectedOption), this.optionsToDisplay) : -1;
      newOption = this.searchOption(++searchIndex);
    }
    if (newOption && !this.isOptionDisabled(newOption)) {
      this.selectItem(event2, newOption);
      this.selectedOptionUpdated = true;
    }
    this.searchTimeout = setTimeout(() => {
      this.searchValue = null;
    }, 250);
  }
  searchOption(index) {
    let option;
    if (this.searchValue) {
      option = this.searchOptionInRange(index, this.optionsToDisplay.length);
      if (!option) {
        option = this.searchOptionInRange(0, index);
      }
    }
    return option;
  }
  searchOptionInRange(start, end) {
    for (let i = start; i < end; i++) {
      let opt = this.optionsToDisplay[i];
      if (this.getOptionLabel(opt).toLocaleLowerCase(this.filterLocale).startsWith(this.searchValue.toLocaleLowerCase(this.filterLocale)) && !this.isOptionDisabled(opt)) {
        return opt;
      }
    }
    return null;
  }
  searchOptionWithinGroup(index) {
    let option;
    if (this.searchValue) {
      if (this.optionsToDisplay) {
        for (let i = index.groupIndex; i < this.optionsToDisplay.length; i++) {
          for (let j = index.groupIndex === i ? index.itemIndex + 1 : 0; j < this.getOptionGroupChildren(this.optionsToDisplay[i]).length; j++) {
            let opt = this.getOptionGroupChildren(this.optionsToDisplay[i])[j];
            if (this.getOptionLabel(opt).toLocaleLowerCase(this.filterLocale).startsWith(this.searchValue.toLocaleLowerCase(this.filterLocale)) && !this.isOptionDisabled(opt)) {
              return opt;
            }
          }
        }
        if (!option) {
          for (let i = 0; i <= index.groupIndex; i++) {
            for (let j = 0; j < (index.groupIndex === i ? index.itemIndex : this.getOptionGroupChildren(this.optionsToDisplay[i]).length); j++) {
              let opt = this.getOptionGroupChildren(this.optionsToDisplay[i])[j];
              if (this.getOptionLabel(opt).toLocaleLowerCase(this.filterLocale).startsWith(this.searchValue.toLocaleLowerCase(this.filterLocale)) && !this.isOptionDisabled(opt)) {
                return opt;
              }
            }
          }
        }
      }
    }
    return null;
  }
  findOptionIndex(val, opts) {
    let index = -1;
    if (opts) {
      for (let i = 0; i < opts.length; i++) {
        if (val == null && this.getOptionValue(opts[i]) == null || ObjectUtils.equals(val, this.getOptionValue(opts[i]), this.dataKey)) {
          index = i;
          break;
        }
      }
    }
    return index;
  }
  findOptionGroupIndex(val, opts) {
    let groupIndex, itemIndex;
    if (opts) {
      for (let i = 0; i < opts.length; i++) {
        groupIndex = i;
        itemIndex = this.findOptionIndex(val, this.getOptionGroupChildren(opts[i]));
        if (itemIndex !== -1) {
          break;
        }
      }
    }
    if (itemIndex !== -1) {
      return {
        groupIndex,
        itemIndex
      };
    } else {
      return -1;
    }
  }
  findOption(val, opts, inGroup) {
    if (this.group && !inGroup) {
      let opt;
      if (opts && opts.length) {
        for (let optgroup of opts) {
          opt = this.findOption(val, this.getOptionGroupChildren(optgroup), true);
          if (opt) {
            break;
          }
        }
      }
      return opt;
    } else {
      let index = this.findOptionIndex(val, opts);
      return index != -1 ? opts[index] : null;
    }
  }
  onFilterInputChange(event2) {
    var _a;
    let inputValue = event2.target.value;
    if (inputValue && inputValue.length) {
      this._filterValue = inputValue;
      this.activateFilter();
    } else {
      this._filterValue = null;
      this.optionsToDisplay = this.options;
    }
    this.virtualScroll && ((_a = this.scroller) == null ? void 0 : _a.scrollToIndex(0));
    this.optionsChanged = true;
    this.onFilter.emit({
      originalEvent: event2,
      filter: this._filterValue
    });
  }
  activateFilter() {
    let searchFields = (this.filterBy || this.optionLabel || "label").split(",");
    if (this.options && this.options.length) {
      if (this.group) {
        let filteredGroups = [];
        for (let optgroup of this.options) {
          let filteredSubOptions = this.filterService.filter(this.getOptionGroupChildren(optgroup), searchFields, this.filterValue, this.filterMatchMode, this.filterLocale);
          if (filteredSubOptions && filteredSubOptions.length) {
            filteredGroups.push({
              ...optgroup,
              ...{
                [this.optionGroupChildren]: filteredSubOptions
              }
            });
          }
        }
        this.optionsToDisplay = filteredGroups;
      } else {
        this.optionsToDisplay = this.filterService.filter(this.options, searchFields, this.filterValue, this.filterMatchMode, this.filterLocale);
      }
      this.optionsChanged = true;
    }
  }
  applyFocus() {
    if (this.editable)
      DomHandler.findSingle(this.el.nativeElement, ".p-dropdown-label.p-inputtext").focus();
    else
      DomHandler.findSingle(this.el.nativeElement, "input[readonly]").focus();
  }
  /**
   * Applies focus.
   * @group Method
   */
  focus() {
    this.applyFocus();
  }
  clear(event2) {
    this.value = null;
    this.onModelChange(this.value);
    this.onChange.emit({
      originalEvent: event2,
      value: this.value
    });
    this.updateSelectedOption(this.value);
    this.updateEditableLabel();
    this.onClear.emit(event2);
  }
};
var Dropdown = _Dropdown;
__publicField(Dropdown, "ɵfac", function Dropdown_Factory(t) {
  return new (t || _Dropdown)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(NgZone), ɵɵdirectiveInject(FilterService), ɵɵdirectiveInject(PrimeNGConfig));
});
__publicField(Dropdown, "ɵcmp", ɵɵdefineComponent({
  type: _Dropdown,
  selectors: [["p-dropdown"]],
  contentQueries: function Dropdown_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  viewQuery: function Dropdown_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c34, 5);
      ɵɵviewQuery(_c44, 5);
      ɵɵviewQuery(_c54, 5);
      ɵɵviewQuery(_c64, 5);
      ɵɵviewQuery(_c74, 5);
      ɵɵviewQuery(_c83, 5);
      ɵɵviewQuery(_c93, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.containerViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.filterViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.accessibleViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.editableInputViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.itemsViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.scroller = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.overlayViewChild = _t.first);
    }
  },
  hostAttrs: [1, "p-element", "p-inputwrapper"],
  hostVars: 4,
  hostBindings: function Dropdown_HostBindings(rf, ctx) {
    if (rf & 2) {
      ɵɵclassProp("p-inputwrapper-filled", ctx.filled)("p-inputwrapper-focus", ctx.focused || ctx.overlayVisible);
    }
  },
  inputs: {
    scrollHeight: "scrollHeight",
    filter: "filter",
    name: "name",
    style: "style",
    panelStyle: "panelStyle",
    styleClass: "styleClass",
    panelStyleClass: "panelStyleClass",
    readonly: "readonly",
    required: "required",
    editable: "editable",
    appendTo: "appendTo",
    tabindex: "tabindex",
    placeholder: "placeholder",
    filterPlaceholder: "filterPlaceholder",
    filterLocale: "filterLocale",
    inputId: "inputId",
    selectId: "selectId",
    dataKey: "dataKey",
    filterBy: "filterBy",
    autofocus: "autofocus",
    resetFilterOnHide: "resetFilterOnHide",
    dropdownIcon: "dropdownIcon",
    optionLabel: "optionLabel",
    optionValue: "optionValue",
    optionDisabled: "optionDisabled",
    optionGroupLabel: "optionGroupLabel",
    optionGroupChildren: "optionGroupChildren",
    autoDisplayFirst: "autoDisplayFirst",
    group: "group",
    showClear: "showClear",
    emptyFilterMessage: "emptyFilterMessage",
    emptyMessage: "emptyMessage",
    lazy: "lazy",
    virtualScroll: "virtualScroll",
    virtualScrollItemSize: "virtualScrollItemSize",
    virtualScrollOptions: "virtualScrollOptions",
    overlayOptions: "overlayOptions",
    ariaFilterLabel: "ariaFilterLabel",
    ariaLabel: "ariaLabel",
    ariaLabelledBy: "ariaLabelledBy",
    filterMatchMode: "filterMatchMode",
    maxlength: "maxlength",
    tooltip: "tooltip",
    tooltipPosition: "tooltipPosition",
    tooltipPositionStyle: "tooltipPositionStyle",
    tooltipStyleClass: "tooltipStyleClass",
    autofocusFilter: "autofocusFilter",
    overlayDirection: "overlayDirection",
    disabled: "disabled",
    itemSize: "itemSize",
    autoZIndex: "autoZIndex",
    baseZIndex: "baseZIndex",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions",
    filterValue: "filterValue",
    options: "options"
  },
  outputs: {
    onChange: "onChange",
    onFilter: "onFilter",
    onFocus: "onFocus",
    onBlur: "onBlur",
    onClick: "onClick",
    onShow: "onShow",
    onHide: "onHide",
    onClear: "onClear",
    onLazyLoad: "onLazyLoad"
  },
  features: [ɵɵProvidersFeature([DROPDOWN_VALUE_ACCESSOR])],
  decls: 15,
  vars: 33,
  consts: [[3, "ngClass", "ngStyle", "click"], ["container", ""], [1, "p-hidden-accessible"], ["type", "text", "readonly", "", "aria-haspopup", "listbox", "aria-haspopup", "listbox", "pAutoFocus", "", "role", "combobox", 3, "disabled", "autofocus", "focus", "blur", "keydown"], ["in", ""], [3, "ngClass", "pTooltip", "tooltipPosition", "positionStyle", "tooltipStyleClass", 4, "ngIf"], [3, "ngClass", 4, "ngIf"], ["type", "text", "class", "p-dropdown-label p-inputtext", "aria-haspopup", "listbox", 3, "disabled", "input", "focus", "blur", 4, "ngIf"], [4, "ngIf"], ["role", "button", "aria-label", "dropdown trigger", "aria-haspopup", "listbox", 1, "p-dropdown-trigger"], ["class", "p-dropdown-trigger-icon", 4, "ngIf"], [3, "visible", "options", "target", "appendTo", "autoZIndex", "baseZIndex", "showTransitionOptions", "hideTransitionOptions", "visibleChange", "onAnimationStart", "onHide"], ["overlay", ""], ["pTemplate", "content"], [3, "ngClass", "pTooltip", "tooltipPosition", "positionStyle", "tooltipStyleClass"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [3, "ngClass"], ["type", "text", "aria-haspopup", "listbox", 1, "p-dropdown-label", "p-inputtext", 3, "disabled", "input", "focus", "blur"], ["editableInput", ""], [3, "styleClass", "click", 4, "ngIf"], ["class", "p-dropdown-clear-icon", 3, "click", 4, "ngIf"], [3, "styleClass", "click"], [1, "p-dropdown-clear-icon", 3, "click"], [4, "ngTemplateOutlet"], ["class", "p-dropdown-trigger-icon", 3, "ngClass", 4, "ngIf"], [3, "styleClass", 4, "ngIf"], [1, "p-dropdown-trigger-icon", 3, "ngClass"], [3, "styleClass"], [1, "p-dropdown-trigger-icon"], [3, "ngClass", "ngStyle"], ["class", "p-dropdown-header", 3, "click", 4, "ngIf"], [1, "p-dropdown-items-wrapper"], [3, "items", "style", "itemSize", "autoSize", "lazy", "options", "onLazyLoad", 4, "ngIf"], ["buildInItems", ""], [1, "p-dropdown-header", 3, "click"], [4, "ngIf", "ngIfElse"], ["builtInFilterElement", ""], [1, "p-dropdown-filter-container"], ["type", "text", "autocomplete", "off", 1, "p-dropdown-filter", "p-inputtext", "p-component", 3, "value", "keydown.enter", "keydown", "input"], ["filter", ""], ["class", "p-dropdown-filter-icon", 4, "ngIf"], [1, "p-dropdown-filter-icon"], [3, "items", "itemSize", "autoSize", "lazy", "options", "onLazyLoad"], ["scroller", ""], ["pTemplate", "loader"], ["role", "listbox", 1, "p-dropdown-items", 3, "ngClass"], ["items", ""], ["itemslist", ""], ["class", "p-dropdown-empty-message", 3, "ngStyle", 4, "ngIf"], ["ngFor", "", 3, "ngForOf"], [1, "p-dropdown-item-group", 3, "ngStyle"], [3, "option", "selected", "label", "disabled", "template", "onClick"], [1, "p-dropdown-empty-message", 3, "ngStyle"], ["emptyFilter", ""], ["empty", ""]],
  template: function Dropdown_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0, 1);
      ɵɵlistener("click", function Dropdown_Template_div_click_0_listener($event) {
        return ctx.onMouseclick($event);
      });
      ɵɵelementStart(2, "div", 2)(3, "input", 3, 4);
      ɵɵlistener("focus", function Dropdown_Template_input_focus_3_listener($event) {
        return ctx.onInputFocus($event);
      })("blur", function Dropdown_Template_input_blur_3_listener($event) {
        return ctx.onInputBlur($event);
      })("keydown", function Dropdown_Template_input_keydown_3_listener($event) {
        return ctx.onKeydown($event, true);
      });
      ɵɵelementEnd()();
      ɵɵtemplate(5, Dropdown_span_5_Template, 3, 13, "span", 5);
      ɵɵtemplate(6, Dropdown_span_6_Template, 2, 4, "span", 6);
      ɵɵtemplate(7, Dropdown_input_7_Template, 2, 4, "input", 7);
      ɵɵtemplate(8, Dropdown_ng_container_8_Template, 3, 2, "ng-container", 8);
      ɵɵelementStart(9, "div", 9);
      ɵɵtemplate(10, Dropdown_ng_container_10_Template, 3, 2, "ng-container", 8);
      ɵɵtemplate(11, Dropdown_span_11_Template, 2, 1, "span", 10);
      ɵɵelementEnd();
      ɵɵelementStart(12, "p-overlay", 11, 12);
      ɵɵlistener("visibleChange", function Dropdown_Template_p_overlay_visibleChange_12_listener($event) {
        return ctx.overlayVisible = $event;
      })("onAnimationStart", function Dropdown_Template_p_overlay_onAnimationStart_12_listener($event) {
        return ctx.onOverlayAnimationStart($event);
      })("onHide", function Dropdown_Template_p_overlay_onHide_12_listener() {
        return ctx.hide();
      });
      ɵɵtemplate(14, Dropdown_ng_template_14_Template, 9, 11, "ng-template", 13);
      ɵɵelementEnd()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.styleClass);
      ɵɵproperty("ngClass", ɵɵpureFunction4(28, _c162, ctx.disabled, ctx.overlayVisible, ctx.focused, ctx.showClear && !ctx.disabled))("ngStyle", ctx.style);
      ɵɵadvance(3);
      ɵɵproperty("disabled", ctx.disabled)("autofocus", ctx.autofocus);
      ɵɵattribute("id", ctx.inputId)("placeholder", ctx.placeholder)("aria-label", ctx.ariaLabel)("aria-expanded", false)("aria-labelledby", ctx.ariaLabelledBy)("tabindex", ctx.tabindex)("aria-activedescendant", ctx.overlayVisible ? ctx.labelId : null);
      ɵɵadvance(2);
      ɵɵproperty("ngIf", !ctx.editable && ctx.label != null);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", !ctx.editable && ctx.label == null);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.editable);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.isVisibleClearIcon);
      ɵɵadvance(1);
      ɵɵattribute("aria-expanded", ctx.overlayVisible);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", !ctx.dropdownIconTemplate);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.dropdownIconTemplate);
      ɵɵadvance(1);
      ɵɵproperty("visible", ctx.overlayVisible)("options", ctx.overlayOptions)("target", "@parent")("appendTo", ctx.appendTo)("autoZIndex", ctx.autoZIndex)("baseZIndex", ctx.baseZIndex)("showTransitionOptions", ctx.showTransitionOptions)("hideTransitionOptions", ctx.hideTransitionOptions);
    }
  },
  dependencies: function() {
    return [NgClass, NgForOf, NgIf, NgTemplateOutlet, NgStyle, Overlay, PrimeTemplate, Tooltip, Scroller, AutoFocus, TimesIcon, ChevronDownIcon, SearchIcon, DropdownItem];
  },
  styles: [".p-dropdown{display:inline-flex;cursor:pointer;position:relative;-webkit-user-select:none;user-select:none}.p-dropdown-clear-icon{position:absolute;top:50%;margin-top:-.5rem}.p-dropdown-trigger{display:flex;align-items:center;justify-content:center;flex-shrink:0}.p-dropdown-label{display:block;white-space:nowrap;overflow:hidden;flex:1 1 auto;width:1%;text-overflow:ellipsis;cursor:pointer}.p-dropdown-label-empty{overflow:hidden;visibility:hidden}input.p-dropdown-label{cursor:default}.p-dropdown-items-wrapper{overflow:auto}.p-dropdown-item{cursor:pointer;font-weight:400;white-space:nowrap;position:relative;overflow:hidden}.p-dropdown-items{margin:0;padding:0;list-style-type:none}.p-dropdown-filter{width:100%}.p-dropdown-filter-container{position:relative}.p-dropdown-filter-icon{position:absolute;top:50%;margin-top:-.5rem}.p-fluid .p-dropdown{display:flex}.p-fluid .p-dropdown .p-dropdown-label{width:1%}\n"],
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Dropdown, [{
    type: Component,
    args: [{
      selector: "p-dropdown",
      template: `
        <div
            #container
            [ngClass]="{ 'p-dropdown p-component': true, 'p-disabled': disabled, 'p-dropdown-open': overlayVisible, 'p-focus': focused, 'p-dropdown-clearable': showClear && !disabled }"
            (click)="onMouseclick($event)"
            [ngStyle]="style"
            [class]="styleClass"
        >
            <div class="p-hidden-accessible">
                <input
                    #in
                    [attr.id]="inputId"
                    type="text"
                    readonly
                    (focus)="onInputFocus($event)"
                    aria-haspopup="listbox"
                    [attr.placeholder]="placeholder"
                    aria-haspopup="listbox"
                    [attr.aria-label]="ariaLabel"
                    [attr.aria-expanded]="false"
                    [attr.aria-labelledby]="ariaLabelledBy"
                    (blur)="onInputBlur($event)"
                    (keydown)="onKeydown($event, true)"
                    [disabled]="disabled"
                    [attr.tabindex]="tabindex"
                    pAutoFocus
                    [autofocus]="autofocus"
                    [attr.aria-activedescendant]="overlayVisible ? labelId : null"
                    role="combobox"
                />
            </div>
            <span
                [attr.id]="labelId"
                [ngClass]="{ 'p-dropdown-label p-inputtext': true, 'p-dropdown-label-empty': label == null || label.length === 0 }"
                *ngIf="!editable && label != null"
                [pTooltip]="tooltip"
                [tooltipPosition]="tooltipPosition"
                [positionStyle]="tooltipPositionStyle"
                [tooltipStyleClass]="tooltipStyleClass"
            >
                <ng-container *ngIf="!selectedItemTemplate">{{ label || 'empty' }}</ng-container>
                <ng-container *ngTemplateOutlet="selectedItemTemplate; context: { $implicit: selectedOption }"></ng-container>
            </span>
            <span [ngClass]="{ 'p-dropdown-label p-inputtext p-placeholder': true, 'p-dropdown-label-empty': placeholder == null || placeholder.length === 0 }" *ngIf="!editable && label == null">{{ placeholder || 'empty' }}</span>
            <input
                #editableInput
                type="text"
                [attr.maxlength]="maxlength"
                class="p-dropdown-label p-inputtext"
                *ngIf="editable"
                [disabled]="disabled"
                [attr.placeholder]="placeholder"
                aria-haspopup="listbox"
                [attr.aria-expanded]="overlayVisible"
                (input)="onEditableInputChange($event)"
                (focus)="onEditableInputFocus($event)"
                (blur)="onInputBlur($event)"
            />

            <ng-container *ngIf="isVisibleClearIcon">
                <TimesIcon [styleClass]="'p-dropdown-clear-icon'" (click)="clear($event)" *ngIf="!clearIconTemplate" />
                <span class="p-dropdown-clear-icon" (click)="clear($event)" *ngIf="clearIconTemplate">
                    <ng-template *ngTemplateOutlet="clearIconTemplate"></ng-template>
                </span>
            </ng-container>

            <div class="p-dropdown-trigger" role="button" aria-label="dropdown trigger" aria-haspopup="listbox" [attr.aria-expanded]="overlayVisible">
                <ng-container *ngIf="!dropdownIconTemplate">
                    <span class="p-dropdown-trigger-icon" *ngIf="dropdownIcon" [ngClass]="dropdownIcon"></span>
                    <ChevronDownIcon *ngIf="!dropdownIcon" [styleClass]="'p-dropdown-trigger-icon'" />
                </ng-container>
                <span *ngIf="dropdownIconTemplate" class="p-dropdown-trigger-icon">
                    <ng-template *ngTemplateOutlet="dropdownIconTemplate"></ng-template>
                </span>
            </div>

            <p-overlay
                #overlay
                [(visible)]="overlayVisible"
                [options]="overlayOptions"
                [target]="'@parent'"
                [appendTo]="appendTo"
                [autoZIndex]="autoZIndex"
                [baseZIndex]="baseZIndex"
                [showTransitionOptions]="showTransitionOptions"
                [hideTransitionOptions]="hideTransitionOptions"
                (onAnimationStart)="onOverlayAnimationStart($event)"
                (onHide)="hide()"
            >
                <ng-template pTemplate="content">
                    <div [ngClass]="'p-dropdown-panel p-component'" [ngStyle]="panelStyle" [class]="panelStyleClass">
                        <ng-container *ngTemplateOutlet="headerTemplate"></ng-container>
                        <div class="p-dropdown-header" *ngIf="filter" (click)="$event.stopPropagation()">
                            <ng-container *ngIf="filterTemplate; else builtInFilterElement">
                                <ng-container *ngTemplateOutlet="filterTemplate; context: { options: filterOptions }"></ng-container>
                            </ng-container>
                            <ng-template #builtInFilterElement>
                                <div class="p-dropdown-filter-container">
                                    <input
                                        #filter
                                        type="text"
                                        autocomplete="off"
                                        [value]="filterValue || ''"
                                        class="p-dropdown-filter p-inputtext p-component"
                                        [attr.placeholder]="filterPlaceholder"
                                        (keydown.enter)="$event.preventDefault()"
                                        (keydown)="onKeydown($event, false)"
                                        (input)="onFilterInputChange($event)"
                                        [attr.aria-label]="ariaFilterLabel"
                                        [attr.aria-activedescendant]="overlayVisible ? 'p-highlighted-option' : labelId"
                                    />
                                    <SearchIcon *ngIf="!filterIconTemplate" [styleClass]="'p-dropdown-filter-icon'" />
                                    <span *ngIf="filterIconTemplate" class="p-dropdown-filter-icon">
                                        <ng-template *ngTemplateOutlet="filterIconTemplate"></ng-template>
                                    </span>
                                </div>
                            </ng-template>
                        </div>
                        <div class="p-dropdown-items-wrapper" [style.max-height]="virtualScroll ? 'auto' : scrollHeight || 'auto'">
                            <p-scroller
                                *ngIf="virtualScroll"
                                #scroller
                                [items]="optionsToDisplay"
                                [style]="{ height: scrollHeight }"
                                [itemSize]="virtualScrollItemSize || _itemSize"
                                [autoSize]="true"
                                [lazy]="lazy"
                                (onLazyLoad)="onLazyLoad.emit($event)"
                                [options]="virtualScrollOptions"
                            >
                                <ng-template pTemplate="content" let-items let-scrollerOptions="options">
                                    <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: items, options: scrollerOptions }"></ng-container>
                                </ng-template>
                                <ng-container *ngIf="loaderTemplate">
                                    <ng-template pTemplate="loader" let-scrollerOptions="options">
                                        <ng-container *ngTemplateOutlet="loaderTemplate; context: { options: scrollerOptions }"></ng-container>
                                    </ng-template>
                                </ng-container>
                            </p-scroller>
                            <ng-container *ngIf="!virtualScroll">
                                <ng-container *ngTemplateOutlet="buildInItems; context: { $implicit: optionsToDisplay, options: {} }"></ng-container>
                            </ng-container>

                            <ng-template #buildInItems let-items let-scrollerOptions="options">
                                <ul #items [attr.id]="listId" class="p-dropdown-items" [ngClass]="scrollerOptions.contentStyleClass" [style]="scrollerOptions.contentStyle" role="listbox">
                                    <ng-container *ngIf="group">
                                        <ng-template ngFor let-optgroup [ngForOf]="items">
                                            <li class="p-dropdown-item-group" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }">
                                                <span *ngIf="!groupTemplate">{{ getOptionGroupLabel(optgroup) || 'empty' }}</span>
                                                <ng-container *ngTemplateOutlet="groupTemplate; context: { $implicit: optgroup }"></ng-container>
                                            </li>
                                            <ng-container *ngTemplateOutlet="itemslist; context: { $implicit: getOptionGroupChildren(optgroup), selectedOption: selectedOption }"></ng-container>
                                        </ng-template>
                                    </ng-container>
                                    <ng-container *ngIf="!group">
                                        <ng-container *ngTemplateOutlet="itemslist; context: { $implicit: items, selectedOption: selectedOption }"></ng-container>
                                    </ng-container>
                                    <ng-template #itemslist let-options let-selectedOption="selectedOption">
                                        <ng-template ngFor let-option let-i="index" [ngForOf]="options">
                                            <p-dropdownItem
                                                [option]="option"
                                                [selected]="selectedOption == option"
                                                [label]="getOptionLabel(option)"
                                                [disabled]="isOptionDisabled(option)"
                                                (onClick)="onItemClick($event)"
                                                [template]="itemTemplate"
                                            ></p-dropdownItem>
                                        </ng-template>
                                    </ng-template>
                                    <li *ngIf="filterValue && isEmpty()" class="p-dropdown-empty-message" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }">
                                        <ng-container *ngIf="!emptyFilterTemplate && !emptyTemplate; else emptyFilter">
                                            {{ emptyFilterMessageLabel }}
                                        </ng-container>
                                        <ng-container #emptyFilter *ngTemplateOutlet="emptyFilterTemplate || emptyTemplate"></ng-container>
                                    </li>
                                    <li *ngIf="!filterValue && isEmpty()" class="p-dropdown-empty-message" [ngStyle]="{ height: scrollerOptions.itemSize + 'px' }">
                                        <ng-container *ngIf="!emptyTemplate; else empty">
                                            {{ emptyMessageLabel }}
                                        </ng-container>
                                        <ng-container #empty *ngTemplateOutlet="emptyTemplate"></ng-container>
                                    </li>
                                </ul>
                            </ng-template>
                        </div>
                        <ng-container *ngTemplateOutlet="footerTemplate"></ng-container>
                    </div>
                </ng-template>
            </p-overlay>
        </div>
    `,
      host: {
        class: "p-element p-inputwrapper",
        "[class.p-inputwrapper-filled]": "filled",
        "[class.p-inputwrapper-focus]": "focused || overlayVisible"
      },
      providers: [DROPDOWN_VALUE_ACCESSOR],
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      styles: [".p-dropdown{display:inline-flex;cursor:pointer;position:relative;-webkit-user-select:none;user-select:none}.p-dropdown-clear-icon{position:absolute;top:50%;margin-top:-.5rem}.p-dropdown-trigger{display:flex;align-items:center;justify-content:center;flex-shrink:0}.p-dropdown-label{display:block;white-space:nowrap;overflow:hidden;flex:1 1 auto;width:1%;text-overflow:ellipsis;cursor:pointer}.p-dropdown-label-empty{overflow:hidden;visibility:hidden}input.p-dropdown-label{cursor:default}.p-dropdown-items-wrapper{overflow:auto}.p-dropdown-item{cursor:pointer;font-weight:400;white-space:nowrap;position:relative;overflow:hidden}.p-dropdown-items{margin:0;padding:0;list-style-type:none}.p-dropdown-filter{width:100%}.p-dropdown-filter-container{position:relative}.p-dropdown-filter-icon{position:absolute;top:50%;margin-top:-.5rem}.p-fluid .p-dropdown{display:flex}.p-fluid .p-dropdown .p-dropdown-label{width:1%}\n"]
    }]
  }], function() {
    return [{
      type: ElementRef
    }, {
      type: Renderer2
    }, {
      type: ChangeDetectorRef
    }, {
      type: NgZone
    }, {
      type: FilterService
    }, {
      type: PrimeNGConfig
    }];
  }, {
    scrollHeight: [{
      type: Input
    }],
    filter: [{
      type: Input
    }],
    name: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    panelStyle: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    panelStyleClass: [{
      type: Input
    }],
    readonly: [{
      type: Input
    }],
    required: [{
      type: Input
    }],
    editable: [{
      type: Input
    }],
    appendTo: [{
      type: Input
    }],
    tabindex: [{
      type: Input
    }],
    placeholder: [{
      type: Input
    }],
    filterPlaceholder: [{
      type: Input
    }],
    filterLocale: [{
      type: Input
    }],
    inputId: [{
      type: Input
    }],
    selectId: [{
      type: Input
    }],
    dataKey: [{
      type: Input
    }],
    filterBy: [{
      type: Input
    }],
    autofocus: [{
      type: Input
    }],
    resetFilterOnHide: [{
      type: Input
    }],
    dropdownIcon: [{
      type: Input
    }],
    optionLabel: [{
      type: Input
    }],
    optionValue: [{
      type: Input
    }],
    optionDisabled: [{
      type: Input
    }],
    optionGroupLabel: [{
      type: Input
    }],
    optionGroupChildren: [{
      type: Input
    }],
    autoDisplayFirst: [{
      type: Input
    }],
    group: [{
      type: Input
    }],
    showClear: [{
      type: Input
    }],
    emptyFilterMessage: [{
      type: Input
    }],
    emptyMessage: [{
      type: Input
    }],
    lazy: [{
      type: Input
    }],
    virtualScroll: [{
      type: Input
    }],
    virtualScrollItemSize: [{
      type: Input
    }],
    virtualScrollOptions: [{
      type: Input
    }],
    overlayOptions: [{
      type: Input
    }],
    ariaFilterLabel: [{
      type: Input
    }],
    ariaLabel: [{
      type: Input
    }],
    ariaLabelledBy: [{
      type: Input
    }],
    filterMatchMode: [{
      type: Input
    }],
    maxlength: [{
      type: Input
    }],
    tooltip: [{
      type: Input
    }],
    tooltipPosition: [{
      type: Input
    }],
    tooltipPositionStyle: [{
      type: Input
    }],
    tooltipStyleClass: [{
      type: Input
    }],
    autofocusFilter: [{
      type: Input
    }],
    overlayDirection: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    itemSize: [{
      type: Input
    }],
    autoZIndex: [{
      type: Input
    }],
    baseZIndex: [{
      type: Input
    }],
    showTransitionOptions: [{
      type: Input
    }],
    hideTransitionOptions: [{
      type: Input
    }],
    filterValue: [{
      type: Input
    }],
    options: [{
      type: Input
    }],
    onChange: [{
      type: Output
    }],
    onFilter: [{
      type: Output
    }],
    onFocus: [{
      type: Output
    }],
    onBlur: [{
      type: Output
    }],
    onClick: [{
      type: Output
    }],
    onShow: [{
      type: Output
    }],
    onHide: [{
      type: Output
    }],
    onClear: [{
      type: Output
    }],
    onLazyLoad: [{
      type: Output
    }],
    containerViewChild: [{
      type: ViewChild,
      args: ["container"]
    }],
    filterViewChild: [{
      type: ViewChild,
      args: ["filter"]
    }],
    accessibleViewChild: [{
      type: ViewChild,
      args: ["in"]
    }],
    editableInputViewChild: [{
      type: ViewChild,
      args: ["editableInput"]
    }],
    itemsViewChild: [{
      type: ViewChild,
      args: ["items"]
    }],
    scroller: [{
      type: ViewChild,
      args: ["scroller"]
    }],
    overlayViewChild: [{
      type: ViewChild,
      args: ["overlay"]
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var _DropdownModule = class {
};
var DropdownModule = _DropdownModule;
__publicField(DropdownModule, "ɵfac", function DropdownModule_Factory(t) {
  return new (t || _DropdownModule)();
});
__publicField(DropdownModule, "ɵmod", ɵɵdefineNgModule({
  type: _DropdownModule,
  declarations: [Dropdown, DropdownItem],
  imports: [CommonModule, OverlayModule, SharedModule, TooltipModule, RippleModule, ScrollerModule, AutoFocusModule, TimesIcon, ChevronDownIcon, SearchIcon],
  exports: [Dropdown, OverlayModule, SharedModule, ScrollerModule]
}));
__publicField(DropdownModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, OverlayModule, SharedModule, TooltipModule, RippleModule, ScrollerModule, AutoFocusModule, TimesIcon, ChevronDownIcon, SearchIcon, OverlayModule, SharedModule, ScrollerModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DropdownModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, OverlayModule, SharedModule, TooltipModule, RippleModule, ScrollerModule, AutoFocusModule, TimesIcon, ChevronDownIcon, SearchIcon],
      exports: [Dropdown, OverlayModule, SharedModule, ScrollerModule],
      declarations: [Dropdown, DropdownItem]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-angledoubleleft.mjs
var _AngleDoubleLeftIcon = class extends BaseIcon {
};
var AngleDoubleLeftIcon = _AngleDoubleLeftIcon;
__publicField(AngleDoubleLeftIcon, "ɵfac", function() {
  let ɵAngleDoubleLeftIcon_BaseFactory;
  return function AngleDoubleLeftIcon_Factory(t) {
    return (ɵAngleDoubleLeftIcon_BaseFactory || (ɵAngleDoubleLeftIcon_BaseFactory = ɵɵgetInheritedFactory(_AngleDoubleLeftIcon)))(t || _AngleDoubleLeftIcon);
  };
}());
__publicField(AngleDoubleLeftIcon, "ɵcmp", ɵɵdefineComponent({
  type: _AngleDoubleLeftIcon,
  selectors: [["AngleDoubleLeftIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 2,
  vars: 5,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M5.71602 11.164C5.80782 11.2021 5.9063 11.2215 6.00569 11.221C6.20216 11.2301 6.39427 11.1612 6.54025 11.0294C6.68191 10.8875 6.76148 10.6953 6.76148 10.4948C6.76148 10.2943 6.68191 10.1021 6.54025 9.96024L3.51441 6.9344L6.54025 3.90855C6.624 3.76126 6.65587 3.59011 6.63076 3.42254C6.60564 3.25498 6.525 3.10069 6.40175 2.98442C6.2785 2.86815 6.11978 2.79662 5.95104 2.7813C5.78229 2.76598 5.61329 2.80776 5.47112 2.89994L1.97123 6.39983C1.82957 6.54167 1.75 6.73393 1.75 6.9344C1.75 7.13486 1.82957 7.32712 1.97123 7.46896L5.47112 10.9991C5.54096 11.0698 5.62422 11.1259 5.71602 11.164ZM11.0488 10.9689C11.1775 11.1156 11.3585 11.2061 11.5531 11.221C11.7477 11.2061 11.9288 11.1156 12.0574 10.9689C12.1815 10.8302 12.25 10.6506 12.25 10.4645C12.25 10.2785 12.1815 10.0989 12.0574 9.96024L9.03158 6.93439L12.0574 3.90855C12.1248 3.76739 12.1468 3.60881 12.1204 3.45463C12.0939 3.30045 12.0203 3.15826 11.9097 3.04765C11.7991 2.93703 11.6569 2.86343 11.5027 2.83698C11.3486 2.81053 11.19 2.83252 11.0488 2.89994L7.51865 6.36957C7.37699 6.51141 7.29742 6.70367 7.29742 6.90414C7.29742 7.1046 7.37699 7.29686 7.51865 7.4387L11.0488 10.9689Z", "fill", "currentColor"]],
  template: function AngleDoubleLeftIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0);
      ɵɵelement(1, "path", 1);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AngleDoubleLeftIcon, [{
    type: Component,
    args: [{
      selector: "AngleDoubleLeftIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M5.71602 11.164C5.80782 11.2021 5.9063 11.2215 6.00569 11.221C6.20216 11.2301 6.39427 11.1612 6.54025 11.0294C6.68191 10.8875 6.76148 10.6953 6.76148 10.4948C6.76148 10.2943 6.68191 10.1021 6.54025 9.96024L3.51441 6.9344L6.54025 3.90855C6.624 3.76126 6.65587 3.59011 6.63076 3.42254C6.60564 3.25498 6.525 3.10069 6.40175 2.98442C6.2785 2.86815 6.11978 2.79662 5.95104 2.7813C5.78229 2.76598 5.61329 2.80776 5.47112 2.89994L1.97123 6.39983C1.82957 6.54167 1.75 6.73393 1.75 6.9344C1.75 7.13486 1.82957 7.32712 1.97123 7.46896L5.47112 10.9991C5.54096 11.0698 5.62422 11.1259 5.71602 11.164ZM11.0488 10.9689C11.1775 11.1156 11.3585 11.2061 11.5531 11.221C11.7477 11.2061 11.9288 11.1156 12.0574 10.9689C12.1815 10.8302 12.25 10.6506 12.25 10.4645C12.25 10.2785 12.1815 10.0989 12.0574 9.96024L9.03158 6.93439L12.0574 3.90855C12.1248 3.76739 12.1468 3.60881 12.1204 3.45463C12.0939 3.30045 12.0203 3.15826 11.9097 3.04765C11.7991 2.93703 11.6569 2.86343 11.5027 2.83698C11.3486 2.81053 11.19 2.83252 11.0488 2.89994L7.51865 6.36957C7.37699 6.51141 7.29742 6.70367 7.29742 6.90414C7.29742 7.1046 7.37699 7.29686 7.51865 7.4387L11.0488 10.9689Z"
                fill="currentColor"
            />
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-angledoubleright.mjs
var _AngleDoubleRightIcon = class extends BaseIcon {
};
var AngleDoubleRightIcon = _AngleDoubleRightIcon;
__publicField(AngleDoubleRightIcon, "ɵfac", function() {
  let ɵAngleDoubleRightIcon_BaseFactory;
  return function AngleDoubleRightIcon_Factory(t) {
    return (ɵAngleDoubleRightIcon_BaseFactory || (ɵAngleDoubleRightIcon_BaseFactory = ɵɵgetInheritedFactory(_AngleDoubleRightIcon)))(t || _AngleDoubleRightIcon);
  };
}());
__publicField(AngleDoubleRightIcon, "ɵcmp", ɵɵdefineComponent({
  type: _AngleDoubleRightIcon,
  selectors: [["AngleDoubleRightIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 2,
  vars: 5,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M7.68757 11.1451C7.7791 11.1831 7.8773 11.2024 7.9764 11.2019C8.07769 11.1985 8.17721 11.1745 8.26886 11.1312C8.36052 11.088 8.44238 11.0265 8.50943 10.9505L12.0294 7.49085C12.1707 7.34942 12.25 7.15771 12.25 6.95782C12.25 6.75794 12.1707 6.56622 12.0294 6.42479L8.50943 2.90479C8.37014 2.82159 8.20774 2.78551 8.04633 2.80192C7.88491 2.81833 7.73309 2.88635 7.6134 2.99588C7.4937 3.10541 7.41252 3.25061 7.38189 3.40994C7.35126 3.56927 7.37282 3.73423 7.44337 3.88033L10.4605 6.89748L7.44337 9.91463C7.30212 10.0561 7.22278 10.2478 7.22278 10.4477C7.22278 10.6475 7.30212 10.8393 7.44337 10.9807C7.51301 11.0512 7.59603 11.1071 7.68757 11.1451ZM1.94207 10.9505C2.07037 11.0968 2.25089 11.1871 2.44493 11.2019C2.63898 11.1871 2.81949 11.0968 2.94779 10.9505L6.46779 7.49085C6.60905 7.34942 6.68839 7.15771 6.68839 6.95782C6.68839 6.75793 6.60905 6.56622 6.46779 6.42479L2.94779 2.90479C2.80704 2.83757 2.6489 2.81563 2.49517 2.84201C2.34143 2.86839 2.19965 2.94178 2.08936 3.05207C1.97906 3.16237 1.90567 3.30415 1.8793 3.45788C1.85292 3.61162 1.87485 3.76975 1.94207 3.9105L4.95922 6.92765L1.94207 9.9448C1.81838 10.0831 1.75 10.2621 1.75 10.4477C1.75 10.6332 1.81838 10.8122 1.94207 10.9505Z", "fill", "currentColor"]],
  template: function AngleDoubleRightIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0);
      ɵɵelement(1, "path", 1);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AngleDoubleRightIcon, [{
    type: Component,
    args: [{
      selector: "AngleDoubleRightIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <path
                fill-rule="evenodd"
                clip-rule="evenodd"
                d="M7.68757 11.1451C7.7791 11.1831 7.8773 11.2024 7.9764 11.2019C8.07769 11.1985 8.17721 11.1745 8.26886 11.1312C8.36052 11.088 8.44238 11.0265 8.50943 10.9505L12.0294 7.49085C12.1707 7.34942 12.25 7.15771 12.25 6.95782C12.25 6.75794 12.1707 6.56622 12.0294 6.42479L8.50943 2.90479C8.37014 2.82159 8.20774 2.78551 8.04633 2.80192C7.88491 2.81833 7.73309 2.88635 7.6134 2.99588C7.4937 3.10541 7.41252 3.25061 7.38189 3.40994C7.35126 3.56927 7.37282 3.73423 7.44337 3.88033L10.4605 6.89748L7.44337 9.91463C7.30212 10.0561 7.22278 10.2478 7.22278 10.4477C7.22278 10.6475 7.30212 10.8393 7.44337 10.9807C7.51301 11.0512 7.59603 11.1071 7.68757 11.1451ZM1.94207 10.9505C2.07037 11.0968 2.25089 11.1871 2.44493 11.2019C2.63898 11.1871 2.81949 11.0968 2.94779 10.9505L6.46779 7.49085C6.60905 7.34942 6.68839 7.15771 6.68839 6.95782C6.68839 6.75793 6.60905 6.56622 6.46779 6.42479L2.94779 2.90479C2.80704 2.83757 2.6489 2.81563 2.49517 2.84201C2.34143 2.86839 2.19965 2.94178 2.08936 3.05207C1.97906 3.16237 1.90567 3.30415 1.8793 3.45788C1.85292 3.61162 1.87485 3.76975 1.94207 3.9105L4.95922 6.92765L1.94207 9.9448C1.81838 10.0831 1.75 10.2621 1.75 10.4477C1.75 10.6332 1.81838 10.8122 1.94207 10.9505Z"
                fill="currentColor"
            />
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-angleleft.mjs
var _AngleLeftIcon = class extends BaseIcon {
};
var AngleLeftIcon = _AngleLeftIcon;
__publicField(AngleLeftIcon, "ɵfac", function() {
  let ɵAngleLeftIcon_BaseFactory;
  return function AngleLeftIcon_Factory(t) {
    return (ɵAngleLeftIcon_BaseFactory || (ɵAngleLeftIcon_BaseFactory = ɵɵgetInheritedFactory(_AngleLeftIcon)))(t || _AngleLeftIcon);
  };
}());
__publicField(AngleLeftIcon, "ɵcmp", ɵɵdefineComponent({
  type: _AngleLeftIcon,
  selectors: [["AngleLeftIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 2,
  vars: 5,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M8.75 11.185C8.65146 11.1854 8.55381 11.1662 8.4628 11.1284C8.37179 11.0906 8.28924 11.0351 8.22 10.965L4.72 7.46496C4.57955 7.32433 4.50066 7.13371 4.50066 6.93496C4.50066 6.73621 4.57955 6.54558 4.72 6.40496L8.22 2.93496C8.36095 2.84357 8.52851 2.80215 8.69582 2.81733C8.86312 2.83252 9.02048 2.90344 9.14268 3.01872C9.26487 3.134 9.34483 3.28696 9.36973 3.4531C9.39463 3.61924 9.36303 3.78892 9.28 3.93496L6.28 6.93496L9.28 9.93496C9.42045 10.0756 9.49934 10.2662 9.49934 10.465C9.49934 10.6637 9.42045 10.8543 9.28 10.995C9.13526 11.1257 8.9448 11.1939 8.75 11.185Z", "fill", "currentColor"]],
  template: function AngleLeftIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0);
      ɵɵelement(1, "path", 1);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AngleLeftIcon, [{
    type: Component,
    args: [{
      selector: "AngleLeftIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <path
                d="M8.75 11.185C8.65146 11.1854 8.55381 11.1662 8.4628 11.1284C8.37179 11.0906 8.28924 11.0351 8.22 10.965L4.72 7.46496C4.57955 7.32433 4.50066 7.13371 4.50066 6.93496C4.50066 6.73621 4.57955 6.54558 4.72 6.40496L8.22 2.93496C8.36095 2.84357 8.52851 2.80215 8.69582 2.81733C8.86312 2.83252 9.02048 2.90344 9.14268 3.01872C9.26487 3.134 9.34483 3.28696 9.36973 3.4531C9.39463 3.61924 9.36303 3.78892 9.28 3.93496L6.28 6.93496L9.28 9.93496C9.42045 10.0756 9.49934 10.2662 9.49934 10.465C9.49934 10.6637 9.42045 10.8543 9.28 10.995C9.13526 11.1257 8.9448 11.1939 8.75 11.185Z"
                fill="currentColor"
            />
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-paginator.mjs
function Paginator_div_0_div_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c05 = function(a0) {
  return {
    $implicit: a0
  };
};
function Paginator_div_0_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 15);
    ɵɵtemplate(1, Paginator_div_0_div_1_ng_container_1_Template, 1, 0, "ng-container", 16);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r1.templateLeft)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c05, ctx_r1.paginatorState));
  }
}
function Paginator_div_0_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 17);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r2.currentPageReport);
  }
}
function Paginator_div_0_button_3_AngleDoubleLeftIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "AngleDoubleLeftIcon", 19);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-paginator-icon");
  }
}
function Paginator_div_0_button_3_span_2_1_ng_template_0_Template(rf, ctx) {
}
function Paginator_div_0_button_3_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Paginator_div_0_button_3_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Paginator_div_0_button_3_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 20);
    ɵɵtemplate(1, Paginator_div_0_button_3_span_2_1_Template, 1, 0, null, 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r16 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r16.firstPageLinkIconTemplate);
  }
}
var _c18 = function(a0) {
  return {
    "p-disabled": a0
  };
};
function Paginator_div_0_button_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r20 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 18);
    ɵɵlistener("click", function Paginator_div_0_button_3_Template_button_click_0_listener($event) {
      ɵɵrestoreView(_r20);
      const ctx_r19 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r19.changePageToFirst($event));
    });
    ɵɵtemplate(1, Paginator_div_0_button_3_AngleDoubleLeftIcon_1_Template, 1, 1, "AngleDoubleLeftIcon", 6);
    ɵɵtemplate(2, Paginator_div_0_button_3_span_2_Template, 2, 1, "span", 7);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext(2);
    ɵɵproperty("disabled", ctx_r3.isFirstPage() || ctx_r3.empty())("ngClass", ɵɵpureFunction1(4, _c18, ctx_r3.isFirstPage() || ctx_r3.empty()));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r3.firstPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r3.firstPageLinkIconTemplate);
  }
}
function Paginator_div_0_AngleLeftIcon_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "AngleLeftIcon", 19);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-paginator-icon");
  }
}
function Paginator_div_0_span_6_1_ng_template_0_Template(rf, ctx) {
}
function Paginator_div_0_span_6_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Paginator_div_0_span_6_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Paginator_div_0_span_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 20);
    ɵɵtemplate(1, Paginator_div_0_span_6_1_Template, 1, 0, null, 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r5 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r5.previousPageLinkIconTemplate);
  }
}
var _c25 = function(a0) {
  return {
    "p-highlight": a0
  };
};
function Paginator_div_0_span_7_button_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r26 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 24);
    ɵɵlistener("click", function Paginator_div_0_span_7_button_1_Template_button_click_0_listener($event) {
      const restoredCtx = ɵɵrestoreView(_r26);
      const pageLink_r24 = restoredCtx.$implicit;
      const ctx_r25 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r25.onPageLinkClick($event, pageLink_r24 - 1));
    });
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const pageLink_r24 = ctx.$implicit;
    const ctx_r23 = ɵɵnextContext(3);
    ɵɵproperty("ngClass", ɵɵpureFunction1(2, _c25, pageLink_r24 - 1 == ctx_r23.getPage()));
    ɵɵadvance(1);
    ɵɵtextInterpolate1(" ", pageLink_r24, " ");
  }
}
function Paginator_div_0_span_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 22);
    ɵɵtemplate(1, Paginator_div_0_span_7_button_1_Template, 2, 4, "button", 23);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r6 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r6.pageLinks);
  }
}
function Paginator_div_0_p_dropdown_8_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0);
  }
  if (rf & 2) {
    const ctx_r27 = ɵɵnextContext(3);
    ɵɵtextInterpolate(ctx_r27.currentPageReport);
  }
}
function Paginator_div_0_p_dropdown_8_Template(rf, ctx) {
  if (rf & 1) {
    const _r29 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-dropdown", 25);
    ɵɵlistener("onChange", function Paginator_div_0_p_dropdown_8_Template_p_dropdown_onChange_0_listener($event) {
      ɵɵrestoreView(_r29);
      const ctx_r28 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r28.onPageDropdownChange($event));
    });
    ɵɵtemplate(1, Paginator_div_0_p_dropdown_8_ng_template_1_Template, 1, 1, "ng-template", 26);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r7 = ɵɵnextContext(2);
    ɵɵproperty("options", ctx_r7.pageItems)("ngModel", ctx_r7.getPage())("disabled", ctx_r7.empty())("appendTo", ctx_r7.dropdownAppendTo)("scrollHeight", ctx_r7.dropdownScrollHeight);
  }
}
function Paginator_div_0_AngleRightIcon_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "AngleRightIcon", 19);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-paginator-icon");
  }
}
function Paginator_div_0_span_11_1_ng_template_0_Template(rf, ctx) {
}
function Paginator_div_0_span_11_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Paginator_div_0_span_11_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Paginator_div_0_span_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 20);
    ɵɵtemplate(1, Paginator_div_0_span_11_1_Template, 1, 0, null, 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r9 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r9.nextPageLinkIconTemplate);
  }
}
function Paginator_div_0_button_12_AngleDoubleRightIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "AngleDoubleRightIcon", 19);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-paginator-icon");
  }
}
function Paginator_div_0_button_12_span_2_1_ng_template_0_Template(rf, ctx) {
}
function Paginator_div_0_button_12_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Paginator_div_0_button_12_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Paginator_div_0_button_12_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 20);
    ɵɵtemplate(1, Paginator_div_0_button_12_span_2_1_Template, 1, 0, null, 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r33 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r33.lastPageLinkIconTemplate);
  }
}
function Paginator_div_0_button_12_Template(rf, ctx) {
  if (rf & 1) {
    const _r37 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 27);
    ɵɵlistener("click", function Paginator_div_0_button_12_Template_button_click_0_listener($event) {
      ɵɵrestoreView(_r37);
      const ctx_r36 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r36.changePageToLast($event));
    });
    ɵɵtemplate(1, Paginator_div_0_button_12_AngleDoubleRightIcon_1_Template, 1, 1, "AngleDoubleRightIcon", 6);
    ɵɵtemplate(2, Paginator_div_0_button_12_span_2_Template, 2, 1, "span", 7);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r10 = ɵɵnextContext(2);
    ɵɵproperty("disabled", ctx_r10.isLastPage() || ctx_r10.empty())("ngClass", ɵɵpureFunction1(4, _c18, ctx_r10.isLastPage() || ctx_r10.empty()));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r10.lastPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r10.lastPageLinkIconTemplate);
  }
}
function Paginator_div_0_p_inputNumber_13_Template(rf, ctx) {
  if (rf & 1) {
    const _r39 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-inputNumber", 28);
    ɵɵlistener("ngModelChange", function Paginator_div_0_p_inputNumber_13_Template_p_inputNumber_ngModelChange_0_listener($event) {
      ɵɵrestoreView(_r39);
      const ctx_r38 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r38.changePage($event - 1));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r11 = ɵɵnextContext(2);
    ɵɵproperty("ngModel", ctx_r11.currentPage())("disabled", ctx_r11.empty());
  }
}
function Paginator_div_0_p_dropdown_14_ng_container_1_ng_template_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Paginator_div_0_p_dropdown_14_ng_container_1_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Paginator_div_0_p_dropdown_14_ng_container_1_ng_template_1_ng_container_0_Template, 1, 0, "ng-container", 16);
  }
  if (rf & 2) {
    const item_r42 = ctx.$implicit;
    const ctx_r41 = ɵɵnextContext(4);
    ɵɵproperty("ngTemplateOutlet", ctx_r41.dropdownItemTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c05, item_r42));
  }
}
function Paginator_div_0_p_dropdown_14_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Paginator_div_0_p_dropdown_14_ng_container_1_ng_template_1_Template, 1, 4, "ng-template", 31);
    ɵɵelementContainerEnd();
  }
}
function Paginator_div_0_p_dropdown_14_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-dropdown", 29);
    ɵɵlistener("ngModelChange", function Paginator_div_0_p_dropdown_14_Template_p_dropdown_ngModelChange_0_listener($event) {
      ɵɵrestoreView(_r45);
      const ctx_r44 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r44.rows = $event);
    })("onChange", function Paginator_div_0_p_dropdown_14_Template_p_dropdown_onChange_0_listener($event) {
      ɵɵrestoreView(_r45);
      const ctx_r46 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r46.onRppChange($event));
    });
    ɵɵtemplate(1, Paginator_div_0_p_dropdown_14_ng_container_1_Template, 2, 0, "ng-container", 30);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r12 = ɵɵnextContext(2);
    ɵɵproperty("options", ctx_r12.rowsPerPageItems)("ngModel", ctx_r12.rows)("disabled", ctx_r12.empty())("appendTo", ctx_r12.dropdownAppendTo)("scrollHeight", ctx_r12.dropdownScrollHeight);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r12.dropdownItemTemplate);
  }
}
function Paginator_div_0_div_15_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Paginator_div_0_div_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 32);
    ɵɵtemplate(1, Paginator_div_0_div_15_ng_container_1_Template, 1, 0, "ng-container", 16);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r13 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r13.templateRight)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c05, ctx_r13.paginatorState));
  }
}
function Paginator_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r49 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 1);
    ɵɵtemplate(1, Paginator_div_0_div_1_Template, 2, 4, "div", 2);
    ɵɵtemplate(2, Paginator_div_0_span_2_Template, 2, 1, "span", 3);
    ɵɵtemplate(3, Paginator_div_0_button_3_Template, 3, 6, "button", 4);
    ɵɵelementStart(4, "button", 5);
    ɵɵlistener("click", function Paginator_div_0_Template_button_click_4_listener($event) {
      ɵɵrestoreView(_r49);
      const ctx_r48 = ɵɵnextContext();
      return ɵɵresetView(ctx_r48.changePageToPrev($event));
    });
    ɵɵtemplate(5, Paginator_div_0_AngleLeftIcon_5_Template, 1, 1, "AngleLeftIcon", 6);
    ɵɵtemplate(6, Paginator_div_0_span_6_Template, 2, 1, "span", 7);
    ɵɵelementEnd();
    ɵɵtemplate(7, Paginator_div_0_span_7_Template, 2, 1, "span", 8);
    ɵɵtemplate(8, Paginator_div_0_p_dropdown_8_Template, 2, 5, "p-dropdown", 9);
    ɵɵelementStart(9, "button", 10);
    ɵɵlistener("click", function Paginator_div_0_Template_button_click_9_listener($event) {
      ɵɵrestoreView(_r49);
      const ctx_r50 = ɵɵnextContext();
      return ɵɵresetView(ctx_r50.changePageToNext($event));
    });
    ɵɵtemplate(10, Paginator_div_0_AngleRightIcon_10_Template, 1, 1, "AngleRightIcon", 6);
    ɵɵtemplate(11, Paginator_div_0_span_11_Template, 2, 1, "span", 7);
    ɵɵelementEnd();
    ɵɵtemplate(12, Paginator_div_0_button_12_Template, 3, 6, "button", 11);
    ɵɵtemplate(13, Paginator_div_0_p_inputNumber_13_Template, 1, 2, "p-inputNumber", 12);
    ɵɵtemplate(14, Paginator_div_0_p_dropdown_14_Template, 2, 6, "p-dropdown", 13);
    ɵɵtemplate(15, Paginator_div_0_div_15_Template, 2, 4, "div", 14);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵclassMap(ctx_r0.styleClass);
    ɵɵproperty("ngStyle", ctx_r0.style)("ngClass", "p-paginator p-component");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.templateLeft);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.showCurrentPageReport);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.showFirstLastIcon);
    ɵɵadvance(1);
    ɵɵproperty("disabled", ctx_r0.isFirstPage() || ctx_r0.empty())("ngClass", ɵɵpureFunction1(21, _c18, ctx_r0.isFirstPage() || ctx_r0.empty()));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r0.previousPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.previousPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.showPageLinks);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.showJumpToPageDropdown);
    ɵɵadvance(1);
    ɵɵproperty("disabled", ctx_r0.isLastPage() || ctx_r0.empty())("ngClass", ɵɵpureFunction1(23, _c18, ctx_r0.isLastPage() || ctx_r0.empty()));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r0.nextPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.nextPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.showFirstLastIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.showJumpToPageInput);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.rowsPerPageOptions);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.templateRight);
  }
}
var _Paginator = class {
  constructor(cd) {
    __publicField(this, "cd");
    /**
     * Number of page links to display.
     * @group Props
     */
    __publicField(this, "pageLinkSize", 5);
    /**
     * Inline style of the component.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Style class of the component.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Whether to show it even there is only one page.
     * @group Props
     */
    __publicField(this, "alwaysShow", true);
    /**
     * Target element to attach the dropdown overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @group Props
     */
    __publicField(this, "dropdownAppendTo");
    /**
     * Template instance to inject into the left side of the paginator.
     * @param {PaginatorState} context - Paginator state.
     * @group Props
     */
    __publicField(this, "templateLeft");
    /**
     * Template instance to inject into the right side of the paginator.
     * @param {PaginatorState} context - Paginator state.
     * @group Props
     */
    __publicField(this, "templateRight");
    /**
     * Target element to attach the dropdown overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @group Props
     */
    __publicField(this, "appendTo");
    /**
     * Dropdown height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    __publicField(this, "dropdownScrollHeight", "200px");
    /**
     * Template of the current page report element. Available placeholders are {currentPage},{totalPages},{rows},{first},{last} and {totalRecords}
     * @group Props
     */
    __publicField(this, "currentPageReportTemplate", "{currentPage} of {totalPages}");
    /**
     * Whether to display current page report.
     * @group Props
     */
    __publicField(this, "showCurrentPageReport");
    /**
     * When enabled, icons are displayed on paginator to go first and last page.
     * @group Props
     */
    __publicField(this, "showFirstLastIcon", true);
    /**
     * Number of total records.
     * @group Props
     */
    __publicField(this, "totalRecords", 0);
    /**
     * Data count to display per page.
     * @group Props
     */
    __publicField(this, "rows", 0);
    /**
     * Array of integer/object values to display inside rows per page dropdown. A object that have 'showAll' key can be added to it to show all data. Exp; [10,20,30,{showAll:'All'}]
     * @group Props
     */
    __publicField(this, "rowsPerPageOptions");
    /**
     * Whether to display a dropdown to navigate to any page.
     * @group Props
     */
    __publicField(this, "showJumpToPageDropdown");
    /**
     * Whether to display a input to navigate to any page.
     * @group Props
     */
    __publicField(this, "showJumpToPageInput");
    /**
     * Whether to show page links.
     * @group Props
     */
    __publicField(this, "showPageLinks", true);
    /**
     * Template instance to inject into the dropdown item inside in the paginator.
     * @param {Object} context - item instance.
     * @group Props
     */
    __publicField(this, "dropdownItemTemplate");
    /**
     * Callback to invoke when page changes, the event object contains information about the new state.
     * @param {PaginatorState} event - Paginator state.
     * @group Emits
     */
    __publicField(this, "onPageChange", new EventEmitter());
    __publicField(this, "templates");
    __publicField(this, "firstPageLinkIconTemplate");
    __publicField(this, "previousPageLinkIconTemplate");
    __publicField(this, "lastPageLinkIconTemplate");
    __publicField(this, "nextPageLinkIconTemplate");
    __publicField(this, "pageLinks");
    __publicField(this, "pageItems");
    __publicField(this, "rowsPerPageItems");
    __publicField(this, "paginatorState");
    __publicField(this, "_first", 0);
    __publicField(this, "_page", 0);
    this.cd = cd;
  }
  /**
   * Zero-relative number of the first row to be displayed.
   * @group Props
   */
  get first() {
    return this._first;
  }
  set first(val) {
    this._first = val;
  }
  ngOnInit() {
    this.updatePaginatorState();
  }
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "firstpagelinkicon":
          this.firstPageLinkIconTemplate = item.template;
          break;
        case "previouspagelinkicon":
          this.previousPageLinkIconTemplate = item.template;
          break;
        case "lastpagelinkicon":
          this.lastPageLinkIconTemplate = item.template;
          break;
        case "nextpagelinkicon":
          this.nextPageLinkIconTemplate = item.template;
          break;
      }
    });
  }
  ngOnChanges(simpleChange) {
    if (simpleChange.totalRecords) {
      this.updatePageLinks();
      this.updatePaginatorState();
      this.updateFirst();
      this.updateRowsPerPageOptions();
    }
    if (simpleChange.first) {
      this._first = simpleChange.first.currentValue;
      this.updatePageLinks();
      this.updatePaginatorState();
    }
    if (simpleChange.rows) {
      this.updatePageLinks();
      this.updatePaginatorState();
    }
    if (simpleChange.rowsPerPageOptions) {
      this.updateRowsPerPageOptions();
    }
  }
  updateRowsPerPageOptions() {
    if (this.rowsPerPageOptions) {
      this.rowsPerPageItems = [];
      for (let opt of this.rowsPerPageOptions) {
        if (typeof opt == "object" && opt["showAll"]) {
          this.rowsPerPageItems.unshift({
            label: opt["showAll"],
            value: this.totalRecords
          });
        } else {
          this.rowsPerPageItems.push({
            label: String(opt),
            value: opt
          });
        }
      }
    }
  }
  isFirstPage() {
    return this.getPage() === 0;
  }
  isLastPage() {
    return this.getPage() === this.getPageCount() - 1;
  }
  getPageCount() {
    return Math.ceil(this.totalRecords / this.rows);
  }
  calculatePageLinkBoundaries() {
    let numberOfPages = this.getPageCount(), visiblePages = Math.min(this.pageLinkSize, numberOfPages);
    let start = Math.max(0, Math.ceil(this.getPage() - visiblePages / 2)), end = Math.min(numberOfPages - 1, start + visiblePages - 1);
    var delta = this.pageLinkSize - (end - start + 1);
    start = Math.max(0, start - delta);
    return [start, end];
  }
  updatePageLinks() {
    this.pageLinks = [];
    let boundaries = this.calculatePageLinkBoundaries(), start = boundaries[0], end = boundaries[1];
    for (let i = start; i <= end; i++) {
      this.pageLinks.push(i + 1);
    }
    if (this.showJumpToPageDropdown) {
      this.pageItems = [];
      for (let i = 0; i < this.getPageCount(); i++) {
        this.pageItems.push({
          label: String(i + 1),
          value: i
        });
      }
    }
  }
  changePage(p) {
    var pc = this.getPageCount();
    if (p >= 0 && p < pc) {
      this._first = this.rows * p;
      var state2 = {
        page: p,
        first: this.first,
        rows: this.rows,
        pageCount: pc
      };
      this.updatePageLinks();
      this.onPageChange.emit(state2);
      this.updatePaginatorState();
    }
  }
  updateFirst() {
    const page = this.getPage();
    if (page > 0 && this.totalRecords && this.first >= this.totalRecords) {
      Promise.resolve(null).then(() => this.changePage(page - 1));
    }
  }
  getPage() {
    return Math.floor(this.first / this.rows);
  }
  changePageToFirst(event2) {
    if (!this.isFirstPage()) {
      this.changePage(0);
    }
    event2.preventDefault();
  }
  changePageToPrev(event2) {
    this.changePage(this.getPage() - 1);
    event2.preventDefault();
  }
  changePageToNext(event2) {
    this.changePage(this.getPage() + 1);
    event2.preventDefault();
  }
  changePageToLast(event2) {
    if (!this.isLastPage()) {
      this.changePage(this.getPageCount() - 1);
    }
    event2.preventDefault();
  }
  onPageLinkClick(event2, page) {
    this.changePage(page);
    event2.preventDefault();
  }
  onRppChange(event2) {
    this.changePage(this.getPage());
  }
  onPageDropdownChange(event2) {
    this.changePage(event2.value);
  }
  updatePaginatorState() {
    this.paginatorState = {
      page: this.getPage(),
      pageCount: this.getPageCount(),
      rows: this.rows,
      first: this.first,
      totalRecords: this.totalRecords
    };
  }
  empty() {
    return this.getPageCount() === 0;
  }
  currentPage() {
    return this.getPageCount() > 0 ? this.getPage() + 1 : 0;
  }
  get currentPageReport() {
    return this.currentPageReportTemplate.replace("{currentPage}", String(this.currentPage())).replace("{totalPages}", String(this.getPageCount())).replace("{first}", String(this.totalRecords > 0 ? this._first + 1 : 0)).replace("{last}", String(Math.min(this._first + this.rows, this.totalRecords))).replace("{rows}", String(this.rows)).replace("{totalRecords}", String(this.totalRecords));
  }
};
var Paginator = _Paginator;
__publicField(Paginator, "ɵfac", function Paginator_Factory(t) {
  return new (t || _Paginator)(ɵɵdirectiveInject(ChangeDetectorRef));
});
__publicField(Paginator, "ɵcmp", ɵɵdefineComponent({
  type: _Paginator,
  selectors: [["p-paginator"]],
  contentQueries: function Paginator_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    pageLinkSize: "pageLinkSize",
    style: "style",
    styleClass: "styleClass",
    alwaysShow: "alwaysShow",
    dropdownAppendTo: "dropdownAppendTo",
    templateLeft: "templateLeft",
    templateRight: "templateRight",
    appendTo: "appendTo",
    dropdownScrollHeight: "dropdownScrollHeight",
    currentPageReportTemplate: "currentPageReportTemplate",
    showCurrentPageReport: "showCurrentPageReport",
    showFirstLastIcon: "showFirstLastIcon",
    totalRecords: "totalRecords",
    rows: "rows",
    rowsPerPageOptions: "rowsPerPageOptions",
    showJumpToPageDropdown: "showJumpToPageDropdown",
    showJumpToPageInput: "showJumpToPageInput",
    showPageLinks: "showPageLinks",
    dropdownItemTemplate: "dropdownItemTemplate",
    first: "first"
  },
  outputs: {
    onPageChange: "onPageChange"
  },
  features: [ɵɵNgOnChangesFeature],
  decls: 1,
  vars: 1,
  consts: [[3, "class", "ngStyle", "ngClass", 4, "ngIf"], [3, "ngStyle", "ngClass"], ["class", "p-paginator-left-content", 4, "ngIf"], ["class", "p-paginator-current", 4, "ngIf"], ["type", "button", "pRipple", "", "class", "p-paginator-first p-paginator-element p-link", 3, "disabled", "ngClass", "click", 4, "ngIf"], ["type", "button", "pRipple", "", 1, "p-paginator-prev", "p-paginator-element", "p-link", 3, "disabled", "ngClass", "click"], [3, "styleClass", 4, "ngIf"], ["class", "p-paginator-icon", 4, "ngIf"], ["class", "p-paginator-pages", 4, "ngIf"], ["styleClass", "p-paginator-page-options", 3, "options", "ngModel", "disabled", "appendTo", "scrollHeight", "onChange", 4, "ngIf"], ["type", "button", "pRipple", "", 1, "p-paginator-next", "p-paginator-element", "p-link", 3, "disabled", "ngClass", "click"], ["type", "button", "pRipple", "", "class", "p-paginator-last p-paginator-element p-link", 3, "disabled", "ngClass", "click", 4, "ngIf"], ["class", "p-paginator-page-input", 3, "ngModel", "disabled", "ngModelChange", 4, "ngIf"], ["styleClass", "p-paginator-rpp-options", 3, "options", "ngModel", "disabled", "appendTo", "scrollHeight", "ngModelChange", "onChange", 4, "ngIf"], ["class", "p-paginator-right-content", 4, "ngIf"], [1, "p-paginator-left-content"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "p-paginator-current"], ["type", "button", "pRipple", "", 1, "p-paginator-first", "p-paginator-element", "p-link", 3, "disabled", "ngClass", "click"], [3, "styleClass"], [1, "p-paginator-icon"], [4, "ngTemplateOutlet"], [1, "p-paginator-pages"], ["type", "button", "class", "p-paginator-page p-paginator-element p-link", "pRipple", "", 3, "ngClass", "click", 4, "ngFor", "ngForOf"], ["type", "button", "pRipple", "", 1, "p-paginator-page", "p-paginator-element", "p-link", 3, "ngClass", "click"], ["styleClass", "p-paginator-page-options", 3, "options", "ngModel", "disabled", "appendTo", "scrollHeight", "onChange"], ["pTemplate", "selectedItem"], ["type", "button", "pRipple", "", 1, "p-paginator-last", "p-paginator-element", "p-link", 3, "disabled", "ngClass", "click"], [1, "p-paginator-page-input", 3, "ngModel", "disabled", "ngModelChange"], ["styleClass", "p-paginator-rpp-options", 3, "options", "ngModel", "disabled", "appendTo", "scrollHeight", "ngModelChange", "onChange"], [4, "ngIf"], ["pTemplate", "item"], [1, "p-paginator-right-content"]],
  template: function Paginator_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵtemplate(0, Paginator_div_0_Template, 16, 25, "div", 0);
    }
    if (rf & 2) {
      ɵɵproperty("ngIf", ctx.alwaysShow ? true : ctx.pageLinks && ctx.pageLinks.length > 1);
    }
  },
  dependencies: function() {
    return [NgClass, NgForOf, NgIf, NgTemplateOutlet, NgStyle, Dropdown, PrimeTemplate, InputNumber, NgControlStatus, NgModel, Ripple, AngleDoubleLeftIcon, AngleDoubleRightIcon, AngleLeftIcon, AngleRightIcon];
  },
  styles: [".p-paginator{display:flex;align-items:center;justify-content:center;flex-wrap:wrap}.p-paginator-left-content{margin-right:auto}.p-paginator-right-content{margin-left:auto}.p-paginator-page,.p-paginator-next,.p-paginator-last,.p-paginator-first,.p-paginator-prev,.p-paginator-current{cursor:pointer;display:inline-flex;align-items:center;justify-content:center;line-height:1;-webkit-user-select:none;user-select:none;overflow:hidden;position:relative}.p-paginator-element:focus{z-index:1;position:relative}\n"],
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Paginator, [{
    type: Component,
    args: [{
      selector: "p-paginator",
      template: `
        <div [class]="styleClass" [ngStyle]="style" [ngClass]="'p-paginator p-component'" *ngIf="alwaysShow ? true : pageLinks && pageLinks.length > 1">
            <div class="p-paginator-left-content" *ngIf="templateLeft">
                <ng-container *ngTemplateOutlet="templateLeft; context: { $implicit: paginatorState }"></ng-container>
            </div>
            <span class="p-paginator-current" *ngIf="showCurrentPageReport">{{ currentPageReport }}</span>
            <button *ngIf="showFirstLastIcon" type="button" [disabled]="isFirstPage() || empty()" (click)="changePageToFirst($event)" pRipple class="p-paginator-first p-paginator-element p-link" [ngClass]="{ 'p-disabled': isFirstPage() || empty() }">
                <AngleDoubleLeftIcon *ngIf="!firstPageLinkIconTemplate" [styleClass]="'p-paginator-icon'" />
                <span class="p-paginator-icon" *ngIf="firstPageLinkIconTemplate">
                    <ng-template *ngTemplateOutlet="firstPageLinkIconTemplate"></ng-template>
                </span>
            </button>
            <button type="button" [disabled]="isFirstPage() || empty()" (click)="changePageToPrev($event)" pRipple class="p-paginator-prev p-paginator-element p-link" [ngClass]="{ 'p-disabled': isFirstPage() || empty() }">
                <AngleLeftIcon *ngIf="!previousPageLinkIconTemplate" [styleClass]="'p-paginator-icon'" />
                <span class="p-paginator-icon" *ngIf="previousPageLinkIconTemplate">
                    <ng-template *ngTemplateOutlet="previousPageLinkIconTemplate"></ng-template>
                </span>
            </button>
            <span class="p-paginator-pages" *ngIf="showPageLinks">
                <button type="button" *ngFor="let pageLink of pageLinks" class="p-paginator-page p-paginator-element p-link" [ngClass]="{ 'p-highlight': pageLink - 1 == getPage() }" (click)="onPageLinkClick($event, pageLink - 1)" pRipple>
                    {{ pageLink }}
                </button>
            </span>
            <p-dropdown
                [options]="pageItems"
                [ngModel]="getPage()"
                *ngIf="showJumpToPageDropdown"
                [disabled]="empty()"
                styleClass="p-paginator-page-options"
                (onChange)="onPageDropdownChange($event)"
                [appendTo]="dropdownAppendTo"
                [scrollHeight]="dropdownScrollHeight"
            >
                <ng-template pTemplate="selectedItem">{{ currentPageReport }}</ng-template>
            </p-dropdown>
            <button type="button" [disabled]="isLastPage() || empty()" (click)="changePageToNext($event)" pRipple class="p-paginator-next p-paginator-element p-link" [ngClass]="{ 'p-disabled': isLastPage() || empty() }">
                <AngleRightIcon *ngIf="!nextPageLinkIconTemplate" [styleClass]="'p-paginator-icon'" />
                <span class="p-paginator-icon" *ngIf="nextPageLinkIconTemplate">
                    <ng-template *ngTemplateOutlet="nextPageLinkIconTemplate"></ng-template>
                </span>
            </button>
            <button *ngIf="showFirstLastIcon" type="button" [disabled]="isLastPage() || empty()" (click)="changePageToLast($event)" pRipple class="p-paginator-last p-paginator-element p-link" [ngClass]="{ 'p-disabled': isLastPage() || empty() }">
                <AngleDoubleRightIcon *ngIf="!lastPageLinkIconTemplate" [styleClass]="'p-paginator-icon'" />
                <span class="p-paginator-icon" *ngIf="lastPageLinkIconTemplate">
                    <ng-template *ngTemplateOutlet="lastPageLinkIconTemplate"></ng-template>
                </span>
            </button>
            <p-inputNumber *ngIf="showJumpToPageInput" [ngModel]="currentPage()" class="p-paginator-page-input" [disabled]="empty()" (ngModelChange)="changePage($event - 1)"></p-inputNumber>
            <p-dropdown
                [options]="rowsPerPageItems"
                [(ngModel)]="rows"
                *ngIf="rowsPerPageOptions"
                styleClass="p-paginator-rpp-options"
                [disabled]="empty()"
                (onChange)="onRppChange($event)"
                [appendTo]="dropdownAppendTo"
                [scrollHeight]="dropdownScrollHeight"
            >
                <ng-container *ngIf="dropdownItemTemplate">
                    <ng-template let-item pTemplate="item">
                        <ng-container *ngTemplateOutlet="dropdownItemTemplate; context: { $implicit: item }"> </ng-container>
                    </ng-template>
                </ng-container>
            </p-dropdown>
            <div class="p-paginator-right-content" *ngIf="templateRight">
                <ng-container *ngTemplateOutlet="templateRight; context: { $implicit: paginatorState }"></ng-container>
            </div>
        </div>
    `,
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      },
      styles: [".p-paginator{display:flex;align-items:center;justify-content:center;flex-wrap:wrap}.p-paginator-left-content{margin-right:auto}.p-paginator-right-content{margin-left:auto}.p-paginator-page,.p-paginator-next,.p-paginator-last,.p-paginator-first,.p-paginator-prev,.p-paginator-current{cursor:pointer;display:inline-flex;align-items:center;justify-content:center;line-height:1;-webkit-user-select:none;user-select:none;overflow:hidden;position:relative}.p-paginator-element:focus{z-index:1;position:relative}\n"]
    }]
  }], function() {
    return [{
      type: ChangeDetectorRef
    }];
  }, {
    pageLinkSize: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    alwaysShow: [{
      type: Input
    }],
    dropdownAppendTo: [{
      type: Input
    }],
    templateLeft: [{
      type: Input
    }],
    templateRight: [{
      type: Input
    }],
    appendTo: [{
      type: Input
    }],
    dropdownScrollHeight: [{
      type: Input
    }],
    currentPageReportTemplate: [{
      type: Input
    }],
    showCurrentPageReport: [{
      type: Input
    }],
    showFirstLastIcon: [{
      type: Input
    }],
    totalRecords: [{
      type: Input
    }],
    rows: [{
      type: Input
    }],
    rowsPerPageOptions: [{
      type: Input
    }],
    showJumpToPageDropdown: [{
      type: Input
    }],
    showJumpToPageInput: [{
      type: Input
    }],
    showPageLinks: [{
      type: Input
    }],
    dropdownItemTemplate: [{
      type: Input
    }],
    first: [{
      type: Input
    }],
    onPageChange: [{
      type: Output
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var _PaginatorModule = class {
};
var PaginatorModule = _PaginatorModule;
__publicField(PaginatorModule, "ɵfac", function PaginatorModule_Factory(t) {
  return new (t || _PaginatorModule)();
});
__publicField(PaginatorModule, "ɵmod", ɵɵdefineNgModule({
  type: _PaginatorModule,
  declarations: [Paginator],
  imports: [CommonModule, DropdownModule, InputNumberModule, FormsModule, SharedModule, RippleModule, AngleDoubleLeftIcon, AngleDoubleRightIcon, AngleLeftIcon, AngleRightIcon],
  exports: [Paginator, DropdownModule, InputNumberModule, FormsModule, SharedModule]
}));
__publicField(PaginatorModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, DropdownModule, InputNumberModule, FormsModule, SharedModule, RippleModule, AngleDoubleLeftIcon, AngleDoubleRightIcon, AngleLeftIcon, AngleRightIcon, DropdownModule, InputNumberModule, FormsModule, SharedModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PaginatorModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, DropdownModule, InputNumberModule, FormsModule, SharedModule, RippleModule, AngleDoubleLeftIcon, AngleDoubleRightIcon, AngleLeftIcon, AngleRightIcon],
      exports: [Paginator, DropdownModule, InputNumberModule, FormsModule, SharedModule],
      declarations: [Paginator]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-selectbutton.mjs
function SelectButton_div_1_ng_container_2_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 8);
  }
  if (rf & 2) {
    const option_r1 = ɵɵnextContext(2).$implicit;
    ɵɵclassMap(option_r1.icon);
    ɵɵproperty("ngClass", "p-button-icon p-button-icon-left");
  }
}
function SelectButton_div_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, SelectButton_div_1_ng_container_2_span_1_Template, 1, 3, "span", 6);
    ɵɵelementStart(2, "span", 7);
    ɵɵtext(3);
    ɵɵelementEnd();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const option_r1 = ɵɵnextContext().$implicit;
    const ctx_r4 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", option_r1.icon);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ctx_r4.getOptionLabel(option_r1));
  }
}
function SelectButton_div_1_ng_template_3_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c06 = function(a0, a1) {
  return {
    $implicit: a0,
    index: a1
  };
};
function SelectButton_div_1_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, SelectButton_div_1_ng_template_3_ng_container_0_Template, 1, 0, "ng-container", 9);
  }
  if (rf & 2) {
    const ctx_r11 = ɵɵnextContext();
    const option_r1 = ctx_r11.$implicit;
    const i_r2 = ctx_r11.index;
    const ctx_r6 = ɵɵnextContext();
    ɵɵproperty("ngTemplateOutlet", ctx_r6.selectButtonTemplate)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c06, option_r1, i_r2));
  }
}
var _c19 = function(a0, a1, a2) {
  return {
    "p-highlight": a0,
    "p-disabled": a1,
    "p-button-icon-only": a2
  };
};
function SelectButton_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 2, 3);
    ɵɵlistener("click", function SelectButton_div_1_Template_div_click_0_listener($event) {
      const restoredCtx = ɵɵrestoreView(_r13);
      const option_r1 = restoredCtx.$implicit;
      const i_r2 = restoredCtx.index;
      const ctx_r12 = ɵɵnextContext();
      return ɵɵresetView(ctx_r12.onItemClick($event, option_r1, i_r2));
    })("keydown.enter", function SelectButton_div_1_Template_div_keydown_enter_0_listener($event) {
      const restoredCtx = ɵɵrestoreView(_r13);
      const option_r1 = restoredCtx.$implicit;
      const i_r2 = restoredCtx.index;
      const ctx_r14 = ɵɵnextContext();
      return ɵɵresetView(ctx_r14.onItemClick($event, option_r1, i_r2));
    })("blur", function SelectButton_div_1_Template_div_blur_0_listener() {
      ɵɵrestoreView(_r13);
      const ctx_r15 = ɵɵnextContext();
      return ɵɵresetView(ctx_r15.onBlur());
    });
    ɵɵtemplate(2, SelectButton_div_1_ng_container_2_Template, 4, 2, "ng-container", 4);
    ɵɵtemplate(3, SelectButton_div_1_ng_template_3_Template, 1, 5, "ng-template", null, 5, ɵɵtemplateRefExtractor);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const option_r1 = ctx.$implicit;
    const _r5 = ɵɵreference(4);
    const ctx_r0 = ɵɵnextContext();
    ɵɵclassMap(option_r1.styleClass);
    ɵɵproperty("ngClass", ɵɵpureFunction3(10, _c19, ctx_r0.isSelected(option_r1), ctx_r0.disabled || ctx_r0.isOptionDisabled(option_r1), option_r1.icon && !ctx_r0.getOptionLabel(option_r1)));
    ɵɵattribute("aria-pressed", ctx_r0.isSelected(option_r1))("title", option_r1.title)("aria-label", option_r1.label)("tabindex", ctx_r0.disabled ? null : ctx_r0.tabindex)("aria-labelledby", ctx_r0.getOptionLabel(option_r1));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r0.itemTemplate)("ngIfElse", _r5);
  }
}
var SELECTBUTTON_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => SelectButton),
  multi: true
};
var _SelectButton = class {
  constructor(cd) {
    __publicField(this, "cd");
    /**
     * An array of selectitems to display as the available options.
     * @group Props
     */
    __publicField(this, "options");
    /**
     * Name of the label field of an option.
     * @group Props
     */
    __publicField(this, "optionLabel");
    /**
     * Name of the value field of an option.
     * @group Props
     */
    __publicField(this, "optionValue");
    /**
     * Name of the disabled field of an option.
     * @group Props
     */
    __publicField(this, "optionDisabled");
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    __publicField(this, "tabindex", 0);
    /**
     * When specified, allows selecting multiple values.
     * @group Props
     */
    __publicField(this, "multiple");
    /**
     * Inline style of the component.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Style class of the component.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    __publicField(this, "ariaLabelledBy");
    /**
     * When present, it specifies that the element should be disabled.
     * @group Props
     */
    __publicField(this, "disabled");
    /**
     * A property to uniquely identify a value in options.
     * @group Props
     */
    __publicField(this, "dataKey");
    /**
     * Callback to invoke on input click.
     * @param {SelectButtonOptionClickEvent} event - Custom click event.
     * @group Emits
     */
    __publicField(this, "onOptionClick", new EventEmitter());
    /**
     * Callback to invoke on selection change.
     * @param {SelectButtonChangeEvent} event - Custom change event.
     * @group Emits
     */
    __publicField(this, "onChange", new EventEmitter());
    __publicField(this, "itemTemplate");
    __publicField(this, "value");
    __publicField(this, "onModelChange", () => {
    });
    __publicField(this, "onModelTouched", () => {
    });
    this.cd = cd;
  }
  get selectButtonTemplate() {
    var _a;
    return (_a = this.itemTemplate) == null ? void 0 : _a.template;
  }
  getOptionLabel(option) {
    return this.optionLabel ? ObjectUtils.resolveFieldData(option, this.optionLabel) : option.label != void 0 ? option.label : option;
  }
  getOptionValue(option) {
    return this.optionValue ? ObjectUtils.resolveFieldData(option, this.optionValue) : this.optionLabel || option.value === void 0 ? option : option.value;
  }
  isOptionDisabled(option) {
    return this.optionDisabled ? ObjectUtils.resolveFieldData(option, this.optionDisabled) : option.disabled !== void 0 ? option.disabled : false;
  }
  writeValue(value) {
    this.value = value;
    this.cd.markForCheck();
  }
  registerOnChange(fn) {
    this.onModelChange = fn;
  }
  registerOnTouched(fn) {
    this.onModelTouched = fn;
  }
  setDisabledState(val) {
    this.disabled = val;
    this.cd.markForCheck();
  }
  onItemClick(event2, option, index) {
    if (this.disabled || this.isOptionDisabled(option)) {
      return;
    }
    if (this.multiple) {
      if (this.isSelected(option))
        this.removeOption(option);
      else
        this.value = [...this.value || [], this.getOptionValue(option)];
      this.onModelChange(this.value);
      this.onChange.emit({
        originalEvent: event2,
        value: this.value
      });
    } else {
      let value = this.getOptionValue(option);
      if (this.value !== value) {
        this.value = this.getOptionValue(option);
        this.onModelChange(this.value);
        this.onChange.emit({
          originalEvent: event2,
          value: this.value
        });
      }
    }
    this.onOptionClick.emit({
      originalEvent: event2,
      option,
      index
    });
  }
  onBlur() {
    this.onModelTouched();
  }
  removeOption(option) {
    this.value = this.value.filter((val) => !ObjectUtils.equals(val, this.getOptionValue(option), this.dataKey));
  }
  isSelected(option) {
    let selected = false;
    let optionValue = this.getOptionValue(option);
    if (this.multiple) {
      if (this.value && Array.isArray(this.value)) {
        for (let val of this.value) {
          if (ObjectUtils.equals(val, optionValue, this.dataKey)) {
            selected = true;
            break;
          }
        }
      }
    } else {
      selected = ObjectUtils.equals(this.getOptionValue(option), this.value, this.dataKey);
    }
    return selected;
  }
};
var SelectButton = _SelectButton;
__publicField(SelectButton, "ɵfac", function SelectButton_Factory(t) {
  return new (t || _SelectButton)(ɵɵdirectiveInject(ChangeDetectorRef));
});
__publicField(SelectButton, "ɵcmp", ɵɵdefineComponent({
  type: _SelectButton,
  selectors: [["p-selectButton"]],
  contentQueries: function SelectButton_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.itemTemplate = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    options: "options",
    optionLabel: "optionLabel",
    optionValue: "optionValue",
    optionDisabled: "optionDisabled",
    tabindex: "tabindex",
    multiple: "multiple",
    style: "style",
    styleClass: "styleClass",
    ariaLabelledBy: "ariaLabelledBy",
    disabled: "disabled",
    dataKey: "dataKey"
  },
  outputs: {
    onOptionClick: "onOptionClick",
    onChange: "onChange"
  },
  features: [ɵɵProvidersFeature([SELECTBUTTON_VALUE_ACCESSOR])],
  decls: 2,
  vars: 5,
  consts: [["role", "group", 3, "ngClass", "ngStyle"], ["class", "p-button p-component", "role", "button", "pRipple", "", 3, "class", "ngClass", "click", "keydown.enter", "blur", 4, "ngFor", "ngForOf"], ["role", "button", "pRipple", "", 1, "p-button", "p-component", 3, "ngClass", "click", "keydown.enter", "blur"], ["btn", ""], [4, "ngIf", "ngIfElse"], ["customcontent", ""], [3, "ngClass", "class", 4, "ngIf"], [1, "p-button-label"], [3, "ngClass"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"]],
  template: function SelectButton_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0);
      ɵɵtemplate(1, SelectButton_div_1_Template, 5, 14, "div", 1);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.styleClass);
      ɵɵproperty("ngClass", "p-selectbutton p-buttonset p-component")("ngStyle", ctx.style);
      ɵɵadvance(1);
      ɵɵproperty("ngForOf", ctx.options);
    }
  },
  dependencies: [NgClass, NgForOf, NgIf, NgTemplateOutlet, NgStyle, Ripple],
  styles: ['.p-button{margin:0;display:inline-flex;cursor:pointer;-webkit-user-select:none;user-select:none;align-items:center;vertical-align:bottom;text-align:center;overflow:hidden;position:relative}.p-button-label{flex:1 1 auto}.p-button-icon-right{order:1}.p-button:disabled{cursor:default;pointer-events:none}.p-button-icon-only{justify-content:center}.p-button-icon-only:after{content:"p";visibility:hidden;clip:rect(0 0 0 0);width:0}.p-button-vertical{flex-direction:column}.p-button-icon-bottom{order:2}.p-buttonset .p-button{margin:0}.p-buttonset .p-button:not(:last-child){border-right:0 none}.p-buttonset .p-button:not(:first-of-type):not(:last-of-type){border-radius:0}.p-buttonset .p-button:first-of-type{border-top-right-radius:0;border-bottom-right-radius:0}.p-buttonset .p-button:last-of-type{border-top-left-radius:0;border-bottom-left-radius:0}.p-buttonset .p-button:focus{position:relative;z-index:1}\n'],
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SelectButton, [{
    type: Component,
    args: [{
      selector: "p-selectButton",
      template: `
        <div [ngClass]="'p-selectbutton p-buttonset p-component'" [ngStyle]="style" [class]="styleClass" role="group">
            <div
                *ngFor="let option of options; let i = index"
                #btn
                class="p-button p-component"
                [class]="option.styleClass"
                role="button"
                [attr.aria-pressed]="isSelected(option)"
                [ngClass]="{ 'p-highlight': isSelected(option), 'p-disabled': disabled || isOptionDisabled(option), 'p-button-icon-only': option.icon && !getOptionLabel(option) }"
                (click)="onItemClick($event, option, i)"
                (keydown.enter)="onItemClick($event, option, i)"
                [attr.title]="option.title"
                [attr.aria-label]="option.label"
                (blur)="onBlur()"
                [attr.tabindex]="disabled ? null : tabindex"
                [attr.aria-labelledby]="this.getOptionLabel(option)"
                pRipple
            >
                <ng-container *ngIf="!itemTemplate; else customcontent">
                    <span [ngClass]="'p-button-icon p-button-icon-left'" [class]="option.icon" *ngIf="option.icon"></span>
                    <span class="p-button-label">{{ getOptionLabel(option) }}</span>
                </ng-container>
                <ng-template #customcontent>
                    <ng-container *ngTemplateOutlet="selectButtonTemplate; context: { $implicit: option, index: i }"></ng-container>
                </ng-template>
            </div>
        </div>
    `,
      providers: [SELECTBUTTON_VALUE_ACCESSOR],
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      },
      styles: ['.p-button{margin:0;display:inline-flex;cursor:pointer;-webkit-user-select:none;user-select:none;align-items:center;vertical-align:bottom;text-align:center;overflow:hidden;position:relative}.p-button-label{flex:1 1 auto}.p-button-icon-right{order:1}.p-button:disabled{cursor:default;pointer-events:none}.p-button-icon-only{justify-content:center}.p-button-icon-only:after{content:"p";visibility:hidden;clip:rect(0 0 0 0);width:0}.p-button-vertical{flex-direction:column}.p-button-icon-bottom{order:2}.p-buttonset .p-button{margin:0}.p-buttonset .p-button:not(:last-child){border-right:0 none}.p-buttonset .p-button:not(:first-of-type):not(:last-of-type){border-radius:0}.p-buttonset .p-button:first-of-type{border-top-right-radius:0;border-bottom-right-radius:0}.p-buttonset .p-button:last-of-type{border-top-left-radius:0;border-bottom-left-radius:0}.p-buttonset .p-button:focus{position:relative;z-index:1}\n']
    }]
  }], function() {
    return [{
      type: ChangeDetectorRef
    }];
  }, {
    options: [{
      type: Input
    }],
    optionLabel: [{
      type: Input
    }],
    optionValue: [{
      type: Input
    }],
    optionDisabled: [{
      type: Input
    }],
    tabindex: [{
      type: Input
    }],
    multiple: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    ariaLabelledBy: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    dataKey: [{
      type: Input
    }],
    onOptionClick: [{
      type: Output
    }],
    onChange: [{
      type: Output
    }],
    itemTemplate: [{
      type: ContentChild,
      args: [PrimeTemplate]
    }]
  });
})();
var _SelectButtonModule = class {
};
var SelectButtonModule = _SelectButtonModule;
__publicField(SelectButtonModule, "ɵfac", function SelectButtonModule_Factory(t) {
  return new (t || _SelectButtonModule)();
});
__publicField(SelectButtonModule, "ɵmod", ɵɵdefineNgModule({
  type: _SelectButtonModule,
  declarations: [SelectButton],
  imports: [CommonModule, RippleModule, SharedModule],
  exports: [SelectButton, SharedModule]
}));
__publicField(SelectButtonModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, RippleModule, SharedModule, SharedModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SelectButtonModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RippleModule, SharedModule],
      exports: [SelectButton, SharedModule],
      declarations: [SelectButton]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-tristatecheckbox.mjs
function TriStateCheckbox_ng_container_5_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 8);
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext(2);
    ɵɵproperty("ngClass", ctx_r4.checkboxTrueIcon);
  }
}
function TriStateCheckbox_ng_container_5_ng_container_2_CheckIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "CheckIcon", 11);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-checkbox-icon");
  }
}
function TriStateCheckbox_ng_container_5_ng_container_2_span_2_1_ng_template_0_Template(rf, ctx) {
}
function TriStateCheckbox_ng_container_5_ng_container_2_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, TriStateCheckbox_ng_container_5_ng_container_2_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function TriStateCheckbox_ng_container_5_ng_container_2_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 12);
    ɵɵtemplate(1, TriStateCheckbox_ng_container_5_ng_container_2_span_2_1_Template, 1, 0, null, 13);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r7 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r7.checkIconTemplate);
  }
}
function TriStateCheckbox_ng_container_5_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TriStateCheckbox_ng_container_5_ng_container_2_CheckIcon_1_Template, 1, 1, "CheckIcon", 9);
    ɵɵtemplate(2, TriStateCheckbox_ng_container_5_ng_container_2_span_2_Template, 2, 1, "span", 10);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r5 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r5.checkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.checkIconTemplate);
  }
}
function TriStateCheckbox_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TriStateCheckbox_ng_container_5_span_1_Template, 1, 1, "span", 7);
    ɵɵtemplate(2, TriStateCheckbox_ng_container_5_ng_container_2_Template, 3, 2, "ng-container", 5);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r1.checkboxTrueIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r1.checkboxTrueIcon);
  }
}
function TriStateCheckbox_ng_container_6_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 8);
  }
  if (rf & 2) {
    const ctx_r10 = ɵɵnextContext(2);
    ɵɵproperty("ngClass", ctx_r10.checkboxFalseIcon);
  }
}
function TriStateCheckbox_ng_container_6_ng_container_2_TimesIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "TimesIcon", 11);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-checkbox-icon");
  }
}
function TriStateCheckbox_ng_container_6_ng_container_2_span_2_1_ng_template_0_Template(rf, ctx) {
}
function TriStateCheckbox_ng_container_6_ng_container_2_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, TriStateCheckbox_ng_container_6_ng_container_2_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function TriStateCheckbox_ng_container_6_ng_container_2_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 12);
    ɵɵtemplate(1, TriStateCheckbox_ng_container_6_ng_container_2_span_2_1_Template, 1, 0, null, 13);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r13 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r13.uncheckIconTemplate);
  }
}
function TriStateCheckbox_ng_container_6_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TriStateCheckbox_ng_container_6_ng_container_2_TimesIcon_1_Template, 1, 1, "TimesIcon", 9);
    ɵɵtemplate(2, TriStateCheckbox_ng_container_6_ng_container_2_span_2_Template, 2, 1, "span", 10);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r11 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r11.uncheckIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r11.uncheckIconTemplate);
  }
}
function TriStateCheckbox_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TriStateCheckbox_ng_container_6_span_1_Template, 1, 1, "span", 7);
    ɵɵtemplate(2, TriStateCheckbox_ng_container_6_ng_container_2_Template, 3, 2, "ng-container", 5);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r2.checkboxFalseIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r2.checkboxFalseIcon);
  }
}
var _c07 = function(a0, a1, a2) {
  return {
    "p-checkbox-label-active": a0,
    "p-disabled": a1,
    "p-checkbox-label-focus": a2
  };
};
function TriStateCheckbox_label_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "label", 14);
    ɵɵlistener("click", function TriStateCheckbox_label_7_Template_label_click_0_listener($event) {
      ɵɵrestoreView(_r17);
      const ctx_r16 = ɵɵnextContext();
      const _r0 = ɵɵreference(3);
      return ɵɵresetView(ctx_r16.onClick($event, _r0));
    });
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    ɵɵproperty("ngClass", ɵɵpureFunction3(3, _c07, ctx_r3.value != null, ctx_r3.disabled, ctx_r3.focused));
    ɵɵattribute("for", ctx_r3.inputId);
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r3.label);
  }
}
var _c110 = function(a1, a2) {
  return {
    "p-checkbox p-component": true,
    "p-checkbox-disabled": a1,
    "p-checkbox-focused": a2
  };
};
var _c26 = function(a0, a1, a2) {
  return {
    "p-highlight": a0,
    "p-disabled": a1,
    "p-focus": a2
  };
};
var TRISTATECHECKBOX_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => TriStateCheckbox),
  multi: true
};
var _TriStateCheckbox = class {
  constructor(cd) {
    __publicField(this, "cd");
    /**
     * When present, it specifies that the element should be disabled.
     * @group Props
     */
    __publicField(this, "disabled");
    /**
     * Name of the component.
     * @group Props
     */
    __publicField(this, "name");
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    __publicField(this, "ariaLabelledBy");
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    __publicField(this, "tabindex");
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    __publicField(this, "inputId");
    /**
     * Inline style of the component.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Style class of the component.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Label of the checkbox.
     * @group Props
     */
    __publicField(this, "label");
    /**
     * When present, it specifies that the component cannot be edited.
     * @group Props
     */
    __publicField(this, "readonly");
    /**
     * Specifies the icon for checkbox true value.
     * @group Props
     */
    __publicField(this, "checkboxTrueIcon");
    /**
     * Specifies the icon for checkbox false value.
     * @group Props
     */
    __publicField(this, "checkboxFalseIcon");
    /**
     * Callback to invoke on value change.
     * @param {TriStateCheckboxChangeEvent} event - Custom change event.
     * @group Emits
     */
    __publicField(this, "onChange", new EventEmitter());
    __publicField(this, "templates");
    __publicField(this, "checkIconTemplate");
    __publicField(this, "uncheckIconTemplate");
    __publicField(this, "focused");
    __publicField(this, "value");
    __publicField(this, "onModelChange", () => {
    });
    __publicField(this, "onModelTouched", () => {
    });
    this.cd = cd;
  }
  onClick(event2, input) {
    if (!this.disabled && !this.readonly) {
      this.toggle(event2);
      this.focused = true;
      input.focus();
    }
  }
  onKeydown(event2) {
    if (event2.keyCode == 32) {
      event2.preventDefault();
    }
  }
  onKeyup(event2) {
    if (event2.keyCode == 32 && !this.readonly) {
      this.toggle(event2);
      event2.preventDefault();
    }
  }
  toggle(event2) {
    if (this.value == null || this.value == void 0)
      this.value = true;
    else if (this.value == true)
      this.value = false;
    else if (this.value == false)
      this.value = null;
    this.onModelChange(this.value);
    this.onChange.emit({
      originalEvent: event2,
      value: this.value
    });
  }
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "checkicon":
          this.checkIconTemplate = item.template;
          break;
        case "uncheckicon":
          this.uncheckIconTemplate = item.template;
          break;
      }
    });
  }
  onFocus() {
    this.focused = true;
  }
  onBlur() {
    this.focused = false;
    this.onModelTouched();
  }
  registerOnChange(fn) {
    this.onModelChange = fn;
  }
  registerOnTouched(fn) {
    this.onModelTouched = fn;
  }
  writeValue(value) {
    this.value = value;
    this.cd.markForCheck();
  }
  setDisabledState(disabled) {
    this.disabled = disabled;
    this.cd.markForCheck();
  }
};
var TriStateCheckbox = _TriStateCheckbox;
__publicField(TriStateCheckbox, "ɵfac", function TriStateCheckbox_Factory(t) {
  return new (t || _TriStateCheckbox)(ɵɵdirectiveInject(ChangeDetectorRef));
});
__publicField(TriStateCheckbox, "ɵcmp", ɵɵdefineComponent({
  type: _TriStateCheckbox,
  selectors: [["p-triStateCheckbox"]],
  contentQueries: function TriStateCheckbox_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    disabled: "disabled",
    name: "name",
    ariaLabelledBy: "ariaLabelledBy",
    tabindex: "tabindex",
    inputId: "inputId",
    style: "style",
    styleClass: "styleClass",
    label: "label",
    readonly: "readonly",
    checkboxTrueIcon: "checkboxTrueIcon",
    checkboxFalseIcon: "checkboxFalseIcon"
  },
  outputs: {
    onChange: "onChange"
  },
  features: [ɵɵProvidersFeature([TRISTATECHECKBOX_VALUE_ACCESSOR])],
  decls: 8,
  vars: 22,
  consts: [[3, "ngStyle", "ngClass"], [1, "p-hidden-accessible"], ["type", "text", "inputmode", "none", 3, "name", "readonly", "disabled", "keyup", "keydown", "focus", "blur"], ["input", ""], ["role", "checkbox", 1, "p-checkbox-box", 3, "ngClass", "click"], [4, "ngIf"], ["class", "p-checkbox-label", 3, "ngClass", "click", 4, "ngIf"], ["class", "p-checkbox-icon", 3, "ngClass", 4, "ngIf"], [1, "p-checkbox-icon", 3, "ngClass"], [3, "styleClass", 4, "ngIf"], ["class", "p-checkbox-icon", 4, "ngIf"], [3, "styleClass"], [1, "p-checkbox-icon"], [4, "ngTemplateOutlet"], [1, "p-checkbox-label", 3, "ngClass", "click"]],
  template: function TriStateCheckbox_Template(rf, ctx) {
    if (rf & 1) {
      const _r18 = ɵɵgetCurrentView();
      ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "input", 2, 3);
      ɵɵlistener("keyup", function TriStateCheckbox_Template_input_keyup_2_listener($event) {
        return ctx.onKeyup($event);
      })("keydown", function TriStateCheckbox_Template_input_keydown_2_listener($event) {
        return ctx.onKeydown($event);
      })("focus", function TriStateCheckbox_Template_input_focus_2_listener() {
        return ctx.onFocus();
      })("blur", function TriStateCheckbox_Template_input_blur_2_listener() {
        return ctx.onBlur();
      });
      ɵɵelementEnd()();
      ɵɵelementStart(4, "div", 4);
      ɵɵlistener("click", function TriStateCheckbox_Template_div_click_4_listener($event) {
        ɵɵrestoreView(_r18);
        const _r0 = ɵɵreference(3);
        return ɵɵresetView(ctx.onClick($event, _r0));
      });
      ɵɵtemplate(5, TriStateCheckbox_ng_container_5_Template, 3, 2, "ng-container", 5);
      ɵɵtemplate(6, TriStateCheckbox_ng_container_6_Template, 3, 2, "ng-container", 5);
      ɵɵelementEnd()();
      ɵɵtemplate(7, TriStateCheckbox_label_7_Template, 2, 7, "label", 6);
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.styleClass);
      ɵɵproperty("ngStyle", ctx.style)("ngClass", ɵɵpureFunction2(15, _c110, ctx.disabled, ctx.focused));
      ɵɵadvance(2);
      ɵɵproperty("name", ctx.name)("readonly", ctx.readonly)("disabled", ctx.disabled);
      ɵɵattribute("id", ctx.inputId)("tabindex", ctx.tabindex)("aria-labelledby", ctx.ariaLabelledBy);
      ɵɵadvance(2);
      ɵɵproperty("ngClass", ɵɵpureFunction3(18, _c26, ctx.value != null, ctx.disabled, ctx.focused));
      ɵɵattribute("aria-checked", ctx.value === true);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.value === true);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.value === false);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.label);
    }
  },
  dependencies: function() {
    return [NgClass, NgIf, NgTemplateOutlet, NgStyle, CheckIcon, TimesIcon];
  },
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TriStateCheckbox, [{
    type: Component,
    args: [{
      selector: "p-triStateCheckbox",
      template: `
        <div [ngStyle]="style" [ngClass]="{ 'p-checkbox p-component': true, 'p-checkbox-disabled': disabled, 'p-checkbox-focused': focused }" [class]="styleClass">
            <div class="p-hidden-accessible">
                <input
                    #input
                    type="text"
                    [attr.id]="inputId"
                    [name]="name"
                    [attr.tabindex]="tabindex"
                    [readonly]="readonly"
                    [disabled]="disabled"
                    (keyup)="onKeyup($event)"
                    (keydown)="onKeydown($event)"
                    (focus)="onFocus()"
                    (blur)="onBlur()"
                    [attr.aria-labelledby]="ariaLabelledBy"
                    inputmode="none"
                />
            </div>
            <div class="p-checkbox-box" (click)="onClick($event, input)" role="checkbox" [attr.aria-checked]="value === true" [ngClass]="{ 'p-highlight': value != null, 'p-disabled': disabled, 'p-focus': focused }">
                <ng-container *ngIf="value === true">
                    <span *ngIf="checkboxTrueIcon" [ngClass]="checkboxTrueIcon" class="p-checkbox-icon"></span>
                    <ng-container *ngIf="!checkboxTrueIcon">
                        <CheckIcon [styleClass]="'p-checkbox-icon'" *ngIf="!checkIconTemplate" />
                        <span *ngIf="checkIconTemplate" class="p-checkbox-icon">
                            <ng-template *ngTemplateOutlet="checkIconTemplate"></ng-template>
                        </span>
                    </ng-container>
                </ng-container>
                <ng-container *ngIf="value === false">
                    <span *ngIf="checkboxFalseIcon" [ngClass]="checkboxFalseIcon" class="p-checkbox-icon"></span>
                    <ng-container *ngIf="!checkboxFalseIcon">
                        <TimesIcon [styleClass]="'p-checkbox-icon'" *ngIf="!uncheckIconTemplate" />
                        <span class="p-checkbox-icon" *ngIf="uncheckIconTemplate">
                            <ng-template *ngTemplateOutlet="uncheckIconTemplate"></ng-template>
                        </span>
                    </ng-container>
                </ng-container>
            </div>
        </div>
        <label class="p-checkbox-label" (click)="onClick($event, input)" [ngClass]="{ 'p-checkbox-label-active': value != null, 'p-disabled': disabled, 'p-checkbox-label-focus': focused }" *ngIf="label" [attr.for]="inputId">{{ label }}</label>
    `,
      providers: [TRISTATECHECKBOX_VALUE_ACCESSOR],
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: ChangeDetectorRef
    }];
  }, {
    disabled: [{
      type: Input
    }],
    name: [{
      type: Input
    }],
    ariaLabelledBy: [{
      type: Input
    }],
    tabindex: [{
      type: Input
    }],
    inputId: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    label: [{
      type: Input
    }],
    readonly: [{
      type: Input
    }],
    checkboxTrueIcon: [{
      type: Input
    }],
    checkboxFalseIcon: [{
      type: Input
    }],
    onChange: [{
      type: Output
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var _TriStateCheckboxModule = class {
};
var TriStateCheckboxModule = _TriStateCheckboxModule;
__publicField(TriStateCheckboxModule, "ɵfac", function TriStateCheckboxModule_Factory(t) {
  return new (t || _TriStateCheckboxModule)();
});
__publicField(TriStateCheckboxModule, "ɵmod", ɵɵdefineNgModule({
  type: _TriStateCheckboxModule,
  declarations: [TriStateCheckbox],
  imports: [CommonModule, SharedModule, CheckIcon, TimesIcon],
  exports: [TriStateCheckbox, SharedModule]
}));
__publicField(TriStateCheckboxModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, SharedModule, CheckIcon, TimesIcon, SharedModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TriStateCheckboxModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, SharedModule, CheckIcon, TimesIcon],
      exports: [TriStateCheckbox, SharedModule],
      declarations: [TriStateCheckbox]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-arrowdown.mjs
var _ArrowDownIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var ArrowDownIcon = _ArrowDownIcon;
__publicField(ArrowDownIcon, "ɵfac", function() {
  let ɵArrowDownIcon_BaseFactory;
  return function ArrowDownIcon_Factory(t) {
    return (ɵArrowDownIcon_BaseFactory || (ɵArrowDownIcon_BaseFactory = ɵɵgetInheritedFactory(_ArrowDownIcon)))(t || _ArrowDownIcon);
  };
}());
__publicField(ArrowDownIcon, "ɵcmp", ɵɵdefineComponent({
  type: _ArrowDownIcon,
  selectors: [["ArrowDownIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 6,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.99994 14C6.91097 14.0004 6.82281 13.983 6.74064 13.9489C6.65843 13.9148 6.58387 13.8646 6.52133 13.8013L1.10198 8.38193C0.982318 8.25351 0.917175 8.08367 0.920272 7.90817C0.923368 7.73267 0.994462 7.56523 1.11858 7.44111C1.24269 7.317 1.41014 7.2459 1.58563 7.2428C1.76113 7.23971 1.93098 7.30485 2.0594 7.42451L6.32263 11.6877V0.677419C6.32263 0.497756 6.394 0.325452 6.52104 0.198411C6.64808 0.0713706 6.82039 0 7.00005 0C7.17971 0 7.35202 0.0713706 7.47906 0.198411C7.6061 0.325452 7.67747 0.497756 7.67747 0.677419V11.6877L11.9407 7.42451C12.0691 7.30485 12.2389 7.23971 12.4144 7.2428C12.5899 7.2459 12.7574 7.317 12.8815 7.44111C13.0056 7.56523 13.0767 7.73267 13.0798 7.90817C13.0829 8.08367 13.0178 8.25351 12.8981 8.38193L7.47875 13.8013C7.41621 13.8646 7.34164 13.9148 7.25944 13.9489C7.17727 13.983 7.08912 14.0004 7.00015 14C7.00012 14 7.00009 14 7.00005 14C7.00001 14 6.99998 14 6.99994 14Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function ArrowDownIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1);
      ɵɵelementEnd();
      ɵɵelementStart(3, "defs")(4, "clipPath", 2);
      ɵɵelement(5, "rect", 3);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(3);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ArrowDownIcon, [{
    type: Component,
    args: [{
      selector: "ArrowDownIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M6.99994 14C6.91097 14.0004 6.82281 13.983 6.74064 13.9489C6.65843 13.9148 6.58387 13.8646 6.52133 13.8013L1.10198 8.38193C0.982318 8.25351 0.917175 8.08367 0.920272 7.90817C0.923368 7.73267 0.994462 7.56523 1.11858 7.44111C1.24269 7.317 1.41014 7.2459 1.58563 7.2428C1.76113 7.23971 1.93098 7.30485 2.0594 7.42451L6.32263 11.6877V0.677419C6.32263 0.497756 6.394 0.325452 6.52104 0.198411C6.64808 0.0713706 6.82039 0 7.00005 0C7.17971 0 7.35202 0.0713706 7.47906 0.198411C7.6061 0.325452 7.67747 0.497756 7.67747 0.677419V11.6877L11.9407 7.42451C12.0691 7.30485 12.2389 7.23971 12.4144 7.2428C12.5899 7.2459 12.7574 7.317 12.8815 7.44111C13.0056 7.56523 13.0767 7.73267 13.0798 7.90817C13.0829 8.08367 13.0178 8.25351 12.8981 8.38193L7.47875 13.8013C7.41621 13.8646 7.34164 13.9148 7.25944 13.9489C7.17727 13.983 7.08912 14.0004 7.00015 14C7.00012 14 7.00009 14 7.00005 14C7.00001 14 6.99998 14 6.99994 14Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-arrowup.mjs
var _ArrowUpIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var ArrowUpIcon = _ArrowUpIcon;
__publicField(ArrowUpIcon, "ɵfac", function() {
  let ɵArrowUpIcon_BaseFactory;
  return function ArrowUpIcon_Factory(t) {
    return (ɵArrowUpIcon_BaseFactory || (ɵArrowUpIcon_BaseFactory = ɵɵgetInheritedFactory(_ArrowUpIcon)))(t || _ArrowUpIcon);
  };
}());
__publicField(ArrowUpIcon, "ɵcmp", ɵɵdefineComponent({
  type: _ArrowUpIcon,
  selectors: [["ArrowUpIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 6,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.51551 13.799C6.64205 13.9255 6.813 13.9977 6.99193 14C7.17087 13.9977 7.34182 13.9255 7.46835 13.799C7.59489 13.6725 7.66701 13.5015 7.66935 13.3226V2.31233L11.9326 6.57554C11.9951 6.63887 12.0697 6.68907 12.1519 6.72319C12.2341 6.75731 12.3223 6.77467 12.4113 6.77425C12.5003 6.77467 12.5885 6.75731 12.6707 6.72319C12.7529 6.68907 12.8274 6.63887 12.89 6.57554C13.0168 6.44853 13.0881 6.27635 13.0881 6.09683C13.0881 5.91732 13.0168 5.74514 12.89 5.61812L7.48846 0.216594C7.48274 0.210436 7.4769 0.204374 7.47094 0.198411C7.3439 0.0713707 7.1716 0 6.99193 0C6.81227 0 6.63997 0.0713707 6.51293 0.198411C6.50704 0.204296 6.50128 0.210278 6.49563 0.216354L1.09386 5.61812C0.974201 5.74654 0.909057 5.91639 0.912154 6.09189C0.91525 6.26738 0.986345 6.43483 1.11046 6.55894C1.23457 6.68306 1.40202 6.75415 1.57752 6.75725C1.75302 6.76035 1.92286 6.6952 2.05128 6.57554L6.31451 2.31231V13.3226C6.31685 13.5015 6.38898 13.6725 6.51551 13.799Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function ArrowUpIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1);
      ɵɵelementEnd();
      ɵɵelementStart(3, "defs")(4, "clipPath", 2);
      ɵɵelement(5, "rect", 3);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(3);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ArrowUpIcon, [{
    type: Component,
    args: [{
      selector: "ArrowUpIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M6.51551 13.799C6.64205 13.9255 6.813 13.9977 6.99193 14C7.17087 13.9977 7.34182 13.9255 7.46835 13.799C7.59489 13.6725 7.66701 13.5015 7.66935 13.3226V2.31233L11.9326 6.57554C11.9951 6.63887 12.0697 6.68907 12.1519 6.72319C12.2341 6.75731 12.3223 6.77467 12.4113 6.77425C12.5003 6.77467 12.5885 6.75731 12.6707 6.72319C12.7529 6.68907 12.8274 6.63887 12.89 6.57554C13.0168 6.44853 13.0881 6.27635 13.0881 6.09683C13.0881 5.91732 13.0168 5.74514 12.89 5.61812L7.48846 0.216594C7.48274 0.210436 7.4769 0.204374 7.47094 0.198411C7.3439 0.0713707 7.1716 0 6.99193 0C6.81227 0 6.63997 0.0713707 6.51293 0.198411C6.50704 0.204296 6.50128 0.210278 6.49563 0.216354L1.09386 5.61812C0.974201 5.74654 0.909057 5.91639 0.912154 6.09189C0.91525 6.26738 0.986345 6.43483 1.11046 6.55894C1.23457 6.68306 1.40202 6.75415 1.57752 6.75725C1.75302 6.76035 1.92286 6.6952 2.05128 6.57554L6.31451 2.31231V13.3226C6.31685 13.5015 6.38898 13.6725 6.51551 13.799Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-filter.mjs
var _FilterIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var FilterIcon = _FilterIcon;
__publicField(FilterIcon, "ɵfac", function() {
  let ɵFilterIcon_BaseFactory;
  return function FilterIcon_Factory(t) {
    return (ɵFilterIcon_BaseFactory || (ɵFilterIcon_BaseFactory = ɵɵgetInheritedFactory(_FilterIcon)))(t || _FilterIcon);
  };
}());
__publicField(FilterIcon, "ɵcmp", ɵɵdefineComponent({
  type: _FilterIcon,
  selectors: [["FilterIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 6,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M8.64708 14H5.35296C5.18981 13.9979 5.03395 13.9321 4.91858 13.8167C4.8032 13.7014 4.73745 13.5455 4.73531 13.3824V7L0.329431 0.98C0.259794 0.889466 0.217389 0.780968 0.20718 0.667208C0.19697 0.553448 0.219379 0.439133 0.271783 0.337647C0.324282 0.236453 0.403423 0.151519 0.500663 0.0920138C0.597903 0.0325088 0.709548 0.000692754 0.823548 0H13.1765C13.2905 0.000692754 13.4021 0.0325088 13.4994 0.0920138C13.5966 0.151519 13.6758 0.236453 13.7283 0.337647C13.7807 0.439133 13.8031 0.553448 13.7929 0.667208C13.7826 0.780968 13.7402 0.889466 13.6706 0.98L9.26472 7V13.3824C9.26259 13.5455 9.19683 13.7014 9.08146 13.8167C8.96609 13.9321 8.81022 13.9979 8.64708 14ZM5.97061 12.7647H8.02943V6.79412C8.02878 6.66289 8.07229 6.53527 8.15296 6.43177L11.9412 1.23529H2.05884L5.86355 6.43177C5.94422 6.53527 5.98773 6.66289 5.98708 6.79412L5.97061 12.7647Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function FilterIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1);
      ɵɵelementEnd();
      ɵɵelementStart(3, "defs")(4, "clipPath", 2);
      ɵɵelement(5, "rect", 3);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(3);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FilterIcon, [{
    type: Component,
    args: [{
      selector: "FilterIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    d="M8.64708 14H5.35296C5.18981 13.9979 5.03395 13.9321 4.91858 13.8167C4.8032 13.7014 4.73745 13.5455 4.73531 13.3824V7L0.329431 0.98C0.259794 0.889466 0.217389 0.780968 0.20718 0.667208C0.19697 0.553448 0.219379 0.439133 0.271783 0.337647C0.324282 0.236453 0.403423 0.151519 0.500663 0.0920138C0.597903 0.0325088 0.709548 0.000692754 0.823548 0H13.1765C13.2905 0.000692754 13.4021 0.0325088 13.4994 0.0920138C13.5966 0.151519 13.6758 0.236453 13.7283 0.337647C13.7807 0.439133 13.8031 0.553448 13.7929 0.667208C13.7826 0.780968 13.7402 0.889466 13.6706 0.98L9.26472 7V13.3824C9.26259 13.5455 9.19683 13.7014 9.08146 13.8167C8.96609 13.9321 8.81022 13.9979 8.64708 14ZM5.97061 12.7647H8.02943V6.79412C8.02878 6.66289 8.07229 6.53527 8.15296 6.43177L11.9412 1.23529H2.05884L5.86355 6.43177C5.94422 6.53527 5.98773 6.66289 5.98708 6.79412L5.97061 12.7647Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-sortalt.mjs
var _SortAltIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var SortAltIcon = _SortAltIcon;
__publicField(SortAltIcon, "ɵfac", function() {
  let ɵSortAltIcon_BaseFactory;
  return function SortAltIcon_Factory(t) {
    return (ɵSortAltIcon_BaseFactory || (ɵSortAltIcon_BaseFactory = ɵɵgetInheritedFactory(_SortAltIcon)))(t || _SortAltIcon);
  };
}());
__publicField(SortAltIcon, "ɵcmp", ɵɵdefineComponent({
  type: _SortAltIcon,
  selectors: [["SortAltIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 9,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M5.64515 3.61291C5.47353 3.61291 5.30192 3.54968 5.16644 3.4142L3.38708 1.63484L1.60773 3.4142C1.34579 3.67613 0.912244 3.67613 0.650309 3.4142C0.388374 3.15226 0.388374 2.71871 0.650309 2.45678L2.90837 0.198712C3.17031 -0.0632236 3.60386 -0.0632236 3.86579 0.198712L6.12386 2.45678C6.38579 2.71871 6.38579 3.15226 6.12386 3.4142C5.98837 3.54968 5.81676 3.61291 5.64515 3.61291Z", "fill", "currentColor"], ["d", "M3.38714 14C3.01681 14 2.70972 13.6929 2.70972 13.3226V0.677419C2.70972 0.307097 3.01681 0 3.38714 0C3.75746 0 4.06456 0.307097 4.06456 0.677419V13.3226C4.06456 13.6929 3.75746 14 3.38714 14Z", "fill", "currentColor"], ["d", "M10.6129 14C10.4413 14 10.2697 13.9368 10.1342 13.8013L7.87611 11.5432C7.61418 11.2813 7.61418 10.8477 7.87611 10.5858C8.13805 10.3239 8.5716 10.3239 8.83353 10.5858L10.6129 12.3652L12.3922 10.5858C12.6542 10.3239 13.0877 10.3239 13.3497 10.5858C13.6116 10.8477 13.6116 11.2813 13.3497 11.5432L11.0916 13.8013C10.9561 13.9368 10.7845 14 10.6129 14Z", "fill", "currentColor"], ["d", "M10.6129 14C10.2426 14 9.93552 13.6929 9.93552 13.3226V0.677419C9.93552 0.307097 10.2426 0 10.6129 0C10.9833 0 11.2904 0.307097 11.2904 0.677419V13.3226C11.2904 13.6929 10.9832 14 10.6129 14Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function SortAltIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1)(3, "path", 2)(4, "path", 3)(5, "path", 4);
      ɵɵelementEnd();
      ɵɵelementStart(6, "defs")(7, "clipPath", 5);
      ɵɵelement(8, "rect", 6);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(6);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SortAltIcon, [{
    type: Component,
    args: [{
      selector: "SortAltIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    d="M5.64515 3.61291C5.47353 3.61291 5.30192 3.54968 5.16644 3.4142L3.38708 1.63484L1.60773 3.4142C1.34579 3.67613 0.912244 3.67613 0.650309 3.4142C0.388374 3.15226 0.388374 2.71871 0.650309 2.45678L2.90837 0.198712C3.17031 -0.0632236 3.60386 -0.0632236 3.86579 0.198712L6.12386 2.45678C6.38579 2.71871 6.38579 3.15226 6.12386 3.4142C5.98837 3.54968 5.81676 3.61291 5.64515 3.61291Z"
                    fill="currentColor"
                />
                <path d="M3.38714 14C3.01681 14 2.70972 13.6929 2.70972 13.3226V0.677419C2.70972 0.307097 3.01681 0 3.38714 0C3.75746 0 4.06456 0.307097 4.06456 0.677419V13.3226C4.06456 13.6929 3.75746 14 3.38714 14Z" fill="currentColor" />
                <path
                    d="M10.6129 14C10.4413 14 10.2697 13.9368 10.1342 13.8013L7.87611 11.5432C7.61418 11.2813 7.61418 10.8477 7.87611 10.5858C8.13805 10.3239 8.5716 10.3239 8.83353 10.5858L10.6129 12.3652L12.3922 10.5858C12.6542 10.3239 13.0877 10.3239 13.3497 10.5858C13.6116 10.8477 13.6116 11.2813 13.3497 11.5432L11.0916 13.8013C10.9561 13.9368 10.7845 14 10.6129 14Z"
                    fill="currentColor"
                />
                <path d="M10.6129 14C10.2426 14 9.93552 13.6929 9.93552 13.3226V0.677419C9.93552 0.307097 10.2426 0 10.6129 0C10.9833 0 11.2904 0.307097 11.2904 0.677419V13.3226C11.2904 13.6929 10.9832 14 10.6129 14Z" fill="currentColor" />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-sortamountdown.mjs
var _SortAmountDownIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var SortAmountDownIcon = _SortAmountDownIcon;
__publicField(SortAmountDownIcon, "ɵfac", function() {
  let ɵSortAmountDownIcon_BaseFactory;
  return function SortAmountDownIcon_Factory(t) {
    return (ɵSortAmountDownIcon_BaseFactory || (ɵSortAmountDownIcon_BaseFactory = ɵɵgetInheritedFactory(_SortAmountDownIcon)))(t || _SortAmountDownIcon);
  };
}());
__publicField(SortAmountDownIcon, "ɵcmp", ɵɵdefineComponent({
  type: _SortAmountDownIcon,
  selectors: [["SortAmountDownIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 11,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M2.59836 13.2009C2.44634 13.2009 2.29432 13.1449 2.1743 13.0248L0.174024 11.0246C-0.0580081 10.7925 -0.0580081 10.4085 0.174024 10.1764C0.406057 9.94441 0.79011 9.94441 1.02214 10.1764L2.59836 11.7527L4.17458 10.1764C4.40662 9.94441 4.79067 9.94441 5.0227 10.1764C5.25473 10.4085 5.25473 10.7925 5.0227 11.0246L3.02242 13.0248C2.90241 13.1449 2.75038 13.2009 2.59836 13.2009Z", "fill", "currentColor"], ["d", "M2.59836 13.2009C2.27032 13.2009 1.99833 12.9288 1.99833 12.6008V1.39922C1.99833 1.07117 2.27036 0.799133 2.59841 0.799133C2.92646 0.799133 3.19849 1.07117 3.19849 1.39922V12.6008C3.19849 12.9288 2.92641 13.2009 2.59836 13.2009Z", "fill", "currentColor"], ["d", "M13.3999 11.2006H6.99902C6.67098 11.2006 6.39894 10.9285 6.39894 10.6005C6.39894 10.2725 6.67098 10.0004 6.99902 10.0004H13.3999C13.728 10.0004 14 10.2725 14 10.6005C14 10.9285 13.728 11.2006 13.3999 11.2006Z", "fill", "currentColor"], ["d", "M10.1995 6.39991H6.99902C6.67098 6.39991 6.39894 6.12788 6.39894 5.79983C6.39894 5.47179 6.67098 5.19975 6.99902 5.19975H10.1995C10.5275 5.19975 10.7996 5.47179 10.7996 5.79983C10.7996 6.12788 10.5275 6.39991 10.1995 6.39991Z", "fill", "currentColor"], ["d", "M8.59925 3.99958H6.99902C6.67098 3.99958 6.39894 3.72754 6.39894 3.3995C6.39894 3.07145 6.67098 2.79941 6.99902 2.79941H8.59925C8.92729 2.79941 9.19933 3.07145 9.19933 3.3995C9.19933 3.72754 8.92729 3.99958 8.59925 3.99958Z", "fill", "currentColor"], ["d", "M11.7997 8.80025H6.99902C6.67098 8.80025 6.39894 8.52821 6.39894 8.20017C6.39894 7.87212 6.67098 7.60008 6.99902 7.60008H11.7997C12.1277 7.60008 12.3998 7.87212 12.3998 8.20017C12.3998 8.52821 12.1277 8.80025 11.7997 8.80025Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function SortAmountDownIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1)(3, "path", 2)(4, "path", 3)(5, "path", 4)(6, "path", 5)(7, "path", 6);
      ɵɵelementEnd();
      ɵɵelementStart(8, "defs")(9, "clipPath", 7);
      ɵɵelement(10, "rect", 8);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(8);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SortAmountDownIcon, [{
    type: Component,
    args: [{
      selector: "SortAmountDownIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    d="M2.59836 13.2009C2.44634 13.2009 2.29432 13.1449 2.1743 13.0248L0.174024 11.0246C-0.0580081 10.7925 -0.0580081 10.4085 0.174024 10.1764C0.406057 9.94441 0.79011 9.94441 1.02214 10.1764L2.59836 11.7527L4.17458 10.1764C4.40662 9.94441 4.79067 9.94441 5.0227 10.1764C5.25473 10.4085 5.25473 10.7925 5.0227 11.0246L3.02242 13.0248C2.90241 13.1449 2.75038 13.2009 2.59836 13.2009Z"
                    fill="currentColor"
                />
                <path
                    d="M2.59836 13.2009C2.27032 13.2009 1.99833 12.9288 1.99833 12.6008V1.39922C1.99833 1.07117 2.27036 0.799133 2.59841 0.799133C2.92646 0.799133 3.19849 1.07117 3.19849 1.39922V12.6008C3.19849 12.9288 2.92641 13.2009 2.59836 13.2009Z"
                    fill="currentColor"
                />
                <path
                    d="M13.3999 11.2006H6.99902C6.67098 11.2006 6.39894 10.9285 6.39894 10.6005C6.39894 10.2725 6.67098 10.0004 6.99902 10.0004H13.3999C13.728 10.0004 14 10.2725 14 10.6005C14 10.9285 13.728 11.2006 13.3999 11.2006Z"
                    fill="currentColor"
                />
                <path
                    d="M10.1995 6.39991H6.99902C6.67098 6.39991 6.39894 6.12788 6.39894 5.79983C6.39894 5.47179 6.67098 5.19975 6.99902 5.19975H10.1995C10.5275 5.19975 10.7996 5.47179 10.7996 5.79983C10.7996 6.12788 10.5275 6.39991 10.1995 6.39991Z"
                    fill="currentColor"
                />
                <path
                    d="M8.59925 3.99958H6.99902C6.67098 3.99958 6.39894 3.72754 6.39894 3.3995C6.39894 3.07145 6.67098 2.79941 6.99902 2.79941H8.59925C8.92729 2.79941 9.19933 3.07145 9.19933 3.3995C9.19933 3.72754 8.92729 3.99958 8.59925 3.99958Z"
                    fill="currentColor"
                />
                <path
                    d="M11.7997 8.80025H6.99902C6.67098 8.80025 6.39894 8.52821 6.39894 8.20017C6.39894 7.87212 6.67098 7.60008 6.99902 7.60008H11.7997C12.1277 7.60008 12.3998 7.87212 12.3998 8.20017C12.3998 8.52821 12.1277 8.80025 11.7997 8.80025Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-sortamountupalt.mjs
var _SortAmountUpAltIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var SortAmountUpAltIcon = _SortAmountUpAltIcon;
__publicField(SortAmountUpAltIcon, "ɵfac", function() {
  let ɵSortAmountUpAltIcon_BaseFactory;
  return function SortAmountUpAltIcon_Factory(t) {
    return (ɵSortAmountUpAltIcon_BaseFactory || (ɵSortAmountUpAltIcon_BaseFactory = ɵɵgetInheritedFactory(_SortAmountUpAltIcon)))(t || _SortAmountUpAltIcon);
  };
}());
__publicField(SortAmountUpAltIcon, "ɵcmp", ɵɵdefineComponent({
  type: _SortAmountUpAltIcon,
  selectors: [["SortAmountUpAltIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 11,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M4.59864 3.99958C4.44662 3.99958 4.2946 3.94357 4.17458 3.82356L2.59836 2.24734L1.02214 3.82356C0.79011 4.05559 0.406057 4.05559 0.174024 3.82356C-0.0580081 3.59152 -0.0580081 3.20747 0.174024 2.97544L2.1743 0.97516C2.40634 0.743127 2.79039 0.743127 3.02242 0.97516L5.0227 2.97544C5.25473 3.20747 5.25473 3.59152 5.0227 3.82356C4.90268 3.94357 4.75066 3.99958 4.59864 3.99958Z", "fill", "currentColor"], ["d", "M2.59841 13.2009C2.27036 13.2009 1.99833 12.9288 1.99833 12.6008V1.39922C1.99833 1.07117 2.27036 0.799133 2.59841 0.799133C2.92646 0.799133 3.19849 1.07117 3.19849 1.39922V12.6008C3.19849 12.9288 2.92646 13.2009 2.59841 13.2009Z", "fill", "currentColor"], ["d", "M13.3999 11.2006H6.99902C6.67098 11.2006 6.39894 10.9285 6.39894 10.6005C6.39894 10.2725 6.67098 10.0004 6.99902 10.0004H13.3999C13.728 10.0004 14 10.2725 14 10.6005C14 10.9285 13.728 11.2006 13.3999 11.2006Z", "fill", "currentColor"], ["d", "M10.1995 6.39991H6.99902C6.67098 6.39991 6.39894 6.12788 6.39894 5.79983C6.39894 5.47179 6.67098 5.19975 6.99902 5.19975H10.1995C10.5275 5.19975 10.7996 5.47179 10.7996 5.79983C10.7996 6.12788 10.5275 6.39991 10.1995 6.39991Z", "fill", "currentColor"], ["d", "M8.59925 3.99958H6.99902C6.67098 3.99958 6.39894 3.72754 6.39894 3.3995C6.39894 3.07145 6.67098 2.79941 6.99902 2.79941H8.59925C8.92729 2.79941 9.19933 3.07145 9.19933 3.3995C9.19933 3.72754 8.92729 3.99958 8.59925 3.99958Z", "fill", "currentColor"], ["d", "M11.7997 8.80025H6.99902C6.67098 8.80025 6.39894 8.52821 6.39894 8.20017C6.39894 7.87212 6.67098 7.60008 6.99902 7.60008H11.7997C12.1277 7.60008 12.3998 7.87212 12.3998 8.20017C12.3998 8.52821 12.1277 8.80025 11.7997 8.80025Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function SortAmountUpAltIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1)(3, "path", 2)(4, "path", 3)(5, "path", 4)(6, "path", 5)(7, "path", 6);
      ɵɵelementEnd();
      ɵɵelementStart(8, "defs")(9, "clipPath", 7);
      ɵɵelement(10, "rect", 8);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(8);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SortAmountUpAltIcon, [{
    type: Component,
    args: [{
      selector: "SortAmountUpAltIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    d="M4.59864 3.99958C4.44662 3.99958 4.2946 3.94357 4.17458 3.82356L2.59836 2.24734L1.02214 3.82356C0.79011 4.05559 0.406057 4.05559 0.174024 3.82356C-0.0580081 3.59152 -0.0580081 3.20747 0.174024 2.97544L2.1743 0.97516C2.40634 0.743127 2.79039 0.743127 3.02242 0.97516L5.0227 2.97544C5.25473 3.20747 5.25473 3.59152 5.0227 3.82356C4.90268 3.94357 4.75066 3.99958 4.59864 3.99958Z"
                    fill="currentColor"
                />
                <path
                    d="M2.59841 13.2009C2.27036 13.2009 1.99833 12.9288 1.99833 12.6008V1.39922C1.99833 1.07117 2.27036 0.799133 2.59841 0.799133C2.92646 0.799133 3.19849 1.07117 3.19849 1.39922V12.6008C3.19849 12.9288 2.92646 13.2009 2.59841 13.2009Z"
                    fill="currentColor"
                />
                <path
                    d="M13.3999 11.2006H6.99902C6.67098 11.2006 6.39894 10.9285 6.39894 10.6005C6.39894 10.2725 6.67098 10.0004 6.99902 10.0004H13.3999C13.728 10.0004 14 10.2725 14 10.6005C14 10.9285 13.728 11.2006 13.3999 11.2006Z"
                    fill="currentColor"
                />
                <path
                    d="M10.1995 6.39991H6.99902C6.67098 6.39991 6.39894 6.12788 6.39894 5.79983C6.39894 5.47179 6.67098 5.19975 6.99902 5.19975H10.1995C10.5275 5.19975 10.7996 5.47179 10.7996 5.79983C10.7996 6.12788 10.5275 6.39991 10.1995 6.39991Z"
                    fill="currentColor"
                />
                <path
                    d="M8.59925 3.99958H6.99902C6.67098 3.99958 6.39894 3.72754 6.39894 3.3995C6.39894 3.07145 6.67098 2.79941 6.99902 2.79941H8.59925C8.92729 2.79941 9.19933 3.07145 9.19933 3.3995C9.19933 3.72754 8.92729 3.99958 8.59925 3.99958Z"
                    fill="currentColor"
                />
                <path
                    d="M11.7997 8.80025H6.99902C6.67098 8.80025 6.39894 8.52821 6.39894 8.20017C6.39894 7.87212 6.67098 7.60008 6.99902 7.60008H11.7997C12.1277 7.60008 12.3998 7.87212 12.3998 8.20017C12.3998 8.52821 12.1277 8.80025 11.7997 8.80025Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-filterslash.mjs
var _FilterSlashIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var FilterSlashIcon = _FilterSlashIcon;
__publicField(FilterSlashIcon, "ɵfac", function() {
  let ɵFilterSlashIcon_BaseFactory;
  return function FilterSlashIcon_Factory(t) {
    return (ɵFilterSlashIcon_BaseFactory || (ɵFilterSlashIcon_BaseFactory = ɵɵgetInheritedFactory(_FilterSlashIcon)))(t || _FilterSlashIcon);
  };
}());
__publicField(FilterSlashIcon, "ɵcmp", ɵɵdefineComponent({
  type: _FilterSlashIcon,
  selectors: [["FilterSlashIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 6,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M13.4994 0.0920138C13.5967 0.151519 13.6758 0.236453 13.7283 0.337647C13.7807 0.439133 13.8031 0.553448 13.7929 0.667208C13.7827 0.780968 13.7403 0.889466 13.6707 0.98L11.406 4.06823C11.3099 4.19928 11.1656 4.28679 11.005 4.3115C10.8444 4.33621 10.6805 4.2961 10.5495 4.2C10.4184 4.1039 10.3309 3.95967 10.3062 3.79905C10.2815 3.63843 10.3216 3.47458 10.4177 3.34353L11.9412 1.23529H7.41184C7.24803 1.23529 7.09093 1.17022 6.97509 1.05439C6.85926 0.938558 6.79419 0.781457 6.79419 0.617647C6.79419 0.453837 6.85926 0.296736 6.97509 0.180905C7.09093 0.0650733 7.24803 0 7.41184 0H13.1765C13.2905 0.000692754 13.4022 0.0325088 13.4994 0.0920138ZM4.20008 0.181168H4.24126L13.2013 9.03411C13.3169 9.14992 13.3819 9.3069 13.3819 9.47058C13.3819 9.63426 13.3169 9.79124 13.2013 9.90705C13.1445 9.96517 13.0766 10.0112 13.0016 10.0423C12.9266 10.0735 12.846 10.0891 12.7648 10.0882C12.6836 10.0886 12.6032 10.0728 12.5283 10.0417C12.4533 10.0106 12.3853 9.96479 12.3283 9.90705L9.3142 6.92587L9.26479 6.99999V13.3823C9.26265 13.5455 9.19689 13.7014 9.08152 13.8167C8.96615 13.9321 8.81029 13.9979 8.64714 14H5.35302C5.18987 13.9979 5.03401 13.9321 4.91864 13.8167C4.80327 13.7014 4.73751 13.5455 4.73537 13.3823V6.99999L0.329492 1.02117C0.259855 0.930634 0.21745 0.822137 0.207241 0.708376C0.197031 0.594616 0.21944 0.480301 0.271844 0.378815C0.324343 0.277621 0.403484 0.192687 0.500724 0.133182C0.597964 0.073677 0.709609 0.041861 0.823609 0.0411682H3.86243C3.92448 0.0461551 3.9855 0.060022 4.04361 0.0823446C4.10037 0.10735 4.15311 0.140655 4.20008 0.181168ZM8.02949 6.79411C8.02884 6.66289 8.07235 6.53526 8.15302 6.43176L8.42478 6.05293L3.55773 1.23529H2.0589L5.84714 6.43176C5.92781 6.53526 5.97132 6.66289 5.97067 6.79411V12.7647H8.02949V6.79411Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function FilterSlashIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1);
      ɵɵelementEnd();
      ɵɵelementStart(3, "defs")(4, "clipPath", 2);
      ɵɵelement(5, "rect", 3);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(3);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FilterSlashIcon, [{
    type: Component,
    args: [{
      selector: "FilterSlashIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M13.4994 0.0920138C13.5967 0.151519 13.6758 0.236453 13.7283 0.337647C13.7807 0.439133 13.8031 0.553448 13.7929 0.667208C13.7827 0.780968 13.7403 0.889466 13.6707 0.98L11.406 4.06823C11.3099 4.19928 11.1656 4.28679 11.005 4.3115C10.8444 4.33621 10.6805 4.2961 10.5495 4.2C10.4184 4.1039 10.3309 3.95967 10.3062 3.79905C10.2815 3.63843 10.3216 3.47458 10.4177 3.34353L11.9412 1.23529H7.41184C7.24803 1.23529 7.09093 1.17022 6.97509 1.05439C6.85926 0.938558 6.79419 0.781457 6.79419 0.617647C6.79419 0.453837 6.85926 0.296736 6.97509 0.180905C7.09093 0.0650733 7.24803 0 7.41184 0H13.1765C13.2905 0.000692754 13.4022 0.0325088 13.4994 0.0920138ZM4.20008 0.181168H4.24126L13.2013 9.03411C13.3169 9.14992 13.3819 9.3069 13.3819 9.47058C13.3819 9.63426 13.3169 9.79124 13.2013 9.90705C13.1445 9.96517 13.0766 10.0112 13.0016 10.0423C12.9266 10.0735 12.846 10.0891 12.7648 10.0882C12.6836 10.0886 12.6032 10.0728 12.5283 10.0417C12.4533 10.0106 12.3853 9.96479 12.3283 9.90705L9.3142 6.92587L9.26479 6.99999V13.3823C9.26265 13.5455 9.19689 13.7014 9.08152 13.8167C8.96615 13.9321 8.81029 13.9979 8.64714 14H5.35302C5.18987 13.9979 5.03401 13.9321 4.91864 13.8167C4.80327 13.7014 4.73751 13.5455 4.73537 13.3823V6.99999L0.329492 1.02117C0.259855 0.930634 0.21745 0.822137 0.207241 0.708376C0.197031 0.594616 0.21944 0.480301 0.271844 0.378815C0.324343 0.277621 0.403484 0.192687 0.500724 0.133182C0.597964 0.073677 0.709609 0.041861 0.823609 0.0411682H3.86243C3.92448 0.0461551 3.9855 0.060022 4.04361 0.0823446C4.10037 0.10735 4.15311 0.140655 4.20008 0.181168ZM8.02949 6.79411C8.02884 6.66289 8.07235 6.53526 8.15302 6.43176L8.42478 6.05293L3.55773 1.23529H2.0589L5.84714 6.43176C5.92781 6.53526 5.97132 6.66289 5.97067 6.79411V12.7647H8.02949V6.79411Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-table.mjs
var _c08 = ["container"];
var _c111 = ["resizeHelper"];
var _c27 = ["reorderIndicatorUp"];
var _c35 = ["reorderIndicatorDown"];
var _c45 = ["wrapper"];
var _c55 = ["table"];
var _c65 = ["thead"];
var _c75 = ["tfoot"];
var _c84 = ["scroller"];
function Table_div_2_i_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "i");
  }
  if (rf & 2) {
    const ctx_r14 = ɵɵnextContext(2);
    ɵɵclassMap("p-datatable-loading-icon " + ctx_r14.loadingIcon);
  }
}
function Table_div_2_ng_container_2_SpinnerIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "SpinnerIcon", 19);
  }
  if (rf & 2) {
    ɵɵproperty("spin", true)("styleClass", "p-datatable-loading-icon");
  }
}
function Table_div_2_ng_container_2_span_2_1_ng_template_0_Template(rf, ctx) {
}
function Table_div_2_ng_container_2_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_div_2_ng_container_2_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Table_div_2_ng_container_2_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 20);
    ɵɵtemplate(1, Table_div_2_ng_container_2_span_2_1_Template, 1, 0, null, 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r17 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r17.loadingIconTemplate);
  }
}
function Table_div_2_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Table_div_2_ng_container_2_SpinnerIcon_1_Template, 1, 2, "SpinnerIcon", 17);
    ɵɵtemplate(2, Table_div_2_ng_container_2_span_2_Template, 2, 1, "span", 18);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r15 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r15.loadingIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r15.loadingIconTemplate);
  }
}
function Table_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 15);
    ɵɵtemplate(1, Table_div_2_i_1_Template, 1, 2, "i", 16);
    ɵɵtemplate(2, Table_div_2_ng_container_2_Template, 3, 2, "ng-container", 8);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r1.loadingIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r1.loadingIcon);
  }
}
function Table_div_3_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_div_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22);
    ɵɵtemplate(1, Table_div_3_ng_container_1_Template, 1, 0, "ng-container", 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r2.captionTemplate);
  }
}
function Table_p_paginator_4_1_ng_template_0_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_p_paginator_4_1_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_4_1_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 21);
  }
  if (rf & 2) {
    const ctx_r25 = ɵɵnextContext(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r25.paginatorFirstPageLinkIconTemplate);
  }
}
function Table_p_paginator_4_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_4_1_ng_template_0_Template, 1, 1, "ng-template", 24);
  }
}
function Table_p_paginator_4_2_ng_template_0_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_p_paginator_4_2_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_4_2_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 21);
  }
  if (rf & 2) {
    const ctx_r27 = ɵɵnextContext(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r27.paginatorPreviousPageLinkIconTemplate);
  }
}
function Table_p_paginator_4_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_4_2_ng_template_0_Template, 1, 1, "ng-template", 25);
  }
}
function Table_p_paginator_4_3_ng_template_0_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_p_paginator_4_3_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_4_3_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 21);
  }
  if (rf & 2) {
    const ctx_r29 = ɵɵnextContext(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r29.paginatorLastPageLinkIconTemplate);
  }
}
function Table_p_paginator_4_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_4_3_ng_template_0_Template, 1, 1, "ng-template", 26);
  }
}
function Table_p_paginator_4_4_ng_template_0_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_p_paginator_4_4_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_4_4_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 21);
  }
  if (rf & 2) {
    const ctx_r31 = ɵɵnextContext(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r31.paginatorNextPageLinkIconTemplate);
  }
}
function Table_p_paginator_4_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_4_4_ng_template_0_Template, 1, 1, "ng-template", 27);
  }
}
function Table_p_paginator_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r34 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-paginator", 23);
    ɵɵlistener("onPageChange", function Table_p_paginator_4_Template_p_paginator_onPageChange_0_listener($event) {
      ɵɵrestoreView(_r34);
      const ctx_r33 = ɵɵnextContext();
      return ɵɵresetView(ctx_r33.onPageChange($event));
    });
    ɵɵtemplate(1, Table_p_paginator_4_1_Template, 1, 0, null, 8);
    ɵɵtemplate(2, Table_p_paginator_4_2_Template, 1, 0, null, 8);
    ɵɵtemplate(3, Table_p_paginator_4_3_Template, 1, 0, null, 8);
    ɵɵtemplate(4, Table_p_paginator_4_4_Template, 1, 0, null, 8);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    ɵɵproperty("rows", ctx_r3.rows)("first", ctx_r3.first)("totalRecords", ctx_r3.totalRecords)("pageLinkSize", ctx_r3.pageLinks)("alwaysShow", ctx_r3.alwaysShowPaginator)("rowsPerPageOptions", ctx_r3.rowsPerPageOptions)("templateLeft", ctx_r3.paginatorLeftTemplate)("templateRight", ctx_r3.paginatorRightTemplate)("dropdownAppendTo", ctx_r3.paginatorDropdownAppendTo)("dropdownScrollHeight", ctx_r3.paginatorDropdownScrollHeight)("currentPageReportTemplate", ctx_r3.currentPageReportTemplate)("showFirstLastIcon", ctx_r3.showFirstLastIcon)("dropdownItemTemplate", ctx_r3.paginatorDropdownItemTemplate)("showCurrentPageReport", ctx_r3.showCurrentPageReport)("showJumpToPageDropdown", ctx_r3.showJumpToPageDropdown)("showJumpToPageInput", ctx_r3.showJumpToPageInput)("showPageLinks", ctx_r3.showPageLinks);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r3.paginatorFirstPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r3.paginatorPreviousPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r3.paginatorLastPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r3.paginatorNextPageLinkIconTemplate);
  }
}
function Table_p_scroller_7_ng_template_2_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c94 = function(a0, a1) {
  return {
    $implicit: a0,
    options: a1
  };
};
function Table_p_scroller_7_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_scroller_7_ng_template_2_ng_container_0_Template, 1, 0, "ng-container", 31);
  }
  if (rf & 2) {
    const items_r37 = ctx.$implicit;
    const scrollerOptions_r38 = ctx.options;
    ɵɵnextContext(2);
    const _r7 = ɵɵreference(10);
    ɵɵproperty("ngTemplateOutlet", _r7)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c94, items_r37, scrollerOptions_r38));
  }
}
var _c104 = function(a0) {
  return {
    height: a0
  };
};
function Table_p_scroller_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r41 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-scroller", 28, 29);
    ɵɵlistener("onLazyLoad", function Table_p_scroller_7_Template_p_scroller_onLazyLoad_0_listener($event) {
      ɵɵrestoreView(_r41);
      const ctx_r40 = ɵɵnextContext();
      return ɵɵresetView(ctx_r40.onLazyItemLoad($event));
    });
    ɵɵtemplate(2, Table_p_scroller_7_ng_template_2_Template, 1, 5, "ng-template", 30);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r5 = ɵɵnextContext();
    ɵɵstyleMap(ɵɵpureFunction1(15, _c104, ctx_r5.scrollHeight !== "flex" ? ctx_r5.scrollHeight : void 0));
    ɵɵproperty("items", ctx_r5.processedData)("columns", ctx_r5.columns)("scrollHeight", ctx_r5.scrollHeight !== "flex" ? void 0 : "100%")("itemSize", ctx_r5.virtualScrollItemSize || ctx_r5._virtualRowHeight)("step", ctx_r5.rows)("delay", ctx_r5.lazy ? ctx_r5.virtualScrollDelay : 0)("inline", true)("lazy", ctx_r5.lazy)("loaderDisabled", true)("showSpacer", false)("showLoader", ctx_r5.loadingBodyTemplate)("options", ctx_r5.virtualScrollOptions)("autoSize", true);
  }
}
function Table_ng_container_8_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c113 = function(a0) {
  return {
    columns: a0
  };
};
function Table_ng_container_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Table_ng_container_8_ng_container_1_Template, 1, 0, "ng-container", 31);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r6 = ɵɵnextContext();
    const _r7 = ɵɵreference(10);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", _r7)("ngTemplateOutletContext", ɵɵpureFunction2(4, _c94, ctx_r6.processedData, ɵɵpureFunction1(2, _c113, ctx_r6.columns)));
  }
}
function Table_ng_template_9_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_ng_template_9_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_ng_template_9_tbody_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "tbody", 40);
  }
  if (rf & 2) {
    const scrollerOptions_r44 = ɵɵnextContext().options;
    const ctx_r49 = ɵɵnextContext();
    ɵɵproperty("value", ctx_r49.frozenValue)("frozenRows", true)("pTableBody", scrollerOptions_r44.columns)("pTableBodyTemplate", ctx_r49.frozenBodyTemplate)("frozen", true);
  }
}
function Table_ng_template_9_tbody_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "tbody", 41);
  }
  if (rf & 2) {
    const scrollerOptions_r44 = ɵɵnextContext().options;
    ɵɵstyleMap("height: calc(" + scrollerOptions_r44.spacerStyle.height + " - " + scrollerOptions_r44.rows.length * scrollerOptions_r44.itemSize + "px);");
  }
}
function Table_ng_template_9_tfoot_9_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c123 = function(a0) {
  return {
    $implicit: a0
  };
};
function Table_ng_template_9_tfoot_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "tfoot", 42, 43);
    ɵɵtemplate(2, Table_ng_template_9_tfoot_9_ng_container_2_Template, 1, 0, "ng-container", 31);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const scrollerOptions_r44 = ɵɵnextContext().options;
    const ctx_r51 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", ctx_r51.footerGroupedTemplate || ctx_r51.footerTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c123, scrollerOptions_r44.columns));
  }
}
var _c133 = function(a1, a2, a3) {
  return {
    "p-datatable-table": true,
    "p-datatable-scrollable-table": a1,
    "p-datatable-resizable-table": a2,
    "p-datatable-resizable-table-fit": a3
  };
};
function Table_ng_template_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "table", 32, 33);
    ɵɵtemplate(2, Table_ng_template_9_ng_container_2_Template, 1, 0, "ng-container", 31);
    ɵɵelementStart(3, "thead", 34, 35);
    ɵɵtemplate(5, Table_ng_template_9_ng_container_5_Template, 1, 0, "ng-container", 31);
    ɵɵelementEnd();
    ɵɵtemplate(6, Table_ng_template_9_tbody_6_Template, 1, 5, "tbody", 36);
    ɵɵelement(7, "tbody", 37);
    ɵɵtemplate(8, Table_ng_template_9_tbody_8_Template, 1, 2, "tbody", 38);
    ɵɵtemplate(9, Table_ng_template_9_tfoot_9_Template, 3, 4, "tfoot", 39);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const scrollerOptions_r44 = ctx.options;
    const ctx_r8 = ɵɵnextContext();
    ɵɵstyleMap(ctx_r8.tableStyle);
    ɵɵclassMap(ctx_r8.tableStyleClass);
    ɵɵproperty("ngClass", ɵɵpureFunction3(20, _c133, ctx_r8.scrollable, ctx_r8.resizableColumns, ctx_r8.resizableColumns && ctx_r8.columnResizeMode === "fit"));
    ɵɵattribute("id", ctx_r8.id + "-table");
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", ctx_r8.colGroupTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(24, _c123, scrollerOptions_r44.columns));
    ɵɵadvance(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r8.headerGroupedTemplate || ctx_r8.headerTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(26, _c123, scrollerOptions_r44.columns));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r8.frozenValue || ctx_r8.frozenBodyTemplate);
    ɵɵadvance(1);
    ɵɵstyleMap(scrollerOptions_r44.contentStyle);
    ɵɵproperty("ngClass", scrollerOptions_r44.contentStyleClass)("value", ctx_r8.dataToRender(scrollerOptions_r44.rows))("pTableBody", scrollerOptions_r44.columns)("pTableBodyTemplate", ctx_r8.bodyTemplate)("scrollerOptions", scrollerOptions_r44);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", scrollerOptions_r44.spacerStyle);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r8.footerGroupedTemplate || ctx_r8.footerTemplate);
  }
}
function Table_p_paginator_11_1_ng_template_0_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_p_paginator_11_1_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_11_1_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 21);
  }
  if (rf & 2) {
    const ctx_r61 = ɵɵnextContext(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r61.paginatorFirstPageLinkIconTemplate);
  }
}
function Table_p_paginator_11_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_11_1_ng_template_0_Template, 1, 1, "ng-template", 24);
  }
}
function Table_p_paginator_11_2_ng_template_0_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_p_paginator_11_2_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_11_2_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 21);
  }
  if (rf & 2) {
    const ctx_r63 = ɵɵnextContext(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r63.paginatorPreviousPageLinkIconTemplate);
  }
}
function Table_p_paginator_11_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_11_2_ng_template_0_Template, 1, 1, "ng-template", 25);
  }
}
function Table_p_paginator_11_3_ng_template_0_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_p_paginator_11_3_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_11_3_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 21);
  }
  if (rf & 2) {
    const ctx_r65 = ɵɵnextContext(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r65.paginatorLastPageLinkIconTemplate);
  }
}
function Table_p_paginator_11_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_11_3_ng_template_0_Template, 1, 1, "ng-template", 26);
  }
}
function Table_p_paginator_11_4_ng_template_0_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_p_paginator_11_4_ng_template_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_11_4_ng_template_0_ng_container_0_Template, 1, 0, "ng-container", 21);
  }
  if (rf & 2) {
    const ctx_r67 = ɵɵnextContext(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r67.paginatorNextPageLinkIconTemplate);
  }
}
function Table_p_paginator_11_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_p_paginator_11_4_ng_template_0_Template, 1, 1, "ng-template", 27);
  }
}
function Table_p_paginator_11_Template(rf, ctx) {
  if (rf & 1) {
    const _r70 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-paginator", 44);
    ɵɵlistener("onPageChange", function Table_p_paginator_11_Template_p_paginator_onPageChange_0_listener($event) {
      ɵɵrestoreView(_r70);
      const ctx_r69 = ɵɵnextContext();
      return ɵɵresetView(ctx_r69.onPageChange($event));
    });
    ɵɵtemplate(1, Table_p_paginator_11_1_Template, 1, 0, null, 8);
    ɵɵtemplate(2, Table_p_paginator_11_2_Template, 1, 0, null, 8);
    ɵɵtemplate(3, Table_p_paginator_11_3_Template, 1, 0, null, 8);
    ɵɵtemplate(4, Table_p_paginator_11_4_Template, 1, 0, null, 8);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r9 = ɵɵnextContext();
    ɵɵproperty("rows", ctx_r9.rows)("first", ctx_r9.first)("totalRecords", ctx_r9.totalRecords)("pageLinkSize", ctx_r9.pageLinks)("alwaysShow", ctx_r9.alwaysShowPaginator)("rowsPerPageOptions", ctx_r9.rowsPerPageOptions)("templateLeft", ctx_r9.paginatorLeftTemplate)("templateRight", ctx_r9.paginatorRightTemplate)("dropdownAppendTo", ctx_r9.paginatorDropdownAppendTo)("dropdownScrollHeight", ctx_r9.paginatorDropdownScrollHeight)("currentPageReportTemplate", ctx_r9.currentPageReportTemplate)("showFirstLastIcon", ctx_r9.showFirstLastIcon)("dropdownItemTemplate", ctx_r9.paginatorDropdownItemTemplate)("showCurrentPageReport", ctx_r9.showCurrentPageReport)("showJumpToPageDropdown", ctx_r9.showJumpToPageDropdown)("showJumpToPageInput", ctx_r9.showJumpToPageInput)("showPageLinks", ctx_r9.showPageLinks);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r9.paginatorFirstPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r9.paginatorPreviousPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r9.paginatorLastPageLinkIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r9.paginatorNextPageLinkIconTemplate);
  }
}
function Table_div_12_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Table_div_12_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 45);
    ɵɵtemplate(1, Table_div_12_ng_container_1_Template, 1, 0, "ng-container", 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r10 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r10.summaryTemplate);
  }
}
function Table_div_13_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "div", 46, 47);
  }
}
function Table_span_14_ArrowDownIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ArrowDownIcon");
  }
}
function Table_span_14_3_ng_template_0_Template(rf, ctx) {
}
function Table_span_14_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_span_14_3_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Table_span_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 48, 49);
    ɵɵtemplate(2, Table_span_14_ArrowDownIcon_2_Template, 1, 0, "ArrowDownIcon", 8);
    ɵɵtemplate(3, Table_span_14_3_Template, 1, 0, null, 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r12 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r12.reorderIndicatorUpIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r12.reorderIndicatorUpIconTemplate);
  }
}
function Table_span_15_ArrowUpIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ArrowUpIcon");
  }
}
function Table_span_15_3_ng_template_0_Template(rf, ctx) {
}
function Table_span_15_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Table_span_15_3_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Table_span_15_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 50, 51);
    ɵɵtemplate(2, Table_span_15_ArrowUpIcon_2_Template, 1, 0, "ArrowUpIcon", 8);
    ɵɵtemplate(3, Table_span_15_3_Template, 1, 0, null, 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r13 = ɵɵnextContext();
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r13.reorderIndicatorDownIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r13.reorderIndicatorDownIconTemplate);
  }
}
var _c143 = function(a1, a2, a3) {
  return {
    "p-datatable p-component": true,
    "p-datatable-hoverable-rows": a1,
    "p-datatable-scrollable": a2,
    "p-datatable-flex-scrollable": a3
  };
};
var _c153 = function(a0) {
  return {
    maxHeight: a0
  };
};
var _c163 = ["pTableBody", ""];
function TableBody_ng_container_0_ng_template_1_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c172 = function(a0, a1, a2, a3, a4) {
  return {
    $implicit: a0,
    rowIndex: a1,
    columns: a2,
    editing: a3,
    frozen: a4
  };
};
function TableBody_ng_container_0_ng_template_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0, 3);
    ɵɵtemplate(1, TableBody_ng_container_0_ng_template_1_ng_container_0_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r13 = ɵɵnextContext();
    const rowData_r6 = ctx_r13.$implicit;
    const rowIndex_r7 = ctx_r13.index;
    const ctx_r8 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r8.dt.groupHeaderTemplate)("ngTemplateOutletContext", ɵɵpureFunction5(2, _c172, rowData_r6, ctx_r8.getRowIndex(rowIndex_r7), ctx_r8.columns, ctx_r8.dt.editMode === "row" && ctx_r8.dt.isRowEditing(rowData_r6), ctx_r8.frozen));
  }
}
function TableBody_ng_container_0_ng_template_1_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function TableBody_ng_container_0_ng_template_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_0_ng_template_1_ng_container_1_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r15 = ɵɵnextContext();
    const rowData_r6 = ctx_r15.$implicit;
    const rowIndex_r7 = ctx_r15.index;
    const ctx_r9 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", rowData_r6 ? ctx_r9.template : ctx_r9.dt.loadingBodyTemplate)("ngTemplateOutletContext", ɵɵpureFunction5(2, _c172, rowData_r6, ctx_r9.getRowIndex(rowIndex_r7), ctx_r9.columns, ctx_r9.dt.editMode === "row" && ctx_r9.dt.isRowEditing(rowData_r6), ctx_r9.frozen));
  }
}
function TableBody_ng_container_0_ng_template_1_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c182 = function(a0, a1, a2, a3, a4, a5, a6) {
  return {
    $implicit: a0,
    rowIndex: a1,
    columns: a2,
    editing: a3,
    frozen: a4,
    rowgroup: a5,
    rowspan: a6
  };
};
function TableBody_ng_container_0_ng_template_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_0_ng_template_1_ng_container_2_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r17 = ɵɵnextContext();
    const rowData_r6 = ctx_r17.$implicit;
    const rowIndex_r7 = ctx_r17.index;
    const ctx_r10 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", rowData_r6 ? ctx_r10.template : ctx_r10.dt.loadingBodyTemplate)("ngTemplateOutletContext", ɵɵpureFunction7(2, _c182, rowData_r6, ctx_r10.getRowIndex(rowIndex_r7), ctx_r10.columns, ctx_r10.dt.editMode === "row" && ctx_r10.dt.isRowEditing(rowData_r6), ctx_r10.frozen, ctx_r10.shouldRenderRowspan(ctx_r10.value, rowData_r6, rowIndex_r7), ctx_r10.calculateRowGroupSize(ctx_r10.value, rowData_r6, rowIndex_r7)));
  }
}
function TableBody_ng_container_0_ng_template_1_ng_container_3_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function TableBody_ng_container_0_ng_template_1_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0, 3);
    ɵɵtemplate(1, TableBody_ng_container_0_ng_template_1_ng_container_3_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r19 = ɵɵnextContext();
    const rowData_r6 = ctx_r19.$implicit;
    const rowIndex_r7 = ctx_r19.index;
    const ctx_r11 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r11.dt.groupFooterTemplate)("ngTemplateOutletContext", ɵɵpureFunction5(2, _c172, rowData_r6, ctx_r11.getRowIndex(rowIndex_r7), ctx_r11.columns, ctx_r11.dt.editMode === "row" && ctx_r11.dt.isRowEditing(rowData_r6), ctx_r11.frozen));
  }
}
function TableBody_ng_container_0_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, TableBody_ng_container_0_ng_template_1_ng_container_0_Template, 2, 8, "ng-container", 2);
    ɵɵtemplate(1, TableBody_ng_container_0_ng_template_1_ng_container_1_Template, 2, 8, "ng-container", 0);
    ɵɵtemplate(2, TableBody_ng_container_0_ng_template_1_ng_container_2_Template, 2, 10, "ng-container", 0);
    ɵɵtemplate(3, TableBody_ng_container_0_ng_template_1_ng_container_3_Template, 2, 8, "ng-container", 2);
  }
  if (rf & 2) {
    const rowData_r6 = ctx.$implicit;
    const rowIndex_r7 = ctx.index;
    const ctx_r5 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", ctx_r5.dt.groupHeaderTemplate && !ctx_r5.dt.virtualScroll && ctx_r5.dt.rowGroupMode === "subheader" && ctx_r5.shouldRenderRowGroupHeader(ctx_r5.value, rowData_r6, rowIndex_r7));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.dt.rowGroupMode !== "rowspan");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.dt.rowGroupMode === "rowspan");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.dt.groupFooterTemplate && !ctx_r5.dt.virtualScroll && ctx_r5.dt.rowGroupMode === "subheader" && ctx_r5.shouldRenderRowGroupFooter(ctx_r5.value, rowData_r6, rowIndex_r7));
  }
}
function TableBody_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_0_ng_template_1_Template, 4, 4, "ng-template", 1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r0.value)("ngForTrackBy", ctx_r0.dt.rowTrackBy);
  }
}
function TableBody_ng_container_1_ng_template_1_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c192 = function(a0, a1, a2, a3, a4, a5) {
  return {
    $implicit: a0,
    rowIndex: a1,
    columns: a2,
    expanded: a3,
    editing: a4,
    frozen: a5
  };
};
function TableBody_ng_container_1_ng_template_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_1_ng_template_1_ng_container_0_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r27 = ɵɵnextContext();
    const rowData_r21 = ctx_r27.$implicit;
    const rowIndex_r22 = ctx_r27.index;
    const ctx_r23 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r23.template)("ngTemplateOutletContext", ɵɵpureFunction6(2, _c192, rowData_r21, ctx_r23.getRowIndex(rowIndex_r22), ctx_r23.columns, ctx_r23.dt.isRowExpanded(rowData_r21), ctx_r23.dt.editMode === "row" && ctx_r23.dt.isRowEditing(rowData_r21), ctx_r23.frozen));
  }
}
function TableBody_ng_container_1_ng_template_1_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function TableBody_ng_container_1_ng_template_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0, 3);
    ɵɵtemplate(1, TableBody_ng_container_1_ng_template_1_ng_container_1_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r29 = ɵɵnextContext();
    const rowData_r21 = ctx_r29.$implicit;
    const rowIndex_r22 = ctx_r29.index;
    const ctx_r24 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r24.dt.groupHeaderTemplate)("ngTemplateOutletContext", ɵɵpureFunction6(2, _c192, rowData_r21, ctx_r24.getRowIndex(rowIndex_r22), ctx_r24.columns, ctx_r24.dt.isRowExpanded(rowData_r21), ctx_r24.dt.editMode === "row" && ctx_r24.dt.isRowEditing(rowData_r21), ctx_r24.frozen));
  }
}
function TableBody_ng_container_1_ng_template_1_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function TableBody_ng_container_1_ng_template_1_ng_container_2_ng_container_2_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function TableBody_ng_container_1_ng_template_1_ng_container_2_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0, 3);
    ɵɵtemplate(1, TableBody_ng_container_1_ng_template_1_ng_container_2_ng_container_2_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r33 = ɵɵnextContext(2);
    const rowData_r21 = ctx_r33.$implicit;
    const rowIndex_r22 = ctx_r33.index;
    const ctx_r31 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r31.dt.groupFooterTemplate)("ngTemplateOutletContext", ɵɵpureFunction6(2, _c192, rowData_r21, ctx_r31.getRowIndex(rowIndex_r22), ctx_r31.columns, ctx_r31.dt.isRowExpanded(rowData_r21), ctx_r31.dt.editMode === "row" && ctx_r31.dt.isRowEditing(rowData_r21), ctx_r31.frozen));
  }
}
var _c20 = function(a0, a1, a2, a3) {
  return {
    $implicit: a0,
    rowIndex: a1,
    columns: a2,
    frozen: a3
  };
};
function TableBody_ng_container_1_ng_template_1_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_1_ng_template_1_ng_container_2_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵtemplate(2, TableBody_ng_container_1_ng_template_1_ng_container_2_ng_container_2_Template, 2, 9, "ng-container", 2);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r34 = ɵɵnextContext();
    const rowData_r21 = ctx_r34.$implicit;
    const rowIndex_r22 = ctx_r34.index;
    const ctx_r25 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r25.dt.expandedRowTemplate)("ngTemplateOutletContext", ɵɵpureFunction4(3, _c20, rowData_r21, ctx_r25.getRowIndex(rowIndex_r22), ctx_r25.columns, ctx_r25.frozen));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r25.dt.groupFooterTemplate && ctx_r25.dt.rowGroupMode === "subheader" && ctx_r25.shouldRenderRowGroupFooter(ctx_r25.value, rowData_r21, ctx_r25.getRowIndex(rowIndex_r22)));
  }
}
function TableBody_ng_container_1_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, TableBody_ng_container_1_ng_template_1_ng_container_0_Template, 2, 9, "ng-container", 0);
    ɵɵtemplate(1, TableBody_ng_container_1_ng_template_1_ng_container_1_Template, 2, 9, "ng-container", 2);
    ɵɵtemplate(2, TableBody_ng_container_1_ng_template_1_ng_container_2_Template, 3, 8, "ng-container", 0);
  }
  if (rf & 2) {
    const rowData_r21 = ctx.$implicit;
    const rowIndex_r22 = ctx.index;
    const ctx_r20 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", !ctx_r20.dt.groupHeaderTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r20.dt.groupHeaderTemplate && ctx_r20.dt.rowGroupMode === "subheader" && ctx_r20.shouldRenderRowGroupHeader(ctx_r20.value, rowData_r21, ctx_r20.getRowIndex(rowIndex_r22)));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r20.dt.isRowExpanded(rowData_r21));
  }
}
function TableBody_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_1_ng_template_1_Template, 3, 3, "ng-template", 1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r1.value)("ngForTrackBy", ctx_r1.dt.rowTrackBy);
  }
}
function TableBody_ng_container_2_ng_template_1_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function TableBody_ng_container_2_ng_template_1_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function TableBody_ng_container_2_ng_template_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_2_ng_template_1_ng_container_1_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r41 = ɵɵnextContext();
    const rowData_r36 = ctx_r41.$implicit;
    const rowIndex_r37 = ctx_r41.index;
    const ctx_r39 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r39.dt.frozenExpandedRowTemplate)("ngTemplateOutletContext", ɵɵpureFunction4(2, _c20, rowData_r36, ctx_r39.getRowIndex(rowIndex_r37), ctx_r39.columns, ctx_r39.frozen));
  }
}
function TableBody_ng_container_2_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, TableBody_ng_container_2_ng_template_1_ng_container_0_Template, 1, 0, "ng-container", 4);
    ɵɵtemplate(1, TableBody_ng_container_2_ng_template_1_ng_container_1_Template, 2, 7, "ng-container", 0);
  }
  if (rf & 2) {
    const rowData_r36 = ctx.$implicit;
    const rowIndex_r37 = ctx.index;
    const ctx_r35 = ɵɵnextContext(2);
    ɵɵproperty("ngTemplateOutlet", ctx_r35.template)("ngTemplateOutletContext", ɵɵpureFunction6(3, _c192, rowData_r36, ctx_r35.getRowIndex(rowIndex_r37), ctx_r35.columns, ctx_r35.dt.isRowExpanded(rowData_r36), ctx_r35.dt.editMode === "row" && ctx_r35.dt.isRowEditing(rowData_r36), ctx_r35.frozen));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r35.dt.isRowExpanded(rowData_r36));
  }
}
function TableBody_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_2_ng_template_1_Template, 2, 10, "ng-template", 1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r2.value)("ngForTrackBy", ctx_r2.dt.rowTrackBy);
  }
}
function TableBody_ng_container_3_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c21 = function(a0, a1) {
  return {
    $implicit: a0,
    frozen: a1
  };
};
function TableBody_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_3_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r3.dt.loadingBodyTemplate)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c21, ctx_r3.columns, ctx_r3.frozen));
  }
}
function TableBody_ng_container_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function TableBody_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableBody_ng_container_4_ng_container_1_Template, 1, 0, "ng-container", 4);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r4.dt.emptyMessageTemplate)("ngTemplateOutletContext", ɵɵpureFunction2(2, _c21, ctx_r4.columns, ctx_r4.frozen));
  }
}
function SortIcon_ng_container_0_SortAltIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "SortAltIcon", 4);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-sortable-column-icon");
  }
}
function SortIcon_ng_container_0_SortAmountUpAltIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "SortAmountUpAltIcon", 4);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-sortable-column-icon");
  }
}
function SortIcon_ng_container_0_SortAmountDownIcon_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "SortAmountDownIcon", 4);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-sortable-column-icon");
  }
}
function SortIcon_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, SortIcon_ng_container_0_SortAltIcon_1_Template, 1, 1, "SortAltIcon", 3);
    ɵɵtemplate(2, SortIcon_ng_container_0_SortAmountUpAltIcon_2_Template, 1, 1, "SortAmountUpAltIcon", 3);
    ɵɵtemplate(3, SortIcon_ng_container_0_SortAmountDownIcon_3_Template, 1, 1, "SortAmountDownIcon", 3);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.sortOrder === 0);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.sortOrder === 1);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.sortOrder === -1);
  }
}
function SortIcon_span_1_1_ng_template_0_Template(rf, ctx) {
}
function SortIcon_span_1_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, SortIcon_span_1_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function SortIcon_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 5);
    ɵɵtemplate(1, SortIcon_span_1_1_Template, 1, 0, null, 6);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r1.dt.sortIconTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c123, ctx_r1.sortOrder));
  }
}
function SortIcon_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 7);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r2.getBadgeValue());
  }
}
function CellEditor_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CellEditor_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CellEditor_ng_container_0_ng_container_1_Template, 1, 0, "ng-container", 1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r0.inputTemplate);
  }
}
function CellEditor_ng_container_1_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function CellEditor_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, CellEditor_ng_container_1_ng_container_1_Template, 1, 0, "ng-container", 1);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r1.outputTemplate);
  }
}
var _c222 = ["rb"];
var _c232 = function(a0, a1, a2) {
  return {
    "p-radiobutton-focused": a0,
    "p-radiobutton-checked": a1,
    "p-radiobutton-disabled": a2
  };
};
var _c242 = function(a1, a2, a3) {
  return {
    "p-radiobutton-box p-component": true,
    "p-highlight": a1,
    "p-focus": a2,
    "p-disabled": a3
  };
};
function TableCheckbox_ng_container_5_CheckIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "CheckIcon", 7);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-checkbox-icon");
  }
}
function TableCheckbox_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableCheckbox_ng_container_5_CheckIcon_1_Template, 1, 1, "CheckIcon", 6);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r1.checked);
  }
}
function TableCheckbox_span_6_1_ng_template_0_Template(rf, ctx) {
}
function TableCheckbox_span_6_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, TableCheckbox_span_6_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function TableCheckbox_span_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span");
    ɵɵtemplate(1, TableCheckbox_span_6_1_Template, 1, 0, null, 8);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r2.dt.checkboxIconTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c123, ctx_r2.checked));
  }
}
var _c252 = function(a0, a1) {
  return {
    "p-checkbox-focused": a0,
    "p-checkbox-disabled": a1
  };
};
var _c262 = function(a1, a2, a3) {
  return {
    "p-checkbox-box p-component": true,
    "p-highlight": a1,
    "p-focus": a2,
    "p-disabled": a3
  };
};
function TableHeaderCheckbox_ng_container_6_CheckIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "CheckIcon", 9);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-checkbox-icon");
  }
}
function TableHeaderCheckbox_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, TableHeaderCheckbox_ng_container_6_CheckIcon_1_Template, 1, 1, "CheckIcon", 8);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r2.checked);
  }
}
function TableHeaderCheckbox_span_7_1_ng_template_0_Template(rf, ctx) {
}
function TableHeaderCheckbox_span_7_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, TableHeaderCheckbox_span_7_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function TableHeaderCheckbox_span_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 10);
    ɵɵtemplate(1, TableHeaderCheckbox_span_7_1_Template, 1, 0, null, 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r3.dt.headerCheckboxIconTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(2, _c123, ctx_r3.checked));
  }
}
var _c272 = function(a1, a2, a3) {
  return {
    "p-checkbox-box": true,
    "p-highlight": a1,
    "p-focus": a2,
    "p-disabled": a3
  };
};
var _c28 = ["icon"];
function ColumnFilter_p_columnFilterFormElement_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "p-columnFilterFormElement", 5);
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵproperty("type", ctx_r0.type)("field", ctx_r0.field)("filterConstraint", ctx_r0.dt.filters[ctx_r0.field])("filterTemplate", ctx_r0.filterTemplate)("placeholder", ctx_r0.placeholder)("minFractionDigits", ctx_r0.minFractionDigits)("maxFractionDigits", ctx_r0.maxFractionDigits)("prefix", ctx_r0.prefix)("suffix", ctx_r0.suffix)("locale", ctx_r0.locale)("localeMatcher", ctx_r0.localeMatcher)("currency", ctx_r0.currency)("currencyDisplay", ctx_r0.currencyDisplay)("useGrouping", ctx_r0.useGrouping)("showButtons", ctx_r0.showButtons);
  }
}
function ColumnFilter_button_2_FilterIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "FilterIcon", 10);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "pi-filter-icon");
  }
}
function ColumnFilter_button_2_span_3_1_ng_template_0_Template(rf, ctx) {
}
function ColumnFilter_button_2_span_3_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ColumnFilter_button_2_span_3_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function ColumnFilter_button_2_span_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 11);
    ɵɵtemplate(1, ColumnFilter_button_2_span_3_1_Template, 1, 0, null, 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r6 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r6.filterIconTemplate);
  }
}
var _c29 = function(a0, a1) {
  return {
    "p-column-filter-menu-button-open": a0,
    "p-column-filter-menu-button-active": a1
  };
};
function ColumnFilter_button_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 6, 7);
    ɵɵlistener("click", function ColumnFilter_button_2_Template_button_click_0_listener() {
      ɵɵrestoreView(_r10);
      const ctx_r9 = ɵɵnextContext();
      return ɵɵresetView(ctx_r9.toggleMenu());
    })("keydown", function ColumnFilter_button_2_Template_button_keydown_0_listener($event) {
      ɵɵrestoreView(_r10);
      const ctx_r11 = ɵɵnextContext();
      return ɵɵresetView(ctx_r11.onToggleButtonKeyDown($event));
    });
    ɵɵtemplate(2, ColumnFilter_button_2_FilterIcon_2_Template, 1, 1, "FilterIcon", 8);
    ɵɵtemplate(3, ColumnFilter_button_2_span_3_Template, 2, 1, "span", 9);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("ngClass", ɵɵpureFunction2(4, _c29, ctx_r1.overlayVisible, ctx_r1.hasFilter()));
    ɵɵattribute("aria-expanded", ctx_r1.overlayVisible);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r1.filterIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r1.filterIconTemplate);
  }
}
function ColumnFilter_button_3_FilterSlashIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "FilterSlashIcon");
  }
}
function ColumnFilter_button_3_3_ng_template_0_Template(rf, ctx) {
}
function ColumnFilter_button_3_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ColumnFilter_button_3_3_ng_template_0_Template, 0, 0, "ng-template");
  }
}
var _c30 = function(a0) {
  return {
    "p-hidden-space": a0
  };
};
function ColumnFilter_button_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 13, 7);
    ɵɵlistener("click", function ColumnFilter_button_3_Template_button_click_0_listener() {
      ɵɵrestoreView(_r17);
      const ctx_r16 = ɵɵnextContext();
      return ɵɵresetView(ctx_r16.clearFilter());
    });
    ɵɵtemplate(2, ColumnFilter_button_3_FilterSlashIcon_2_Template, 1, 0, "FilterSlashIcon", 14);
    ɵɵtemplate(3, ColumnFilter_button_3_3_Template, 1, 0, null, 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("ngClass", ɵɵpureFunction1(3, _c30, !ctx_r2.hasRowFilter()));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", !ctx_r2.clearIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r2.clearFilterIcon);
  }
}
function ColumnFilter_div_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c31 = function(a0) {
  return {
    "p-highlight": a0
  };
};
function ColumnFilter_div_4_ul_2_li_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r27 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "li", 23);
    ɵɵlistener("click", function ColumnFilter_div_4_ul_2_li_1_Template_li_click_0_listener() {
      const restoredCtx = ɵɵrestoreView(_r27);
      const matchMode_r24 = restoredCtx.$implicit;
      const ctx_r26 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r26.onRowMatchModeChange(matchMode_r24.value));
    })("keydown", function ColumnFilter_div_4_ul_2_li_1_Template_li_keydown_0_listener($event) {
      ɵɵrestoreView(_r27);
      const ctx_r28 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r28.onRowMatchModeKeyDown($event));
    })("keydown.enter", function ColumnFilter_div_4_ul_2_li_1_Template_li_keydown_enter_0_listener() {
      const restoredCtx = ɵɵrestoreView(_r27);
      const matchMode_r24 = restoredCtx.$implicit;
      const ctx_r29 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r29.onRowMatchModeChange(matchMode_r24.value));
    });
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const matchMode_r24 = ctx.$implicit;
    const i_r25 = ctx.index;
    const ctx_r23 = ɵɵnextContext(3);
    ɵɵproperty("ngClass", ɵɵpureFunction1(3, _c31, ctx_r23.isRowMatchModeSelected(matchMode_r24.value)));
    ɵɵattribute("tabindex", i_r25 === 0 ? "0" : null);
    ɵɵadvance(1);
    ɵɵtextInterpolate1(" ", matchMode_r24.label, " ");
  }
}
function ColumnFilter_div_4_ul_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "ul", 19);
    ɵɵtemplate(1, ColumnFilter_div_4_ul_2_li_1_Template, 2, 5, "li", 20);
    ɵɵelement(2, "li", 21);
    ɵɵelementStart(3, "li", 22);
    ɵɵlistener("click", function ColumnFilter_div_4_ul_2_Template_li_click_3_listener() {
      ɵɵrestoreView(_r31);
      const ctx_r30 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r30.onRowClearItemClick());
    })("keydown", function ColumnFilter_div_4_ul_2_Template_li_keydown_3_listener($event) {
      ɵɵrestoreView(_r31);
      const ctx_r32 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r32.onRowMatchModeKeyDown($event));
    })("keydown.enter", function ColumnFilter_div_4_ul_2_Template_li_keydown_enter_3_listener() {
      ɵɵrestoreView(_r31);
      const ctx_r33 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r33.onRowClearItemClick());
    });
    ɵɵtext(4);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r19 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r19.matchModes);
    ɵɵadvance(3);
    ɵɵtextInterpolate(ctx_r19.noFilterLabel);
  }
}
function ColumnFilter_div_4_ng_template_3_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r40 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 31)(1, "p-dropdown", 32);
    ɵɵlistener("ngModelChange", function ColumnFilter_div_4_ng_template_3_div_0_Template_p_dropdown_ngModelChange_1_listener($event) {
      ɵɵrestoreView(_r40);
      const ctx_r39 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r39.onOperatorChange($event));
    });
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r34 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("options", ctx_r34.operatorOptions)("ngModel", ctx_r34.operator);
  }
}
function ColumnFilter_div_4_ng_template_3_div_2_p_dropdown_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r47 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-dropdown", 37);
    ɵɵlistener("ngModelChange", function ColumnFilter_div_4_ng_template_3_div_2_p_dropdown_1_Template_p_dropdown_ngModelChange_0_listener($event) {
      ɵɵrestoreView(_r47);
      const fieldConstraint_r41 = ɵɵnextContext().$implicit;
      const ctx_r45 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r45.onMenuMatchModeChange($event, fieldConstraint_r41));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const fieldConstraint_r41 = ɵɵnextContext().$implicit;
    const ctx_r43 = ɵɵnextContext(3);
    ɵɵproperty("options", ctx_r43.matchModes)("ngModel", fieldConstraint_r41.matchMode);
  }
}
function ColumnFilter_div_4_ng_template_3_div_2_button_4_TrashIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "TrashIcon");
  }
}
function ColumnFilter_div_4_ng_template_3_div_2_button_4_2_ng_template_0_Template(rf, ctx) {
}
function ColumnFilter_div_4_ng_template_3_div_2_button_4_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ColumnFilter_div_4_ng_template_3_div_2_button_4_2_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function ColumnFilter_div_4_ng_template_3_div_2_button_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r54 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 38);
    ɵɵlistener("click", function ColumnFilter_div_4_ng_template_3_div_2_button_4_Template_button_click_0_listener() {
      ɵɵrestoreView(_r54);
      const fieldConstraint_r41 = ɵɵnextContext().$implicit;
      const ctx_r52 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r52.removeConstraint(fieldConstraint_r41));
    });
    ɵɵtemplate(1, ColumnFilter_div_4_ng_template_3_div_2_button_4_TrashIcon_1_Template, 1, 0, "TrashIcon", 14);
    ɵɵtemplate(2, ColumnFilter_div_4_ng_template_3_div_2_button_4_2_Template, 1, 0, null, 12);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r44 = ɵɵnextContext(4);
    ɵɵproperty("label", ctx_r44.removeRuleButtonLabel);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r44.removeRuleIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r44.removeRuleIconTemplate);
  }
}
function ColumnFilter_div_4_ng_template_3_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 33);
    ɵɵtemplate(1, ColumnFilter_div_4_ng_template_3_div_2_p_dropdown_1_Template, 1, 2, "p-dropdown", 34);
    ɵɵelement(2, "p-columnFilterFormElement", 35);
    ɵɵelementStart(3, "div");
    ɵɵtemplate(4, ColumnFilter_div_4_ng_template_3_div_2_button_4_Template, 3, 3, "button", 36);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const fieldConstraint_r41 = ctx.$implicit;
    const ctx_r35 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r35.showMatchModes && ctx_r35.matchModes);
    ɵɵadvance(1);
    ɵɵproperty("type", ctx_r35.type)("field", ctx_r35.field)("filterConstraint", fieldConstraint_r41)("filterTemplate", ctx_r35.filterTemplate)("placeholder", ctx_r35.placeholder)("minFractionDigits", ctx_r35.minFractionDigits)("maxFractionDigits", ctx_r35.maxFractionDigits)("prefix", ctx_r35.prefix)("suffix", ctx_r35.suffix)("locale", ctx_r35.locale)("localeMatcher", ctx_r35.localeMatcher)("currency", ctx_r35.currency)("currencyDisplay", ctx_r35.currencyDisplay)("useGrouping", ctx_r35.useGrouping);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r35.showRemoveIcon);
  }
}
function ColumnFilter_div_4_ng_template_3_div_3_PlusIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "PlusIcon");
  }
}
function ColumnFilter_div_4_ng_template_3_div_3_3_ng_template_0_Template(rf, ctx) {
}
function ColumnFilter_div_4_ng_template_3_div_3_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ColumnFilter_div_4_ng_template_3_div_3_3_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function ColumnFilter_div_4_ng_template_3_div_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r59 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 39)(1, "button", 40);
    ɵɵlistener("click", function ColumnFilter_div_4_ng_template_3_div_3_Template_button_click_1_listener() {
      ɵɵrestoreView(_r59);
      const ctx_r58 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r58.addConstraint());
    });
    ɵɵtemplate(2, ColumnFilter_div_4_ng_template_3_div_3_PlusIcon_2_Template, 1, 0, "PlusIcon", 14);
    ɵɵtemplate(3, ColumnFilter_div_4_ng_template_3_div_3_3_Template, 1, 0, null, 12);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r36 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("label", ctx_r36.addRuleButtonLabel);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r36.addRuleIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r36.addRuleIconTemplate);
  }
}
function ColumnFilter_div_4_ng_template_3_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r61 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 41);
    ɵɵlistener("click", function ColumnFilter_div_4_ng_template_3_button_5_Template_button_click_0_listener() {
      ɵɵrestoreView(_r61);
      const ctx_r60 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r60.clearFilter());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r37 = ɵɵnextContext(3);
    ɵɵproperty("label", ctx_r37.clearButtonLabel);
  }
}
function ColumnFilter_div_4_ng_template_3_button_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r63 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 42);
    ɵɵlistener("click", function ColumnFilter_div_4_ng_template_3_button_6_Template_button_click_0_listener() {
      ɵɵrestoreView(_r63);
      const ctx_r62 = ɵɵnextContext(3);
      return ɵɵresetView(ctx_r62.applyFilter());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r38 = ɵɵnextContext(3);
    ɵɵproperty("label", ctx_r38.applyButtonLabel);
  }
}
function ColumnFilter_div_4_ng_template_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, ColumnFilter_div_4_ng_template_3_div_0_Template, 2, 2, "div", 24);
    ɵɵelementStart(1, "div", 25);
    ɵɵtemplate(2, ColumnFilter_div_4_ng_template_3_div_2_Template, 5, 16, "div", 26);
    ɵɵelementEnd();
    ɵɵtemplate(3, ColumnFilter_div_4_ng_template_3_div_3_Template, 4, 3, "div", 27);
    ɵɵelementStart(4, "div", 28);
    ɵɵtemplate(5, ColumnFilter_div_4_ng_template_3_button_5_Template, 1, 1, "button", 29);
    ɵɵtemplate(6, ColumnFilter_div_4_ng_template_3_button_6_Template, 1, 1, "button", 30);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r21 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", ctx_r21.isShowOperator);
    ɵɵadvance(2);
    ɵɵproperty("ngForOf", ctx_r21.fieldConstraints);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r21.isShowAddConstraint);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r21.showClearButton);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r21.showApplyButton);
  }
}
function ColumnFilter_div_4_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c322 = function(a1) {
  return {
    "p-column-filter-overlay p-component p-fluid": true,
    "p-column-filter-overlay-menu": a1
  };
};
function ColumnFilter_div_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r65 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 15);
    ɵɵlistener("click", function ColumnFilter_div_4_Template_div_click_0_listener() {
      ɵɵrestoreView(_r65);
      const ctx_r64 = ɵɵnextContext();
      return ɵɵresetView(ctx_r64.onContentClick());
    })("@overlayAnimation.start", function ColumnFilter_div_4_Template_div_animation_overlayAnimation_start_0_listener($event) {
      ɵɵrestoreView(_r65);
      const ctx_r66 = ɵɵnextContext();
      return ɵɵresetView(ctx_r66.onOverlayAnimationStart($event));
    })("@overlayAnimation.done", function ColumnFilter_div_4_Template_div_animation_overlayAnimation_done_0_listener($event) {
      ɵɵrestoreView(_r65);
      const ctx_r67 = ɵɵnextContext();
      return ɵɵresetView(ctx_r67.onOverlayAnimationEnd($event));
    })("keydown.escape", function ColumnFilter_div_4_Template_div_keydown_escape_0_listener() {
      ɵɵrestoreView(_r65);
      const ctx_r68 = ɵɵnextContext();
      return ɵɵresetView(ctx_r68.onEscape());
    });
    ɵɵtemplate(1, ColumnFilter_div_4_ng_container_1_Template, 1, 0, "ng-container", 16);
    ɵɵtemplate(2, ColumnFilter_div_4_ul_2_Template, 5, 2, "ul", 17);
    ɵɵtemplate(3, ColumnFilter_div_4_ng_template_3_Template, 7, 5, "ng-template", null, 18, ɵɵtemplateRefExtractor);
    ɵɵtemplate(5, ColumnFilter_div_4_ng_container_5_Template, 1, 0, "ng-container", 16);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const _r20 = ɵɵreference(4);
    const ctx_r3 = ɵɵnextContext();
    ɵɵproperty("ngClass", ɵɵpureFunction1(8, _c322, ctx_r3.display === "menu"))("@overlayAnimation", "visible");
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r3.headerTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(10, _c123, ctx_r3.field));
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r3.display === "row")("ngIfElse", _r20);
    ɵɵadvance(3);
    ɵɵproperty("ngTemplateOutlet", ctx_r3.footerTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(12, _c123, ctx_r3.field));
  }
}
var _c332 = function(a0, a1) {
  return {
    "p-column-filter-row": a0,
    "p-column-filter-menu": a1
  };
};
function ColumnFilterFormElement_ng_container_0_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c342 = function(a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15) {
  return {
    $implicit: a0,
    filterCallback: a1,
    type: a2,
    field: a3,
    filterConstraint: a4,
    placeholder: a5,
    minFractionDigits: a6,
    maxFractionDigits: a7,
    prefix: a8,
    suffix: a9,
    locale: a10,
    localeMatcher: a11,
    currency: a12,
    currencyDisplay: a13,
    useGrouping: a14,
    showButtons: a15
  };
};
function ColumnFilterFormElement_ng_container_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, ColumnFilterFormElement_ng_container_0_ng_container_1_Template, 1, 0, "ng-container", 2);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r0.filterTemplate)("ngTemplateOutletContext", ɵɵpureFunctionV(2, _c342, [ctx_r0.filterConstraint.value, ctx_r0.filterCallback, ctx_r0.type, ctx_r0.field, ctx_r0.filterConstraint, ctx_r0.placeholder, ctx_r0.minFractionDigits, ctx_r0.maxFractionDigits, ctx_r0.prefix, ctx_r0.suffix, ctx_r0.locale, ctx_r0.localeMatcher, ctx_r0.currency, ctx_r0.currencyDisplay, ctx_r0.useGrouping, ctx_r0.showButtons]));
  }
}
function ColumnFilterFormElement_ng_template_1_input_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r9 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "input", 8);
    ɵɵlistener("input", function ColumnFilterFormElement_ng_template_1_input_1_Template_input_input_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r8 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r8.onModelChange($event.target.value));
    })("keydown.enter", function ColumnFilterFormElement_ng_template_1_input_1_Template_input_keydown_enter_0_listener($event) {
      ɵɵrestoreView(_r9);
      const ctx_r10 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r10.onTextInputEnterKeyDown($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext(2);
    ɵɵproperty("value", ctx_r4.filterConstraint == null ? null : ctx_r4.filterConstraint.value);
    ɵɵattribute("placeholder", ctx_r4.placeholder);
  }
}
function ColumnFilterFormElement_ng_template_1_p_inputNumber_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r12 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-inputNumber", 9);
    ɵɵlistener("ngModelChange", function ColumnFilterFormElement_ng_template_1_p_inputNumber_2_Template_p_inputNumber_ngModelChange_0_listener($event) {
      ɵɵrestoreView(_r12);
      const ctx_r11 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r11.onModelChange($event));
    })("onKeyDown", function ColumnFilterFormElement_ng_template_1_p_inputNumber_2_Template_p_inputNumber_onKeyDown_0_listener($event) {
      ɵɵrestoreView(_r12);
      const ctx_r13 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r13.onNumericInputKeyDown($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r5 = ɵɵnextContext(2);
    ɵɵproperty("ngModel", ctx_r5.filterConstraint == null ? null : ctx_r5.filterConstraint.value)("showButtons", ctx_r5.showButtons)("minFractionDigits", ctx_r5.minFractionDigits)("maxFractionDigits", ctx_r5.maxFractionDigits)("prefix", ctx_r5.prefix)("suffix", ctx_r5.suffix)("placeholder", ctx_r5.placeholder)("mode", ctx_r5.currency ? "currency" : "decimal")("locale", ctx_r5.locale)("localeMatcher", ctx_r5.localeMatcher)("currency", ctx_r5.currency)("currencyDisplay", ctx_r5.currencyDisplay)("useGrouping", ctx_r5.useGrouping);
  }
}
function ColumnFilterFormElement_ng_template_1_p_triStateCheckbox_3_Template(rf, ctx) {
  if (rf & 1) {
    const _r15 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-triStateCheckbox", 10);
    ɵɵlistener("ngModelChange", function ColumnFilterFormElement_ng_template_1_p_triStateCheckbox_3_Template_p_triStateCheckbox_ngModelChange_0_listener($event) {
      ɵɵrestoreView(_r15);
      const ctx_r14 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r14.onModelChange($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r6 = ɵɵnextContext(2);
    ɵɵproperty("ngModel", ctx_r6.filterConstraint == null ? null : ctx_r6.filterConstraint.value);
  }
}
function ColumnFilterFormElement_ng_template_1_p_calendar_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r17 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-calendar", 11);
    ɵɵlistener("ngModelChange", function ColumnFilterFormElement_ng_template_1_p_calendar_4_Template_p_calendar_ngModelChange_0_listener($event) {
      ɵɵrestoreView(_r17);
      const ctx_r16 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r16.onModelChange($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r7 = ɵɵnextContext(2);
    ɵɵproperty("placeholder", ctx_r7.placeholder)("ngModel", ctx_r7.filterConstraint == null ? null : ctx_r7.filterConstraint.value);
  }
}
function ColumnFilterFormElement_ng_template_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0, 3);
    ɵɵtemplate(1, ColumnFilterFormElement_ng_template_1_input_1_Template, 1, 2, "input", 4);
    ɵɵtemplate(2, ColumnFilterFormElement_ng_template_1_p_inputNumber_2_Template, 1, 13, "p-inputNumber", 5);
    ɵɵtemplate(3, ColumnFilterFormElement_ng_template_1_p_triStateCheckbox_3_Template, 1, 1, "p-triStateCheckbox", 6);
    ɵɵtemplate(4, ColumnFilterFormElement_ng_template_1_p_calendar_4_Template, 1, 2, "p-calendar", 7);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("ngSwitch", ctx_r2.type);
    ɵɵadvance(1);
    ɵɵproperty("ngSwitchCase", "text");
    ɵɵadvance(1);
    ɵɵproperty("ngSwitchCase", "numeric");
    ɵɵadvance(1);
    ɵɵproperty("ngSwitchCase", "boolean");
    ɵɵadvance(1);
    ɵɵproperty("ngSwitchCase", "date");
  }
}
var _TableService = class {
  constructor() {
    __publicField(this, "sortSource", new Subject());
    __publicField(this, "selectionSource", new Subject());
    __publicField(this, "contextMenuSource", new Subject());
    __publicField(this, "valueSource", new Subject());
    __publicField(this, "totalRecordsSource", new Subject());
    __publicField(this, "columnsSource", new Subject());
    __publicField(this, "sortSource$", this.sortSource.asObservable());
    __publicField(this, "selectionSource$", this.selectionSource.asObservable());
    __publicField(this, "contextMenuSource$", this.contextMenuSource.asObservable());
    __publicField(this, "valueSource$", this.valueSource.asObservable());
    __publicField(this, "totalRecordsSource$", this.totalRecordsSource.asObservable());
    __publicField(this, "columnsSource$", this.columnsSource.asObservable());
  }
  onSort(sortMeta) {
    this.sortSource.next(sortMeta);
  }
  onSelectionChange() {
    this.selectionSource.next(null);
  }
  onContextMenu(data) {
    this.contextMenuSource.next(data);
  }
  onValueChange(value) {
    this.valueSource.next(value);
  }
  onTotalRecordsChange(value) {
    this.totalRecordsSource.next(value);
  }
  onColumnsChange(columns) {
    this.columnsSource.next(columns);
  }
};
var TableService = _TableService;
__publicField(TableService, "ɵfac", function TableService_Factory(t) {
  return new (t || _TableService)();
});
__publicField(TableService, "ɵprov", ɵɵdefineInjectable({
  token: _TableService,
  factory: _TableService.ɵfac
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TableService, [{
    type: Injectable
  }], null, null);
})();
var _Table = class {
  constructor(document, platformId, renderer, el, zone, tableService, cd, filterService, overlayService) {
    __publicField(this, "document");
    __publicField(this, "platformId");
    __publicField(this, "renderer");
    __publicField(this, "el");
    __publicField(this, "zone");
    __publicField(this, "tableService");
    __publicField(this, "cd");
    __publicField(this, "filterService");
    __publicField(this, "overlayService");
    /**
     * An array of objects to represent dynamic columns that are frozen.
     * @group Props
     */
    __publicField(this, "frozenColumns");
    /**
     * An array of objects to display as frozen.
     * @group Props
     */
    __publicField(this, "frozenValue");
    /**
     * Inline style of the component.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Style class of the component.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Inline style of the table.
     * @group Props
     */
    __publicField(this, "tableStyle");
    /**
     * Style class of the table.
     * @group Props
     */
    __publicField(this, "tableStyleClass");
    /**
     * When specified as true, enables the pagination.
     * @group Props
     */
    __publicField(this, "paginator");
    /**
     * Number of page links to display in paginator.
     * @group Props
     */
    __publicField(this, "pageLinks", 5);
    /**
     * Array of integer/object values to display inside rows per page dropdown of paginator
     * @group Props
     */
    __publicField(this, "rowsPerPageOptions");
    /**
     * Whether to show it even there is only one page.
     * @group Props
     */
    __publicField(this, "alwaysShowPaginator", true);
    /**
     * Position of the paginator, options are "top", "bottom" or "both".
     * @group Props
     */
    __publicField(this, "paginatorPosition", "bottom");
    /**
     * Target element to attach the paginator dropdown overlay, valid values are "body" or a local ng-template variable of another element (note: use binding with brackets for template variables, e.g. [appendTo]="mydiv" for a div element having #mydiv as variable name).
     * @group Props
     */
    __publicField(this, "paginatorDropdownAppendTo");
    /**
     * Paginator dropdown height of the viewport in pixels, a scrollbar is defined if height of list exceeds this value.
     * @group Props
     */
    __publicField(this, "paginatorDropdownScrollHeight", "200px");
    /**
     * Template of the current page report element. Available placeholders are {currentPage},{totalPages},{rows},{first},{last} and {totalRecords}
     * @group Props
     */
    __publicField(this, "currentPageReportTemplate", "{currentPage} of {totalPages}");
    /**
     * Whether to display current page report.
     * @group Props
     */
    __publicField(this, "showCurrentPageReport");
    /**
     * Whether to display a dropdown to navigate to any page.
     * @group Props
     */
    __publicField(this, "showJumpToPageDropdown");
    /**
     * Whether to display a input to navigate to any page.
     * @group Props
     */
    __publicField(this, "showJumpToPageInput");
    /**
     * When enabled, icons are displayed on paginator to go first and last page.
     * @group Props
     */
    __publicField(this, "showFirstLastIcon", true);
    /**
     * Whether to show page links.
     * @group Props
     */
    __publicField(this, "showPageLinks", true);
    /**
     * Sort order to use when an unsorted column gets sorted by user interaction.
     * @group Props
     */
    __publicField(this, "defaultSortOrder", 1);
    /**
     * Defines whether sorting works on single column or on multiple columns.
     * @group Props
     */
    __publicField(this, "sortMode", "single");
    /**
     * When true, resets paginator to first page after sorting. Available only when sortMode is set to single.
     * @group Props
     */
    __publicField(this, "resetPageOnSort", true);
    /**
     * Specifies the selection mode, valid values are "single" and "multiple".
     * @group Props
     */
    __publicField(this, "selectionMode");
    /**
     * When enabled with paginator and checkbox selection mode, the select all checkbox in the header will select all rows on the current page.
     * @group Props
     */
    __publicField(this, "selectionPageOnly");
    /**
     * Selected row with a context menu.
     * @group Props
     */
    __publicField(this, "contextMenuSelection");
    /**
     * Callback to invoke on context menu selection change.
     * @param {*} object - row data.
     * @group Emits
     */
    __publicField(this, "contextMenuSelectionChange", new EventEmitter());
    /**
     *  Defines the behavior of context menu selection, in "separate" mode context menu updates contextMenuSelection property whereas in joint mode selection property is used instead so that when row selection is enabled, both row selection and context menu selection use the same property.
     * @group Props
     */
    __publicField(this, "contextMenuSelectionMode", "separate");
    /**
     * A property to uniquely identify a record in data.
     * @group Props
     */
    __publicField(this, "dataKey");
    /**
     * Defines whether metaKey should be considered for the selection. On touch enabled devices, metaKeySelection is turned off automatically.
     * @group Props
     */
    __publicField(this, "metaKeySelection");
    /**
     * Defines if the row is selectable.
     * @group Props
     */
    __publicField(this, "rowSelectable");
    /**
     * Function to optimize the dom operations by delegating to ngForTrackBy, default algorithm checks for object identity.
     * @group Props
     */
    __publicField(this, "rowTrackBy", (index, item) => item);
    /**
     * Defines if data is loaded and interacted with in lazy manner.
     * @group Props
     */
    __publicField(this, "lazy", false);
    /**
     * Whether to call lazy loading on initialization.
     * @group Props
     */
    __publicField(this, "lazyLoadOnInit", true);
    /**
     * Algorithm to define if a row is selected, valid values are "equals" that compares by reference and "deepEquals" that compares all fields.
     * @group Props
     */
    __publicField(this, "compareSelectionBy", "deepEquals");
    /**
     * Character to use as the csv separator.
     * @group Props
     */
    __publicField(this, "csvSeparator", ",");
    /**
     * Name of the exported file.
     * @group Props
     */
    __publicField(this, "exportFilename", "download");
    /**
     * An array of FilterMetadata objects to provide external filters.
     * @group Props
     */
    __publicField(this, "filters", {});
    /**
     * An array of fields as string to use in global filtering.
     * @group Props
     */
    __publicField(this, "globalFilterFields");
    /**
     * Delay in milliseconds before filtering the data.
     * @group Props
     */
    __publicField(this, "filterDelay", 300);
    /**
     * Locale to use in filtering. The default locale is the host environment's current locale.
     * @group Props
     */
    __publicField(this, "filterLocale");
    /**
     * Map instance to keep the expanded rows where key of the map is the data key of the row.
     * @group Props
     */
    __publicField(this, "expandedRowKeys", {});
    /**
     * Map instance to keep the rows being edited where key of the map is the data key of the row.
     * @group Props
     */
    __publicField(this, "editingRowKeys", {});
    /**
     * Whether multiple rows can be expanded at any time. Valid values are "multiple" and "single".
     * @group Props
     */
    __publicField(this, "rowExpandMode", "multiple");
    /**
     * Enables scrollable tables.
     * @group Props
     */
    __publicField(this, "scrollable");
    /**
     * Orientation of the scrolling, options are "vertical", "horizontal" and "both".
     * @group Props
     * @deprecated Property is obselete since v14.2.0.
     */
    __publicField(this, "scrollDirection", "vertical");
    /**
     * Type of the row grouping, valid values are "subheader" and "rowspan".
     * @group Props
     */
    __publicField(this, "rowGroupMode");
    /**
     * Height of the scroll viewport in fixed pixels or the "flex" keyword for a dynamic size.
     * @group Props
     */
    __publicField(this, "scrollHeight");
    /**
     * Whether the data should be loaded on demand during scroll.
     * @group Props
     */
    __publicField(this, "virtualScroll");
    /**
     * Height of a row to use in calculations of virtual scrolling.
     * @group Props
     */
    __publicField(this, "virtualScrollItemSize");
    /**
     * Whether to use the scroller feature. The properties of scroller component can be used like an object in it.
     * @group Props
     */
    __publicField(this, "virtualScrollOptions");
    /**
     * Threshold in milliseconds to delay lazy loading during scrolling.
     * @group Props
     */
    __publicField(this, "virtualScrollDelay", 250);
    /**
     * Width of the frozen columns container.
     * @group Props
     */
    __publicField(this, "frozenWidth");
    __publicField(this, "_responsive");
    /**
     * Local ng-template varilable of a ContextMenu.
     * @group Props
     */
    __publicField(this, "contextMenu");
    /**
     * When enabled, columns can be resized using drag and drop.
     * @group Props
     */
    __publicField(this, "resizableColumns");
    /**
     * Defines whether the overall table width should change on column resize, valid values are "fit" and "expand".
     * @group Props
     */
    __publicField(this, "columnResizeMode", "fit");
    /**
     * When enabled, columns can be reordered using drag and drop.
     * @group Props
     */
    __publicField(this, "reorderableColumns");
    /**
     * Displays a loader to indicate data load is in progress.
     * @group Props
     */
    __publicField(this, "loading");
    /**
     * The icon to show while indicating data load is in progress.
     * @group Props
     */
    __publicField(this, "loadingIcon");
    /**
     * Whether to show the loading mask when loading property is true.
     * @group Props
     */
    __publicField(this, "showLoader", true);
    /**
     * Adds hover effect to rows without the need for selectionMode. Note that tr elements that can be hovered need to have "p-selectable-row" class for rowHover to work.
     * @group Props
     */
    __publicField(this, "rowHover");
    /**
     * Whether to use the default sorting or a custom one using sortFunction.
     * @group Props
     */
    __publicField(this, "customSort");
    /**
     * Whether to use the initial sort badge or not.
     * @group Props
     */
    __publicField(this, "showInitialSortBadge", true);
    /**
     * Whether the cell widths scale according to their content or not.  Deprecated:  Table layout is always "auto".
     * @group Props
     */
    __publicField(this, "autoLayout");
    /**
     * Export function.
     * @group Props
     */
    __publicField(this, "exportFunction");
    /**
     * Custom export header of the column to be exported as CSV.
     * @group Props
     */
    __publicField(this, "exportHeader");
    /**
     * Unique identifier of a stateful table to use in state storage.
     * @group Props
     */
    __publicField(this, "stateKey");
    /**
     * Defines where a stateful table keeps its state, valid values are "session" for sessionStorage and "local" for localStorage.
     * @group Props
     */
    __publicField(this, "stateStorage", "session");
    /**
     * Defines the editing mode, valid values are "cell" and "row".
     * @group Props
     */
    __publicField(this, "editMode", "cell");
    /**
     * Field name to use in row grouping.
     * @group Props
     */
    __publicField(this, "groupRowsBy");
    /**
     * Order to sort when default row grouping is enabled.
     * @group Props
     */
    __publicField(this, "groupRowsByOrder", 1);
    /**
     * Defines the responsive mode, valid options are "stack" and "scroll".
     * @group Props
     */
    __publicField(this, "responsiveLayout", "scroll");
    /**
     * The breakpoint to define the maximum width boundary when using stack responsive layout.
     * @group Props
     */
    __publicField(this, "breakpoint", "960px");
    __publicField(this, "selectAllChange", new EventEmitter());
    /**
     * Callback to invoke on selection changed.
     * @param {any | null} value - selected data.
     * @group Emits
     */
    __publicField(this, "selectionChange", new EventEmitter());
    /**
     * Callback to invoke when a row is selected.
     * @param {TableRowSelectEvent} event - custom select event.
     * @group Emits
     */
    __publicField(this, "onRowSelect", new EventEmitter());
    /**
     * Callback to invoke when a row is unselected.
     * @param {TableRowUnSelectEvent} event - custom unselect event.
     * @group Emits
     */
    __publicField(this, "onRowUnselect", new EventEmitter());
    /**
     * Callback to invoke when pagination occurs.
     * @param {TablePageEvent} event - custom pagination event.
     * @group Emits
     */
    __publicField(this, "onPage", new EventEmitter());
    /**
     * Callback to invoke when a column gets sorted.
     * @param {Object} object - sort meta.
     * @group Emits
     */
    __publicField(this, "onSort", new EventEmitter());
    /**
     * Callback to invoke when data is filtered.
     * @param {TableFilterEvent} event - custom filtering event.
     * @group Emits
     */
    __publicField(this, "onFilter", new EventEmitter());
    /**
     * Callback to invoke when paging, sorting or filtering happens in lazy mode.
     * @param {TableLazyLoadEvent} event - custom lazy loading event.
     * @group Emits
     */
    __publicField(this, "onLazyLoad", new EventEmitter());
    /**
     * Callback to invoke when a row is expanded.
     * @param {TableRowExpandEvent} event - custom row expand event.
     * @group Emits
     */
    __publicField(this, "onRowExpand", new EventEmitter());
    /**
     * Callback to invoke when a row is collapsed.
     * @param {TableRowCollapseEvent} event - custom row collapse event.
     * @group Emits
     */
    __publicField(this, "onRowCollapse", new EventEmitter());
    /**
     * Callback to invoke when a row is selected with right click.
     * @param {TableContextMenuSelectEvent} event - custom context menu select event.
     * @group Emits
     */
    __publicField(this, "onContextMenuSelect", new EventEmitter());
    /**
     * Callback to invoke when a column is resized.
     * @param {TableColResizeEvent} event - custom column resize event.
     * @group Emits
     */
    __publicField(this, "onColResize", new EventEmitter());
    /**
     * Callback to invoke when a column is reordered.
     * @param {TableColumnReorderEvent} event - custom column reorder event.
     * @group Emits
     */
    __publicField(this, "onColReorder", new EventEmitter());
    /**
     * Callback to invoke when a row is reordered.
     * @param {TableRowReorderEvent} event - custom row reorder event.
     * @group Emits
     */
    __publicField(this, "onRowReorder", new EventEmitter());
    /**
     * Callback to invoke when a cell switches to edit mode.
     * @param {TableEditInitEvent} event - custom edit init event.
     * @group Emits
     */
    __publicField(this, "onEditInit", new EventEmitter());
    /**
     * Callback to invoke when cell edit is completed.
     * @param {TableEditCompleteEvent} event - custom edit complete event.
     * @group Emits
     */
    __publicField(this, "onEditComplete", new EventEmitter());
    /**
     * Callback to invoke when cell edit is cancelled with escape key.
     * @param {TableEditCancelEvent} event - custom edit cancel event.
     * @group Emits
     */
    __publicField(this, "onEditCancel", new EventEmitter());
    /**
     * Callback to invoke when state of header checkbox changes.
     * @param {TableHeaderCheckboxToggleEvent} event - custom header checkbox event.
     * @group Emits
     */
    __publicField(this, "onHeaderCheckboxToggle", new EventEmitter());
    /**
     * A function to implement custom sorting, refer to sorting section for details.
     * @param {any} any - sort meta.
     * @group Emits
     */
    __publicField(this, "sortFunction", new EventEmitter());
    /**
     * Callback to invoke on pagination.
     * @param {number} number - first element.
     * @group Emits
     */
    __publicField(this, "firstChange", new EventEmitter());
    /**
     * Callback to invoke on rows change.
     * @param {number} number - Row count.
     * @group Emits
     */
    __publicField(this, "rowsChange", new EventEmitter());
    /**
     * Callback to invoke table state is saved.
     * @param {TableState} object - table state.
     * @group Emits
     */
    __publicField(this, "onStateSave", new EventEmitter());
    /**
     * Callback to invoke table state is restored.
     * @param {TableState} object - table state.
     * @group Emits
     */
    __publicField(this, "onStateRestore", new EventEmitter());
    __publicField(this, "containerViewChild");
    __publicField(this, "resizeHelperViewChild");
    __publicField(this, "reorderIndicatorUpViewChild");
    __publicField(this, "reorderIndicatorDownViewChild");
    __publicField(this, "wrapperViewChild");
    __publicField(this, "tableViewChild");
    __publicField(this, "tableHeaderViewChild");
    __publicField(this, "tableFooterViewChild");
    __publicField(this, "scroller");
    __publicField(this, "templates");
    __publicField(this, "_virtualRowHeight", 28);
    __publicField(this, "_value", []);
    __publicField(this, "_columns");
    __publicField(this, "_totalRecords", 0);
    __publicField(this, "_first", 0);
    __publicField(this, "_rows");
    __publicField(this, "filteredValue");
    __publicField(this, "headerTemplate");
    __publicField(this, "headerGroupedTemplate");
    __publicField(this, "bodyTemplate");
    __publicField(this, "loadingBodyTemplate");
    __publicField(this, "captionTemplate");
    __publicField(this, "footerTemplate");
    __publicField(this, "footerGroupedTemplate");
    __publicField(this, "summaryTemplate");
    __publicField(this, "colGroupTemplate");
    __publicField(this, "expandedRowTemplate");
    __publicField(this, "groupHeaderTemplate");
    __publicField(this, "groupFooterTemplate");
    __publicField(this, "frozenExpandedRowTemplate");
    __publicField(this, "frozenHeaderTemplate");
    __publicField(this, "frozenBodyTemplate");
    __publicField(this, "frozenFooterTemplate");
    __publicField(this, "frozenColGroupTemplate");
    __publicField(this, "emptyMessageTemplate");
    __publicField(this, "paginatorLeftTemplate");
    __publicField(this, "paginatorRightTemplate");
    __publicField(this, "paginatorDropdownItemTemplate");
    __publicField(this, "loadingIconTemplate");
    __publicField(this, "reorderIndicatorUpIconTemplate");
    __publicField(this, "reorderIndicatorDownIconTemplate");
    __publicField(this, "sortIconTemplate");
    __publicField(this, "checkboxIconTemplate");
    __publicField(this, "headerCheckboxIconTemplate");
    __publicField(this, "paginatorFirstPageLinkIconTemplate");
    __publicField(this, "paginatorLastPageLinkIconTemplate");
    __publicField(this, "paginatorPreviousPageLinkIconTemplate");
    __publicField(this, "paginatorNextPageLinkIconTemplate");
    __publicField(this, "selectionKeys", {});
    __publicField(this, "lastResizerHelperX");
    __publicField(this, "reorderIconWidth");
    __publicField(this, "reorderIconHeight");
    __publicField(this, "draggedColumn");
    __publicField(this, "draggedRowIndex");
    __publicField(this, "droppedRowIndex");
    __publicField(this, "rowDragging");
    __publicField(this, "dropPosition");
    __publicField(this, "editingCell");
    __publicField(this, "editingCellData");
    __publicField(this, "editingCellField");
    __publicField(this, "editingCellRowIndex");
    __publicField(this, "selfClick");
    __publicField(this, "documentEditListener");
    __publicField(this, "_multiSortMeta");
    __publicField(this, "_sortField");
    __publicField(this, "_sortOrder", 1);
    __publicField(this, "preventSelectionSetterPropagation");
    __publicField(this, "_selection");
    __publicField(this, "_selectAll", null);
    __publicField(this, "anchorRowIndex");
    __publicField(this, "rangeRowIndex");
    __publicField(this, "filterTimeout");
    __publicField(this, "initialized");
    __publicField(this, "rowTouched");
    __publicField(this, "restoringSort");
    __publicField(this, "restoringFilter");
    __publicField(this, "stateRestored");
    __publicField(this, "columnOrderStateRestored");
    __publicField(this, "columnWidthsState");
    __publicField(this, "tableWidthState");
    __publicField(this, "overlaySubscription");
    __publicField(this, "resizeColumnElement");
    __publicField(this, "columnResizing", false);
    __publicField(this, "rowGroupHeaderStyleObject", {});
    __publicField(this, "id", UniqueComponentId());
    __publicField(this, "styleElement");
    __publicField(this, "responsiveStyleElement");
    __publicField(this, "window");
    __publicField(this, "_initialColWidths");
    this.document = document;
    this.platformId = platformId;
    this.renderer = renderer;
    this.el = el;
    this.zone = zone;
    this.tableService = tableService;
    this.cd = cd;
    this.filterService = filterService;
    this.overlayService = overlayService;
    this.window = this.document.defaultView;
  }
  /**
   * Defines if the table is responsive.
   * @group Props
   * @deprecated table is always responsive with scrollable behavior.
   */
  get responsive() {
    return this._responsive;
  }
  set responsive(val) {
    this._responsive = val;
    console.warn("responsive property is deprecated as table is always responsive with scrollable behavior.");
  }
  /**
   * No description available.
   * @param {TableSelectAllChangeEvent} event - custom  all selection change event.
   * @group Emits
   */
  /**
   * An array of objects to display.
   * @group Props
   */
  get value() {
    return this._value;
  }
  set value(val) {
    this._value = val;
  }
  /**
   * An array of objects to represent dynamic columns.
   * @group Props
   */
  get columns() {
    return this._columns;
  }
  set columns(cols) {
    this._columns = cols;
  }
  /**
   * Index of the first row to be displayed.
   * @group Props
   */
  get first() {
    return this._first;
  }
  set first(val) {
    this._first = val;
  }
  /**
   * Number of rows to display per page.
   * @group Props
   */
  get rows() {
    return this._rows;
  }
  set rows(val) {
    this._rows = val;
  }
  /**
   * Number of total records, defaults to length of value when not defined.
   * @group Props
   */
  get totalRecords() {
    return this._totalRecords;
  }
  set totalRecords(val) {
    this._totalRecords = val;
    this.tableService.onTotalRecordsChange(this._totalRecords);
  }
  /**
   * Name of the field to sort data by default.
   * @group Props
   */
  get sortField() {
    return this._sortField;
  }
  set sortField(val) {
    this._sortField = val;
  }
  /**
   * Order to sort when default sorting is enabled.
   * @group Props
   */
  get sortOrder() {
    return this._sortOrder;
  }
  set sortOrder(val) {
    this._sortOrder = val;
  }
  /**
   * An array of SortMeta objects to sort the data by default in multiple sort mode.
   * @group Props
   */
  get multiSortMeta() {
    return this._multiSortMeta;
  }
  set multiSortMeta(val) {
    this._multiSortMeta = val;
  }
  /**
   * Selected row in single mode or an array of values in multiple mode.
   * @group Props
   */
  get selection() {
    return this._selection;
  }
  set selection(val) {
    this._selection = val;
  }
  /**
   * Whether all data is selected.
   * @group Props
   */
  get selectAll() {
    return this._selection;
  }
  set selectAll(val) {
    this._selection = val;
  }
  /**
   * Indicates the height of rows to be scrolled.
   * @group Props
   * @deprecated use virtualScrollItemSize property instead.
   */
  get virtualRowHeight() {
    return this._virtualRowHeight;
  }
  set virtualRowHeight(val) {
    this._virtualRowHeight = val;
    console.warn("The virtualRowHeight property is deprecated.");
  }
  ngOnInit() {
    if (this.lazy && this.lazyLoadOnInit) {
      if (!this.virtualScroll) {
        this.onLazyLoad.emit(this.createLazyLoadMetadata());
      }
      if (this.restoringFilter) {
        this.restoringFilter = false;
      }
    }
    if (this.responsiveLayout === "stack" && !this.scrollable) {
      this.createResponsiveStyle();
    }
    this.initialized = true;
  }
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "caption":
          this.captionTemplate = item.template;
          break;
        case "header":
          this.headerTemplate = item.template;
          break;
        case "headergrouped":
          this.headerGroupedTemplate = item.template;
          break;
        case "body":
          this.bodyTemplate = item.template;
          break;
        case "loadingbody":
          this.loadingBodyTemplate = item.template;
          break;
        case "footer":
          this.footerTemplate = item.template;
          break;
        case "footergrouped":
          this.footerGroupedTemplate = item.template;
          break;
        case "summary":
          this.summaryTemplate = item.template;
          break;
        case "colgroup":
          this.colGroupTemplate = item.template;
          break;
        case "rowexpansion":
          this.expandedRowTemplate = item.template;
          break;
        case "groupheader":
          this.groupHeaderTemplate = item.template;
          break;
        case "groupfooter":
          this.groupFooterTemplate = item.template;
          break;
        case "frozenheader":
          this.frozenHeaderTemplate = item.template;
          break;
        case "frozenbody":
          this.frozenBodyTemplate = item.template;
          break;
        case "frozenfooter":
          this.frozenFooterTemplate = item.template;
          break;
        case "frozencolgroup":
          this.frozenColGroupTemplate = item.template;
          break;
        case "frozenrowexpansion":
          this.frozenExpandedRowTemplate = item.template;
          break;
        case "emptymessage":
          this.emptyMessageTemplate = item.template;
          break;
        case "paginatorleft":
          this.paginatorLeftTemplate = item.template;
          break;
        case "paginatorright":
          this.paginatorRightTemplate = item.template;
          break;
        case "paginatordropdownitem":
          this.paginatorDropdownItemTemplate = item.template;
          break;
        case "paginatorfirstpagelinkicon":
          this.paginatorFirstPageLinkIconTemplate = item.template;
          break;
        case "paginatorlastpagelinkicon":
          this.paginatorLastPageLinkIconTemplate = item.template;
          break;
        case "paginatorpreviouspagelinkicon":
          this.paginatorPreviousPageLinkIconTemplate = item.template;
          break;
        case "paginatornextpagelinkicon":
          this.paginatorNextPageLinkIconTemplate = item.template;
          break;
        case "loadingicon":
          this.loadingIconTemplate = item.template;
          break;
        case "reorderindicatorupicon":
          this.reorderIndicatorUpIconTemplate = item.template;
          break;
        case "reorderindicatordownicon":
          this.reorderIndicatorDownIconTemplate = item.template;
          break;
        case "sorticon":
          this.sortIconTemplate = item.template;
          break;
        case "checkboxicon":
          this.checkboxIconTemplate = item.template;
          break;
        case "headercheckboxicon":
          this.headerCheckboxIconTemplate = item.template;
          break;
      }
    });
  }
  ngAfterViewInit() {
    if (this.isStateful() && this.resizableColumns) {
      this.restoreColumnWidths();
    }
  }
  ngOnChanges(simpleChange) {
    if (simpleChange.value) {
      if (this.isStateful() && !this.stateRestored) {
        this.restoreState();
      }
      this._value = simpleChange.value.currentValue;
      if (!this.lazy) {
        this.totalRecords = this._value ? this._value.length : 0;
        if (this.sortMode == "single" && (this.sortField || this.groupRowsBy))
          this.sortSingle();
        else if (this.sortMode == "multiple" && (this.multiSortMeta || this.groupRowsBy))
          this.sortMultiple();
        else if (this.hasFilter())
          this._filter();
      }
      this.tableService.onValueChange(simpleChange.value.currentValue);
    }
    if (simpleChange.columns) {
      this._columns = simpleChange.columns.currentValue;
      this.tableService.onColumnsChange(simpleChange.columns.currentValue);
      if (this._columns && this.isStateful() && this.reorderableColumns && !this.columnOrderStateRestored) {
        this.restoreColumnOrder();
      }
    }
    if (simpleChange.sortField) {
      this._sortField = simpleChange.sortField.currentValue;
      if (!this.lazy || this.initialized) {
        if (this.sortMode === "single") {
          this.sortSingle();
        }
      }
    }
    if (simpleChange.groupRowsBy) {
      if (!this.lazy || this.initialized) {
        if (this.sortMode === "single") {
          this.sortSingle();
        }
      }
    }
    if (simpleChange.sortOrder) {
      this._sortOrder = simpleChange.sortOrder.currentValue;
      if (!this.lazy || this.initialized) {
        if (this.sortMode === "single") {
          this.sortSingle();
        }
      }
    }
    if (simpleChange.groupRowsByOrder) {
      if (!this.lazy || this.initialized) {
        if (this.sortMode === "single") {
          this.sortSingle();
        }
      }
    }
    if (simpleChange.multiSortMeta) {
      this._multiSortMeta = simpleChange.multiSortMeta.currentValue;
      if (this.sortMode === "multiple" && (this.initialized || !this.lazy && !this.virtualScroll)) {
        this.sortMultiple();
      }
    }
    if (simpleChange.selection) {
      this._selection = simpleChange.selection.currentValue;
      if (!this.preventSelectionSetterPropagation) {
        this.updateSelectionKeys();
        this.tableService.onSelectionChange();
      }
      this.preventSelectionSetterPropagation = false;
    }
    if (simpleChange.selectAll) {
      this._selectAll = simpleChange.selectAll.currentValue;
      if (!this.preventSelectionSetterPropagation) {
        this.updateSelectionKeys();
        this.tableService.onSelectionChange();
        if (this.isStateful()) {
          this.saveState();
        }
      }
      this.preventSelectionSetterPropagation = false;
    }
  }
  get processedData() {
    return this.filteredValue || this.value || [];
  }
  dataToRender(data) {
    const _data = data || this.processedData;
    if (_data && this.paginator) {
      const first = this.lazy ? 0 : this.first;
      return _data.slice(first, first + this.rows);
    }
    return _data;
  }
  updateSelectionKeys() {
    if (this.dataKey && this._selection) {
      this.selectionKeys = {};
      if (Array.isArray(this._selection)) {
        for (let data of this._selection) {
          this.selectionKeys[String(ObjectUtils.resolveFieldData(data, this.dataKey))] = 1;
        }
      } else {
        this.selectionKeys[String(ObjectUtils.resolveFieldData(this._selection, this.dataKey))] = 1;
      }
    }
  }
  onPageChange(event2) {
    this.first = event2.first;
    this.rows = event2.rows;
    this.onPage.emit({
      first: this.first,
      rows: this.rows
    });
    if (this.lazy) {
      this.onLazyLoad.emit(this.createLazyLoadMetadata());
    }
    this.firstChange.emit(this.first);
    this.rowsChange.emit(this.rows);
    this.tableService.onValueChange(this.value);
    if (this.isStateful()) {
      this.saveState();
    }
    this.anchorRowIndex = null;
    if (this.scrollable) {
      this.resetScrollTop();
    }
  }
  sort(event2) {
    let originalEvent = event2.originalEvent;
    if (this.sortMode === "single") {
      this._sortOrder = this.sortField === event2.field ? this.sortOrder * -1 : this.defaultSortOrder;
      this._sortField = event2.field;
      if (this.resetPageOnSort) {
        this._first = 0;
        this.firstChange.emit(this._first);
        if (this.scrollable) {
          this.resetScrollTop();
        }
      }
      this.sortSingle();
    }
    if (this.sortMode === "multiple") {
      let metaKey = originalEvent.metaKey || originalEvent.ctrlKey;
      let sortMeta = this.getSortMeta(event2.field);
      if (sortMeta) {
        if (!metaKey) {
          this._multiSortMeta = [{
            field: event2.field,
            order: sortMeta.order * -1
          }];
          if (this.resetPageOnSort) {
            this._first = 0;
            this.firstChange.emit(this._first);
            if (this.scrollable) {
              this.resetScrollTop();
            }
          }
        } else {
          sortMeta.order = sortMeta.order * -1;
        }
      } else {
        if (!metaKey || !this.multiSortMeta) {
          this._multiSortMeta = [];
          if (this.resetPageOnSort) {
            this._first = 0;
            this.firstChange.emit(this._first);
          }
        }
        this._multiSortMeta.push({
          field: event2.field,
          order: this.defaultSortOrder
        });
      }
      this.sortMultiple();
    }
    if (this.isStateful()) {
      this.saveState();
    }
    this.anchorRowIndex = null;
  }
  sortSingle() {
    let field = this.sortField || this.groupRowsBy;
    let order = this.sortField ? this.sortOrder : this.groupRowsByOrder;
    if (this.groupRowsBy && this.sortField && this.groupRowsBy !== this.sortField) {
      this._multiSortMeta = [this.getGroupRowsMeta(), {
        field: this.sortField,
        order: this.sortOrder
      }];
      this.sortMultiple();
      return;
    }
    if (field && order) {
      if (this.restoringSort) {
        this.restoringSort = false;
      }
      if (this.lazy) {
        this.onLazyLoad.emit(this.createLazyLoadMetadata());
      } else if (this.value) {
        if (this.customSort) {
          this.sortFunction.emit({
            data: this.value,
            mode: this.sortMode,
            field,
            order
          });
        } else {
          this.value.sort((data1, data2) => {
            let value1 = ObjectUtils.resolveFieldData(data1, field);
            let value2 = ObjectUtils.resolveFieldData(data2, field);
            let result = null;
            if (value1 == null && value2 != null)
              result = -1;
            else if (value1 != null && value2 == null)
              result = 1;
            else if (value1 == null && value2 == null)
              result = 0;
            else if (typeof value1 === "string" && typeof value2 === "string")
              result = value1.localeCompare(value2);
            else
              result = value1 < value2 ? -1 : value1 > value2 ? 1 : 0;
            return order * result;
          });
          this._value = [...this.value];
        }
        if (this.hasFilter()) {
          this._filter();
        }
      }
      let sortMeta = {
        field,
        order
      };
      this.onSort.emit(sortMeta);
      this.tableService.onSort(sortMeta);
    }
  }
  sortMultiple() {
    if (this.groupRowsBy) {
      if (!this._multiSortMeta)
        this._multiSortMeta = [this.getGroupRowsMeta()];
      else if (this.multiSortMeta[0].field !== this.groupRowsBy)
        this._multiSortMeta = [this.getGroupRowsMeta(), ...this._multiSortMeta];
    }
    if (this.multiSortMeta) {
      if (this.lazy) {
        this.onLazyLoad.emit(this.createLazyLoadMetadata());
      } else if (this.value) {
        if (this.customSort) {
          this.sortFunction.emit({
            data: this.value,
            mode: this.sortMode,
            multiSortMeta: this.multiSortMeta
          });
        } else {
          this.value.sort((data1, data2) => {
            return this.multisortField(data1, data2, this.multiSortMeta, 0);
          });
          this._value = [...this.value];
        }
        if (this.hasFilter()) {
          this._filter();
        }
      }
      this.onSort.emit({
        multisortmeta: this.multiSortMeta
      });
      this.tableService.onSort(this.multiSortMeta);
    }
  }
  multisortField(data1, data2, multiSortMeta, index) {
    const value1 = ObjectUtils.resolveFieldData(data1, multiSortMeta[index].field);
    const value2 = ObjectUtils.resolveFieldData(data2, multiSortMeta[index].field);
    if (ObjectUtils.compare(value1, value2, this.filterLocale) === 0) {
      return multiSortMeta.length - 1 > index ? this.multisortField(data1, data2, multiSortMeta, index + 1) : 0;
    }
    return this.compareValuesOnSort(value1, value2, multiSortMeta[index].order);
  }
  compareValuesOnSort(value1, value2, order) {
    return ObjectUtils.sort(value1, value2, order, this.filterLocale, this.sortOrder);
  }
  getSortMeta(field) {
    if (this.multiSortMeta && this.multiSortMeta.length) {
      for (let i = 0; i < this.multiSortMeta.length; i++) {
        if (this.multiSortMeta[i].field === field) {
          return this.multiSortMeta[i];
        }
      }
    }
    return null;
  }
  isSorted(field) {
    if (this.sortMode === "single") {
      return this.sortField && this.sortField === field;
    } else if (this.sortMode === "multiple") {
      let sorted = false;
      if (this.multiSortMeta) {
        for (let i = 0; i < this.multiSortMeta.length; i++) {
          if (this.multiSortMeta[i].field == field) {
            sorted = true;
            break;
          }
        }
      }
      return sorted;
    }
  }
  handleRowClick(event2) {
    let target = event2.originalEvent.target;
    let targetNode = target.nodeName;
    let parentNode = target.parentElement && target.parentElement.nodeName;
    if (targetNode == "INPUT" || targetNode == "BUTTON" || targetNode == "A" || parentNode == "INPUT" || parentNode == "BUTTON" || parentNode == "A" || DomHandler.hasClass(event2.originalEvent.target, "p-clickable")) {
      return;
    }
    if (this.selectionMode) {
      let rowData = event2.rowData;
      let rowIndex = event2.rowIndex;
      this.preventSelectionSetterPropagation = true;
      if (this.isMultipleSelectionMode() && event2.originalEvent.shiftKey && this.anchorRowIndex != null) {
        DomHandler.clearSelection();
        if (this.rangeRowIndex != null) {
          this.clearSelectionRange(event2.originalEvent);
        }
        this.rangeRowIndex = rowIndex;
        this.selectRange(event2.originalEvent, rowIndex);
      } else {
        let selected = this.isSelected(rowData);
        if (!selected && !this.isRowSelectable(rowData, rowIndex)) {
          return;
        }
        let metaSelection = this.rowTouched ? false : this.metaKeySelection;
        let dataKeyValue = this.dataKey ? String(ObjectUtils.resolveFieldData(rowData, this.dataKey)) : null;
        this.anchorRowIndex = rowIndex;
        this.rangeRowIndex = rowIndex;
        if (metaSelection) {
          let metaKey = event2.originalEvent.metaKey || event2.originalEvent.ctrlKey;
          if (selected && metaKey) {
            if (this.isSingleSelectionMode()) {
              this._selection = null;
              this.selectionKeys = {};
              this.selectionChange.emit(null);
            } else {
              let selectionIndex = this.findIndexInSelection(rowData);
              this._selection = this.selection.filter((val, i) => i != selectionIndex);
              this.selectionChange.emit(this.selection);
              if (dataKeyValue) {
                delete this.selectionKeys[dataKeyValue];
              }
            }
            this.onRowUnselect.emit({
              originalEvent: event2.originalEvent,
              data: rowData,
              type: "row"
            });
          } else {
            if (this.isSingleSelectionMode()) {
              this._selection = rowData;
              this.selectionChange.emit(rowData);
              if (dataKeyValue) {
                this.selectionKeys = {};
                this.selectionKeys[dataKeyValue] = 1;
              }
            } else if (this.isMultipleSelectionMode()) {
              if (metaKey) {
                this._selection = this.selection || [];
              } else {
                this._selection = [];
                this.selectionKeys = {};
              }
              this._selection = [...this.selection, rowData];
              this.selectionChange.emit(this.selection);
              if (dataKeyValue) {
                this.selectionKeys[dataKeyValue] = 1;
              }
            }
            this.onRowSelect.emit({
              originalEvent: event2.originalEvent,
              data: rowData,
              type: "row",
              index: rowIndex
            });
          }
        } else {
          if (this.selectionMode === "single") {
            if (selected) {
              this._selection = null;
              this.selectionKeys = {};
              this.selectionChange.emit(this.selection);
              this.onRowUnselect.emit({
                originalEvent: event2.originalEvent,
                data: rowData,
                type: "row",
                index: rowIndex
              });
            } else {
              this._selection = rowData;
              this.selectionChange.emit(this.selection);
              this.onRowSelect.emit({
                originalEvent: event2.originalEvent,
                data: rowData,
                type: "row",
                index: rowIndex
              });
              if (dataKeyValue) {
                this.selectionKeys = {};
                this.selectionKeys[dataKeyValue] = 1;
              }
            }
          } else if (this.selectionMode === "multiple") {
            if (selected) {
              let selectionIndex = this.findIndexInSelection(rowData);
              this._selection = this.selection.filter((val, i) => i != selectionIndex);
              this.selectionChange.emit(this.selection);
              this.onRowUnselect.emit({
                originalEvent: event2.originalEvent,
                data: rowData,
                type: "row",
                index: rowIndex
              });
              if (dataKeyValue) {
                delete this.selectionKeys[dataKeyValue];
              }
            } else {
              this._selection = this.selection ? [...this.selection, rowData] : [rowData];
              this.selectionChange.emit(this.selection);
              this.onRowSelect.emit({
                originalEvent: event2.originalEvent,
                data: rowData,
                type: "row",
                index: rowIndex
              });
              if (dataKeyValue) {
                this.selectionKeys[dataKeyValue] = 1;
              }
            }
          }
        }
      }
      this.tableService.onSelectionChange();
      if (this.isStateful()) {
        this.saveState();
      }
    }
    this.rowTouched = false;
  }
  handleRowTouchEnd(event2) {
    this.rowTouched = true;
  }
  handleRowRightClick(event2) {
    if (this.contextMenu) {
      const rowData = event2.rowData;
      const rowIndex = event2.rowIndex;
      if (this.contextMenuSelectionMode === "separate") {
        this.contextMenuSelection = rowData;
        this.contextMenuSelectionChange.emit(rowData);
        this.onContextMenuSelect.emit({
          originalEvent: event2.originalEvent,
          data: rowData,
          index: event2.rowIndex
        });
        this.contextMenu.show(event2.originalEvent);
        this.tableService.onContextMenu(rowData);
      } else if (this.contextMenuSelectionMode === "joint") {
        this.preventSelectionSetterPropagation = true;
        let selected = this.isSelected(rowData);
        let dataKeyValue = this.dataKey ? String(ObjectUtils.resolveFieldData(rowData, this.dataKey)) : null;
        if (!selected) {
          if (!this.isRowSelectable(rowData, rowIndex)) {
            return;
          }
          if (this.isSingleSelectionMode()) {
            this.selection = rowData;
            this.selectionChange.emit(rowData);
            if (dataKeyValue) {
              this.selectionKeys = {};
              this.selectionKeys[dataKeyValue] = 1;
            }
          } else if (this.isMultipleSelectionMode()) {
            this._selection = this.selection ? [...this.selection, rowData] : [rowData];
            this.selectionChange.emit(this.selection);
            if (dataKeyValue) {
              this.selectionKeys[dataKeyValue] = 1;
            }
          }
        }
        this.tableService.onSelectionChange();
        this.contextMenu.show(event2.originalEvent);
        this.onContextMenuSelect.emit({
          originalEvent: event2,
          data: rowData,
          index: event2.rowIndex
        });
      }
    }
  }
  selectRange(event2, rowIndex) {
    let rangeStart, rangeEnd;
    if (this.anchorRowIndex > rowIndex) {
      rangeStart = rowIndex;
      rangeEnd = this.anchorRowIndex;
    } else if (this.anchorRowIndex < rowIndex) {
      rangeStart = this.anchorRowIndex;
      rangeEnd = rowIndex;
    } else {
      rangeStart = rowIndex;
      rangeEnd = rowIndex;
    }
    if (this.lazy && this.paginator) {
      rangeStart -= this.first;
      rangeStart -= this.first;
    }
    let rangeRowsData = [];
    for (let i = rangeStart; i <= rangeEnd; i++) {
      let rangeRowData = this.filteredValue ? this.filteredValue[i] : this.value[i];
      if (!this.isSelected(rangeRowData)) {
        if (!this.isRowSelectable(rangeRowData, rowIndex)) {
          continue;
        }
        rangeRowsData.push(rangeRowData);
        this._selection = [...this.selection, rangeRowData];
        let dataKeyValue = this.dataKey ? String(ObjectUtils.resolveFieldData(rangeRowData, this.dataKey)) : null;
        if (dataKeyValue) {
          this.selectionKeys[dataKeyValue] = 1;
        }
      }
    }
    this.selectionChange.emit(this.selection);
    this.onRowSelect.emit({
      originalEvent: event2,
      data: rangeRowsData,
      type: "row"
    });
  }
  clearSelectionRange(event2) {
    let rangeStart, rangeEnd;
    let rangeRowIndex = this.rangeRowIndex;
    let anchorRowIndex = this.anchorRowIndex;
    if (rangeRowIndex > anchorRowIndex) {
      rangeStart = this.anchorRowIndex;
      rangeEnd = this.rangeRowIndex;
    } else if (rangeRowIndex < anchorRowIndex) {
      rangeStart = this.rangeRowIndex;
      rangeEnd = this.anchorRowIndex;
    } else {
      rangeStart = this.rangeRowIndex;
      rangeEnd = this.rangeRowIndex;
    }
    for (let i = rangeStart; i <= rangeEnd; i++) {
      let rangeRowData = this.value[i];
      let selectionIndex = this.findIndexInSelection(rangeRowData);
      this._selection = this.selection.filter((val, i2) => i2 != selectionIndex);
      let dataKeyValue = this.dataKey ? String(ObjectUtils.resolveFieldData(rangeRowData, this.dataKey)) : null;
      if (dataKeyValue) {
        delete this.selectionKeys[dataKeyValue];
      }
      this.onRowUnselect.emit({
        originalEvent: event2,
        data: rangeRowData,
        type: "row"
      });
    }
  }
  isSelected(rowData) {
    if (rowData && this.selection) {
      if (this.dataKey) {
        return this.selectionKeys[ObjectUtils.resolveFieldData(rowData, this.dataKey)] !== void 0;
      } else {
        if (Array.isArray(this.selection))
          return this.findIndexInSelection(rowData) > -1;
        else
          return this.equals(rowData, this.selection);
      }
    }
    return false;
  }
  findIndexInSelection(rowData) {
    let index = -1;
    if (this.selection && this.selection.length) {
      for (let i = 0; i < this.selection.length; i++) {
        if (this.equals(rowData, this.selection[i])) {
          index = i;
          break;
        }
      }
    }
    return index;
  }
  isRowSelectable(data, index) {
    if (this.rowSelectable && !this.rowSelectable({
      data,
      index
    })) {
      return false;
    }
    return true;
  }
  toggleRowWithRadio(event2, rowData) {
    this.preventSelectionSetterPropagation = true;
    if (this.selection != rowData) {
      if (!this.isRowSelectable(rowData, event2.rowIndex)) {
        return;
      }
      this._selection = rowData;
      this.selectionChange.emit(this.selection);
      this.onRowSelect.emit({
        originalEvent: event2.originalEvent,
        index: event2.rowIndex,
        data: rowData,
        type: "radiobutton"
      });
      if (this.dataKey) {
        this.selectionKeys = {};
        this.selectionKeys[String(ObjectUtils.resolveFieldData(rowData, this.dataKey))] = 1;
      }
    } else {
      this._selection = null;
      this.selectionChange.emit(this.selection);
      this.onRowUnselect.emit({
        originalEvent: event2.originalEvent,
        index: event2.rowIndex,
        data: rowData,
        type: "radiobutton"
      });
    }
    this.tableService.onSelectionChange();
    if (this.isStateful()) {
      this.saveState();
    }
  }
  toggleRowWithCheckbox(event2, rowData) {
    this.selection = this.selection || [];
    let selected = this.isSelected(rowData);
    let dataKeyValue = this.dataKey ? String(ObjectUtils.resolveFieldData(rowData, this.dataKey)) : null;
    this.preventSelectionSetterPropagation = true;
    if (selected) {
      let selectionIndex = this.findIndexInSelection(rowData);
      this._selection = this.selection.filter((val, i) => i != selectionIndex);
      this.selectionChange.emit(this.selection);
      this.onRowUnselect.emit({
        originalEvent: event2.originalEvent,
        index: event2.rowIndex,
        data: rowData,
        type: "checkbox"
      });
      if (dataKeyValue) {
        delete this.selectionKeys[dataKeyValue];
      }
    } else {
      if (!this.isRowSelectable(rowData, event2.rowIndex)) {
        return;
      }
      this._selection = this.selection ? [...this.selection, rowData] : [rowData];
      this.selectionChange.emit(this.selection);
      this.onRowSelect.emit({
        originalEvent: event2.originalEvent,
        index: event2.rowIndex,
        data: rowData,
        type: "checkbox"
      });
      if (dataKeyValue) {
        this.selectionKeys[dataKeyValue] = 1;
      }
    }
    this.tableService.onSelectionChange();
    if (this.isStateful()) {
      this.saveState();
    }
  }
  toggleRowsWithCheckbox(event2, check) {
    if (this._selectAll !== null) {
      this.selectAllChange.emit({
        originalEvent: event2,
        checked: check
      });
    } else {
      const data = this.selectionPageOnly ? this.dataToRender(this.processedData) : this.processedData;
      let selection = this.selectionPageOnly && this._selection ? this._selection.filter((s) => !data.some((d) => this.equals(s, d))) : [];
      if (check) {
        selection = this.frozenValue ? [...selection, ...this.frozenValue, ...data] : [...selection, ...data];
        selection = this.rowSelectable ? selection.filter((data2, index) => this.rowSelectable({
          data: data2,
          index
        })) : selection;
      }
      this._selection = selection;
      this.preventSelectionSetterPropagation = true;
      this.updateSelectionKeys();
      this.selectionChange.emit(this._selection);
      this.tableService.onSelectionChange();
      this.onHeaderCheckboxToggle.emit({
        originalEvent: event2,
        checked: check
      });
      if (this.isStateful()) {
        this.saveState();
      }
    }
  }
  equals(data1, data2) {
    return this.compareSelectionBy === "equals" ? data1 === data2 : ObjectUtils.equals(data1, data2, this.dataKey);
  }
  /* Legacy Filtering for custom elements */
  filter(value, field, matchMode) {
    if (this.filterTimeout) {
      clearTimeout(this.filterTimeout);
    }
    if (!this.isFilterBlank(value)) {
      this.filters[field] = {
        value,
        matchMode
      };
    } else if (this.filters[field]) {
      delete this.filters[field];
    }
    this.filterTimeout = setTimeout(() => {
      this._filter();
      this.filterTimeout = null;
    }, this.filterDelay);
    this.anchorRowIndex = null;
  }
  filterGlobal(value, matchMode) {
    this.filter(value, "global", matchMode);
  }
  isFilterBlank(filter) {
    if (filter !== null && filter !== void 0) {
      if (typeof filter === "string" && filter.trim().length == 0 || Array.isArray(filter) && filter.length == 0)
        return true;
      else
        return false;
    }
    return true;
  }
  _filter() {
    if (!this.restoringFilter) {
      this.first = 0;
      this.firstChange.emit(this.first);
    }
    if (this.lazy) {
      this.onLazyLoad.emit(this.createLazyLoadMetadata());
    } else {
      if (!this.value) {
        return;
      }
      if (!this.hasFilter()) {
        this.filteredValue = null;
        if (this.paginator) {
          this.totalRecords = this.value ? this.value.length : 0;
        }
      } else {
        let globalFilterFieldsArray;
        if (this.filters["global"]) {
          if (!this.columns && !this.globalFilterFields)
            throw new Error("Global filtering requires dynamic columns or globalFilterFields to be defined.");
          else
            globalFilterFieldsArray = this.globalFilterFields || this.columns;
        }
        this.filteredValue = [];
        for (let i = 0; i < this.value.length; i++) {
          let localMatch = true;
          let globalMatch = false;
          let localFiltered = false;
          for (let prop in this.filters) {
            if (this.filters.hasOwnProperty(prop) && prop !== "global") {
              localFiltered = true;
              let filterField = prop;
              let filterMeta = this.filters[filterField];
              if (Array.isArray(filterMeta)) {
                for (let meta of filterMeta) {
                  localMatch = this.executeLocalFilter(filterField, this.value[i], meta);
                  if (meta.operator === FilterOperator.OR && localMatch || meta.operator === FilterOperator.AND && !localMatch) {
                    break;
                  }
                }
              } else {
                localMatch = this.executeLocalFilter(filterField, this.value[i], filterMeta);
              }
              if (!localMatch) {
                break;
              }
            }
          }
          if (this.filters["global"] && !globalMatch && globalFilterFieldsArray) {
            for (let j = 0; j < globalFilterFieldsArray.length; j++) {
              let globalFilterField = globalFilterFieldsArray[j].field || globalFilterFieldsArray[j];
              globalMatch = this.filterService.filters[this.filters["global"].matchMode](ObjectUtils.resolveFieldData(this.value[i], globalFilterField), this.filters["global"].value, this.filterLocale);
              if (globalMatch) {
                break;
              }
            }
          }
          let matches;
          if (this.filters["global"]) {
            matches = localFiltered ? localFiltered && localMatch && globalMatch : globalMatch;
          } else {
            matches = localFiltered && localMatch;
          }
          if (matches) {
            this.filteredValue.push(this.value[i]);
          }
        }
        if (this.filteredValue.length === this.value.length) {
          this.filteredValue = null;
        }
        if (this.paginator) {
          this.totalRecords = this.filteredValue ? this.filteredValue.length : this.value ? this.value.length : 0;
        }
      }
    }
    this.onFilter.emit({
      filters: this.filters,
      filteredValue: this.filteredValue || this.value
    });
    this.tableService.onValueChange(this.value);
    if (this.isStateful() && !this.restoringFilter) {
      this.saveState();
    }
    if (this.restoringFilter) {
      this.restoringFilter = false;
    }
    this.cd.markForCheck();
    if (this.scrollable) {
      this.resetScrollTop();
    }
  }
  executeLocalFilter(field, rowData, filterMeta) {
    let filterValue = filterMeta.value;
    let filterMatchMode = filterMeta.matchMode || FilterMatchMode.STARTS_WITH;
    let dataFieldValue = ObjectUtils.resolveFieldData(rowData, field);
    let filterConstraint = this.filterService.filters[filterMatchMode];
    return filterConstraint(dataFieldValue, filterValue, this.filterLocale);
  }
  hasFilter() {
    let empty = true;
    for (let prop in this.filters) {
      if (this.filters.hasOwnProperty(prop)) {
        empty = false;
        break;
      }
    }
    return !empty;
  }
  createLazyLoadMetadata() {
    return {
      first: this.first,
      rows: this.rows,
      sortField: this.sortField,
      sortOrder: this.sortOrder,
      filters: this.filters,
      globalFilter: this.filters && this.filters["global"] ? this.filters["global"].value : null,
      multiSortMeta: this.multiSortMeta,
      forceUpdate: () => this.cd.detectChanges()
    };
  }
  clear() {
    this._sortField = null;
    this._sortOrder = this.defaultSortOrder;
    this._multiSortMeta = null;
    this.tableService.onSort(null);
    this.clearFilterValues();
    this.filteredValue = null;
    this.first = 0;
    this.firstChange.emit(this.first);
    if (this.lazy) {
      this.onLazyLoad.emit(this.createLazyLoadMetadata());
    } else {
      this.totalRecords = this._value ? this._value.length : 0;
    }
  }
  clearFilterValues() {
    for (const [, filterMetadata] of Object.entries(this.filters)) {
      if (Array.isArray(filterMetadata)) {
        for (let filter of filterMetadata) {
          filter.value = null;
        }
      } else if (filterMetadata) {
        filterMetadata.value = null;
      }
    }
  }
  reset() {
    this.clear();
  }
  getExportHeader(column) {
    return column[this.exportHeader] || column.header || column.field;
  }
  /**
   * Data export method.
   * @param {Object} object - Export options.
   * @group Method
   */
  exportCSV(options) {
    let data;
    let csv = "";
    let columns = this.columns;
    if (options && options.selectionOnly) {
      data = this.selection || [];
    } else if (options && options.allValues) {
      data = this.value || [];
    } else {
      data = this.filteredValue || this.value;
      if (this.frozenValue) {
        data = data ? [...this.frozenValue, ...data] : this.frozenValue;
      }
    }
    for (let i = 0; i < columns.length; i++) {
      let column = columns[i];
      if (column.exportable !== false && column.field) {
        csv += '"' + this.getExportHeader(column) + '"';
        if (i < columns.length - 1) {
          csv += this.csvSeparator;
        }
      }
    }
    data.forEach((record, i) => {
      csv += "\n";
      for (let i2 = 0; i2 < columns.length; i2++) {
        let column = columns[i2];
        if (column.exportable !== false && column.field) {
          let cellData = ObjectUtils.resolveFieldData(record, column.field);
          if (cellData != null) {
            if (this.exportFunction) {
              cellData = this.exportFunction({
                data: cellData,
                field: column.field
              });
            } else
              cellData = String(cellData).replace(/"/g, '""');
          } else
            cellData = "";
          csv += '"' + cellData + '"';
          if (i2 < columns.length - 1) {
            csv += this.csvSeparator;
          }
        }
      }
    });
    let blob = new Blob([csv], {
      type: "text/csv;charset=utf-8;"
    });
    let link = this.renderer.createElement("a");
    link.style.display = "none";
    this.renderer.appendChild(this.document.body, link);
    if (link.download !== void 0) {
      link.setAttribute("href", URL.createObjectURL(blob));
      link.setAttribute("download", this.exportFilename + ".csv");
      link.click();
    } else {
      csv = "data:text/csv;charset=utf-8," + csv;
      this.window.open(encodeURI(csv));
    }
    this.renderer.removeChild(this.document.body, link);
  }
  onLazyItemLoad(event2) {
    this.onLazyLoad.emit({
      ...this.createLazyLoadMetadata(),
      ...event2,
      rows: event2.last - event2.first
    });
  }
  /**
   * Resets scroll to top.
   * @group Method
   */
  resetScrollTop() {
    if (this.virtualScroll)
      this.scrollToVirtualIndex(0);
    else
      this.scrollTo({
        top: 0
      });
  }
  /**
   * Scrolls to given index when using virtual scroll.
   * @param {number} index - index of the element.
   * @group Method
   */
  scrollToVirtualIndex(index) {
    this.scroller && this.scroller.scrollToIndex(index);
  }
  /**
   * Scrolls to given index.
   * @param {ScrollToOptions} options - scroll options.
   * @group Method
   */
  scrollTo(options) {
    var _a;
    if (this.virtualScroll) {
      (_a = this.scroller) == null ? void 0 : _a.scrollTo(options);
    } else if (this.wrapperViewChild && this.wrapperViewChild.nativeElement) {
      if (this.wrapperViewChild.nativeElement.scrollTo) {
        this.wrapperViewChild.nativeElement.scrollTo(options);
      } else {
        this.wrapperViewChild.nativeElement.scrollLeft = options.left;
        this.wrapperViewChild.nativeElement.scrollTop = options.top;
      }
    }
  }
  updateEditingCell(cell, data, field, index) {
    this.editingCell = cell;
    this.editingCellData = data;
    this.editingCellField = field;
    this.editingCellRowIndex = index;
    this.bindDocumentEditListener();
  }
  isEditingCellValid() {
    return this.editingCell && DomHandler.find(this.editingCell, ".ng-invalid.ng-dirty").length === 0;
  }
  bindDocumentEditListener() {
    if (!this.documentEditListener) {
      this.documentEditListener = this.renderer.listen(this.document, "click", (event2) => {
        if (this.editingCell && !this.selfClick && this.isEditingCellValid()) {
          DomHandler.removeClass(this.editingCell, "p-cell-editing");
          this.editingCell = null;
          this.onEditComplete.emit({
            field: this.editingCellField,
            data: this.editingCellData,
            originalEvent: event2,
            index: this.editingCellRowIndex
          });
          this.editingCellField = null;
          this.editingCellData = null;
          this.editingCellRowIndex = null;
          this.unbindDocumentEditListener();
          this.cd.markForCheck();
          if (this.overlaySubscription) {
            this.overlaySubscription.unsubscribe();
          }
        }
        this.selfClick = false;
      });
    }
  }
  unbindDocumentEditListener() {
    if (this.documentEditListener) {
      this.documentEditListener();
      this.documentEditListener = null;
    }
  }
  initRowEdit(rowData) {
    let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey));
    this.editingRowKeys[dataKeyValue] = true;
  }
  saveRowEdit(rowData, rowElement) {
    if (DomHandler.find(rowElement, ".ng-invalid.ng-dirty").length === 0) {
      let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey));
      delete this.editingRowKeys[dataKeyValue];
    }
  }
  cancelRowEdit(rowData) {
    let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey));
    delete this.editingRowKeys[dataKeyValue];
  }
  toggleRow(rowData, event2) {
    if (!this.dataKey) {
      throw new Error("dataKey must be defined to use row expansion");
    }
    let dataKeyValue = String(ObjectUtils.resolveFieldData(rowData, this.dataKey));
    if (this.expandedRowKeys[dataKeyValue] != null) {
      delete this.expandedRowKeys[dataKeyValue];
      this.onRowCollapse.emit({
        originalEvent: event2,
        data: rowData
      });
    } else {
      if (this.rowExpandMode === "single") {
        this.expandedRowKeys = {};
      }
      this.expandedRowKeys[dataKeyValue] = true;
      this.onRowExpand.emit({
        originalEvent: event2,
        data: rowData
      });
    }
    if (event2) {
      event2.preventDefault();
    }
    if (this.isStateful()) {
      this.saveState();
    }
  }
  isRowExpanded(rowData) {
    return this.expandedRowKeys[String(ObjectUtils.resolveFieldData(rowData, this.dataKey))] === true;
  }
  isRowEditing(rowData) {
    return this.editingRowKeys[String(ObjectUtils.resolveFieldData(rowData, this.dataKey))] === true;
  }
  isSingleSelectionMode() {
    return this.selectionMode === "single";
  }
  isMultipleSelectionMode() {
    return this.selectionMode === "multiple";
  }
  onColumnResizeBegin(event2) {
    var _a, _b;
    let containerLeft = DomHandler.getOffset((_a = this.containerViewChild) == null ? void 0 : _a.nativeElement).left;
    this.resizeColumnElement = event2.target.parentElement;
    this.columnResizing = true;
    this.lastResizerHelperX = event2.pageX - containerLeft + ((_b = this.containerViewChild) == null ? void 0 : _b.nativeElement.scrollLeft);
    this.onColumnResize(event2);
    event2.preventDefault();
  }
  onColumnResize(event2) {
    var _a, _b, _c, _d;
    let containerLeft = DomHandler.getOffset((_a = this.containerViewChild) == null ? void 0 : _a.nativeElement).left;
    DomHandler.addClass((_b = this.containerViewChild) == null ? void 0 : _b.nativeElement, "p-unselectable-text");
    this.resizeHelperViewChild.nativeElement.style.height = ((_c = this.containerViewChild) == null ? void 0 : _c.nativeElement.offsetHeight) + "px";
    this.resizeHelperViewChild.nativeElement.style.top = "0px";
    this.resizeHelperViewChild.nativeElement.style.left = event2.pageX - containerLeft + ((_d = this.containerViewChild) == null ? void 0 : _d.nativeElement.scrollLeft) + "px";
    this.resizeHelperViewChild.nativeElement.style.display = "block";
  }
  onColumnResizeEnd() {
    var _a, _b, _c;
    let delta = ((_a = this.resizeHelperViewChild) == null ? void 0 : _a.nativeElement.offsetLeft) - this.lastResizerHelperX;
    let columnWidth = this.resizeColumnElement.offsetWidth;
    let newColumnWidth = columnWidth + delta;
    let minWidth = this.resizeColumnElement.style.minWidth.replace(/[^\d.]/g, "") || 15;
    if (newColumnWidth >= minWidth) {
      if (this.columnResizeMode === "fit") {
        let nextColumn = this.resizeColumnElement.nextElementSibling;
        let nextColumnWidth = nextColumn.offsetWidth - delta;
        if (newColumnWidth > 15 && nextColumnWidth > 15) {
          this.resizeTableCells(newColumnWidth, nextColumnWidth);
        }
      } else if (this.columnResizeMode === "expand") {
        this._initialColWidths = this._totalTableWidth();
        let tableWidth = ((_b = this.tableViewChild) == null ? void 0 : _b.nativeElement.offsetWidth) + delta;
        this.setResizeTableWidth(tableWidth + "px");
        this.resizeTableCells(newColumnWidth, null);
      }
      this.onColResize.emit({
        element: this.resizeColumnElement,
        delta
      });
      if (this.isStateful()) {
        this.saveState();
      }
    }
    this.resizeHelperViewChild.nativeElement.style.display = "none";
    DomHandler.removeClass((_c = this.containerViewChild) == null ? void 0 : _c.nativeElement, "p-unselectable-text");
  }
  _totalTableWidth() {
    let widths = [];
    const tableHead = DomHandler.findSingle(this.containerViewChild.nativeElement, ".p-datatable-thead");
    let headers = DomHandler.find(tableHead, "tr > th");
    headers.forEach((header) => widths.push(DomHandler.getOuterWidth(header)));
    return widths;
  }
  resizeTableCells(newColumnWidth, nextColumnWidth) {
    let colIndex = DomHandler.index(this.resizeColumnElement);
    let width = this.columnResizeMode === "expand" ? this._initialColWidths : this._totalTableWidth();
    this.destroyStyleElement();
    this.createStyleElement();
    let innerHTML = "";
    width.forEach((width2, index) => {
      let colWidth = index === colIndex ? newColumnWidth : nextColumnWidth && index === colIndex + 1 ? nextColumnWidth : width2;
      let style2 = `width: ${colWidth}px !important; max-width: ${colWidth}px !important;`;
      innerHTML += `
                #${this.id}-table > .p-datatable-thead > tr > th:nth-child(${index + 1}),
                #${this.id}-table > .p-datatable-tbody > tr > td:nth-child(${index + 1}),
                #${this.id}-table > .p-datatable-tfoot > tr > td:nth-child(${index + 1}) {
                    ${style2}
                }
            `;
    });
    this.renderer.setProperty(this.styleElement, "innerHTML", innerHTML);
  }
  onColumnDragStart(event2, columnElement) {
    var _a, _b;
    this.reorderIconWidth = DomHandler.getHiddenElementOuterWidth((_a = this.reorderIndicatorUpViewChild) == null ? void 0 : _a.nativeElement);
    this.reorderIconHeight = DomHandler.getHiddenElementOuterHeight((_b = this.reorderIndicatorDownViewChild) == null ? void 0 : _b.nativeElement);
    this.draggedColumn = columnElement;
    event2.dataTransfer.setData("text", "b");
  }
  onColumnDragEnter(event2, dropHeader) {
    var _a;
    if (this.reorderableColumns && this.draggedColumn && dropHeader) {
      event2.preventDefault();
      let containerOffset = DomHandler.getOffset((_a = this.containerViewChild) == null ? void 0 : _a.nativeElement);
      let dropHeaderOffset = DomHandler.getOffset(dropHeader);
      if (this.draggedColumn != dropHeader) {
        let dragIndex = DomHandler.indexWithinGroup(this.draggedColumn, "preorderablecolumn");
        let dropIndex = DomHandler.indexWithinGroup(dropHeader, "preorderablecolumn");
        let targetLeft = dropHeaderOffset.left - containerOffset.left;
        let targetTop = containerOffset.top - dropHeaderOffset.top;
        let columnCenter = dropHeaderOffset.left + dropHeader.offsetWidth / 2;
        this.reorderIndicatorUpViewChild.nativeElement.style.top = dropHeaderOffset.top - containerOffset.top - (this.reorderIconHeight - 1) + "px";
        this.reorderIndicatorDownViewChild.nativeElement.style.top = dropHeaderOffset.top - containerOffset.top + dropHeader.offsetHeight + "px";
        if (event2.pageX > columnCenter) {
          this.reorderIndicatorUpViewChild.nativeElement.style.left = targetLeft + dropHeader.offsetWidth - Math.ceil(this.reorderIconWidth / 2) + "px";
          this.reorderIndicatorDownViewChild.nativeElement.style.left = targetLeft + dropHeader.offsetWidth - Math.ceil(this.reorderIconWidth / 2) + "px";
          this.dropPosition = 1;
        } else {
          this.reorderIndicatorUpViewChild.nativeElement.style.left = targetLeft - Math.ceil(this.reorderIconWidth / 2) + "px";
          this.reorderIndicatorDownViewChild.nativeElement.style.left = targetLeft - Math.ceil(this.reorderIconWidth / 2) + "px";
          this.dropPosition = -1;
        }
        this.reorderIndicatorUpViewChild.nativeElement.style.display = "block";
        this.reorderIndicatorDownViewChild.nativeElement.style.display = "block";
      } else {
        event2.dataTransfer.dropEffect = "none";
      }
    }
  }
  onColumnDragLeave(event2) {
    if (this.reorderableColumns && this.draggedColumn) {
      event2.preventDefault();
    }
  }
  onColumnDrop(event2, dropColumn) {
    event2.preventDefault();
    if (this.draggedColumn) {
      let dragIndex = DomHandler.indexWithinGroup(this.draggedColumn, "preorderablecolumn");
      let dropIndex = DomHandler.indexWithinGroup(dropColumn, "preorderablecolumn");
      let allowDrop = dragIndex != dropIndex;
      if (allowDrop && (dropIndex - dragIndex == 1 && this.dropPosition === -1 || dragIndex - dropIndex == 1 && this.dropPosition === 1)) {
        allowDrop = false;
      }
      if (allowDrop && dropIndex < dragIndex && this.dropPosition === 1) {
        dropIndex = dropIndex + 1;
      }
      if (allowDrop && dropIndex > dragIndex && this.dropPosition === -1) {
        dropIndex = dropIndex - 1;
      }
      if (allowDrop) {
        ObjectUtils.reorderArray(this.columns, dragIndex, dropIndex);
        this.onColReorder.emit({
          dragIndex,
          dropIndex,
          columns: this.columns
        });
        if (this.isStateful()) {
          this.zone.runOutsideAngular(() => {
            setTimeout(() => {
              this.saveState();
            });
          });
        }
      }
      this.reorderIndicatorUpViewChild.nativeElement.style.display = "none";
      this.reorderIndicatorDownViewChild.nativeElement.style.display = "none";
      this.draggedColumn.draggable = false;
      this.draggedColumn = null;
      this.dropPosition = null;
    }
  }
  onRowDragStart(event2, index) {
    this.rowDragging = true;
    this.draggedRowIndex = index;
    event2.dataTransfer.setData("text", "b");
  }
  onRowDragOver(event2, index, rowElement) {
    if (this.rowDragging && this.draggedRowIndex !== index) {
      let rowY = DomHandler.getOffset(rowElement).top;
      let pageY = event2.pageY;
      let rowMidY = rowY + DomHandler.getOuterHeight(rowElement) / 2;
      let prevRowElement = rowElement.previousElementSibling;
      if (pageY < rowMidY) {
        DomHandler.removeClass(rowElement, "p-datatable-dragpoint-bottom");
        this.droppedRowIndex = index;
        if (prevRowElement)
          DomHandler.addClass(prevRowElement, "p-datatable-dragpoint-bottom");
        else
          DomHandler.addClass(rowElement, "p-datatable-dragpoint-top");
      } else {
        if (prevRowElement)
          DomHandler.removeClass(prevRowElement, "p-datatable-dragpoint-bottom");
        else
          DomHandler.addClass(rowElement, "p-datatable-dragpoint-top");
        this.droppedRowIndex = index + 1;
        DomHandler.addClass(rowElement, "p-datatable-dragpoint-bottom");
      }
    }
  }
  onRowDragLeave(event2, rowElement) {
    let prevRowElement = rowElement.previousElementSibling;
    if (prevRowElement) {
      DomHandler.removeClass(prevRowElement, "p-datatable-dragpoint-bottom");
    }
    DomHandler.removeClass(rowElement, "p-datatable-dragpoint-bottom");
    DomHandler.removeClass(rowElement, "p-datatable-dragpoint-top");
  }
  onRowDragEnd(event2) {
    this.rowDragging = false;
    this.draggedRowIndex = null;
    this.droppedRowIndex = null;
  }
  onRowDrop(event2, rowElement) {
    if (this.droppedRowIndex != null) {
      let dropIndex = this.draggedRowIndex > this.droppedRowIndex ? this.droppedRowIndex : this.droppedRowIndex === 0 ? 0 : this.droppedRowIndex - 1;
      ObjectUtils.reorderArray(this.value, this.draggedRowIndex, dropIndex);
      if (this.virtualScroll) {
        this._value = [...this._value];
      }
      this.onRowReorder.emit({
        dragIndex: this.draggedRowIndex,
        dropIndex
      });
    }
    this.onRowDragLeave(event2, rowElement);
    this.onRowDragEnd(event2);
  }
  isEmpty() {
    let data = this.filteredValue || this.value;
    return data == null || data.length == 0;
  }
  getBlockableElement() {
    return this.el.nativeElement.children[0];
  }
  getStorage() {
    if (isPlatformBrowser(this.platformId)) {
      switch (this.stateStorage) {
        case "local":
          return window.localStorage;
        case "session":
          return window.sessionStorage;
        default:
          throw new Error(this.stateStorage + ' is not a valid value for the state storage, supported values are "local" and "session".');
      }
    } else {
      throw new Error("Browser storage is not available in the server side.");
    }
  }
  isStateful() {
    return this.stateKey != null;
  }
  saveState() {
    const storage = this.getStorage();
    let state2 = {};
    if (this.paginator) {
      state2.first = this.first;
      state2.rows = this.rows;
    }
    if (this.sortField) {
      state2.sortField = this.sortField;
      state2.sortOrder = this.sortOrder;
    }
    if (this.multiSortMeta) {
      state2.multiSortMeta = this.multiSortMeta;
    }
    if (this.hasFilter()) {
      state2.filters = this.filters;
    }
    if (this.resizableColumns) {
      this.saveColumnWidths(state2);
    }
    if (this.reorderableColumns) {
      this.saveColumnOrder(state2);
    }
    if (this.selection) {
      state2.selection = this.selection;
    }
    if (Object.keys(this.expandedRowKeys).length) {
      state2.expandedRowKeys = this.expandedRowKeys;
    }
    storage.setItem(this.stateKey, JSON.stringify(state2));
    this.onStateSave.emit(state2);
  }
  clearState() {
    const storage = this.getStorage();
    if (this.stateKey) {
      storage.removeItem(this.stateKey);
    }
  }
  restoreState() {
    const storage = this.getStorage();
    const stateString = storage.getItem(this.stateKey);
    const dateFormat = /\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}.\d{3}Z/;
    const reviver = function(key, value) {
      if (typeof value === "string" && dateFormat.test(value)) {
        return new Date(value);
      }
      return value;
    };
    if (stateString) {
      let state2 = JSON.parse(stateString, reviver);
      if (this.paginator) {
        if (this.first !== void 0) {
          this.first = state2.first;
          this.firstChange.emit(this.first);
        }
        if (this.rows !== void 0) {
          this.rows = state2.rows;
          this.rowsChange.emit(this.rows);
        }
      }
      if (state2.sortField) {
        this.restoringSort = true;
        this._sortField = state2.sortField;
        this._sortOrder = state2.sortOrder;
      }
      if (state2.multiSortMeta) {
        this.restoringSort = true;
        this._multiSortMeta = state2.multiSortMeta;
      }
      if (state2.filters) {
        this.restoringFilter = true;
        this.filters = state2.filters;
      }
      if (this.resizableColumns) {
        this.columnWidthsState = state2.columnWidths;
        this.tableWidthState = state2.tableWidth;
      }
      if (state2.expandedRowKeys) {
        this.expandedRowKeys = state2.expandedRowKeys;
      }
      if (state2.selection) {
        Promise.resolve(null).then(() => this.selectionChange.emit(state2.selection));
      }
      this.stateRestored = true;
      this.onStateRestore.emit(state2);
    }
  }
  saveColumnWidths(state2) {
    var _a, _b;
    let widths = [];
    let headers = DomHandler.find((_a = this.containerViewChild) == null ? void 0 : _a.nativeElement, ".p-datatable-thead > tr > th");
    headers.forEach((header) => widths.push(DomHandler.getOuterWidth(header)));
    state2.columnWidths = widths.join(",");
    if (this.columnResizeMode === "expand") {
      state2.tableWidth = DomHandler.getOuterWidth((_b = this.tableViewChild) == null ? void 0 : _b.nativeElement);
    }
  }
  setResizeTableWidth(width) {
    this.tableViewChild.nativeElement.style.width = width;
    this.tableViewChild.nativeElement.style.minWidth = width;
  }
  restoreColumnWidths() {
    if (this.columnWidthsState) {
      let widths = this.columnWidthsState.split(",");
      if (this.columnResizeMode === "expand" && this.tableWidthState) {
        this.setResizeTableWidth(this.tableWidthState + "px");
      }
      if (ObjectUtils.isNotEmpty(widths)) {
        this.createStyleElement();
        let innerHTML = "";
        widths.forEach((width, index) => {
          let style2 = `width: ${width}px !important; max-width: ${width}px !important`;
          innerHTML += `
                        #${this.id}-table > .p-datatable-thead > tr > th:nth-child(${index + 1}),
                        #${this.id}-table > .p-datatable-tbody > tr > td:nth-child(${index + 1}),
                        #${this.id}-table > .p-datatable-tfoot > tr > td:nth-child(${index + 1}) {
                            ${style2}
                        }
                    `;
        });
        this.styleElement.innerHTML = innerHTML;
      }
    }
  }
  saveColumnOrder(state2) {
    if (this.columns) {
      let columnOrder = [];
      this.columns.map((column) => {
        columnOrder.push(column.field || column.key);
      });
      state2.columnOrder = columnOrder;
    }
  }
  restoreColumnOrder() {
    const storage = this.getStorage();
    const stateString = storage.getItem(this.stateKey);
    if (stateString) {
      let state2 = JSON.parse(stateString);
      let columnOrder = state2.columnOrder;
      if (columnOrder) {
        let reorderedColumns = [];
        columnOrder.map((key) => {
          let col = this.findColumnByKey(key);
          if (col) {
            reorderedColumns.push(col);
          }
        });
        this.columnOrderStateRestored = true;
        this.columns = reorderedColumns;
      }
    }
  }
  findColumnByKey(key) {
    if (this.columns) {
      for (let col of this.columns) {
        if (col.key === key || col.field === key)
          return col;
        else
          continue;
      }
    } else {
      return null;
    }
  }
  createStyleElement() {
    this.styleElement = this.renderer.createElement("style");
    this.styleElement.type = "text/css";
    this.renderer.appendChild(this.document.head, this.styleElement);
  }
  getGroupRowsMeta() {
    return {
      field: this.groupRowsBy,
      order: this.groupRowsByOrder
    };
  }
  createResponsiveStyle() {
    if (isPlatformBrowser(this.platformId)) {
      if (!this.responsiveStyleElement) {
        this.responsiveStyleElement = this.renderer.createElement("style");
        this.responsiveStyleElement.type = "text/css";
        this.renderer.appendChild(this.document.head, this.responsiveStyleElement);
        let innerHTML = `
    @media screen and (max-width: ${this.breakpoint}) {
        #${this.id}-table > .p-datatable-thead > tr > th,
        #${this.id}-table > .p-datatable-tfoot > tr > td {
            display: none !important;
        }
    
        #${this.id}-table > .p-datatable-tbody > tr > td {
            display: flex;
            width: 100% !important;
            align-items: center;
            justify-content: space-between;
        }
    
        #${this.id}-table > .p-datatable-tbody > tr > td:not(:last-child) {
            border: 0 none;
        }
    
        #${this.id}.p-datatable-gridlines > .p-datatable-wrapper > .p-datatable-table > .p-datatable-tbody > tr > td:last-child {
            border-top: 0;
            border-right: 0;
            border-left: 0;
        }
    
        #${this.id}-table > .p-datatable-tbody > tr > td > .p-column-title {
            display: block;
        }
    }
    `;
        this.renderer.setProperty(this.responsiveStyleElement, "innerHTML", innerHTML);
      }
    }
  }
  destroyResponsiveStyle() {
    if (this.responsiveStyleElement) {
      this.renderer.removeChild(this.document.head, this.responsiveStyleElement);
      this.responsiveStyleElement = null;
    }
  }
  destroyStyleElement() {
    if (this.styleElement) {
      this.renderer.removeChild(this.document.head, this.styleElement);
      this.styleElement = null;
    }
  }
  ngOnDestroy() {
    this.unbindDocumentEditListener();
    this.editingCell = null;
    this.initialized = null;
    this.destroyStyleElement();
    this.destroyResponsiveStyle();
  }
};
var Table = _Table;
__publicField(Table, "ɵfac", function Table_Factory(t) {
  return new (t || _Table)(ɵɵdirectiveInject(DOCUMENT), ɵɵdirectiveInject(PLATFORM_ID), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone), ɵɵdirectiveInject(TableService), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(FilterService), ɵɵdirectiveInject(OverlayService));
});
__publicField(Table, "ɵcmp", ɵɵdefineComponent({
  type: _Table,
  selectors: [["p-table"]],
  contentQueries: function Table_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  viewQuery: function Table_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c08, 5);
      ɵɵviewQuery(_c111, 5);
      ɵɵviewQuery(_c27, 5);
      ɵɵviewQuery(_c35, 5);
      ɵɵviewQuery(_c45, 5);
      ɵɵviewQuery(_c55, 5);
      ɵɵviewQuery(_c65, 5);
      ɵɵviewQuery(_c75, 5);
      ɵɵviewQuery(_c84, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.containerViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.resizeHelperViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.reorderIndicatorUpViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.reorderIndicatorDownViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.wrapperViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.tableViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.tableHeaderViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.tableFooterViewChild = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.scroller = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    frozenColumns: "frozenColumns",
    frozenValue: "frozenValue",
    style: "style",
    styleClass: "styleClass",
    tableStyle: "tableStyle",
    tableStyleClass: "tableStyleClass",
    paginator: "paginator",
    pageLinks: "pageLinks",
    rowsPerPageOptions: "rowsPerPageOptions",
    alwaysShowPaginator: "alwaysShowPaginator",
    paginatorPosition: "paginatorPosition",
    paginatorDropdownAppendTo: "paginatorDropdownAppendTo",
    paginatorDropdownScrollHeight: "paginatorDropdownScrollHeight",
    currentPageReportTemplate: "currentPageReportTemplate",
    showCurrentPageReport: "showCurrentPageReport",
    showJumpToPageDropdown: "showJumpToPageDropdown",
    showJumpToPageInput: "showJumpToPageInput",
    showFirstLastIcon: "showFirstLastIcon",
    showPageLinks: "showPageLinks",
    defaultSortOrder: "defaultSortOrder",
    sortMode: "sortMode",
    resetPageOnSort: "resetPageOnSort",
    selectionMode: "selectionMode",
    selectionPageOnly: "selectionPageOnly",
    contextMenuSelection: "contextMenuSelection",
    contextMenuSelectionMode: "contextMenuSelectionMode",
    dataKey: "dataKey",
    metaKeySelection: "metaKeySelection",
    rowSelectable: "rowSelectable",
    rowTrackBy: "rowTrackBy",
    lazy: "lazy",
    lazyLoadOnInit: "lazyLoadOnInit",
    compareSelectionBy: "compareSelectionBy",
    csvSeparator: "csvSeparator",
    exportFilename: "exportFilename",
    filters: "filters",
    globalFilterFields: "globalFilterFields",
    filterDelay: "filterDelay",
    filterLocale: "filterLocale",
    expandedRowKeys: "expandedRowKeys",
    editingRowKeys: "editingRowKeys",
    rowExpandMode: "rowExpandMode",
    scrollable: "scrollable",
    scrollDirection: "scrollDirection",
    rowGroupMode: "rowGroupMode",
    scrollHeight: "scrollHeight",
    virtualScroll: "virtualScroll",
    virtualScrollItemSize: "virtualScrollItemSize",
    virtualScrollOptions: "virtualScrollOptions",
    virtualScrollDelay: "virtualScrollDelay",
    frozenWidth: "frozenWidth",
    responsive: "responsive",
    contextMenu: "contextMenu",
    resizableColumns: "resizableColumns",
    columnResizeMode: "columnResizeMode",
    reorderableColumns: "reorderableColumns",
    loading: "loading",
    loadingIcon: "loadingIcon",
    showLoader: "showLoader",
    rowHover: "rowHover",
    customSort: "customSort",
    showInitialSortBadge: "showInitialSortBadge",
    autoLayout: "autoLayout",
    exportFunction: "exportFunction",
    exportHeader: "exportHeader",
    stateKey: "stateKey",
    stateStorage: "stateStorage",
    editMode: "editMode",
    groupRowsBy: "groupRowsBy",
    groupRowsByOrder: "groupRowsByOrder",
    responsiveLayout: "responsiveLayout",
    breakpoint: "breakpoint",
    value: "value",
    columns: "columns",
    first: "first",
    rows: "rows",
    totalRecords: "totalRecords",
    sortField: "sortField",
    sortOrder: "sortOrder",
    multiSortMeta: "multiSortMeta",
    selection: "selection",
    selectAll: "selectAll",
    virtualRowHeight: "virtualRowHeight"
  },
  outputs: {
    contextMenuSelectionChange: "contextMenuSelectionChange",
    selectAllChange: "selectAllChange",
    selectionChange: "selectionChange",
    onRowSelect: "onRowSelect",
    onRowUnselect: "onRowUnselect",
    onPage: "onPage",
    onSort: "onSort",
    onFilter: "onFilter",
    onLazyLoad: "onLazyLoad",
    onRowExpand: "onRowExpand",
    onRowCollapse: "onRowCollapse",
    onContextMenuSelect: "onContextMenuSelect",
    onColResize: "onColResize",
    onColReorder: "onColReorder",
    onRowReorder: "onRowReorder",
    onEditInit: "onEditInit",
    onEditComplete: "onEditComplete",
    onEditCancel: "onEditCancel",
    onHeaderCheckboxToggle: "onHeaderCheckboxToggle",
    sortFunction: "sortFunction",
    firstChange: "firstChange",
    rowsChange: "rowsChange",
    onStateSave: "onStateSave",
    onStateRestore: "onStateRestore"
  },
  features: [ɵɵProvidersFeature([TableService]), ɵɵNgOnChangesFeature],
  decls: 16,
  vars: 22,
  consts: [[3, "ngStyle", "ngClass"], ["container", ""], ["class", "p-datatable-loading-overlay p-component-overlay", 4, "ngIf"], ["class", "p-datatable-header", 4, "ngIf"], ["styleClass", "p-paginator-top", 3, "rows", "first", "totalRecords", "pageLinkSize", "alwaysShow", "rowsPerPageOptions", "templateLeft", "templateRight", "dropdownAppendTo", "dropdownScrollHeight", "currentPageReportTemplate", "showFirstLastIcon", "dropdownItemTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showPageLinks", "onPageChange", 4, "ngIf"], [1, "p-datatable-wrapper", 3, "ngStyle"], ["wrapper", ""], [3, "items", "columns", "style", "scrollHeight", "itemSize", "step", "delay", "inline", "lazy", "loaderDisabled", "showSpacer", "showLoader", "options", "autoSize", "onLazyLoad", 4, "ngIf"], [4, "ngIf"], ["buildInTable", ""], ["styleClass", "p-paginator-bottom", 3, "rows", "first", "totalRecords", "pageLinkSize", "alwaysShow", "rowsPerPageOptions", "templateLeft", "templateRight", "dropdownAppendTo", "dropdownScrollHeight", "currentPageReportTemplate", "showFirstLastIcon", "dropdownItemTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showPageLinks", "onPageChange", 4, "ngIf"], ["class", "p-datatable-footer", 4, "ngIf"], ["class", "p-column-resizer-helper", "style", "display:none", 4, "ngIf"], ["class", "p-datatable-reorder-indicator-up", "style", "display: none;", 4, "ngIf"], ["class", "p-datatable-reorder-indicator-down", "style", "display: none;", 4, "ngIf"], [1, "p-datatable-loading-overlay", "p-component-overlay"], [3, "class", 4, "ngIf"], [3, "spin", "styleClass", 4, "ngIf"], ["class", "p-datatable-loading-icon", 4, "ngIf"], [3, "spin", "styleClass"], [1, "p-datatable-loading-icon"], [4, "ngTemplateOutlet"], [1, "p-datatable-header"], ["styleClass", "p-paginator-top", 3, "rows", "first", "totalRecords", "pageLinkSize", "alwaysShow", "rowsPerPageOptions", "templateLeft", "templateRight", "dropdownAppendTo", "dropdownScrollHeight", "currentPageReportTemplate", "showFirstLastIcon", "dropdownItemTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showPageLinks", "onPageChange"], ["pTemplate", "firstpagelinkicon"], ["pTemplate", "previouspagelinkicon"], ["pTemplate", "lastpagelinkicon"], ["pTemplate", "nextpagelinkicon"], [3, "items", "columns", "scrollHeight", "itemSize", "step", "delay", "inline", "lazy", "loaderDisabled", "showSpacer", "showLoader", "options", "autoSize", "onLazyLoad"], ["scroller", ""], ["pTemplate", "content"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["role", "table", 3, "ngClass"], ["table", ""], [1, "p-datatable-thead"], ["thead", ""], ["class", "p-datatable-tbody p-datatable-frozen-tbody", 3, "value", "frozenRows", "pTableBody", "pTableBodyTemplate", "frozen", 4, "ngIf"], [1, "p-datatable-tbody", 3, "ngClass", "value", "pTableBody", "pTableBodyTemplate", "scrollerOptions"], ["class", "p-datatable-scroller-spacer", 3, "style", 4, "ngIf"], ["class", "p-datatable-tfoot", 4, "ngIf"], [1, "p-datatable-tbody", "p-datatable-frozen-tbody", 3, "value", "frozenRows", "pTableBody", "pTableBodyTemplate", "frozen"], [1, "p-datatable-scroller-spacer"], [1, "p-datatable-tfoot"], ["tfoot", ""], ["styleClass", "p-paginator-bottom", 3, "rows", "first", "totalRecords", "pageLinkSize", "alwaysShow", "rowsPerPageOptions", "templateLeft", "templateRight", "dropdownAppendTo", "dropdownScrollHeight", "currentPageReportTemplate", "showFirstLastIcon", "dropdownItemTemplate", "showCurrentPageReport", "showJumpToPageDropdown", "showJumpToPageInput", "showPageLinks", "onPageChange"], [1, "p-datatable-footer"], [1, "p-column-resizer-helper", 2, "display", "none"], ["resizeHelper", ""], [1, "p-datatable-reorder-indicator-up", 2, "display", "none"], ["reorderIndicatorUp", ""], [1, "p-datatable-reorder-indicator-down", 2, "display", "none"], ["reorderIndicatorDown", ""]],
  template: function Table_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0, 1);
      ɵɵtemplate(2, Table_div_2_Template, 3, 2, "div", 2);
      ɵɵtemplate(3, Table_div_3_Template, 2, 1, "div", 3);
      ɵɵtemplate(4, Table_p_paginator_4_Template, 5, 21, "p-paginator", 4);
      ɵɵelementStart(5, "div", 5, 6);
      ɵɵtemplate(7, Table_p_scroller_7_Template, 3, 17, "p-scroller", 7);
      ɵɵtemplate(8, Table_ng_container_8_Template, 2, 7, "ng-container", 8);
      ɵɵtemplate(9, Table_ng_template_9_Template, 10, 28, "ng-template", null, 9, ɵɵtemplateRefExtractor);
      ɵɵelementEnd();
      ɵɵtemplate(11, Table_p_paginator_11_Template, 5, 21, "p-paginator", 10);
      ɵɵtemplate(12, Table_div_12_Template, 2, 1, "div", 11);
      ɵɵtemplate(13, Table_div_13_Template, 2, 0, "div", 12);
      ɵɵtemplate(14, Table_span_14_Template, 4, 2, "span", 13);
      ɵɵtemplate(15, Table_span_15_Template, 4, 2, "span", 14);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.styleClass);
      ɵɵproperty("ngStyle", ctx.style)("ngClass", ɵɵpureFunction3(16, _c143, ctx.rowHover || ctx.selectionMode, ctx.scrollable, ctx.scrollable && ctx.scrollHeight === "flex"));
      ɵɵattribute("id", ctx.id);
      ɵɵadvance(2);
      ɵɵproperty("ngIf", ctx.loading && ctx.showLoader);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.captionTemplate);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.paginator && (ctx.paginatorPosition === "top" || ctx.paginatorPosition == "both"));
      ɵɵadvance(1);
      ɵɵproperty("ngStyle", ɵɵpureFunction1(20, _c153, ctx.virtualScroll ? "" : ctx.scrollHeight));
      ɵɵadvance(2);
      ɵɵproperty("ngIf", ctx.virtualScroll);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", !ctx.virtualScroll);
      ɵɵadvance(3);
      ɵɵproperty("ngIf", ctx.paginator && (ctx.paginatorPosition === "bottom" || ctx.paginatorPosition == "both"));
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.summaryTemplate);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.resizableColumns);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.reorderableColumns);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.reorderableColumns);
    }
  },
  dependencies: function() {
    return [NgClass, NgIf, NgTemplateOutlet, NgStyle, Paginator, PrimeTemplate, Scroller, ArrowDownIcon, ArrowUpIcon, SpinnerIcon, TableBody];
  },
  styles: [".p-datatable{position:relative}.p-datatable>.p-datatable-wrapper{overflow:auto}.p-datatable-table{border-spacing:0px;width:100%}.p-datatable .p-sortable-column{cursor:pointer;-webkit-user-select:none;user-select:none}.p-datatable .p-sortable-column .p-column-title,.p-datatable .p-sortable-column .p-sortable-column-icon,.p-datatable .p-sortable-column .p-sortable-column-badge{vertical-align:middle}.p-datatable .p-sortable-column .p-icon-wrapper{display:inline}.p-datatable .p-sortable-column .p-sortable-column-badge{display:inline-flex;align-items:center;justify-content:center}.p-datatable-hoverable-rows .p-selectable-row{cursor:pointer}.p-datatable-scrollable>.p-datatable-wrapper{position:relative}.p-datatable-scrollable-table>.p-datatable-thead{position:sticky;top:0;z-index:1}.p-datatable-scrollable-table>.p-datatable-frozen-tbody{position:sticky;z-index:1}.p-datatable-scrollable-table>.p-datatable-tfoot{position:sticky;bottom:0;z-index:1}.p-datatable-scrollable .p-frozen-column{position:sticky;background:inherit}.p-datatable-scrollable th.p-frozen-column{z-index:1}.p-datatable-flex-scrollable{display:flex;flex-direction:column;height:100%}.p-datatable-flex-scrollable>.p-datatable-wrapper{display:flex;flex-direction:column;flex:1;height:100%}.p-datatable-scrollable-table>.p-datatable-tbody>.p-rowgroup-header{position:sticky;z-index:1}.p-datatable-resizable-table>.p-datatable-thead>tr>th,.p-datatable-resizable-table>.p-datatable-tfoot>tr>td,.p-datatable-resizable-table>.p-datatable-tbody>tr>td{overflow:hidden;white-space:nowrap}.p-datatable-resizable-table>.p-datatable-thead>tr>th.p-resizable-column:not(.p-frozen-column){background-clip:padding-box;position:relative}.p-datatable-resizable-table-fit>.p-datatable-thead>tr>th.p-resizable-column:last-child .p-column-resizer{display:none}.p-datatable .p-column-resizer{display:block;position:absolute!important;top:0;right:0;margin:0;width:.5rem;height:100%;padding:0;cursor:col-resize;border:1px solid transparent}.p-datatable .p-column-resizer-helper{width:1px;position:absolute;z-index:10;display:none}.p-datatable .p-row-editor-init,.p-datatable .p-row-editor-save,.p-datatable .p-row-editor-cancel,.p-datatable .p-row-toggler{display:inline-flex;align-items:center;justify-content:center;overflow:hidden;position:relative}.p-datatable-reorder-indicator-up,.p-datatable-reorder-indicator-down{position:absolute}.p-datatable-reorderablerow-handle,[pReorderableColumn]{cursor:move}.p-datatable .p-datatable-loading-overlay{position:absolute;display:flex;align-items:center;justify-content:center;z-index:2}.p-column-filter-row{display:flex;align-items:center;width:100%}.p-column-filter-menu{display:inline-flex}.p-column-filter-row p-columnfilterformelement{flex:1 1 auto;width:1%}.p-column-filter-menu-button,.p-column-filter-clear-button{display:inline-flex;justify-content:center;align-items:center;cursor:pointer;text-decoration:none;overflow:hidden;position:relative}.p-column-filter-overlay{position:absolute;top:0;left:0}.p-column-filter-row-items{margin:0;padding:0;list-style:none}.p-column-filter-row-item{cursor:pointer}.p-column-filter-add-button,.p-column-filter-remove-button{justify-content:center}.p-column-filter-add-button .p-button-label,.p-column-filter-remove-button .p-button-label{flex-grow:0}.p-column-filter-buttonbar{display:flex;align-items:center;justify-content:space-between}.p-column-filter-buttonbar .p-button{width:auto}.p-datatable-tbody>tr>td>.p-column-title{display:none}.p-datatable-scroller-spacer{display:flex}.p-datatable .p-scroller .p-scroller-loading{transform:none!important;min-height:0;position:sticky;top:0;left:0}\n"],
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Table, [{
    type: Component,
    args: [{
      selector: "p-table",
      template: `
        <div
            #container
            [ngStyle]="style"
            [class]="styleClass"
            [ngClass]="{ 'p-datatable p-component': true, 'p-datatable-hoverable-rows': rowHover || selectionMode, 'p-datatable-scrollable': scrollable, 'p-datatable-flex-scrollable': scrollable && scrollHeight === 'flex' }"
            [attr.id]="id"
        >
            <div class="p-datatable-loading-overlay p-component-overlay" *ngIf="loading && showLoader">
                <i *ngIf="loadingIcon" [class]="'p-datatable-loading-icon ' + loadingIcon"></i>
                <ng-container *ngIf="!loadingIcon">
                    <SpinnerIcon *ngIf="!loadingIconTemplate" [spin]="true" [styleClass]="'p-datatable-loading-icon'" />
                    <span *ngIf="loadingIconTemplate" class="p-datatable-loading-icon">
                        <ng-template *ngTemplateOutlet="loadingIconTemplate"></ng-template>
                    </span>
                </ng-container>
            </div>
            <div *ngIf="captionTemplate" class="p-datatable-header">
                <ng-container *ngTemplateOutlet="captionTemplate"></ng-container>
            </div>
            <p-paginator
                [rows]="rows"
                [first]="first"
                [totalRecords]="totalRecords"
                [pageLinkSize]="pageLinks"
                styleClass="p-paginator-top"
                [alwaysShow]="alwaysShowPaginator"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions"
                *ngIf="paginator && (paginatorPosition === 'top' || paginatorPosition == 'both')"
                [templateLeft]="paginatorLeftTemplate"
                [templateRight]="paginatorRightTemplate"
                [dropdownAppendTo]="paginatorDropdownAppendTo"
                [dropdownScrollHeight]="paginatorDropdownScrollHeight"
                [currentPageReportTemplate]="currentPageReportTemplate"
                [showFirstLastIcon]="showFirstLastIcon"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate"
                [showCurrentPageReport]="showCurrentPageReport"
                [showJumpToPageDropdown]="showJumpToPageDropdown"
                [showJumpToPageInput]="showJumpToPageInput"
                [showPageLinks]="showPageLinks"
            >
                <ng-template pTemplate="firstpagelinkicon" *ngIf="paginatorFirstPageLinkIconTemplate">
                    <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate"></ng-container>
                </ng-template>

                <ng-template pTemplate="previouspagelinkicon" *ngIf="paginatorPreviousPageLinkIconTemplate">
                    <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate"></ng-container>
                </ng-template>

                <ng-template pTemplate="lastpagelinkicon" *ngIf="paginatorLastPageLinkIconTemplate">
                    <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate"></ng-container>
                </ng-template>

                <ng-template pTemplate="nextpagelinkicon" *ngIf="paginatorNextPageLinkIconTemplate">
                    <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate"></ng-container>
                </ng-template>
            </p-paginator>

            <div #wrapper class="p-datatable-wrapper" [ngStyle]="{ maxHeight: virtualScroll ? '' : scrollHeight }">
                <p-scroller
                    #scroller
                    *ngIf="virtualScroll"
                    [items]="processedData"
                    [columns]="columns"
                    [style]="{ height: scrollHeight !== 'flex' ? scrollHeight : undefined }"
                    [scrollHeight]="scrollHeight !== 'flex' ? undefined : '100%'"
                    [itemSize]="virtualScrollItemSize || _virtualRowHeight"
                    [step]="rows"
                    [delay]="lazy ? virtualScrollDelay : 0"
                    [inline]="true"
                    [lazy]="lazy"
                    (onLazyLoad)="onLazyItemLoad($event)"
                    [loaderDisabled]="true"
                    [showSpacer]="false"
                    [showLoader]="loadingBodyTemplate"
                    [options]="virtualScrollOptions"
                    [autoSize]="true"
                >
                    <ng-template pTemplate="content" let-items let-scrollerOptions="options">
                        <ng-container *ngTemplateOutlet="buildInTable; context: { $implicit: items, options: scrollerOptions }"></ng-container>
                    </ng-template>
                </p-scroller>
                <ng-container *ngIf="!virtualScroll">
                    <ng-container *ngTemplateOutlet="buildInTable; context: { $implicit: processedData, options: { columns } }"></ng-container>
                </ng-container>

                <ng-template #buildInTable let-items let-scrollerOptions="options">
                    <table
                        #table
                        role="table"
                        [ngClass]="{ 'p-datatable-table': true, 'p-datatable-scrollable-table': scrollable, 'p-datatable-resizable-table': resizableColumns, 'p-datatable-resizable-table-fit': resizableColumns && columnResizeMode === 'fit' }"
                        [class]="tableStyleClass"
                        [style]="tableStyle"
                        [attr.id]="id + '-table'"
                    >
                        <ng-container *ngTemplateOutlet="colGroupTemplate; context: { $implicit: scrollerOptions.columns }"></ng-container>
                        <thead #thead class="p-datatable-thead">
                            <ng-container *ngTemplateOutlet="headerGroupedTemplate || headerTemplate; context: { $implicit: scrollerOptions.columns }"></ng-container>
                        </thead>
                        <tbody
                            class="p-datatable-tbody p-datatable-frozen-tbody"
                            *ngIf="frozenValue || frozenBodyTemplate"
                            [value]="frozenValue"
                            [frozenRows]="true"
                            [pTableBody]="scrollerOptions.columns"
                            [pTableBodyTemplate]="frozenBodyTemplate"
                            [frozen]="true"
                        ></tbody>
                        <tbody
                            class="p-datatable-tbody"
                            [ngClass]="scrollerOptions.contentStyleClass"
                            [style]="scrollerOptions.contentStyle"
                            [value]="dataToRender(scrollerOptions.rows)"
                            [pTableBody]="scrollerOptions.columns"
                            [pTableBodyTemplate]="bodyTemplate"
                            [scrollerOptions]="scrollerOptions"
                        ></tbody>
                        <tbody *ngIf="scrollerOptions.spacerStyle" [style]="'height: calc(' + scrollerOptions.spacerStyle.height + ' - ' + scrollerOptions.rows.length * scrollerOptions.itemSize + 'px);'" class="p-datatable-scroller-spacer"></tbody>
                        <tfoot *ngIf="footerGroupedTemplate || footerTemplate" #tfoot class="p-datatable-tfoot">
                            <ng-container *ngTemplateOutlet="footerGroupedTemplate || footerTemplate; context: { $implicit: scrollerOptions.columns }"></ng-container>
                        </tfoot>
                    </table>
                </ng-template>
            </div>

            <p-paginator
                [rows]="rows"
                [first]="first"
                [totalRecords]="totalRecords"
                [pageLinkSize]="pageLinks"
                styleClass="p-paginator-bottom"
                [alwaysShow]="alwaysShowPaginator"
                (onPageChange)="onPageChange($event)"
                [rowsPerPageOptions]="rowsPerPageOptions"
                *ngIf="paginator && (paginatorPosition === 'bottom' || paginatorPosition == 'both')"
                [templateLeft]="paginatorLeftTemplate"
                [templateRight]="paginatorRightTemplate"
                [dropdownAppendTo]="paginatorDropdownAppendTo"
                [dropdownScrollHeight]="paginatorDropdownScrollHeight"
                [currentPageReportTemplate]="currentPageReportTemplate"
                [showFirstLastIcon]="showFirstLastIcon"
                [dropdownItemTemplate]="paginatorDropdownItemTemplate"
                [showCurrentPageReport]="showCurrentPageReport"
                [showJumpToPageDropdown]="showJumpToPageDropdown"
                [showJumpToPageInput]="showJumpToPageInput"
                [showPageLinks]="showPageLinks"
            >
                <ng-template pTemplate="firstpagelinkicon" *ngIf="paginatorFirstPageLinkIconTemplate">
                    <ng-container *ngTemplateOutlet="paginatorFirstPageLinkIconTemplate"></ng-container>
                </ng-template>

                <ng-template pTemplate="previouspagelinkicon" *ngIf="paginatorPreviousPageLinkIconTemplate">
                    <ng-container *ngTemplateOutlet="paginatorPreviousPageLinkIconTemplate"></ng-container>
                </ng-template>

                <ng-template pTemplate="lastpagelinkicon" *ngIf="paginatorLastPageLinkIconTemplate">
                    <ng-container *ngTemplateOutlet="paginatorLastPageLinkIconTemplate"></ng-container>
                </ng-template>

                <ng-template pTemplate="nextpagelinkicon" *ngIf="paginatorNextPageLinkIconTemplate">
                    <ng-container *ngTemplateOutlet="paginatorNextPageLinkIconTemplate"></ng-container>
                </ng-template>
            </p-paginator>

            <div *ngIf="summaryTemplate" class="p-datatable-footer">
                <ng-container *ngTemplateOutlet="summaryTemplate"></ng-container>
            </div>

            <div #resizeHelper class="p-column-resizer-helper" style="display:none" *ngIf="resizableColumns"></div>
            <span #reorderIndicatorUp class="p-datatable-reorder-indicator-up" style="display: none;" *ngIf="reorderableColumns">
                <ArrowDownIcon *ngIf="!reorderIndicatorUpIconTemplate" />
                <ng-template *ngTemplateOutlet="reorderIndicatorUpIconTemplate"></ng-template>
            </span>
            <span #reorderIndicatorDown class="p-datatable-reorder-indicator-down" style="display: none;" *ngIf="reorderableColumns">
                <ArrowUpIcon *ngIf="!reorderIndicatorDownIconTemplate" />
                <ng-template *ngTemplateOutlet="reorderIndicatorDownIconTemplate"></ng-template>
            </span>
        </div>
    `,
      providers: [TableService],
      changeDetection: ChangeDetectionStrategy.Default,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      },
      styles: [".p-datatable{position:relative}.p-datatable>.p-datatable-wrapper{overflow:auto}.p-datatable-table{border-spacing:0px;width:100%}.p-datatable .p-sortable-column{cursor:pointer;-webkit-user-select:none;user-select:none}.p-datatable .p-sortable-column .p-column-title,.p-datatable .p-sortable-column .p-sortable-column-icon,.p-datatable .p-sortable-column .p-sortable-column-badge{vertical-align:middle}.p-datatable .p-sortable-column .p-icon-wrapper{display:inline}.p-datatable .p-sortable-column .p-sortable-column-badge{display:inline-flex;align-items:center;justify-content:center}.p-datatable-hoverable-rows .p-selectable-row{cursor:pointer}.p-datatable-scrollable>.p-datatable-wrapper{position:relative}.p-datatable-scrollable-table>.p-datatable-thead{position:sticky;top:0;z-index:1}.p-datatable-scrollable-table>.p-datatable-frozen-tbody{position:sticky;z-index:1}.p-datatable-scrollable-table>.p-datatable-tfoot{position:sticky;bottom:0;z-index:1}.p-datatable-scrollable .p-frozen-column{position:sticky;background:inherit}.p-datatable-scrollable th.p-frozen-column{z-index:1}.p-datatable-flex-scrollable{display:flex;flex-direction:column;height:100%}.p-datatable-flex-scrollable>.p-datatable-wrapper{display:flex;flex-direction:column;flex:1;height:100%}.p-datatable-scrollable-table>.p-datatable-tbody>.p-rowgroup-header{position:sticky;z-index:1}.p-datatable-resizable-table>.p-datatable-thead>tr>th,.p-datatable-resizable-table>.p-datatable-tfoot>tr>td,.p-datatable-resizable-table>.p-datatable-tbody>tr>td{overflow:hidden;white-space:nowrap}.p-datatable-resizable-table>.p-datatable-thead>tr>th.p-resizable-column:not(.p-frozen-column){background-clip:padding-box;position:relative}.p-datatable-resizable-table-fit>.p-datatable-thead>tr>th.p-resizable-column:last-child .p-column-resizer{display:none}.p-datatable .p-column-resizer{display:block;position:absolute!important;top:0;right:0;margin:0;width:.5rem;height:100%;padding:0;cursor:col-resize;border:1px solid transparent}.p-datatable .p-column-resizer-helper{width:1px;position:absolute;z-index:10;display:none}.p-datatable .p-row-editor-init,.p-datatable .p-row-editor-save,.p-datatable .p-row-editor-cancel,.p-datatable .p-row-toggler{display:inline-flex;align-items:center;justify-content:center;overflow:hidden;position:relative}.p-datatable-reorder-indicator-up,.p-datatable-reorder-indicator-down{position:absolute}.p-datatable-reorderablerow-handle,[pReorderableColumn]{cursor:move}.p-datatable .p-datatable-loading-overlay{position:absolute;display:flex;align-items:center;justify-content:center;z-index:2}.p-column-filter-row{display:flex;align-items:center;width:100%}.p-column-filter-menu{display:inline-flex}.p-column-filter-row p-columnfilterformelement{flex:1 1 auto;width:1%}.p-column-filter-menu-button,.p-column-filter-clear-button{display:inline-flex;justify-content:center;align-items:center;cursor:pointer;text-decoration:none;overflow:hidden;position:relative}.p-column-filter-overlay{position:absolute;top:0;left:0}.p-column-filter-row-items{margin:0;padding:0;list-style:none}.p-column-filter-row-item{cursor:pointer}.p-column-filter-add-button,.p-column-filter-remove-button{justify-content:center}.p-column-filter-add-button .p-button-label,.p-column-filter-remove-button .p-button-label{flex-grow:0}.p-column-filter-buttonbar{display:flex;align-items:center;justify-content:space-between}.p-column-filter-buttonbar .p-button{width:auto}.p-datatable-tbody>tr>td>.p-column-title{display:none}.p-datatable-scroller-spacer{display:flex}.p-datatable .p-scroller .p-scroller-loading{transform:none!important;min-height:0;position:sticky;top:0;left:0}\n"]
    }]
  }], function() {
    return [{
      type: Document,
      decorators: [{
        type: Inject,
        args: [DOCUMENT]
      }]
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }, {
      type: Renderer2
    }, {
      type: ElementRef
    }, {
      type: NgZone
    }, {
      type: TableService
    }, {
      type: ChangeDetectorRef
    }, {
      type: FilterService
    }, {
      type: OverlayService
    }];
  }, {
    frozenColumns: [{
      type: Input
    }],
    frozenValue: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    tableStyle: [{
      type: Input
    }],
    tableStyleClass: [{
      type: Input
    }],
    paginator: [{
      type: Input
    }],
    pageLinks: [{
      type: Input
    }],
    rowsPerPageOptions: [{
      type: Input
    }],
    alwaysShowPaginator: [{
      type: Input
    }],
    paginatorPosition: [{
      type: Input
    }],
    paginatorDropdownAppendTo: [{
      type: Input
    }],
    paginatorDropdownScrollHeight: [{
      type: Input
    }],
    currentPageReportTemplate: [{
      type: Input
    }],
    showCurrentPageReport: [{
      type: Input
    }],
    showJumpToPageDropdown: [{
      type: Input
    }],
    showJumpToPageInput: [{
      type: Input
    }],
    showFirstLastIcon: [{
      type: Input
    }],
    showPageLinks: [{
      type: Input
    }],
    defaultSortOrder: [{
      type: Input
    }],
    sortMode: [{
      type: Input
    }],
    resetPageOnSort: [{
      type: Input
    }],
    selectionMode: [{
      type: Input
    }],
    selectionPageOnly: [{
      type: Input
    }],
    contextMenuSelection: [{
      type: Input
    }],
    contextMenuSelectionChange: [{
      type: Output
    }],
    contextMenuSelectionMode: [{
      type: Input
    }],
    dataKey: [{
      type: Input
    }],
    metaKeySelection: [{
      type: Input
    }],
    rowSelectable: [{
      type: Input
    }],
    rowTrackBy: [{
      type: Input
    }],
    lazy: [{
      type: Input
    }],
    lazyLoadOnInit: [{
      type: Input
    }],
    compareSelectionBy: [{
      type: Input
    }],
    csvSeparator: [{
      type: Input
    }],
    exportFilename: [{
      type: Input
    }],
    filters: [{
      type: Input
    }],
    globalFilterFields: [{
      type: Input
    }],
    filterDelay: [{
      type: Input
    }],
    filterLocale: [{
      type: Input
    }],
    expandedRowKeys: [{
      type: Input
    }],
    editingRowKeys: [{
      type: Input
    }],
    rowExpandMode: [{
      type: Input
    }],
    scrollable: [{
      type: Input
    }],
    scrollDirection: [{
      type: Input
    }],
    rowGroupMode: [{
      type: Input
    }],
    scrollHeight: [{
      type: Input
    }],
    virtualScroll: [{
      type: Input
    }],
    virtualScrollItemSize: [{
      type: Input
    }],
    virtualScrollOptions: [{
      type: Input
    }],
    virtualScrollDelay: [{
      type: Input
    }],
    frozenWidth: [{
      type: Input
    }],
    responsive: [{
      type: Input
    }],
    contextMenu: [{
      type: Input
    }],
    resizableColumns: [{
      type: Input
    }],
    columnResizeMode: [{
      type: Input
    }],
    reorderableColumns: [{
      type: Input
    }],
    loading: [{
      type: Input
    }],
    loadingIcon: [{
      type: Input
    }],
    showLoader: [{
      type: Input
    }],
    rowHover: [{
      type: Input
    }],
    customSort: [{
      type: Input
    }],
    showInitialSortBadge: [{
      type: Input
    }],
    autoLayout: [{
      type: Input
    }],
    exportFunction: [{
      type: Input
    }],
    exportHeader: [{
      type: Input
    }],
    stateKey: [{
      type: Input
    }],
    stateStorage: [{
      type: Input
    }],
    editMode: [{
      type: Input
    }],
    groupRowsBy: [{
      type: Input
    }],
    groupRowsByOrder: [{
      type: Input
    }],
    responsiveLayout: [{
      type: Input
    }],
    breakpoint: [{
      type: Input
    }],
    value: [{
      type: Input
    }],
    columns: [{
      type: Input
    }],
    first: [{
      type: Input
    }],
    rows: [{
      type: Input
    }],
    totalRecords: [{
      type: Input
    }],
    sortField: [{
      type: Input
    }],
    sortOrder: [{
      type: Input
    }],
    multiSortMeta: [{
      type: Input
    }],
    selection: [{
      type: Input
    }],
    selectAll: [{
      type: Input
    }],
    selectAllChange: [{
      type: Output
    }],
    selectionChange: [{
      type: Output
    }],
    onRowSelect: [{
      type: Output
    }],
    onRowUnselect: [{
      type: Output
    }],
    onPage: [{
      type: Output
    }],
    onSort: [{
      type: Output
    }],
    onFilter: [{
      type: Output
    }],
    onLazyLoad: [{
      type: Output
    }],
    onRowExpand: [{
      type: Output
    }],
    onRowCollapse: [{
      type: Output
    }],
    onContextMenuSelect: [{
      type: Output
    }],
    onColResize: [{
      type: Output
    }],
    onColReorder: [{
      type: Output
    }],
    onRowReorder: [{
      type: Output
    }],
    onEditInit: [{
      type: Output
    }],
    onEditComplete: [{
      type: Output
    }],
    onEditCancel: [{
      type: Output
    }],
    onHeaderCheckboxToggle: [{
      type: Output
    }],
    sortFunction: [{
      type: Output
    }],
    firstChange: [{
      type: Output
    }],
    rowsChange: [{
      type: Output
    }],
    onStateSave: [{
      type: Output
    }],
    onStateRestore: [{
      type: Output
    }],
    containerViewChild: [{
      type: ViewChild,
      args: ["container"]
    }],
    resizeHelperViewChild: [{
      type: ViewChild,
      args: ["resizeHelper"]
    }],
    reorderIndicatorUpViewChild: [{
      type: ViewChild,
      args: ["reorderIndicatorUp"]
    }],
    reorderIndicatorDownViewChild: [{
      type: ViewChild,
      args: ["reorderIndicatorDown"]
    }],
    wrapperViewChild: [{
      type: ViewChild,
      args: ["wrapper"]
    }],
    tableViewChild: [{
      type: ViewChild,
      args: ["table"]
    }],
    tableHeaderViewChild: [{
      type: ViewChild,
      args: ["thead"]
    }],
    tableFooterViewChild: [{
      type: ViewChild,
      args: ["tfoot"]
    }],
    scroller: [{
      type: ViewChild,
      args: ["scroller"]
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }],
    virtualRowHeight: [{
      type: Input
    }]
  });
})();
var _TableBody = class {
  constructor(dt, tableService, cd, el) {
    __publicField(this, "dt");
    __publicField(this, "tableService");
    __publicField(this, "cd");
    __publicField(this, "el");
    __publicField(this, "columns");
    __publicField(this, "template");
    __publicField(this, "frozen");
    __publicField(this, "frozenRows");
    __publicField(this, "scrollerOptions");
    __publicField(this, "subscription");
    __publicField(this, "_value");
    this.dt = dt;
    this.tableService = tableService;
    this.cd = cd;
    this.el = el;
    this.subscription = this.dt.tableService.valueSource$.subscribe(() => {
      if (this.dt.virtualScroll) {
        this.cd.detectChanges();
      }
    });
  }
  get value() {
    return this._value;
  }
  set value(val) {
    this._value = val;
    if (this.frozenRows) {
      this.updateFrozenRowStickyPosition();
    }
    if (this.dt.scrollable && this.dt.rowGroupMode === "subheader") {
      this.updateFrozenRowGroupHeaderStickyPosition();
    }
  }
  ngAfterViewInit() {
    if (this.frozenRows) {
      this.updateFrozenRowStickyPosition();
    }
    if (this.dt.scrollable && this.dt.rowGroupMode === "subheader") {
      this.updateFrozenRowGroupHeaderStickyPosition();
    }
  }
  shouldRenderRowGroupHeader(value, rowData, i) {
    let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.dt.groupRowsBy);
    let prevRowData = value[i - 1];
    if (prevRowData) {
      let previousRowFieldData = ObjectUtils.resolveFieldData(prevRowData, this.dt.groupRowsBy);
      return currentRowFieldData !== previousRowFieldData;
    } else {
      return true;
    }
  }
  shouldRenderRowGroupFooter(value, rowData, i) {
    let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.dt.groupRowsBy);
    let nextRowData = value[i + 1];
    if (nextRowData) {
      let nextRowFieldData = ObjectUtils.resolveFieldData(nextRowData, this.dt.groupRowsBy);
      return currentRowFieldData !== nextRowFieldData;
    } else {
      return true;
    }
  }
  shouldRenderRowspan(value, rowData, i) {
    let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.dt.groupRowsBy);
    let prevRowData = value[i - 1];
    if (prevRowData) {
      let previousRowFieldData = ObjectUtils.resolveFieldData(prevRowData, this.dt.groupRowsBy);
      return currentRowFieldData !== previousRowFieldData;
    } else {
      return true;
    }
  }
  calculateRowGroupSize(value, rowData, index) {
    let currentRowFieldData = ObjectUtils.resolveFieldData(rowData, this.dt.groupRowsBy);
    let nextRowFieldData = currentRowFieldData;
    let groupRowSpan = 0;
    while (currentRowFieldData === nextRowFieldData) {
      groupRowSpan++;
      let nextRowData = value[++index];
      if (nextRowData) {
        nextRowFieldData = ObjectUtils.resolveFieldData(nextRowData, this.dt.groupRowsBy);
      } else {
        break;
      }
    }
    return groupRowSpan === 1 ? null : groupRowSpan;
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
  updateFrozenRowStickyPosition() {
    this.el.nativeElement.style.top = DomHandler.getOuterHeight(this.el.nativeElement.previousElementSibling) + "px";
  }
  updateFrozenRowGroupHeaderStickyPosition() {
    if (this.el.nativeElement.previousElementSibling) {
      let tableHeaderHeight = DomHandler.getOuterHeight(this.el.nativeElement.previousElementSibling);
      this.dt.rowGroupHeaderStyleObject.top = tableHeaderHeight + "px";
    }
  }
  getScrollerOption(option, options) {
    if (this.dt.virtualScroll) {
      options = options || this.scrollerOptions;
      return options ? options[option] : null;
    }
    return null;
  }
  getRowIndex(rowIndex) {
    const index = this.dt.paginator ? this.dt.first + rowIndex : rowIndex;
    const getItemOptions = this.getScrollerOption("getItemOptions");
    return getItemOptions ? getItemOptions(index).index : index;
  }
};
var TableBody = _TableBody;
__publicField(TableBody, "ɵfac", function TableBody_Factory(t) {
  return new (t || _TableBody)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(TableService), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(ElementRef));
});
__publicField(TableBody, "ɵcmp", ɵɵdefineComponent({
  type: _TableBody,
  selectors: [["", "pTableBody", ""]],
  hostAttrs: [1, "p-element"],
  inputs: {
    columns: ["pTableBody", "columns"],
    template: ["pTableBodyTemplate", "template"],
    value: "value",
    frozen: "frozen",
    frozenRows: "frozenRows",
    scrollerOptions: "scrollerOptions"
  },
  attrs: _c163,
  decls: 5,
  vars: 5,
  consts: [[4, "ngIf"], ["ngFor", "", 3, "ngForOf", "ngForTrackBy"], ["role", "row", 4, "ngIf"], ["role", "row"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"]],
  template: function TableBody_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵtemplate(0, TableBody_ng_container_0_Template, 2, 2, "ng-container", 0);
      ɵɵtemplate(1, TableBody_ng_container_1_Template, 2, 2, "ng-container", 0);
      ɵɵtemplate(2, TableBody_ng_container_2_Template, 2, 2, "ng-container", 0);
      ɵɵtemplate(3, TableBody_ng_container_3_Template, 2, 5, "ng-container", 0);
      ɵɵtemplate(4, TableBody_ng_container_4_Template, 2, 5, "ng-container", 0);
    }
    if (rf & 2) {
      ɵɵproperty("ngIf", !ctx.dt.expandedRowTemplate);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.dt.expandedRowTemplate && !(ctx.frozen && ctx.dt.frozenExpandedRowTemplate));
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.dt.frozenExpandedRowTemplate && ctx.frozen);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.dt.loading);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.dt.isEmpty() && !ctx.dt.loading);
    }
  },
  dependencies: [NgForOf, NgIf, NgTemplateOutlet],
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TableBody, [{
    type: Component,
    args: [{
      selector: "[pTableBody]",
      template: `
        <ng-container *ngIf="!dt.expandedRowTemplate">
            <ng-template ngFor let-rowData let-rowIndex="index" [ngForOf]="value" [ngForTrackBy]="dt.rowTrackBy">
                <ng-container *ngIf="dt.groupHeaderTemplate && !dt.virtualScroll && dt.rowGroupMode === 'subheader' && shouldRenderRowGroupHeader(value, rowData, rowIndex)" role="row">
                    <ng-container
                        *ngTemplateOutlet="dt.groupHeaderTemplate; context: { $implicit: rowData, rowIndex: getRowIndex(rowIndex), columns: columns, editing: dt.editMode === 'row' && dt.isRowEditing(rowData), frozen: frozen }"
                    ></ng-container>
                </ng-container>
                <ng-container *ngIf="dt.rowGroupMode !== 'rowspan'">
                    <ng-container
                        *ngTemplateOutlet="rowData ? template : dt.loadingBodyTemplate; context: { $implicit: rowData, rowIndex: getRowIndex(rowIndex), columns: columns, editing: dt.editMode === 'row' && dt.isRowEditing(rowData), frozen: frozen }"
                    ></ng-container>
                </ng-container>
                <ng-container *ngIf="dt.rowGroupMode === 'rowspan'">
                    <ng-container
                        *ngTemplateOutlet="
                            rowData ? template : dt.loadingBodyTemplate;
                            context: {
                                $implicit: rowData,
                                rowIndex: getRowIndex(rowIndex),
                                columns: columns,
                                editing: dt.editMode === 'row' && dt.isRowEditing(rowData),
                                frozen: frozen,
                                rowgroup: shouldRenderRowspan(value, rowData, rowIndex),
                                rowspan: calculateRowGroupSize(value, rowData, rowIndex)
                            }
                        "
                    ></ng-container>
                </ng-container>
                <ng-container *ngIf="dt.groupFooterTemplate && !dt.virtualScroll && dt.rowGroupMode === 'subheader' && shouldRenderRowGroupFooter(value, rowData, rowIndex)" role="row">
                    <ng-container
                        *ngTemplateOutlet="dt.groupFooterTemplate; context: { $implicit: rowData, rowIndex: getRowIndex(rowIndex), columns: columns, editing: dt.editMode === 'row' && dt.isRowEditing(rowData), frozen: frozen }"
                    ></ng-container>
                </ng-container>
            </ng-template>
        </ng-container>
        <ng-container *ngIf="dt.expandedRowTemplate && !(frozen && dt.frozenExpandedRowTemplate)">
            <ng-template ngFor let-rowData let-rowIndex="index" [ngForOf]="value" [ngForTrackBy]="dt.rowTrackBy">
                <ng-container *ngIf="!dt.groupHeaderTemplate">
                    <ng-container
                        *ngTemplateOutlet="template; context: { $implicit: rowData, rowIndex: getRowIndex(rowIndex), columns: columns, expanded: dt.isRowExpanded(rowData), editing: dt.editMode === 'row' && dt.isRowEditing(rowData), frozen: frozen }"
                    ></ng-container>
                </ng-container>
                <ng-container *ngIf="dt.groupHeaderTemplate && dt.rowGroupMode === 'subheader' && shouldRenderRowGroupHeader(value, rowData, getRowIndex(rowIndex))" role="row">
                    <ng-container
                        *ngTemplateOutlet="
                            dt.groupHeaderTemplate;
                            context: { $implicit: rowData, rowIndex: getRowIndex(rowIndex), columns: columns, expanded: dt.isRowExpanded(rowData), editing: dt.editMode === 'row' && dt.isRowEditing(rowData), frozen: frozen }
                        "
                    ></ng-container>
                </ng-container>
                <ng-container *ngIf="dt.isRowExpanded(rowData)">
                    <ng-container *ngTemplateOutlet="dt.expandedRowTemplate; context: { $implicit: rowData, rowIndex: getRowIndex(rowIndex), columns: columns, frozen: frozen }"></ng-container>
                    <ng-container *ngIf="dt.groupFooterTemplate && dt.rowGroupMode === 'subheader' && shouldRenderRowGroupFooter(value, rowData, getRowIndex(rowIndex))" role="row">
                        <ng-container
                            *ngTemplateOutlet="
                                dt.groupFooterTemplate;
                                context: { $implicit: rowData, rowIndex: getRowIndex(rowIndex), columns: columns, expanded: dt.isRowExpanded(rowData), editing: dt.editMode === 'row' && dt.isRowEditing(rowData), frozen: frozen }
                            "
                        ></ng-container>
                    </ng-container>
                </ng-container>
            </ng-template>
        </ng-container>
        <ng-container *ngIf="dt.frozenExpandedRowTemplate && frozen">
            <ng-template ngFor let-rowData let-rowIndex="index" [ngForOf]="value" [ngForTrackBy]="dt.rowTrackBy">
                <ng-container
                    *ngTemplateOutlet="template; context: { $implicit: rowData, rowIndex: getRowIndex(rowIndex), columns: columns, expanded: dt.isRowExpanded(rowData), editing: dt.editMode === 'row' && dt.isRowEditing(rowData), frozen: frozen }"
                ></ng-container>
                <ng-container *ngIf="dt.isRowExpanded(rowData)">
                    <ng-container *ngTemplateOutlet="dt.frozenExpandedRowTemplate; context: { $implicit: rowData, rowIndex: getRowIndex(rowIndex), columns: columns, frozen: frozen }"></ng-container>
                </ng-container>
            </ng-template>
        </ng-container>
        <ng-container *ngIf="dt.loading">
            <ng-container *ngTemplateOutlet="dt.loadingBodyTemplate; context: { $implicit: columns, frozen: frozen }"></ng-container>
        </ng-container>
        <ng-container *ngIf="dt.isEmpty() && !dt.loading">
            <ng-container *ngTemplateOutlet="dt.emptyMessageTemplate; context: { $implicit: columns, frozen: frozen }"></ng-container>
        </ng-container>
    `,
      changeDetection: ChangeDetectionStrategy.Default,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: TableService
    }, {
      type: ChangeDetectorRef
    }, {
      type: ElementRef
    }];
  }, {
    columns: [{
      type: Input,
      args: ["pTableBody"]
    }],
    template: [{
      type: Input,
      args: ["pTableBodyTemplate"]
    }],
    value: [{
      type: Input
    }],
    frozen: [{
      type: Input
    }],
    frozenRows: [{
      type: Input
    }],
    scrollerOptions: [{
      type: Input
    }]
  });
})();
var _RowGroupHeader = class {
  constructor(dt) {
    __publicField(this, "dt");
    this.dt = dt;
  }
  get getFrozenRowGroupHeaderStickyPosition() {
    return this.dt.rowGroupHeaderStyleObject ? this.dt.rowGroupHeaderStyleObject.top : "";
  }
};
var RowGroupHeader = _RowGroupHeader;
__publicField(RowGroupHeader, "ɵfac", function RowGroupHeader_Factory(t) {
  return new (t || _RowGroupHeader)(ɵɵdirectiveInject(Table));
});
__publicField(RowGroupHeader, "ɵdir", ɵɵdefineDirective({
  type: _RowGroupHeader,
  selectors: [["", "pRowGroupHeader", ""]],
  hostAttrs: [1, "p-rowgroup-header", "p-element"],
  hostVars: 2,
  hostBindings: function RowGroupHeader_HostBindings(rf, ctx) {
    if (rf & 2) {
      ɵɵstyleProp("top", ctx.getFrozenRowGroupHeaderStickyPosition);
    }
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RowGroupHeader, [{
    type: Directive,
    args: [{
      selector: "[pRowGroupHeader]",
      host: {
        class: "p-rowgroup-header p-element",
        "[style.top]": "getFrozenRowGroupHeaderStickyPosition"
      }
    }]
  }], function() {
    return [{
      type: Table
    }];
  }, null);
})();
var _FrozenColumn = class {
  constructor(el) {
    __publicField(this, "el");
    __publicField(this, "alignFrozen", "left");
    __publicField(this, "_frozen", true);
    this.el = el;
  }
  get frozen() {
    return this._frozen;
  }
  set frozen(val) {
    this._frozen = val;
    this.updateStickyPosition();
  }
  ngAfterViewInit() {
    setTimeout(() => {
      this.updateStickyPosition();
    }, 1e3);
  }
  updateStickyPosition() {
    var _a, _b;
    if (this._frozen) {
      if (this.alignFrozen === "right") {
        let right = 0;
        let next = this.el.nativeElement.nextElementSibling;
        if (next) {
          right = DomHandler.getOuterWidth(next) + (parseFloat(next.style.right) || 0);
        }
        this.el.nativeElement.style.right = right + "px";
      } else {
        let left = 0;
        let prev = this.el.nativeElement.previousElementSibling;
        if (prev) {
          left = DomHandler.getOuterWidth(prev) + (parseFloat(prev.style.left) || 0);
        }
        this.el.nativeElement.style.left = left + "px";
      }
      const filterRow = (_b = (_a = this.el.nativeElement) == null ? void 0 : _a.parentElement) == null ? void 0 : _b.nextElementSibling;
      if (filterRow) {
        let index = DomHandler.index(this.el.nativeElement);
        if (filterRow.children && filterRow.children[index]) {
          filterRow.children[index].style.left = this.el.nativeElement.style.left;
          filterRow.children[index].style.right = this.el.nativeElement.style.right;
        }
      }
    }
  }
};
var FrozenColumn = _FrozenColumn;
__publicField(FrozenColumn, "ɵfac", function FrozenColumn_Factory(t) {
  return new (t || _FrozenColumn)(ɵɵdirectiveInject(ElementRef));
});
__publicField(FrozenColumn, "ɵdir", ɵɵdefineDirective({
  type: _FrozenColumn,
  selectors: [["", "pFrozenColumn", ""]],
  hostAttrs: [1, "p-element"],
  hostVars: 2,
  hostBindings: function FrozenColumn_HostBindings(rf, ctx) {
    if (rf & 2) {
      ɵɵclassProp("p-frozen-column", ctx.frozen);
    }
  },
  inputs: {
    frozen: "frozen",
    alignFrozen: "alignFrozen"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FrozenColumn, [{
    type: Directive,
    args: [{
      selector: "[pFrozenColumn]",
      host: {
        class: "p-element",
        "[class.p-frozen-column]": "frozen"
      }
    }]
  }], function() {
    return [{
      type: ElementRef
    }];
  }, {
    frozen: [{
      type: Input
    }],
    alignFrozen: [{
      type: Input
    }]
  });
})();
var _SortableColumn = class {
  constructor(dt) {
    __publicField(this, "dt");
    __publicField(this, "field");
    __publicField(this, "pSortableColumnDisabled");
    __publicField(this, "sorted");
    __publicField(this, "sortOrder");
    __publicField(this, "subscription");
    this.dt = dt;
    if (this.isEnabled()) {
      this.subscription = this.dt.tableService.sortSource$.subscribe((sortMeta) => {
        this.updateSortState();
      });
    }
  }
  ngOnInit() {
    if (this.isEnabled()) {
      this.updateSortState();
    }
  }
  updateSortState() {
    this.sorted = this.dt.isSorted(this.field);
    this.sortOrder = this.sorted ? this.dt.sortOrder === 1 ? "ascending" : "descending" : "none";
  }
  onClick(event2) {
    if (this.isEnabled() && !this.isFilterElement(event2.target)) {
      this.updateSortState();
      this.dt.sort({
        originalEvent: event2,
        field: this.field
      });
      DomHandler.clearSelection();
    }
  }
  onEnterKey(event2) {
    this.onClick(event2);
  }
  isEnabled() {
    return this.pSortableColumnDisabled !== true;
  }
  isFilterElement(element) {
    return DomHandler.hasClass(element, "pi-filter-icon") || DomHandler.hasClass(element, "p-column-filter-menu-button");
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
};
var SortableColumn = _SortableColumn;
__publicField(SortableColumn, "ɵfac", function SortableColumn_Factory(t) {
  return new (t || _SortableColumn)(ɵɵdirectiveInject(Table));
});
__publicField(SortableColumn, "ɵdir", ɵɵdefineDirective({
  type: _SortableColumn,
  selectors: [["", "pSortableColumn", ""]],
  hostAttrs: [1, "p-element"],
  hostVars: 7,
  hostBindings: function SortableColumn_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("click", function SortableColumn_click_HostBindingHandler($event) {
        return ctx.onClick($event);
      })("keydown.enter", function SortableColumn_keydown_enter_HostBindingHandler($event) {
        return ctx.onEnterKey($event);
      });
    }
    if (rf & 2) {
      ɵɵattribute("tabindex", ctx.isEnabled() ? "0" : null)("role", "columnheader")("aria-sort", ctx.sortOrder);
      ɵɵclassProp("p-sortable-column", ctx.isEnabled())("p-highlight", ctx.sorted);
    }
  },
  inputs: {
    field: ["pSortableColumn", "field"],
    pSortableColumnDisabled: "pSortableColumnDisabled"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SortableColumn, [{
    type: Directive,
    args: [{
      selector: "[pSortableColumn]",
      host: {
        class: "p-element",
        "[class.p-sortable-column]": "isEnabled()",
        "[class.p-highlight]": "sorted",
        "[attr.tabindex]": 'isEnabled() ? "0" : null',
        "[attr.role]": '"columnheader"',
        "[attr.aria-sort]": "sortOrder"
      }
    }]
  }], function() {
    return [{
      type: Table
    }];
  }, {
    field: [{
      type: Input,
      args: ["pSortableColumn"]
    }],
    pSortableColumnDisabled: [{
      type: Input
    }],
    onClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }],
    onEnterKey: [{
      type: HostListener,
      args: ["keydown.enter", ["$event"]]
    }]
  });
})();
var _SortIcon = class {
  constructor(dt, cd) {
    __publicField(this, "dt");
    __publicField(this, "cd");
    __publicField(this, "field");
    __publicField(this, "subscription");
    __publicField(this, "sortOrder");
    this.dt = dt;
    this.cd = cd;
    this.subscription = this.dt.tableService.sortSource$.subscribe((sortMeta) => {
      this.updateSortState();
    });
  }
  ngOnInit() {
    this.updateSortState();
  }
  onClick(event2) {
    event2.preventDefault();
  }
  updateSortState() {
    if (this.dt.sortMode === "single") {
      this.sortOrder = this.dt.isSorted(this.field) ? this.dt.sortOrder : 0;
    } else if (this.dt.sortMode === "multiple") {
      let sortMeta = this.dt.getSortMeta(this.field);
      this.sortOrder = sortMeta ? sortMeta.order : 0;
    }
    this.cd.markForCheck();
  }
  getMultiSortMetaIndex() {
    let multiSortMeta = this.dt._multiSortMeta;
    let index = -1;
    if (multiSortMeta && this.dt.sortMode === "multiple" && (this.dt.showInitialSortBadge || multiSortMeta.length > 1)) {
      for (let i = 0; i < multiSortMeta.length; i++) {
        let meta = multiSortMeta[i];
        if (meta.field === this.field || meta.field === this.field) {
          index = i;
          break;
        }
      }
    }
    return index;
  }
  getBadgeValue() {
    let index = this.getMultiSortMetaIndex();
    return this.dt.groupRowsBy && index > -1 ? index : index + 1;
  }
  isMultiSorted() {
    return this.dt.sortMode === "multiple" && this.getMultiSortMetaIndex() > -1;
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
};
var SortIcon = _SortIcon;
__publicField(SortIcon, "ɵfac", function SortIcon_Factory(t) {
  return new (t || _SortIcon)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(ChangeDetectorRef));
});
__publicField(SortIcon, "ɵcmp", ɵɵdefineComponent({
  type: _SortIcon,
  selectors: [["p-sortIcon"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    field: "field"
  },
  decls: 3,
  vars: 3,
  consts: [[4, "ngIf"], ["class", "p-sortable-column-icon", 4, "ngIf"], ["class", "p-sortable-column-badge", 4, "ngIf"], [3, "styleClass", 4, "ngIf"], [3, "styleClass"], [1, "p-sortable-column-icon"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [1, "p-sortable-column-badge"]],
  template: function SortIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵtemplate(0, SortIcon_ng_container_0_Template, 4, 3, "ng-container", 0);
      ɵɵtemplate(1, SortIcon_span_1_Template, 2, 4, "span", 1);
      ɵɵtemplate(2, SortIcon_span_2_Template, 2, 1, "span", 2);
    }
    if (rf & 2) {
      ɵɵproperty("ngIf", !ctx.dt.sortIconTemplate);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.dt.sortIconTemplate);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.isMultiSorted());
    }
  },
  dependencies: function() {
    return [NgIf, NgTemplateOutlet, SortAltIcon, SortAmountUpAltIcon, SortAmountDownIcon];
  },
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SortIcon, [{
    type: Component,
    args: [{
      selector: "p-sortIcon",
      template: `
        <ng-container *ngIf="!dt.sortIconTemplate">
            <SortAltIcon [styleClass]="'p-sortable-column-icon'" *ngIf="sortOrder === 0" />
            <SortAmountUpAltIcon [styleClass]="'p-sortable-column-icon'" *ngIf="sortOrder === 1" />
            <SortAmountDownIcon [styleClass]="'p-sortable-column-icon'" *ngIf="sortOrder === -1" />
        </ng-container>
        <span *ngIf="dt.sortIconTemplate" class="p-sortable-column-icon">
            <ng-template *ngTemplateOutlet="dt.sortIconTemplate; context: { $implicit: sortOrder }"></ng-template>
        </span>
        <span *ngIf="isMultiSorted()" class="p-sortable-column-badge">{{ getBadgeValue() }}</span>
    `,
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: ChangeDetectorRef
    }];
  }, {
    field: [{
      type: Input
    }]
  });
})();
var _SelectableRow = class {
  constructor(dt, tableService) {
    __publicField(this, "dt");
    __publicField(this, "tableService");
    __publicField(this, "data");
    __publicField(this, "index");
    __publicField(this, "pSelectableRowDisabled");
    __publicField(this, "selected");
    __publicField(this, "subscription");
    this.dt = dt;
    this.tableService = tableService;
    if (this.isEnabled()) {
      this.subscription = this.dt.tableService.selectionSource$.subscribe(() => {
        this.selected = this.dt.isSelected(this.data);
      });
    }
  }
  ngOnInit() {
    if (this.isEnabled()) {
      this.selected = this.dt.isSelected(this.data);
    }
  }
  onClick(event2) {
    if (this.isEnabled()) {
      this.dt.handleRowClick({
        originalEvent: event2,
        rowData: this.data,
        rowIndex: this.index
      });
    }
  }
  onTouchEnd(event2) {
    if (this.isEnabled()) {
      this.dt.handleRowTouchEnd(event2);
    }
  }
  onArrowDownKeyDown(event2) {
    if (!this.isEnabled()) {
      return;
    }
    const row = event2.currentTarget;
    const nextRow = this.findNextSelectableRow(row);
    if (nextRow) {
      nextRow.focus();
    }
    event2.preventDefault();
  }
  onArrowUpKeyDown(event2) {
    if (!this.isEnabled()) {
      return;
    }
    const row = event2.currentTarget;
    const prevRow = this.findPrevSelectableRow(row);
    if (prevRow) {
      prevRow.focus();
    }
    event2.preventDefault();
  }
  onEnterKeyDown(event2) {
    if (!this.isEnabled()) {
      return;
    }
    this.dt.handleRowClick({
      originalEvent: event2,
      rowData: this.data,
      rowIndex: this.index
    });
  }
  onPageDownKeyDown() {
    if (this.dt.virtualScroll) {
      this.dt.scroller.elementViewChild.nativeElement.focus();
    }
  }
  onSpaceKeydown() {
    if (this.dt.virtualScroll && !this.dt.editingCell) {
      this.dt.scroller.elementViewChild.nativeElement.focus();
    }
  }
  findNextSelectableRow(row) {
    let nextRow = row.nextElementSibling;
    if (nextRow) {
      if (DomHandler.hasClass(nextRow, "p-selectable-row"))
        return nextRow;
      else
        return this.findNextSelectableRow(nextRow);
    } else {
      return null;
    }
  }
  findPrevSelectableRow(row) {
    let prevRow = row.previousElementSibling;
    if (prevRow) {
      if (DomHandler.hasClass(prevRow, "p-selectable-row"))
        return prevRow;
      else
        return this.findPrevSelectableRow(prevRow);
    } else {
      return null;
    }
  }
  isEnabled() {
    return this.pSelectableRowDisabled !== true;
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
};
var SelectableRow = _SelectableRow;
__publicField(SelectableRow, "ɵfac", function SelectableRow_Factory(t) {
  return new (t || _SelectableRow)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(TableService));
});
__publicField(SelectableRow, "ɵdir", ɵɵdefineDirective({
  type: _SelectableRow,
  selectors: [["", "pSelectableRow", ""]],
  hostAttrs: [1, "p-element"],
  hostVars: 5,
  hostBindings: function SelectableRow_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("click", function SelectableRow_click_HostBindingHandler($event) {
        return ctx.onClick($event);
      })("touchend", function SelectableRow_touchend_HostBindingHandler($event) {
        return ctx.onTouchEnd($event);
      })("keydown.arrowdown", function SelectableRow_keydown_arrowdown_HostBindingHandler($event) {
        return ctx.onArrowDownKeyDown($event);
      })("keydown.arrowup", function SelectableRow_keydown_arrowup_HostBindingHandler($event) {
        return ctx.onArrowUpKeyDown($event);
      })("keydown.enter", function SelectableRow_keydown_enter_HostBindingHandler($event) {
        return ctx.onEnterKeyDown($event);
      })("keydown.shift.enter", function SelectableRow_keydown_shift_enter_HostBindingHandler($event) {
        return ctx.onEnterKeyDown($event);
      })("keydown.meta.enter", function SelectableRow_keydown_meta_enter_HostBindingHandler($event) {
        return ctx.onEnterKeyDown($event);
      })("keydown.pagedown", function SelectableRow_keydown_pagedown_HostBindingHandler() {
        return ctx.onPageDownKeyDown();
      })("keydown.pageup", function SelectableRow_keydown_pageup_HostBindingHandler() {
        return ctx.onPageDownKeyDown();
      })("keydown.home", function SelectableRow_keydown_home_HostBindingHandler() {
        return ctx.onPageDownKeyDown();
      })("keydown.end", function SelectableRow_keydown_end_HostBindingHandler() {
        return ctx.onPageDownKeyDown();
      })("keydown.space", function SelectableRow_keydown_space_HostBindingHandler() {
        return ctx.onSpaceKeydown();
      });
    }
    if (rf & 2) {
      ɵɵattribute("tabindex", ctx.isEnabled() ? 0 : void 0);
      ɵɵclassProp("p-selectable-row", ctx.isEnabled())("p-highlight", ctx.selected);
    }
  },
  inputs: {
    data: ["pSelectableRow", "data"],
    index: ["pSelectableRowIndex", "index"],
    pSelectableRowDisabled: "pSelectableRowDisabled"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SelectableRow, [{
    type: Directive,
    args: [{
      selector: "[pSelectableRow]",
      host: {
        class: "p-element",
        "[class.p-selectable-row]": "isEnabled()",
        "[class.p-highlight]": "selected",
        "[attr.tabindex]": "isEnabled() ? 0 : undefined"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: TableService
    }];
  }, {
    data: [{
      type: Input,
      args: ["pSelectableRow"]
    }],
    index: [{
      type: Input,
      args: ["pSelectableRowIndex"]
    }],
    pSelectableRowDisabled: [{
      type: Input
    }],
    onClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }],
    onTouchEnd: [{
      type: HostListener,
      args: ["touchend", ["$event"]]
    }],
    onArrowDownKeyDown: [{
      type: HostListener,
      args: ["keydown.arrowdown", ["$event"]]
    }],
    onArrowUpKeyDown: [{
      type: HostListener,
      args: ["keydown.arrowup", ["$event"]]
    }],
    onEnterKeyDown: [{
      type: HostListener,
      args: ["keydown.enter", ["$event"]]
    }, {
      type: HostListener,
      args: ["keydown.shift.enter", ["$event"]]
    }, {
      type: HostListener,
      args: ["keydown.meta.enter", ["$event"]]
    }],
    onPageDownKeyDown: [{
      type: HostListener,
      args: ["keydown.pagedown"]
    }, {
      type: HostListener,
      args: ["keydown.pageup"]
    }, {
      type: HostListener,
      args: ["keydown.home"]
    }, {
      type: HostListener,
      args: ["keydown.end"]
    }],
    onSpaceKeydown: [{
      type: HostListener,
      args: ["keydown.space"]
    }]
  });
})();
var _SelectableRowDblClick = class {
  constructor(dt, tableService) {
    __publicField(this, "dt");
    __publicField(this, "tableService");
    __publicField(this, "data");
    __publicField(this, "index");
    __publicField(this, "pSelectableRowDisabled");
    __publicField(this, "selected");
    __publicField(this, "subscription");
    this.dt = dt;
    this.tableService = tableService;
    if (this.isEnabled()) {
      this.subscription = this.dt.tableService.selectionSource$.subscribe(() => {
        this.selected = this.dt.isSelected(this.data);
      });
    }
  }
  ngOnInit() {
    if (this.isEnabled()) {
      this.selected = this.dt.isSelected(this.data);
    }
  }
  onClick(event2) {
    if (this.isEnabled()) {
      this.dt.handleRowClick({
        originalEvent: event2,
        rowData: this.data,
        rowIndex: this.index
      });
    }
  }
  isEnabled() {
    return this.pSelectableRowDisabled !== true;
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
};
var SelectableRowDblClick = _SelectableRowDblClick;
__publicField(SelectableRowDblClick, "ɵfac", function SelectableRowDblClick_Factory(t) {
  return new (t || _SelectableRowDblClick)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(TableService));
});
__publicField(SelectableRowDblClick, "ɵdir", ɵɵdefineDirective({
  type: _SelectableRowDblClick,
  selectors: [["", "pSelectableRowDblClick", ""]],
  hostAttrs: [1, "p-element"],
  hostVars: 4,
  hostBindings: function SelectableRowDblClick_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("dblclick", function SelectableRowDblClick_dblclick_HostBindingHandler($event) {
        return ctx.onClick($event);
      });
    }
    if (rf & 2) {
      ɵɵclassProp("p-selectable-row", ctx.isEnabled())("p-highlight", ctx.selected);
    }
  },
  inputs: {
    data: ["pSelectableRowDblClick", "data"],
    index: ["pSelectableRowIndex", "index"],
    pSelectableRowDisabled: "pSelectableRowDisabled"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SelectableRowDblClick, [{
    type: Directive,
    args: [{
      selector: "[pSelectableRowDblClick]",
      host: {
        class: "p-element",
        "[class.p-selectable-row]": "isEnabled()",
        "[class.p-highlight]": "selected"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: TableService
    }];
  }, {
    data: [{
      type: Input,
      args: ["pSelectableRowDblClick"]
    }],
    index: [{
      type: Input,
      args: ["pSelectableRowIndex"]
    }],
    pSelectableRowDisabled: [{
      type: Input
    }],
    onClick: [{
      type: HostListener,
      args: ["dblclick", ["$event"]]
    }]
  });
})();
var _ContextMenuRow = class {
  constructor(dt, tableService, el) {
    __publicField(this, "dt");
    __publicField(this, "tableService");
    __publicField(this, "el");
    __publicField(this, "data");
    __publicField(this, "index");
    __publicField(this, "pContextMenuRowDisabled");
    __publicField(this, "selected");
    __publicField(this, "subscription");
    this.dt = dt;
    this.tableService = tableService;
    this.el = el;
    if (this.isEnabled()) {
      this.subscription = this.dt.tableService.contextMenuSource$.subscribe((data) => {
        this.selected = this.dt.equals(this.data, data);
      });
    }
  }
  onContextMenu(event2) {
    if (this.isEnabled()) {
      this.dt.handleRowRightClick({
        originalEvent: event2,
        rowData: this.data,
        rowIndex: this.index
      });
      this.el.nativeElement.focus();
      event2.preventDefault();
    }
  }
  isEnabled() {
    return this.pContextMenuRowDisabled !== true;
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
};
var ContextMenuRow = _ContextMenuRow;
__publicField(ContextMenuRow, "ɵfac", function ContextMenuRow_Factory(t) {
  return new (t || _ContextMenuRow)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(TableService), ɵɵdirectiveInject(ElementRef));
});
__publicField(ContextMenuRow, "ɵdir", ɵɵdefineDirective({
  type: _ContextMenuRow,
  selectors: [["", "pContextMenuRow", ""]],
  hostAttrs: [1, "p-element"],
  hostVars: 3,
  hostBindings: function ContextMenuRow_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("contextmenu", function ContextMenuRow_contextmenu_HostBindingHandler($event) {
        return ctx.onContextMenu($event);
      });
    }
    if (rf & 2) {
      ɵɵattribute("tabindex", ctx.isEnabled() ? 0 : void 0);
      ɵɵclassProp("p-highlight-contextmenu", ctx.selected);
    }
  },
  inputs: {
    data: ["pContextMenuRow", "data"],
    index: ["pContextMenuRowIndex", "index"],
    pContextMenuRowDisabled: "pContextMenuRowDisabled"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ContextMenuRow, [{
    type: Directive,
    args: [{
      selector: "[pContextMenuRow]",
      host: {
        class: "p-element",
        "[class.p-highlight-contextmenu]": "selected",
        "[attr.tabindex]": "isEnabled() ? 0 : undefined"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: TableService
    }, {
      type: ElementRef
    }];
  }, {
    data: [{
      type: Input,
      args: ["pContextMenuRow"]
    }],
    index: [{
      type: Input,
      args: ["pContextMenuRowIndex"]
    }],
    pContextMenuRowDisabled: [{
      type: Input
    }],
    onContextMenu: [{
      type: HostListener,
      args: ["contextmenu", ["$event"]]
    }]
  });
})();
var _RowToggler = class {
  constructor(dt) {
    __publicField(this, "dt");
    __publicField(this, "data");
    __publicField(this, "pRowTogglerDisabled");
    this.dt = dt;
  }
  onClick(event2) {
    if (this.isEnabled()) {
      this.dt.toggleRow(this.data, event2);
      event2.preventDefault();
    }
  }
  isEnabled() {
    return this.pRowTogglerDisabled !== true;
  }
};
var RowToggler = _RowToggler;
__publicField(RowToggler, "ɵfac", function RowToggler_Factory(t) {
  return new (t || _RowToggler)(ɵɵdirectiveInject(Table));
});
__publicField(RowToggler, "ɵdir", ɵɵdefineDirective({
  type: _RowToggler,
  selectors: [["", "pRowToggler", ""]],
  hostAttrs: [1, "p-element"],
  hostBindings: function RowToggler_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("click", function RowToggler_click_HostBindingHandler($event) {
        return ctx.onClick($event);
      });
    }
  },
  inputs: {
    data: ["pRowToggler", "data"],
    pRowTogglerDisabled: "pRowTogglerDisabled"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(RowToggler, [{
    type: Directive,
    args: [{
      selector: "[pRowToggler]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }];
  }, {
    data: [{
      type: Input,
      args: ["pRowToggler"]
    }],
    pRowTogglerDisabled: [{
      type: Input
    }],
    onClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }]
  });
})();
var _ResizableColumn = class {
  constructor(document, platformId, renderer, dt, el, zone) {
    __publicField(this, "document");
    __publicField(this, "platformId");
    __publicField(this, "renderer");
    __publicField(this, "dt");
    __publicField(this, "el");
    __publicField(this, "zone");
    __publicField(this, "pResizableColumnDisabled");
    __publicField(this, "resizer");
    __publicField(this, "resizerMouseDownListener");
    __publicField(this, "documentMouseMoveListener");
    __publicField(this, "documentMouseUpListener");
    this.document = document;
    this.platformId = platformId;
    this.renderer = renderer;
    this.dt = dt;
    this.el = el;
    this.zone = zone;
  }
  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      if (this.isEnabled()) {
        DomHandler.addClass(this.el.nativeElement, "p-resizable-column");
        this.resizer = this.renderer.createElement("span");
        this.renderer.addClass(this.resizer, "p-column-resizer");
        this.renderer.appendChild(this.el.nativeElement, this.resizer);
        this.zone.runOutsideAngular(() => {
          this.resizerMouseDownListener = this.renderer.listen(this.resizer, "mousedown", this.onMouseDown.bind(this));
        });
      }
    }
  }
  bindDocumentEvents() {
    this.zone.runOutsideAngular(() => {
      this.documentMouseMoveListener = this.renderer.listen(this.document, "mousemove", this.onDocumentMouseMove.bind(this));
      this.documentMouseUpListener = this.renderer.listen(this.document, "mouseup", this.onDocumentMouseUp.bind(this));
    });
  }
  unbindDocumentEvents() {
    if (this.documentMouseMoveListener) {
      this.documentMouseMoveListener();
      this.documentMouseMoveListener = null;
    }
    if (this.documentMouseUpListener) {
      this.documentMouseUpListener();
      this.documentMouseUpListener = null;
    }
  }
  onMouseDown(event2) {
    if (event2.which === 1) {
      this.dt.onColumnResizeBegin(event2);
      this.bindDocumentEvents();
    }
  }
  onDocumentMouseMove(event2) {
    this.dt.onColumnResize(event2);
  }
  onDocumentMouseUp(event2) {
    this.dt.onColumnResizeEnd();
    this.unbindDocumentEvents();
  }
  isEnabled() {
    return this.pResizableColumnDisabled !== true;
  }
  ngOnDestroy() {
    if (this.resizerMouseDownListener) {
      this.resizerMouseDownListener();
      this.resizerMouseDownListener = null;
    }
    this.unbindDocumentEvents();
  }
};
var ResizableColumn = _ResizableColumn;
__publicField(ResizableColumn, "ɵfac", function ResizableColumn_Factory(t) {
  return new (t || _ResizableColumn)(ɵɵdirectiveInject(DOCUMENT), ɵɵdirectiveInject(PLATFORM_ID), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(Table), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone));
});
__publicField(ResizableColumn, "ɵdir", ɵɵdefineDirective({
  type: _ResizableColumn,
  selectors: [["", "pResizableColumn", ""]],
  hostAttrs: [1, "p-element"],
  inputs: {
    pResizableColumnDisabled: "pResizableColumnDisabled"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ResizableColumn, [{
    type: Directive,
    args: [{
      selector: "[pResizableColumn]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Document,
      decorators: [{
        type: Inject,
        args: [DOCUMENT]
      }]
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }, {
      type: Renderer2
    }, {
      type: Table
    }, {
      type: ElementRef
    }, {
      type: NgZone
    }];
  }, {
    pResizableColumnDisabled: [{
      type: Input
    }]
  });
})();
var _ReorderableColumn = class {
  constructor(platformId, renderer, dt, el, zone) {
    __publicField(this, "platformId");
    __publicField(this, "renderer");
    __publicField(this, "dt");
    __publicField(this, "el");
    __publicField(this, "zone");
    __publicField(this, "pReorderableColumnDisabled");
    __publicField(this, "dragStartListener");
    __publicField(this, "dragOverListener");
    __publicField(this, "dragEnterListener");
    __publicField(this, "dragLeaveListener");
    __publicField(this, "mouseDownListener");
    this.platformId = platformId;
    this.renderer = renderer;
    this.dt = dt;
    this.el = el;
    this.zone = zone;
  }
  ngAfterViewInit() {
    if (this.isEnabled()) {
      this.bindEvents();
    }
  }
  bindEvents() {
    if (isPlatformBrowser(this.platformId)) {
      this.zone.runOutsideAngular(() => {
        this.mouseDownListener = this.renderer.listen(this.el.nativeElement, "mousedown", this.onMouseDown.bind(this));
        this.dragStartListener = this.renderer.listen(this.el.nativeElement, "dragstart", this.onDragStart.bind(this));
        this.dragOverListener = this.renderer.listen(this.el.nativeElement, "dragover", this.onDragOver.bind(this));
        this.dragEnterListener = this.renderer.listen(this.el.nativeElement, "dragenter", this.onDragEnter.bind(this));
        this.dragLeaveListener = this.renderer.listen(this.el.nativeElement, "dragleave", this.onDragLeave.bind(this));
      });
    }
  }
  unbindEvents() {
    if (this.mouseDownListener) {
      this.mouseDownListener();
      this.mouseDownListener = null;
    }
    if (this.dragStartListener) {
      this.dragStartListener();
      this.dragStartListener = null;
    }
    if (this.dragOverListener) {
      this.dragOverListener();
      this.dragOverListener = null;
    }
    if (this.dragEnterListener) {
      this.dragEnterListener();
      this.dragEnterListener = null;
    }
    if (this.dragLeaveListener) {
      this.dragLeaveListener();
      this.dragLeaveListener = null;
    }
  }
  onMouseDown(event2) {
    if (event2.target.nodeName === "INPUT" || event2.target.nodeName === "TEXTAREA" || DomHandler.hasClass(event2.target, "p-column-resizer"))
      this.el.nativeElement.draggable = false;
    else
      this.el.nativeElement.draggable = true;
  }
  onDragStart(event2) {
    this.dt.onColumnDragStart(event2, this.el.nativeElement);
  }
  onDragOver(event2) {
    event2.preventDefault();
  }
  onDragEnter(event2) {
    this.dt.onColumnDragEnter(event2, this.el.nativeElement);
  }
  onDragLeave(event2) {
    this.dt.onColumnDragLeave(event2);
  }
  onDrop(event2) {
    if (this.isEnabled()) {
      this.dt.onColumnDrop(event2, this.el.nativeElement);
    }
  }
  isEnabled() {
    return this.pReorderableColumnDisabled !== true;
  }
  ngOnDestroy() {
    this.unbindEvents();
  }
};
var ReorderableColumn = _ReorderableColumn;
__publicField(ReorderableColumn, "ɵfac", function ReorderableColumn_Factory(t) {
  return new (t || _ReorderableColumn)(ɵɵdirectiveInject(PLATFORM_ID), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(Table), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone));
});
__publicField(ReorderableColumn, "ɵdir", ɵɵdefineDirective({
  type: _ReorderableColumn,
  selectors: [["", "pReorderableColumn", ""]],
  hostAttrs: [1, "p-element"],
  hostBindings: function ReorderableColumn_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("drop", function ReorderableColumn_drop_HostBindingHandler($event) {
        return ctx.onDrop($event);
      });
    }
  },
  inputs: {
    pReorderableColumnDisabled: "pReorderableColumnDisabled"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReorderableColumn, [{
    type: Directive,
    args: [{
      selector: "[pReorderableColumn]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }, {
      type: Renderer2
    }, {
      type: Table
    }, {
      type: ElementRef
    }, {
      type: NgZone
    }];
  }, {
    pReorderableColumnDisabled: [{
      type: Input
    }],
    onDrop: [{
      type: HostListener,
      args: ["drop", ["$event"]]
    }]
  });
})();
var _EditableColumn = class {
  constructor(dt, el, zone) {
    __publicField(this, "dt");
    __publicField(this, "el");
    __publicField(this, "zone");
    __publicField(this, "data");
    __publicField(this, "field");
    __publicField(this, "rowIndex");
    __publicField(this, "pEditableColumnDisabled");
    __publicField(this, "pFocusCellSelector");
    __publicField(this, "overlayEventListener");
    this.dt = dt;
    this.el = el;
    this.zone = zone;
  }
  ngAfterViewInit() {
    if (this.isEnabled()) {
      DomHandler.addClass(this.el.nativeElement, "p-editable-column");
    }
  }
  onClick(event2) {
    if (this.isEnabled()) {
      this.dt.selfClick = true;
      if (this.dt.editingCell) {
        if (this.dt.editingCell !== this.el.nativeElement) {
          if (!this.dt.isEditingCellValid()) {
            return;
          }
          this.closeEditingCell(true, event2);
          this.openCell();
        }
      } else {
        this.openCell();
      }
    }
  }
  openCell() {
    this.dt.updateEditingCell(this.el.nativeElement, this.data, this.field, this.rowIndex);
    DomHandler.addClass(this.el.nativeElement, "p-cell-editing");
    this.dt.onEditInit.emit({
      field: this.field,
      data: this.data,
      index: this.rowIndex
    });
    this.zone.runOutsideAngular(() => {
      setTimeout(() => {
        let focusCellSelector = this.pFocusCellSelector || "input, textarea, select";
        let focusableElement = DomHandler.findSingle(this.el.nativeElement, focusCellSelector);
        if (focusableElement) {
          focusableElement.focus();
        }
      }, 50);
    });
    this.overlayEventListener = (e) => {
      if (this.el && this.el.nativeElement.contains(e.target)) {
        this.dt.selfClick = true;
      }
    };
    this.dt.overlaySubscription = this.dt.overlayService.clickObservable.subscribe(this.overlayEventListener);
  }
  closeEditingCell(completed, event2) {
    const eventData = {
      field: this.dt.editingCellField,
      data: this.dt.editingCellData,
      originalEvent: event2,
      index: this.dt.editingCellRowIndex
    };
    if (completed) {
      this.dt.onEditComplete.emit(eventData);
    } else {
      this.dt.onEditCancel.emit(eventData);
      this.dt.value.forEach((element) => {
        if (element[this.dt.editingCellField] === this.data) {
          element[this.dt.editingCellField] = this.dt.editingCellData;
        }
      });
    }
    DomHandler.removeClass(this.dt.editingCell, "p-cell-editing");
    this.dt.editingCell = null;
    this.dt.editingCellData = null;
    this.dt.editingCellField = null;
    this.dt.unbindDocumentEditListener();
    if (this.dt.overlaySubscription) {
      this.dt.overlaySubscription.unsubscribe();
    }
  }
  onEnterKeyDown(event2) {
    if (this.isEnabled()) {
      if (this.dt.isEditingCellValid()) {
        this.closeEditingCell(true, event2);
      }
      event2.preventDefault();
    }
  }
  onTabKeyDown(event2) {
    if (this.isEnabled()) {
      if (this.dt.isEditingCellValid()) {
        this.closeEditingCell(true, event2);
      }
      event2.preventDefault();
    }
  }
  onEscapeKeyDown(event2) {
    if (this.isEnabled()) {
      if (this.dt.isEditingCellValid()) {
        this.closeEditingCell(false, event2);
      }
      event2.preventDefault();
    }
  }
  onShiftKeyDown(event2) {
    if (this.isEnabled()) {
      if (event2.shiftKey)
        this.moveToPreviousCell(event2);
      else {
        this.moveToNextCell(event2);
      }
    }
  }
  onArrowDown(event2) {
    if (this.isEnabled()) {
      let currentCell = this.findCell(event2.target);
      if (currentCell) {
        let cellIndex = DomHandler.index(currentCell);
        let targetCell = this.findNextEditableColumnByIndex(currentCell, cellIndex);
        if (targetCell) {
          if (this.dt.isEditingCellValid()) {
            this.closeEditingCell(true, event2);
          }
          DomHandler.invokeElementMethod(event2.target, "blur");
          DomHandler.invokeElementMethod(targetCell, "click");
        }
        event2.preventDefault();
      }
    }
  }
  onArrowUp(event2) {
    if (this.isEnabled()) {
      let currentCell = this.findCell(event2.target);
      if (currentCell) {
        let cellIndex = DomHandler.index(currentCell);
        let targetCell = this.findPrevEditableColumnByIndex(currentCell, cellIndex);
        if (targetCell) {
          if (this.dt.isEditingCellValid()) {
            this.closeEditingCell(true, event2);
          }
          DomHandler.invokeElementMethod(event2.target, "blur");
          DomHandler.invokeElementMethod(targetCell, "click");
        }
        event2.preventDefault();
      }
    }
  }
  onArrowLeft(event2) {
    if (this.isEnabled()) {
      this.moveToPreviousCell(event2);
    }
  }
  onArrowRight(event2) {
    if (this.isEnabled()) {
      this.moveToNextCell(event2);
    }
  }
  findCell(element) {
    if (element) {
      let cell = element;
      while (cell && !DomHandler.hasClass(cell, "p-cell-editing")) {
        cell = cell.parentElement;
      }
      return cell;
    } else {
      return null;
    }
  }
  moveToPreviousCell(event2) {
    let currentCell = this.findCell(event2.target);
    if (currentCell) {
      let targetCell = this.findPreviousEditableColumn(currentCell);
      if (targetCell) {
        if (this.dt.isEditingCellValid()) {
          this.closeEditingCell(true, event2);
        }
        DomHandler.invokeElementMethod(event2.target, "blur");
        DomHandler.invokeElementMethod(targetCell, "click");
        event2.preventDefault();
      }
    }
  }
  moveToNextCell(event2) {
    let currentCell = this.findCell(event2.target);
    if (currentCell) {
      let targetCell = this.findNextEditableColumn(currentCell);
      if (targetCell) {
        if (this.dt.isEditingCellValid()) {
          this.closeEditingCell(true, event2);
        }
        DomHandler.invokeElementMethod(event2.target, "blur");
        DomHandler.invokeElementMethod(targetCell, "click");
        event2.preventDefault();
      }
    }
  }
  findPreviousEditableColumn(cell) {
    var _a;
    let prevCell = cell.previousElementSibling;
    if (!prevCell) {
      let previousRow = (_a = cell.parentElement) == null ? void 0 : _a.previousElementSibling;
      if (previousRow) {
        prevCell = previousRow.lastElementChild;
      }
    }
    if (prevCell) {
      if (DomHandler.hasClass(prevCell, "p-editable-column"))
        return prevCell;
      else
        return this.findPreviousEditableColumn(prevCell);
    } else {
      return null;
    }
  }
  findNextEditableColumn(cell) {
    var _a;
    let nextCell = cell.nextElementSibling;
    if (!nextCell) {
      let nextRow = (_a = cell.parentElement) == null ? void 0 : _a.nextElementSibling;
      if (nextRow) {
        nextCell = nextRow.firstElementChild;
      }
    }
    if (nextCell) {
      if (DomHandler.hasClass(nextCell, "p-editable-column"))
        return nextCell;
      else
        return this.findNextEditableColumn(nextCell);
    } else {
      return null;
    }
  }
  findNextEditableColumnByIndex(cell, index) {
    var _a;
    let nextRow = (_a = cell.parentElement) == null ? void 0 : _a.nextElementSibling;
    if (nextRow) {
      let nextCell = nextRow.children[index];
      if (nextCell && DomHandler.hasClass(nextCell, "p-editable-column")) {
        return nextCell;
      }
      return null;
    } else {
      return null;
    }
  }
  findPrevEditableColumnByIndex(cell, index) {
    var _a;
    let prevRow = (_a = cell.parentElement) == null ? void 0 : _a.previousElementSibling;
    if (prevRow) {
      let prevCell = prevRow.children[index];
      if (prevCell && DomHandler.hasClass(prevCell, "p-editable-column")) {
        return prevCell;
      }
      return null;
    } else {
      return null;
    }
  }
  isEnabled() {
    return this.pEditableColumnDisabled !== true;
  }
  ngOnDestroy() {
    if (this.dt.overlaySubscription) {
      this.dt.overlaySubscription.unsubscribe();
    }
  }
};
var EditableColumn = _EditableColumn;
__publicField(EditableColumn, "ɵfac", function EditableColumn_Factory(t) {
  return new (t || _EditableColumn)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone));
});
__publicField(EditableColumn, "ɵdir", ɵɵdefineDirective({
  type: _EditableColumn,
  selectors: [["", "pEditableColumn", ""]],
  hostAttrs: [1, "p-element"],
  hostBindings: function EditableColumn_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("click", function EditableColumn_click_HostBindingHandler($event) {
        return ctx.onClick($event);
      })("keydown.enter", function EditableColumn_keydown_enter_HostBindingHandler($event) {
        return ctx.onEnterKeyDown($event);
      })("keydown.tab", function EditableColumn_keydown_tab_HostBindingHandler($event) {
        return ctx.onShiftKeyDown($event);
      })("keydown.escape", function EditableColumn_keydown_escape_HostBindingHandler($event) {
        return ctx.onEscapeKeyDown($event);
      })("keydown.shift.tab", function EditableColumn_keydown_shift_tab_HostBindingHandler($event) {
        return ctx.onShiftKeyDown($event);
      })("keydown.meta.tab", function EditableColumn_keydown_meta_tab_HostBindingHandler($event) {
        return ctx.onShiftKeyDown($event);
      })("keydown.arrowdown", function EditableColumn_keydown_arrowdown_HostBindingHandler($event) {
        return ctx.onArrowDown($event);
      })("keydown.arrowup", function EditableColumn_keydown_arrowup_HostBindingHandler($event) {
        return ctx.onArrowUp($event);
      })("keydown.arrowleft", function EditableColumn_keydown_arrowleft_HostBindingHandler($event) {
        return ctx.onArrowLeft($event);
      })("keydown.arrowright", function EditableColumn_keydown_arrowright_HostBindingHandler($event) {
        return ctx.onArrowRight($event);
      });
    }
  },
  inputs: {
    data: ["pEditableColumn", "data"],
    field: ["pEditableColumnField", "field"],
    rowIndex: ["pEditableColumnRowIndex", "rowIndex"],
    pEditableColumnDisabled: "pEditableColumnDisabled",
    pFocusCellSelector: "pFocusCellSelector"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EditableColumn, [{
    type: Directive,
    args: [{
      selector: "[pEditableColumn]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: ElementRef
    }, {
      type: NgZone
    }];
  }, {
    data: [{
      type: Input,
      args: ["pEditableColumn"]
    }],
    field: [{
      type: Input,
      args: ["pEditableColumnField"]
    }],
    rowIndex: [{
      type: Input,
      args: ["pEditableColumnRowIndex"]
    }],
    pEditableColumnDisabled: [{
      type: Input
    }],
    pFocusCellSelector: [{
      type: Input
    }],
    onClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }],
    onEnterKeyDown: [{
      type: HostListener,
      args: ["keydown.enter", ["$event"]]
    }],
    onTabKeyDown: [{
      type: HostListener,
      args: ["keydown.tab", ["$event"]]
    }],
    onEscapeKeyDown: [{
      type: HostListener,
      args: ["keydown.escape", ["$event"]]
    }],
    onShiftKeyDown: [{
      type: HostListener,
      args: ["keydown.tab", ["$event"]]
    }, {
      type: HostListener,
      args: ["keydown.shift.tab", ["$event"]]
    }, {
      type: HostListener,
      args: ["keydown.meta.tab", ["$event"]]
    }],
    onArrowDown: [{
      type: HostListener,
      args: ["keydown.arrowdown", ["$event"]]
    }],
    onArrowUp: [{
      type: HostListener,
      args: ["keydown.arrowup", ["$event"]]
    }],
    onArrowLeft: [{
      type: HostListener,
      args: ["keydown.arrowleft", ["$event"]]
    }],
    onArrowRight: [{
      type: HostListener,
      args: ["keydown.arrowright", ["$event"]]
    }]
  });
})();
var _EditableRow = class {
  constructor(el) {
    __publicField(this, "el");
    __publicField(this, "data");
    __publicField(this, "pEditableRowDisabled");
    this.el = el;
  }
  isEnabled() {
    return this.pEditableRowDisabled !== true;
  }
};
var EditableRow = _EditableRow;
__publicField(EditableRow, "ɵfac", function EditableRow_Factory(t) {
  return new (t || _EditableRow)(ɵɵdirectiveInject(ElementRef));
});
__publicField(EditableRow, "ɵdir", ɵɵdefineDirective({
  type: _EditableRow,
  selectors: [["", "pEditableRow", ""]],
  hostAttrs: [1, "p-element"],
  inputs: {
    data: ["pEditableRow", "data"],
    pEditableRowDisabled: "pEditableRowDisabled"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(EditableRow, [{
    type: Directive,
    args: [{
      selector: "[pEditableRow]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: ElementRef
    }];
  }, {
    data: [{
      type: Input,
      args: ["pEditableRow"]
    }],
    pEditableRowDisabled: [{
      type: Input
    }]
  });
})();
var _InitEditableRow = class {
  constructor(dt, editableRow) {
    __publicField(this, "dt");
    __publicField(this, "editableRow");
    this.dt = dt;
    this.editableRow = editableRow;
  }
  onClick(event2) {
    this.dt.initRowEdit(this.editableRow.data);
    event2.preventDefault();
  }
};
var InitEditableRow = _InitEditableRow;
__publicField(InitEditableRow, "ɵfac", function InitEditableRow_Factory(t) {
  return new (t || _InitEditableRow)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(EditableRow));
});
__publicField(InitEditableRow, "ɵdir", ɵɵdefineDirective({
  type: _InitEditableRow,
  selectors: [["", "pInitEditableRow", ""]],
  hostAttrs: [1, "p-element"],
  hostBindings: function InitEditableRow_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("click", function InitEditableRow_click_HostBindingHandler($event) {
        return ctx.onClick($event);
      });
    }
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InitEditableRow, [{
    type: Directive,
    args: [{
      selector: "[pInitEditableRow]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: EditableRow
    }];
  }, {
    onClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }]
  });
})();
var _SaveEditableRow = class {
  constructor(dt, editableRow) {
    __publicField(this, "dt");
    __publicField(this, "editableRow");
    this.dt = dt;
    this.editableRow = editableRow;
  }
  onClick(event2) {
    this.dt.saveRowEdit(this.editableRow.data, this.editableRow.el.nativeElement);
    event2.preventDefault();
  }
};
var SaveEditableRow = _SaveEditableRow;
__publicField(SaveEditableRow, "ɵfac", function SaveEditableRow_Factory(t) {
  return new (t || _SaveEditableRow)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(EditableRow));
});
__publicField(SaveEditableRow, "ɵdir", ɵɵdefineDirective({
  type: _SaveEditableRow,
  selectors: [["", "pSaveEditableRow", ""]],
  hostAttrs: [1, "p-element"],
  hostBindings: function SaveEditableRow_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("click", function SaveEditableRow_click_HostBindingHandler($event) {
        return ctx.onClick($event);
      });
    }
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(SaveEditableRow, [{
    type: Directive,
    args: [{
      selector: "[pSaveEditableRow]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: EditableRow
    }];
  }, {
    onClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }]
  });
})();
var _CancelEditableRow = class {
  constructor(dt, editableRow) {
    __publicField(this, "dt");
    __publicField(this, "editableRow");
    this.dt = dt;
    this.editableRow = editableRow;
  }
  onClick(event2) {
    this.dt.cancelRowEdit(this.editableRow.data);
    event2.preventDefault();
  }
};
var CancelEditableRow = _CancelEditableRow;
__publicField(CancelEditableRow, "ɵfac", function CancelEditableRow_Factory(t) {
  return new (t || _CancelEditableRow)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(EditableRow));
});
__publicField(CancelEditableRow, "ɵdir", ɵɵdefineDirective({
  type: _CancelEditableRow,
  selectors: [["", "pCancelEditableRow", ""]],
  hostAttrs: [1, "p-element"],
  hostBindings: function CancelEditableRow_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("click", function CancelEditableRow_click_HostBindingHandler($event) {
        return ctx.onClick($event);
      });
    }
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CancelEditableRow, [{
    type: Directive,
    args: [{
      selector: "[pCancelEditableRow]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: EditableRow
    }];
  }, {
    onClick: [{
      type: HostListener,
      args: ["click", ["$event"]]
    }]
  });
})();
var _CellEditor = class {
  constructor(dt, editableColumn, editableRow) {
    __publicField(this, "dt");
    __publicField(this, "editableColumn");
    __publicField(this, "editableRow");
    __publicField(this, "templates");
    __publicField(this, "inputTemplate");
    __publicField(this, "outputTemplate");
    this.dt = dt;
    this.editableColumn = editableColumn;
    this.editableRow = editableRow;
  }
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "input":
          this.inputTemplate = item.template;
          break;
        case "output":
          this.outputTemplate = item.template;
          break;
      }
    });
  }
  get editing() {
    return this.dt.editingCell && this.editableColumn && this.dt.editingCell === this.editableColumn.el.nativeElement || this.editableRow && this.dt.editMode === "row" && this.dt.isRowEditing(this.editableRow.data);
  }
};
var CellEditor = _CellEditor;
__publicField(CellEditor, "ɵfac", function CellEditor_Factory(t) {
  return new (t || _CellEditor)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(EditableColumn, 8), ɵɵdirectiveInject(EditableRow, 8));
});
__publicField(CellEditor, "ɵcmp", ɵɵdefineComponent({
  type: _CellEditor,
  selectors: [["p-cellEditor"]],
  contentQueries: function CellEditor_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  hostAttrs: [1, "p-element"],
  decls: 2,
  vars: 2,
  consts: [[4, "ngIf"], [4, "ngTemplateOutlet"]],
  template: function CellEditor_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵtemplate(0, CellEditor_ng_container_0_Template, 2, 1, "ng-container", 0);
      ɵɵtemplate(1, CellEditor_ng_container_1_Template, 2, 1, "ng-container", 0);
    }
    if (rf & 2) {
      ɵɵproperty("ngIf", ctx.editing);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", !ctx.editing);
    }
  },
  dependencies: [NgIf, NgTemplateOutlet],
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CellEditor, [{
    type: Component,
    args: [{
      selector: "p-cellEditor",
      template: `
        <ng-container *ngIf="editing">
            <ng-container *ngTemplateOutlet="inputTemplate"></ng-container>
        </ng-container>
        <ng-container *ngIf="!editing">
            <ng-container *ngTemplateOutlet="outputTemplate"></ng-container>
        </ng-container>
    `,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: EditableColumn,
      decorators: [{
        type: Optional
      }]
    }, {
      type: EditableRow,
      decorators: [{
        type: Optional
      }]
    }];
  }, {
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var _TableRadioButton = class {
  constructor(dt, cd) {
    __publicField(this, "dt");
    __publicField(this, "cd");
    __publicField(this, "disabled");
    __publicField(this, "value");
    __publicField(this, "index");
    __publicField(this, "inputId");
    __publicField(this, "name");
    __publicField(this, "ariaLabel");
    __publicField(this, "inputViewChild");
    __publicField(this, "checked");
    __publicField(this, "focused");
    __publicField(this, "subscription");
    this.dt = dt;
    this.cd = cd;
    this.subscription = this.dt.tableService.selectionSource$.subscribe(() => {
      this.checked = this.dt.isSelected(this.value);
      this.cd.markForCheck();
    });
  }
  ngOnInit() {
    this.checked = this.dt.isSelected(this.value);
  }
  onClick(event2) {
    var _a, _b;
    if (!this.disabled) {
      this.dt.toggleRowWithRadio({
        originalEvent: event2,
        rowIndex: this.index
      }, this.value);
      (_b = (_a = this.inputViewChild) == null ? void 0 : _a.nativeElement) == null ? void 0 : _b.focus();
    }
    DomHandler.clearSelection();
  }
  onFocus() {
    this.focused = true;
  }
  onBlur() {
    this.focused = false;
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
};
var TableRadioButton = _TableRadioButton;
__publicField(TableRadioButton, "ɵfac", function TableRadioButton_Factory(t) {
  return new (t || _TableRadioButton)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(ChangeDetectorRef));
});
__publicField(TableRadioButton, "ɵcmp", ɵɵdefineComponent({
  type: _TableRadioButton,
  selectors: [["p-tableRadioButton"]],
  viewQuery: function TableRadioButton_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c222, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.inputViewChild = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    disabled: "disabled",
    value: "value",
    index: "index",
    inputId: "inputId",
    name: "name",
    ariaLabel: "ariaLabel"
  },
  decls: 7,
  vars: 16,
  consts: [[1, "p-radiobutton", "p-component", 3, "ngClass", "click"], [1, "p-hidden-accessible"], ["type", "radio", 3, "checked", "disabled", "focus", "blur"], ["rb", ""], ["role", "radio", 3, "ngClass"], ["box", ""], [1, "p-radiobutton-icon"]],
  template: function TableRadioButton_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0);
      ɵɵlistener("click", function TableRadioButton_Template_div_click_0_listener($event) {
        return ctx.onClick($event);
      });
      ɵɵelementStart(1, "div", 1)(2, "input", 2, 3);
      ɵɵlistener("focus", function TableRadioButton_Template_input_focus_2_listener() {
        return ctx.onFocus();
      })("blur", function TableRadioButton_Template_input_blur_2_listener() {
        return ctx.onBlur();
      });
      ɵɵelementEnd()();
      ɵɵelementStart(4, "div", 4, 5);
      ɵɵelement(6, "div", 6);
      ɵɵelementEnd()();
    }
    if (rf & 2) {
      ɵɵproperty("ngClass", ɵɵpureFunction3(8, _c232, ctx.focused, ctx.checked, ctx.disabled));
      ɵɵadvance(2);
      ɵɵproperty("checked", ctx.checked)("disabled", ctx.disabled);
      ɵɵattribute("id", ctx.inputId)("name", ctx.name)("aria-label", ctx.ariaLabel);
      ɵɵadvance(2);
      ɵɵproperty("ngClass", ɵɵpureFunction3(12, _c242, ctx.checked, ctx.focused, ctx.disabled));
      ɵɵattribute("aria-checked", ctx.checked);
    }
  },
  dependencies: [NgClass],
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TableRadioButton, [{
    type: Component,
    args: [{
      selector: "p-tableRadioButton",
      template: `
        <div class="p-radiobutton p-component" [ngClass]="{ 'p-radiobutton-focused': focused, 'p-radiobutton-checked': checked, 'p-radiobutton-disabled': disabled }" (click)="onClick($event)">
            <div class="p-hidden-accessible">
                <input #rb type="radio" [attr.id]="inputId" [attr.name]="name" [checked]="checked" (focus)="onFocus()" (blur)="onBlur()" [disabled]="disabled" [attr.aria-label]="ariaLabel" />
            </div>
            <div #box [ngClass]="{ 'p-radiobutton-box p-component': true, 'p-highlight': checked, 'p-focus': focused, 'p-disabled': disabled }" role="radio" [attr.aria-checked]="checked">
                <div class="p-radiobutton-icon"></div>
            </div>
        </div>
    `,
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: ChangeDetectorRef
    }];
  }, {
    disabled: [{
      type: Input
    }],
    value: [{
      type: Input
    }],
    index: [{
      type: Input
    }],
    inputId: [{
      type: Input
    }],
    name: [{
      type: Input
    }],
    ariaLabel: [{
      type: Input
    }],
    inputViewChild: [{
      type: ViewChild,
      args: ["rb"]
    }]
  });
})();
var _TableCheckbox = class {
  constructor(dt, tableService, cd) {
    __publicField(this, "dt");
    __publicField(this, "tableService");
    __publicField(this, "cd");
    __publicField(this, "disabled");
    __publicField(this, "value");
    __publicField(this, "index");
    __publicField(this, "inputId");
    __publicField(this, "name");
    __publicField(this, "required");
    __publicField(this, "ariaLabel");
    __publicField(this, "checked");
    __publicField(this, "focused");
    __publicField(this, "subscription");
    this.dt = dt;
    this.tableService = tableService;
    this.cd = cd;
    this.subscription = this.dt.tableService.selectionSource$.subscribe(() => {
      this.checked = this.dt.isSelected(this.value);
      this.cd.markForCheck();
    });
  }
  ngOnInit() {
    this.checked = this.dt.isSelected(this.value);
  }
  onClick(event2) {
    if (!this.disabled) {
      this.dt.toggleRowWithCheckbox({
        originalEvent: event2,
        rowIndex: this.index
      }, this.value);
    }
    DomHandler.clearSelection();
  }
  onFocus() {
    this.focused = true;
  }
  onBlur() {
    this.focused = false;
  }
  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }
};
var TableCheckbox = _TableCheckbox;
__publicField(TableCheckbox, "ɵfac", function TableCheckbox_Factory(t) {
  return new (t || _TableCheckbox)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(TableService), ɵɵdirectiveInject(ChangeDetectorRef));
});
__publicField(TableCheckbox, "ɵcmp", ɵɵdefineComponent({
  type: _TableCheckbox,
  selectors: [["p-tableCheckbox"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    disabled: "disabled",
    value: "value",
    index: "index",
    inputId: "inputId",
    name: "name",
    required: "required",
    ariaLabel: "ariaLabel"
  },
  decls: 7,
  vars: 18,
  consts: [[1, "p-checkbox", "p-component", 3, "ngClass", "click"], [1, "p-hidden-accessible"], ["type", "checkbox", 3, "checked", "disabled", "focus", "blur"], ["role", "checkbox", 3, "ngClass"], ["box", ""], [4, "ngIf"], [3, "styleClass", 4, "ngIf"], [3, "styleClass"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"]],
  template: function TableCheckbox_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0);
      ɵɵlistener("click", function TableCheckbox_Template_div_click_0_listener($event) {
        return ctx.onClick($event);
      });
      ɵɵelementStart(1, "div", 1)(2, "input", 2);
      ɵɵlistener("focus", function TableCheckbox_Template_input_focus_2_listener() {
        return ctx.onFocus();
      })("blur", function TableCheckbox_Template_input_blur_2_listener() {
        return ctx.onBlur();
      });
      ɵɵelementEnd()();
      ɵɵelementStart(3, "div", 3, 4);
      ɵɵtemplate(5, TableCheckbox_ng_container_5_Template, 2, 1, "ng-container", 5);
      ɵɵtemplate(6, TableCheckbox_span_6_Template, 2, 4, "span", 5);
      ɵɵelementEnd()();
    }
    if (rf & 2) {
      ɵɵproperty("ngClass", ɵɵpureFunction2(11, _c252, ctx.focused, ctx.disabled));
      ɵɵadvance(2);
      ɵɵproperty("checked", ctx.checked)("disabled", ctx.disabled);
      ɵɵattribute("id", ctx.inputId)("name", ctx.name)("required", ctx.required)("aria-label", ctx.ariaLabel);
      ɵɵadvance(1);
      ɵɵproperty("ngClass", ɵɵpureFunction3(14, _c262, ctx.checked, ctx.focused, ctx.disabled));
      ɵɵattribute("aria-checked", ctx.checked);
      ɵɵadvance(2);
      ɵɵproperty("ngIf", !ctx.dt.checkboxIconTemplate);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.dt.checkboxIconTemplate);
    }
  },
  dependencies: function() {
    return [NgClass, NgIf, NgTemplateOutlet, CheckIcon];
  },
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TableCheckbox, [{
    type: Component,
    args: [{
      selector: "p-tableCheckbox",
      template: `
        <div class="p-checkbox p-component" [ngClass]="{ 'p-checkbox-focused': focused, 'p-checkbox-disabled': disabled }" (click)="onClick($event)">
            <div class="p-hidden-accessible">
                <input type="checkbox" [attr.id]="inputId" [attr.name]="name" [checked]="checked" (focus)="onFocus()" (blur)="onBlur()" [disabled]="disabled" [attr.required]="required" [attr.aria-label]="ariaLabel" />
            </div>
            <div #box [ngClass]="{ 'p-checkbox-box p-component': true, 'p-highlight': checked, 'p-focus': focused, 'p-disabled': disabled }" role="checkbox" [attr.aria-checked]="checked">
                <ng-container *ngIf="!dt.checkboxIconTemplate">
                    <CheckIcon [styleClass]="'p-checkbox-icon'" *ngIf="checked" />
                </ng-container>
                <span *ngIf="dt.checkboxIconTemplate">
                    <ng-template *ngTemplateOutlet="dt.checkboxIconTemplate; context: { $implicit: checked }"></ng-template>
                </span>
            </div>
        </div>
    `,
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: TableService
    }, {
      type: ChangeDetectorRef
    }];
  }, {
    disabled: [{
      type: Input
    }],
    value: [{
      type: Input
    }],
    index: [{
      type: Input
    }],
    inputId: [{
      type: Input
    }],
    name: [{
      type: Input
    }],
    required: [{
      type: Input
    }],
    ariaLabel: [{
      type: Input
    }]
  });
})();
var _TableHeaderCheckbox = class {
  constructor(dt, tableService, cd) {
    __publicField(this, "dt");
    __publicField(this, "tableService");
    __publicField(this, "cd");
    __publicField(this, "disabled");
    __publicField(this, "inputId");
    __publicField(this, "name");
    __publicField(this, "ariaLabel");
    __publicField(this, "checked");
    __publicField(this, "focused");
    __publicField(this, "selectionChangeSubscription");
    __publicField(this, "valueChangeSubscription");
    this.dt = dt;
    this.tableService = tableService;
    this.cd = cd;
    this.valueChangeSubscription = this.dt.tableService.valueSource$.subscribe(() => {
      this.checked = this.updateCheckedState();
    });
    this.selectionChangeSubscription = this.dt.tableService.selectionSource$.subscribe(() => {
      this.checked = this.updateCheckedState();
    });
  }
  ngOnInit() {
    this.checked = this.updateCheckedState();
  }
  onClick(event2) {
    if (!this.disabled) {
      if (this.dt.value && this.dt.value.length > 0) {
        this.dt.toggleRowsWithCheckbox(event2, !this.checked);
      }
    }
    DomHandler.clearSelection();
  }
  onFocus() {
    this.focused = true;
  }
  onBlur() {
    this.focused = false;
  }
  isDisabled() {
    return this.disabled || !this.dt.value || !this.dt.value.length;
  }
  ngOnDestroy() {
    if (this.selectionChangeSubscription) {
      this.selectionChangeSubscription.unsubscribe();
    }
    if (this.valueChangeSubscription) {
      this.valueChangeSubscription.unsubscribe();
    }
  }
  updateCheckedState() {
    this.cd.markForCheck();
    if (this.dt._selectAll !== null) {
      return this.dt._selectAll;
    } else {
      const data = this.dt.selectionPageOnly ? this.dt.dataToRender(this.dt.processedData) : this.dt.processedData;
      const val = this.dt.frozenValue ? [...this.dt.frozenValue, ...data] : data;
      const selectableVal = this.dt.rowSelectable ? val.filter((data2, index) => this.dt.rowSelectable({
        data: data2,
        index
      })) : val;
      return ObjectUtils.isNotEmpty(selectableVal) && ObjectUtils.isNotEmpty(this.dt.selection) && selectableVal.every((v) => this.dt.selection.some((s) => this.dt.equals(v, s)));
    }
  }
};
var TableHeaderCheckbox = _TableHeaderCheckbox;
__publicField(TableHeaderCheckbox, "ɵfac", function TableHeaderCheckbox_Factory(t) {
  return new (t || _TableHeaderCheckbox)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(TableService), ɵɵdirectiveInject(ChangeDetectorRef));
});
__publicField(TableHeaderCheckbox, "ɵcmp", ɵɵdefineComponent({
  type: _TableHeaderCheckbox,
  selectors: [["p-tableHeaderCheckbox"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    disabled: "disabled",
    inputId: "inputId",
    name: "name",
    ariaLabel: "ariaLabel"
  },
  decls: 8,
  vars: 17,
  consts: [[1, "p-checkbox", "p-component", 3, "ngClass", "click"], [1, "p-hidden-accessible"], ["type", "checkbox", 3, "checked", "disabled", "focus", "blur"], ["cb", ""], ["role", "checkbox", 3, "ngClass"], ["box", ""], [4, "ngIf"], ["class", "p-checkbox-icon", 4, "ngIf"], [3, "styleClass", 4, "ngIf"], [3, "styleClass"], [1, "p-checkbox-icon"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"]],
  template: function TableHeaderCheckbox_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0);
      ɵɵlistener("click", function TableHeaderCheckbox_Template_div_click_0_listener($event) {
        return ctx.onClick($event);
      });
      ɵɵelementStart(1, "div", 1)(2, "input", 2, 3);
      ɵɵlistener("focus", function TableHeaderCheckbox_Template_input_focus_2_listener() {
        return ctx.onFocus();
      })("blur", function TableHeaderCheckbox_Template_input_blur_2_listener() {
        return ctx.onBlur();
      });
      ɵɵelementEnd()();
      ɵɵelementStart(4, "div", 4, 5);
      ɵɵtemplate(6, TableHeaderCheckbox_ng_container_6_Template, 2, 1, "ng-container", 6);
      ɵɵtemplate(7, TableHeaderCheckbox_span_7_Template, 2, 4, "span", 7);
      ɵɵelementEnd()();
    }
    if (rf & 2) {
      ɵɵproperty("ngClass", ɵɵpureFunction2(10, _c252, ctx.focused, ctx.isDisabled()));
      ɵɵadvance(2);
      ɵɵproperty("checked", ctx.checked)("disabled", ctx.isDisabled());
      ɵɵattribute("id", ctx.inputId)("name", ctx.name)("aria-label", ctx.ariaLabel);
      ɵɵadvance(2);
      ɵɵproperty("ngClass", ɵɵpureFunction3(13, _c272, ctx.checked, ctx.focused, ctx.isDisabled()));
      ɵɵattribute("aria-checked", ctx.checked);
      ɵɵadvance(2);
      ɵɵproperty("ngIf", !ctx.dt.headerCheckboxIconTemplate);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.dt.headerCheckboxIconTemplate);
    }
  },
  dependencies: function() {
    return [NgClass, NgIf, NgTemplateOutlet, CheckIcon];
  },
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TableHeaderCheckbox, [{
    type: Component,
    args: [{
      selector: "p-tableHeaderCheckbox",
      template: `
        <div class="p-checkbox p-component" [ngClass]="{ 'p-checkbox-focused': focused, 'p-checkbox-disabled': isDisabled() }" (click)="onClick($event)">
            <div class="p-hidden-accessible">
                <input #cb type="checkbox" [attr.id]="inputId" [attr.name]="name" [checked]="checked" (focus)="onFocus()" (blur)="onBlur()" [disabled]="isDisabled()" [attr.aria-label]="ariaLabel" />
            </div>
            <div #box [ngClass]="{ 'p-checkbox-box': true, 'p-highlight': checked, 'p-focus': focused, 'p-disabled': isDisabled() }" role="checkbox" [attr.aria-checked]="checked">
                <ng-container *ngIf="!dt.headerCheckboxIconTemplate">
                    <CheckIcon *ngIf="checked" [styleClass]="'p-checkbox-icon'" />
                </ng-container>
                <span class="p-checkbox-icon" *ngIf="dt.headerCheckboxIconTemplate">
                    <ng-template *ngTemplateOutlet="dt.headerCheckboxIconTemplate; context: { $implicit: checked }"></ng-template>
                </span>
            </div>
        </div>
    `,
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: TableService
    }, {
      type: ChangeDetectorRef
    }];
  }, {
    disabled: [{
      type: Input
    }],
    inputId: [{
      type: Input
    }],
    name: [{
      type: Input
    }],
    ariaLabel: [{
      type: Input
    }]
  });
})();
var _ReorderableRowHandle = class {
  constructor(el) {
    __publicField(this, "el");
    this.el = el;
  }
  ngAfterViewInit() {
    DomHandler.addClass(this.el.nativeElement, "p-datatable-reorderablerow-handle");
  }
};
var ReorderableRowHandle = _ReorderableRowHandle;
__publicField(ReorderableRowHandle, "ɵfac", function ReorderableRowHandle_Factory(t) {
  return new (t || _ReorderableRowHandle)(ɵɵdirectiveInject(ElementRef));
});
__publicField(ReorderableRowHandle, "ɵdir", ɵɵdefineDirective({
  type: _ReorderableRowHandle,
  selectors: [["", "pReorderableRowHandle", ""]],
  hostAttrs: [1, "p-element"]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReorderableRowHandle, [{
    type: Directive,
    args: [{
      selector: "[pReorderableRowHandle]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: ElementRef
    }];
  }, null);
})();
var _ReorderableRow = class {
  constructor(renderer, dt, el, zone) {
    __publicField(this, "renderer");
    __publicField(this, "dt");
    __publicField(this, "el");
    __publicField(this, "zone");
    __publicField(this, "index");
    __publicField(this, "pReorderableRowDisabled");
    __publicField(this, "mouseDownListener");
    __publicField(this, "dragStartListener");
    __publicField(this, "dragEndListener");
    __publicField(this, "dragOverListener");
    __publicField(this, "dragLeaveListener");
    __publicField(this, "dropListener");
    this.renderer = renderer;
    this.dt = dt;
    this.el = el;
    this.zone = zone;
  }
  ngAfterViewInit() {
    if (this.isEnabled()) {
      this.el.nativeElement.droppable = true;
      this.bindEvents();
    }
  }
  bindEvents() {
    this.zone.runOutsideAngular(() => {
      this.mouseDownListener = this.renderer.listen(this.el.nativeElement, "mousedown", this.onMouseDown.bind(this));
      this.dragStartListener = this.renderer.listen(this.el.nativeElement, "dragstart", this.onDragStart.bind(this));
      this.dragEndListener = this.renderer.listen(this.el.nativeElement, "dragend", this.onDragEnd.bind(this));
      this.dragOverListener = this.renderer.listen(this.el.nativeElement, "dragover", this.onDragOver.bind(this));
      this.dragLeaveListener = this.renderer.listen(this.el.nativeElement, "dragleave", this.onDragLeave.bind(this));
    });
  }
  unbindEvents() {
    if (this.mouseDownListener) {
      this.mouseDownListener();
      this.mouseDownListener = null;
    }
    if (this.dragStartListener) {
      this.dragStartListener();
      this.dragStartListener = null;
    }
    if (this.dragEndListener) {
      this.dragEndListener();
      this.dragEndListener = null;
    }
    if (this.dragOverListener) {
      this.dragOverListener();
      this.dragOverListener = null;
    }
    if (this.dragLeaveListener) {
      this.dragLeaveListener();
      this.dragLeaveListener = null;
    }
  }
  onMouseDown(event2) {
    if (DomHandler.hasClass(event2.target, "p-datatable-reorderablerow-handle"))
      this.el.nativeElement.draggable = true;
    else
      this.el.nativeElement.draggable = false;
  }
  onDragStart(event2) {
    this.dt.onRowDragStart(event2, this.index);
  }
  onDragEnd(event2) {
    this.dt.onRowDragEnd(event2);
    this.el.nativeElement.draggable = false;
  }
  onDragOver(event2) {
    this.dt.onRowDragOver(event2, this.index, this.el.nativeElement);
    event2.preventDefault();
  }
  onDragLeave(event2) {
    this.dt.onRowDragLeave(event2, this.el.nativeElement);
  }
  isEnabled() {
    return this.pReorderableRowDisabled !== true;
  }
  onDrop(event2) {
    if (this.isEnabled() && this.dt.rowDragging) {
      this.dt.onRowDrop(event2, this.el.nativeElement);
    }
    event2.preventDefault();
  }
  ngOnDestroy() {
    this.unbindEvents();
  }
};
var ReorderableRow = _ReorderableRow;
__publicField(ReorderableRow, "ɵfac", function ReorderableRow_Factory(t) {
  return new (t || _ReorderableRow)(ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(Table), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone));
});
__publicField(ReorderableRow, "ɵdir", ɵɵdefineDirective({
  type: _ReorderableRow,
  selectors: [["", "pReorderableRow", ""]],
  hostAttrs: [1, "p-element"],
  hostBindings: function ReorderableRow_HostBindings(rf, ctx) {
    if (rf & 1) {
      ɵɵlistener("drop", function ReorderableRow_drop_HostBindingHandler($event) {
        return ctx.onDrop($event);
      });
    }
  },
  inputs: {
    index: ["pReorderableRow", "index"],
    pReorderableRowDisabled: "pReorderableRowDisabled"
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ReorderableRow, [{
    type: Directive,
    args: [{
      selector: "[pReorderableRow]",
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Renderer2
    }, {
      type: Table
    }, {
      type: ElementRef
    }, {
      type: NgZone
    }];
  }, {
    index: [{
      type: Input,
      args: ["pReorderableRow"]
    }],
    pReorderableRowDisabled: [{
      type: Input
    }],
    onDrop: [{
      type: HostListener,
      args: ["drop", ["$event"]]
    }]
  });
})();
var _ColumnFilter = class {
  constructor(document, el, dt, renderer, config, overlayService) {
    __publicField(this, "document");
    __publicField(this, "el");
    __publicField(this, "dt");
    __publicField(this, "renderer");
    __publicField(this, "config");
    __publicField(this, "overlayService");
    __publicField(this, "field");
    __publicField(this, "type", "text");
    __publicField(this, "display", "row");
    __publicField(this, "showMenu", true);
    __publicField(this, "matchMode");
    __publicField(this, "operator", FilterOperator.AND);
    __publicField(this, "showOperator", true);
    __publicField(this, "showClearButton", true);
    __publicField(this, "showApplyButton", true);
    __publicField(this, "showMatchModes", true);
    __publicField(this, "showAddButton", true);
    __publicField(this, "hideOnClear", false);
    __publicField(this, "placeholder");
    __publicField(this, "matchModeOptions");
    __publicField(this, "maxConstraints", 2);
    __publicField(this, "minFractionDigits");
    __publicField(this, "maxFractionDigits");
    __publicField(this, "prefix");
    __publicField(this, "suffix");
    __publicField(this, "locale");
    __publicField(this, "localeMatcher");
    __publicField(this, "currency");
    __publicField(this, "currencyDisplay");
    __publicField(this, "useGrouping", true);
    __publicField(this, "showButtons", true);
    __publicField(this, "icon");
    __publicField(this, "templates");
    __publicField(this, "overlaySubscription");
    __publicField(this, "headerTemplate");
    __publicField(this, "filterTemplate");
    __publicField(this, "footerTemplate");
    __publicField(this, "filterIconTemplate");
    __publicField(this, "removeRuleIconTemplate");
    __publicField(this, "addRuleIconTemplate");
    __publicField(this, "operatorOptions");
    __publicField(this, "overlayVisible");
    __publicField(this, "overlay");
    __publicField(this, "scrollHandler");
    __publicField(this, "documentClickListener");
    __publicField(this, "documentResizeListener");
    __publicField(this, "matchModes");
    __publicField(this, "translationSubscription");
    __publicField(this, "resetSubscription");
    __publicField(this, "selfClick");
    __publicField(this, "overlayEventListener");
    __publicField(this, "window");
    this.document = document;
    this.el = el;
    this.dt = dt;
    this.renderer = renderer;
    this.config = config;
    this.overlayService = overlayService;
    this.window = this.document.defaultView;
  }
  ngOnInit() {
    if (!this.dt.filters[this.field]) {
      this.initFieldFilterConstraint();
    }
    this.translationSubscription = this.config.translationObserver.subscribe(() => {
      this.generateMatchModeOptions();
      this.generateOperatorOptions();
    });
    this.generateMatchModeOptions();
    this.generateOperatorOptions();
  }
  generateMatchModeOptions() {
    var _a;
    this.matchModes = this.matchModeOptions || ((_a = this.config.filterMatchModeOptions[this.type]) == null ? void 0 : _a.map((key) => {
      return {
        label: this.config.getTranslation(key),
        value: key
      };
    }));
  }
  generateOperatorOptions() {
    this.operatorOptions = [{
      label: this.config.getTranslation(TranslationKeys.MATCH_ALL),
      value: FilterOperator.AND
    }, {
      label: this.config.getTranslation(TranslationKeys.MATCH_ANY),
      value: FilterOperator.OR
    }];
  }
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "header":
          this.headerTemplate = item.template;
          break;
        case "filter":
          this.filterTemplate = item.template;
          break;
        case "footer":
          this.footerTemplate = item.template;
          break;
        case "filtericon":
          this.filterIconTemplate = item.template;
          break;
        case "removeruleicon":
          this.removeRuleIconTemplate = item.template;
          break;
        case "addruleicon":
          this.addRuleIconTemplate = item.template;
          break;
        default:
          this.filterTemplate = item.template;
          break;
      }
    });
  }
  initFieldFilterConstraint() {
    let defaultMatchMode = this.getDefaultMatchMode();
    this.dt.filters[this.field] = this.display == "row" ? {
      value: null,
      matchMode: defaultMatchMode
    } : [{
      value: null,
      matchMode: defaultMatchMode,
      operator: this.operator
    }];
  }
  onMenuMatchModeChange(value, filterMeta) {
    filterMeta.matchMode = value;
    if (!this.showApplyButton) {
      this.dt._filter();
    }
  }
  onRowMatchModeChange(matchMode) {
    this.dt.filters[this.field].matchMode = matchMode;
    this.dt._filter();
    this.hide();
  }
  onRowMatchModeKeyDown(event2) {
    let item = event2.target;
    switch (event2.key) {
      case "ArrowDown":
        var nextItem = this.findNextItem(item);
        if (nextItem) {
          item.removeAttribute("tabindex");
          nextItem.tabIndex = "0";
          nextItem.focus();
        }
        event2.preventDefault();
        break;
      case "ArrowUp":
        var prevItem = this.findPrevItem(item);
        if (prevItem) {
          item.removeAttribute("tabindex");
          prevItem.tabIndex = "0";
          prevItem.focus();
        }
        event2.preventDefault();
        break;
    }
  }
  onRowClearItemClick() {
    this.clearFilter();
    this.hide();
  }
  isRowMatchModeSelected(matchMode) {
    return this.dt.filters[this.field].matchMode === matchMode;
  }
  addConstraint() {
    this.dt.filters[this.field].push({
      value: null,
      matchMode: this.getDefaultMatchMode(),
      operator: this.getDefaultOperator()
    });
  }
  removeConstraint(filterMeta) {
    this.dt.filters[this.field] = this.dt.filters[this.field].filter((meta) => meta !== filterMeta);
    this.dt._filter();
  }
  onOperatorChange(value) {
    this.dt.filters[this.field].forEach((filterMeta) => {
      filterMeta.operator = value;
      this.operator = value;
    });
    if (!this.showApplyButton) {
      this.dt._filter();
    }
  }
  toggleMenu() {
    this.overlayVisible = !this.overlayVisible;
  }
  onToggleButtonKeyDown(event2) {
    switch (event2.key) {
      case "Escape":
      case "Tab":
        this.overlayVisible = false;
        break;
      case "ArrowDown":
        if (this.overlayVisible) {
          let focusable = DomHandler.getFocusableElements(this.overlay);
          if (focusable) {
            focusable[0].focus();
          }
          event2.preventDefault();
        } else if (event2.altKey) {
          this.overlayVisible = true;
          event2.preventDefault();
        }
        break;
    }
  }
  onEscape() {
    var _a;
    this.overlayVisible = false;
    (_a = this.icon) == null ? void 0 : _a.nativeElement.focus();
  }
  findNextItem(item) {
    var _a;
    let nextItem = item.nextElementSibling;
    if (nextItem)
      return DomHandler.hasClass(nextItem, "p-column-filter-separator") ? this.findNextItem(nextItem) : nextItem;
    else
      return (_a = item.parentElement) == null ? void 0 : _a.firstElementChild;
  }
  findPrevItem(item) {
    var _a;
    let prevItem = item.previousElementSibling;
    if (prevItem)
      return DomHandler.hasClass(prevItem, "p-column-filter-separator") ? this.findPrevItem(prevItem) : prevItem;
    else
      return (_a = item.parentElement) == null ? void 0 : _a.lastElementChild;
  }
  onContentClick() {
    this.selfClick = true;
  }
  onOverlayAnimationStart(event2) {
    var _a;
    switch (event2.toState) {
      case "visible":
        this.overlay = event2.element;
        this.renderer.appendChild(this.document.body, this.overlay);
        zindexutils.set("overlay", this.overlay, this.config.zIndex.overlay);
        DomHandler.absolutePosition(this.overlay, (_a = this.icon) == null ? void 0 : _a.nativeElement);
        this.bindDocumentClickListener();
        this.bindDocumentResizeListener();
        this.bindScrollListener();
        this.overlayEventListener = (e) => {
          if (this.overlay && this.overlay.contains(e.target)) {
            this.selfClick = true;
          }
        };
        this.overlaySubscription = this.overlayService.clickObservable.subscribe(this.overlayEventListener);
        break;
      case "void":
        this.onOverlayHide();
        if (this.overlaySubscription) {
          this.overlaySubscription.unsubscribe();
        }
        break;
    }
  }
  onOverlayAnimationEnd(event2) {
    switch (event2.toState) {
      case "void":
        zindexutils.clear(event2.element);
        break;
    }
  }
  getDefaultMatchMode() {
    if (this.matchMode) {
      return this.matchMode;
    } else {
      if (this.type === "text")
        return FilterMatchMode.STARTS_WITH;
      else if (this.type === "numeric")
        return FilterMatchMode.EQUALS;
      else if (this.type === "date")
        return FilterMatchMode.DATE_IS;
      else
        return FilterMatchMode.CONTAINS;
    }
  }
  getDefaultOperator() {
    return this.dt.filters ? this.dt.filters[this.field][0].operator : this.operator;
  }
  hasRowFilter() {
    return this.dt.filters[this.field] && !this.dt.isFilterBlank(this.dt.filters[this.field].value);
  }
  get fieldConstraints() {
    return this.dt.filters ? this.dt.filters[this.field] : null;
  }
  get showRemoveIcon() {
    return this.fieldConstraints ? this.fieldConstraints.length > 1 : false;
  }
  get showMenuButton() {
    return this.showMenu && (this.display === "row" ? this.type !== "boolean" : true);
  }
  get isShowOperator() {
    return this.showOperator && this.type !== "boolean";
  }
  get isShowAddConstraint() {
    return this.showAddButton && this.type !== "boolean" && this.fieldConstraints && this.fieldConstraints.length < this.maxConstraints;
  }
  get applyButtonLabel() {
    return this.config.getTranslation(TranslationKeys.APPLY);
  }
  get clearButtonLabel() {
    return this.config.getTranslation(TranslationKeys.CLEAR);
  }
  get addRuleButtonLabel() {
    return this.config.getTranslation(TranslationKeys.ADD_RULE);
  }
  get removeRuleButtonLabel() {
    return this.config.getTranslation(TranslationKeys.REMOVE_RULE);
  }
  get noFilterLabel() {
    return this.config.getTranslation(TranslationKeys.NO_FILTER);
  }
  hasFilter() {
    let fieldFilter = this.dt.filters[this.field];
    if (fieldFilter) {
      if (Array.isArray(fieldFilter))
        return !this.dt.isFilterBlank(fieldFilter[0].value);
      else
        return !this.dt.isFilterBlank(fieldFilter.value);
    }
    return false;
  }
  isOutsideClicked(event2) {
    var _a, _b, _c, _d;
    return !(((_a = this.overlay) == null ? void 0 : _a.isSameNode(event2.target)) || ((_b = this.overlay) == null ? void 0 : _b.contains(event2.target)) || ((_c = this.icon) == null ? void 0 : _c.nativeElement.isSameNode(event2.target)) || ((_d = this.icon) == null ? void 0 : _d.nativeElement.contains(event2.target)) || DomHandler.hasClass(event2.target, "p-column-filter-add-button") || DomHandler.hasClass(event2.target.parentElement, "p-column-filter-add-button") || DomHandler.hasClass(event2.target, "p-column-filter-remove-button") || DomHandler.hasClass(event2.target.parentElement, "p-column-filter-remove-button"));
  }
  bindDocumentClickListener() {
    if (!this.documentClickListener) {
      const documentTarget = this.el ? this.el.nativeElement.ownerDocument : "document";
      this.documentClickListener = this.renderer.listen(documentTarget, "click", (event2) => {
        if (this.overlayVisible && !this.selfClick && this.isOutsideClicked(event2)) {
          this.hide();
        }
        this.selfClick = false;
      });
    }
  }
  unbindDocumentClickListener() {
    if (this.documentClickListener) {
      this.documentClickListener();
      this.documentClickListener = null;
      this.selfClick = false;
    }
  }
  bindDocumentResizeListener() {
    if (!this.documentResizeListener) {
      this.documentResizeListener = this.renderer.listen(this.window, "resize", (event2) => {
        if (this.overlayVisible && !DomHandler.isTouchDevice()) {
          this.hide();
        }
      });
    }
  }
  unbindDocumentResizeListener() {
    if (this.documentResizeListener) {
      this.documentResizeListener();
      this.documentResizeListener = null;
    }
  }
  bindScrollListener() {
    var _a;
    if (!this.scrollHandler) {
      this.scrollHandler = new ConnectedOverlayScrollHandler((_a = this.icon) == null ? void 0 : _a.nativeElement, () => {
        if (this.overlayVisible) {
          this.hide();
        }
      });
    }
    this.scrollHandler.bindScrollListener();
  }
  unbindScrollListener() {
    if (this.scrollHandler) {
      this.scrollHandler.unbindScrollListener();
    }
  }
  hide() {
    this.overlayVisible = false;
  }
  onOverlayHide() {
    this.unbindDocumentClickListener();
    this.unbindDocumentResizeListener();
    this.unbindScrollListener();
    this.overlay = null;
  }
  clearFilter() {
    this.initFieldFilterConstraint();
    this.dt._filter();
    if (this.hideOnClear)
      this.hide();
  }
  applyFilter() {
    this.dt._filter();
    this.hide();
  }
  ngOnDestroy() {
    if (this.overlay) {
      this.renderer.appendChild(this.el.nativeElement, this.overlay);
      zindexutils.clear(this.overlay);
      this.onOverlayHide();
    }
    if (this.translationSubscription) {
      this.translationSubscription.unsubscribe();
    }
    if (this.resetSubscription) {
      this.resetSubscription.unsubscribe();
    }
    if (this.overlaySubscription) {
      this.overlaySubscription.unsubscribe();
    }
  }
};
var ColumnFilter = _ColumnFilter;
__publicField(ColumnFilter, "ɵfac", function ColumnFilter_Factory(t) {
  return new (t || _ColumnFilter)(ɵɵdirectiveInject(DOCUMENT), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(Table), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(PrimeNGConfig), ɵɵdirectiveInject(OverlayService));
});
__publicField(ColumnFilter, "ɵcmp", ɵɵdefineComponent({
  type: _ColumnFilter,
  selectors: [["p-columnFilter"]],
  contentQueries: function ColumnFilter_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  viewQuery: function ColumnFilter_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c28, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.icon = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    field: "field",
    type: "type",
    display: "display",
    showMenu: "showMenu",
    matchMode: "matchMode",
    operator: "operator",
    showOperator: "showOperator",
    showClearButton: "showClearButton",
    showApplyButton: "showApplyButton",
    showMatchModes: "showMatchModes",
    showAddButton: "showAddButton",
    hideOnClear: "hideOnClear",
    placeholder: "placeholder",
    matchModeOptions: "matchModeOptions",
    maxConstraints: "maxConstraints",
    minFractionDigits: "minFractionDigits",
    maxFractionDigits: "maxFractionDigits",
    prefix: "prefix",
    suffix: "suffix",
    locale: "locale",
    localeMatcher: "localeMatcher",
    currency: "currency",
    currencyDisplay: "currencyDisplay",
    useGrouping: "useGrouping",
    showButtons: "showButtons"
  },
  decls: 5,
  vars: 8,
  consts: [[1, "p-column-filter", 3, "ngClass"], ["class", "p-fluid", 3, "type", "field", "filterConstraint", "filterTemplate", "placeholder", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "locale", "localeMatcher", "currency", "currencyDisplay", "useGrouping", "showButtons", 4, "ngIf"], ["type", "button", "class", "p-column-filter-menu-button p-link", "aria-haspopup", "true", 3, "ngClass", "click", "keydown", 4, "ngIf"], ["type", "button", "class", "p-column-filter-clear-button p-link", 3, "ngClass", "click", 4, "ngIf"], [3, "ngClass", "click", "keydown.escape", 4, "ngIf"], [1, "p-fluid", 3, "type", "field", "filterConstraint", "filterTemplate", "placeholder", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "locale", "localeMatcher", "currency", "currencyDisplay", "useGrouping", "showButtons"], ["type", "button", "aria-haspopup", "true", 1, "p-column-filter-menu-button", "p-link", 3, "ngClass", "click", "keydown"], ["icon", ""], [3, "styleClass", 4, "ngIf"], ["class", "pi-filter-icon", 4, "ngIf"], [3, "styleClass"], [1, "pi-filter-icon"], [4, "ngTemplateOutlet"], ["type", "button", 1, "p-column-filter-clear-button", "p-link", 3, "ngClass", "click"], [4, "ngIf"], [3, "ngClass", "click", "keydown.escape"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["class", "p-column-filter-row-items", 4, "ngIf", "ngIfElse"], ["menu", ""], [1, "p-column-filter-row-items"], ["class", "p-column-filter-row-item", 3, "ngClass", "click", "keydown", "keydown.enter", 4, "ngFor", "ngForOf"], [1, "p-column-filter-separator"], [1, "p-column-filter-row-item", 3, "click", "keydown", "keydown.enter"], [1, "p-column-filter-row-item", 3, "ngClass", "click", "keydown", "keydown.enter"], ["class", "p-column-filter-operator", 4, "ngIf"], [1, "p-column-filter-constraints"], ["class", "p-column-filter-constraint", 4, "ngFor", "ngForOf"], ["class", "p-column-filter-add-rule", 4, "ngIf"], [1, "p-column-filter-buttonbar"], ["type", "button", "pButton", "", "class", "p-button-outlined p-button-sm", "pRipple", "", 3, "label", "click", 4, "ngIf"], ["type", "button", "pButton", "", "class", "p-button-sm", "pRipple", "", 3, "label", "click", 4, "ngIf"], [1, "p-column-filter-operator"], ["styleClass", "p-column-filter-operator-dropdown", 3, "options", "ngModel", "ngModelChange"], [1, "p-column-filter-constraint"], ["styleClass", "p-column-filter-matchmode-dropdown", 3, "options", "ngModel", "ngModelChange", 4, "ngIf"], [3, "type", "field", "filterConstraint", "filterTemplate", "placeholder", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "locale", "localeMatcher", "currency", "currencyDisplay", "useGrouping"], ["type", "button", "pButton", "", "class", "p-column-filter-remove-button p-button-text p-button-danger p-button-sm", "pRipple", "", 3, "label", "click", 4, "ngIf"], ["styleClass", "p-column-filter-matchmode-dropdown", 3, "options", "ngModel", "ngModelChange"], ["type", "button", "pButton", "", "pRipple", "", 1, "p-column-filter-remove-button", "p-button-text", "p-button-danger", "p-button-sm", 3, "label", "click"], [1, "p-column-filter-add-rule"], ["type", "button", "pButton", "", "pRipple", "", 1, "p-column-filter-add-button", "p-button-text", "p-button-sm", 3, "label", "click"], ["type", "button", "pButton", "", "pRipple", "", 1, "p-button-outlined", "p-button-sm", 3, "label", "click"], ["type", "button", "pButton", "", "pRipple", "", 1, "p-button-sm", 3, "label", "click"]],
  template: function ColumnFilter_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0);
      ɵɵtemplate(1, ColumnFilter_p_columnFilterFormElement_1_Template, 1, 15, "p-columnFilterFormElement", 1);
      ɵɵtemplate(2, ColumnFilter_button_2_Template, 4, 7, "button", 2);
      ɵɵtemplate(3, ColumnFilter_button_3_Template, 4, 5, "button", 3);
      ɵɵtemplate(4, ColumnFilter_div_4_Template, 6, 14, "div", 4);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵproperty("ngClass", ɵɵpureFunction2(5, _c332, ctx.display === "row", ctx.display === "menu"));
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.display === "row");
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.showMenuButton);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.showClearButton && ctx.display === "row");
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.showMenu && ctx.overlayVisible);
    }
  },
  dependencies: function() {
    return [NgClass, NgForOf, NgIf, NgTemplateOutlet, Dropdown, NgControlStatus, NgModel, ButtonDirective, FilterIcon, FilterSlashIcon, ColumnFilterFormElement];
  },
  encapsulation: 2,
  data: {
    animation: [trigger("overlayAnimation", [transition(":enter", [style({
      opacity: 0,
      transform: "scaleY(0.8)"
    }), animate(".12s cubic-bezier(0, 0, 0.2, 1)")]), transition(":leave", [animate(".1s linear", style({
      opacity: 0
    }))])])]
  }
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ColumnFilter, [{
    type: Component,
    args: [{
      selector: "p-columnFilter",
      template: `
        <div class="p-column-filter" [ngClass]="{ 'p-column-filter-row': display === 'row', 'p-column-filter-menu': display === 'menu' }">
            <p-columnFilterFormElement
                *ngIf="display === 'row'"
                class="p-fluid"
                [type]="type"
                [field]="field"
                [filterConstraint]="dt.filters[field]"
                [filterTemplate]="filterTemplate"
                [placeholder]="placeholder"
                [minFractionDigits]="minFractionDigits"
                [maxFractionDigits]="maxFractionDigits"
                [prefix]="prefix"
                [suffix]="suffix"
                [locale]="locale"
                [localeMatcher]="localeMatcher"
                [currency]="currency"
                [currencyDisplay]="currencyDisplay"
                [useGrouping]="useGrouping"
                [showButtons]="showButtons"
            ></p-columnFilterFormElement>
            <button
                #icon
                *ngIf="showMenuButton"
                type="button"
                class="p-column-filter-menu-button p-link"
                aria-haspopup="true"
                [attr.aria-expanded]="overlayVisible"
                [ngClass]="{ 'p-column-filter-menu-button-open': overlayVisible, 'p-column-filter-menu-button-active': hasFilter() }"
                (click)="toggleMenu()"
                (keydown)="onToggleButtonKeyDown($event)"
            >
                <FilterIcon [styleClass]="'pi-filter-icon'" *ngIf="!filterIconTemplate" />
                <span class="pi-filter-icon" *ngIf="filterIconTemplate">
                    <ng-template *ngTemplateOutlet="filterIconTemplate"></ng-template>
                </span>
            </button>
            <button #icon *ngIf="showClearButton && display === 'row'" [ngClass]="{ 'p-hidden-space': !hasRowFilter() }" type="button" class="p-column-filter-clear-button p-link" (click)="clearFilter()">
                <FilterSlashIcon *ngIf="!clearIconTemplate" />
                <ng-template *ngTemplateOutlet="clearFilterIcon"></ng-template>
            </button>
            <div
                *ngIf="showMenu && overlayVisible"
                [ngClass]="{ 'p-column-filter-overlay p-component p-fluid': true, 'p-column-filter-overlay-menu': display === 'menu' }"
                (click)="onContentClick()"
                [@overlayAnimation]="'visible'"
                (@overlayAnimation.start)="onOverlayAnimationStart($event)"
                (@overlayAnimation.done)="onOverlayAnimationEnd($event)"
                (keydown.escape)="onEscape()"
            >
                <ng-container *ngTemplateOutlet="headerTemplate; context: { $implicit: field }"></ng-container>
                <ul *ngIf="display === 'row'; else menu" class="p-column-filter-row-items">
                    <li
                        class="p-column-filter-row-item"
                        *ngFor="let matchMode of matchModes; let i = index"
                        (click)="onRowMatchModeChange(matchMode.value)"
                        (keydown)="onRowMatchModeKeyDown($event)"
                        (keydown.enter)="this.onRowMatchModeChange(matchMode.value)"
                        [ngClass]="{ 'p-highlight': isRowMatchModeSelected(matchMode.value) }"
                        [attr.tabindex]="i === 0 ? '0' : null"
                    >
                        {{ matchMode.label }}
                    </li>
                    <li class="p-column-filter-separator"></li>
                    <li class="p-column-filter-row-item" (click)="onRowClearItemClick()" (keydown)="onRowMatchModeKeyDown($event)" (keydown.enter)="onRowClearItemClick()">{{ noFilterLabel }}</li>
                </ul>
                <ng-template #menu>
                    <div class="p-column-filter-operator" *ngIf="isShowOperator">
                        <p-dropdown [options]="operatorOptions" [ngModel]="operator" (ngModelChange)="onOperatorChange($event)" styleClass="p-column-filter-operator-dropdown"></p-dropdown>
                    </div>
                    <div class="p-column-filter-constraints">
                        <div *ngFor="let fieldConstraint of fieldConstraints; let i = index" class="p-column-filter-constraint">
                            <p-dropdown
                                *ngIf="showMatchModes && matchModes"
                                [options]="matchModes"
                                [ngModel]="fieldConstraint.matchMode"
                                (ngModelChange)="onMenuMatchModeChange($event, fieldConstraint)"
                                styleClass="p-column-filter-matchmode-dropdown"
                            ></p-dropdown>
                            <p-columnFilterFormElement
                                [type]="type"
                                [field]="field"
                                [filterConstraint]="fieldConstraint"
                                [filterTemplate]="filterTemplate"
                                [placeholder]="placeholder"
                                [minFractionDigits]="minFractionDigits"
                                [maxFractionDigits]="maxFractionDigits"
                                [prefix]="prefix"
                                [suffix]="suffix"
                                [locale]="locale"
                                [localeMatcher]="localeMatcher"
                                [currency]="currency"
                                [currencyDisplay]="currencyDisplay"
                                [useGrouping]="useGrouping"
                            ></p-columnFilterFormElement>
                            <div>
                                <button *ngIf="showRemoveIcon" type="button" pButton class="p-column-filter-remove-button p-button-text p-button-danger p-button-sm" (click)="removeConstraint(fieldConstraint)" pRipple [label]="removeRuleButtonLabel">
                                    <TrashIcon *ngIf="!removeRuleIconTemplate" />
                                    <ng-template *ngTemplateOutlet="removeRuleIconTemplate"></ng-template>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="p-column-filter-add-rule" *ngIf="isShowAddConstraint">
                        <button type="button" pButton [label]="addRuleButtonLabel" class="p-column-filter-add-button p-button-text p-button-sm" (click)="addConstraint()" pRipple>
                            <PlusIcon *ngIf="!addRuleIconTemplate" />
                            <ng-template *ngTemplateOutlet="addRuleIconTemplate"></ng-template>
                        </button>
                    </div>
                    <div class="p-column-filter-buttonbar">
                        <button *ngIf="showClearButton" type="button" pButton class="p-button-outlined p-button-sm" (click)="clearFilter()" [label]="clearButtonLabel" pRipple></button>
                        <button *ngIf="showApplyButton" type="button" pButton (click)="applyFilter()" class="p-button-sm" [label]="applyButtonLabel" pRipple></button>
                    </div>
                </ng-template>
                <ng-container *ngTemplateOutlet="footerTemplate; context: { $implicit: field }"></ng-container>
            </div>
        </div>
    `,
      animations: [trigger("overlayAnimation", [transition(":enter", [style({
        opacity: 0,
        transform: "scaleY(0.8)"
      }), animate(".12s cubic-bezier(0, 0, 0.2, 1)")]), transition(":leave", [animate(".1s linear", style({
        opacity: 0
      }))])])],
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Document,
      decorators: [{
        type: Inject,
        args: [DOCUMENT]
      }]
    }, {
      type: ElementRef
    }, {
      type: Table
    }, {
      type: Renderer2
    }, {
      type: PrimeNGConfig
    }, {
      type: OverlayService
    }];
  }, {
    field: [{
      type: Input
    }],
    type: [{
      type: Input
    }],
    display: [{
      type: Input
    }],
    showMenu: [{
      type: Input
    }],
    matchMode: [{
      type: Input
    }],
    operator: [{
      type: Input
    }],
    showOperator: [{
      type: Input
    }],
    showClearButton: [{
      type: Input
    }],
    showApplyButton: [{
      type: Input
    }],
    showMatchModes: [{
      type: Input
    }],
    showAddButton: [{
      type: Input
    }],
    hideOnClear: [{
      type: Input
    }],
    placeholder: [{
      type: Input
    }],
    matchModeOptions: [{
      type: Input
    }],
    maxConstraints: [{
      type: Input
    }],
    minFractionDigits: [{
      type: Input
    }],
    maxFractionDigits: [{
      type: Input
    }],
    prefix: [{
      type: Input
    }],
    suffix: [{
      type: Input
    }],
    locale: [{
      type: Input
    }],
    localeMatcher: [{
      type: Input
    }],
    currency: [{
      type: Input
    }],
    currencyDisplay: [{
      type: Input
    }],
    useGrouping: [{
      type: Input
    }],
    showButtons: [{
      type: Input
    }],
    icon: [{
      type: ViewChild,
      args: ["icon"]
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var _ColumnFilterFormElement = class {
  constructor(dt, colFilter) {
    __publicField(this, "dt");
    __publicField(this, "colFilter");
    __publicField(this, "field");
    __publicField(this, "type");
    __publicField(this, "filterConstraint");
    __publicField(this, "filterTemplate");
    __publicField(this, "placeholder");
    __publicField(this, "minFractionDigits");
    __publicField(this, "maxFractionDigits");
    __publicField(this, "prefix");
    __publicField(this, "suffix");
    __publicField(this, "locale");
    __publicField(this, "localeMatcher");
    __publicField(this, "currency");
    __publicField(this, "currencyDisplay");
    __publicField(this, "useGrouping", true);
    __publicField(this, "filterCallback");
    this.dt = dt;
    this.colFilter = colFilter;
  }
  get showButtons() {
    return this.colFilter.showButtons;
  }
  ngOnInit() {
    this.filterCallback = (value) => {
      this.filterConstraint.value = value;
      this.dt._filter();
    };
  }
  onModelChange(value) {
    this.filterConstraint.value = value;
    if (this.type === "boolean" || value === "") {
      this.dt._filter();
    }
  }
  onTextInputEnterKeyDown(event2) {
    this.dt._filter();
    event2.preventDefault();
  }
  onNumericInputKeyDown(event2) {
    if (event2.key === "Enter") {
      this.dt._filter();
      event2.preventDefault();
    }
  }
};
var ColumnFilterFormElement = _ColumnFilterFormElement;
__publicField(ColumnFilterFormElement, "ɵfac", function ColumnFilterFormElement_Factory(t) {
  return new (t || _ColumnFilterFormElement)(ɵɵdirectiveInject(Table), ɵɵdirectiveInject(ColumnFilter));
});
__publicField(ColumnFilterFormElement, "ɵcmp", ɵɵdefineComponent({
  type: _ColumnFilterFormElement,
  selectors: [["p-columnFilterFormElement"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    field: "field",
    type: "type",
    filterConstraint: "filterConstraint",
    filterTemplate: "filterTemplate",
    placeholder: "placeholder",
    minFractionDigits: "minFractionDigits",
    maxFractionDigits: "maxFractionDigits",
    prefix: "prefix",
    suffix: "suffix",
    locale: "locale",
    localeMatcher: "localeMatcher",
    currency: "currency",
    currencyDisplay: "currencyDisplay",
    useGrouping: "useGrouping"
  },
  decls: 3,
  vars: 2,
  consts: [[4, "ngIf", "ngIfElse"], ["builtInElement", ""], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [3, "ngSwitch"], ["type", "text", "pInputText", "", 3, "value", "input", "keydown.enter", 4, "ngSwitchCase"], [3, "ngModel", "showButtons", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "placeholder", "mode", "locale", "localeMatcher", "currency", "currencyDisplay", "useGrouping", "ngModelChange", "onKeyDown", 4, "ngSwitchCase"], [3, "ngModel", "ngModelChange", 4, "ngSwitchCase"], [3, "placeholder", "ngModel", "ngModelChange", 4, "ngSwitchCase"], ["type", "text", "pInputText", "", 3, "value", "input", "keydown.enter"], [3, "ngModel", "showButtons", "minFractionDigits", "maxFractionDigits", "prefix", "suffix", "placeholder", "mode", "locale", "localeMatcher", "currency", "currencyDisplay", "useGrouping", "ngModelChange", "onKeyDown"], [3, "ngModel", "ngModelChange"], [3, "placeholder", "ngModel", "ngModelChange"]],
  template: function ColumnFilterFormElement_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵtemplate(0, ColumnFilterFormElement_ng_container_0_Template, 2, 19, "ng-container", 0);
      ɵɵtemplate(1, ColumnFilterFormElement_ng_template_1_Template, 5, 5, "ng-template", null, 1, ɵɵtemplateRefExtractor);
    }
    if (rf & 2) {
      const _r1 = ɵɵreference(2);
      ɵɵproperty("ngIf", ctx.filterTemplate)("ngIfElse", _r1);
    }
  },
  dependencies: [NgIf, NgTemplateOutlet, NgSwitch, NgSwitchCase, InputNumber, NgControlStatus, NgModel, InputText, Calendar, TriStateCheckbox],
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ColumnFilterFormElement, [{
    type: Component,
    args: [{
      selector: "p-columnFilterFormElement",
      template: `
        <ng-container *ngIf="filterTemplate; else builtInElement">
            <ng-container
                *ngTemplateOutlet="
                    filterTemplate;
                    context: {
                        $implicit: filterConstraint.value,
                        filterCallback: filterCallback,
                        type: type,
                        field: field,
                        filterConstraint: filterConstraint,
                        placeholder: placeholder,
                        minFractionDigits: minFractionDigits,
                        maxFractionDigits: maxFractionDigits,
                        prefix: prefix,
                        suffix: suffix,
                        locale: locale,
                        localeMatcher: localeMatcher,
                        currency: currency,
                        currencyDisplay: currencyDisplay,
                        useGrouping: useGrouping,
                        showButtons: showButtons
                    }
                "
            ></ng-container>
        </ng-container>
        <ng-template #builtInElement>
            <ng-container [ngSwitch]="type">
                <input *ngSwitchCase="'text'" type="text" pInputText [value]="filterConstraint?.value" (input)="onModelChange($event.target.value)" (keydown.enter)="onTextInputEnterKeyDown($event)" [attr.placeholder]="placeholder" />
                <p-inputNumber
                    *ngSwitchCase="'numeric'"
                    [ngModel]="filterConstraint?.value"
                    (ngModelChange)="onModelChange($event)"
                    (onKeyDown)="onNumericInputKeyDown($event)"
                    [showButtons]="showButtons"
                    [minFractionDigits]="minFractionDigits"
                    [maxFractionDigits]="maxFractionDigits"
                    [prefix]="prefix"
                    [suffix]="suffix"
                    [placeholder]="placeholder"
                    [mode]="currency ? 'currency' : 'decimal'"
                    [locale]="locale"
                    [localeMatcher]="localeMatcher"
                    [currency]="currency"
                    [currencyDisplay]="currencyDisplay"
                    [useGrouping]="useGrouping"
                ></p-inputNumber>
                <p-triStateCheckbox *ngSwitchCase="'boolean'" [ngModel]="filterConstraint?.value" (ngModelChange)="onModelChange($event)"></p-triStateCheckbox>
                <p-calendar *ngSwitchCase="'date'" [placeholder]="placeholder" [ngModel]="filterConstraint?.value" (ngModelChange)="onModelChange($event)"></p-calendar>
            </ng-container>
        </ng-template>
    `,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: Table
    }, {
      type: ColumnFilter
    }];
  }, {
    field: [{
      type: Input
    }],
    type: [{
      type: Input
    }],
    filterConstraint: [{
      type: Input
    }],
    filterTemplate: [{
      type: Input
    }],
    placeholder: [{
      type: Input
    }],
    minFractionDigits: [{
      type: Input
    }],
    maxFractionDigits: [{
      type: Input
    }],
    prefix: [{
      type: Input
    }],
    suffix: [{
      type: Input
    }],
    locale: [{
      type: Input
    }],
    localeMatcher: [{
      type: Input
    }],
    currency: [{
      type: Input
    }],
    currencyDisplay: [{
      type: Input
    }],
    useGrouping: [{
      type: Input
    }]
  });
})();
var _TableModule = class {
};
var TableModule = _TableModule;
__publicField(TableModule, "ɵfac", function TableModule_Factory(t) {
  return new (t || _TableModule)();
});
__publicField(TableModule, "ɵmod", ɵɵdefineNgModule({
  type: _TableModule,
  declarations: [Table, SortableColumn, FrozenColumn, RowGroupHeader, SelectableRow, RowToggler, ContextMenuRow, ResizableColumn, ReorderableColumn, EditableColumn, CellEditor, TableBody, SortIcon, TableRadioButton, TableCheckbox, TableHeaderCheckbox, ReorderableRowHandle, ReorderableRow, SelectableRowDblClick, EditableRow, InitEditableRow, SaveEditableRow, CancelEditableRow, ColumnFilter, ColumnFilterFormElement],
  imports: [CommonModule, PaginatorModule, InputTextModule, DropdownModule, FormsModule, ButtonModule, SelectButtonModule, CalendarModule, InputNumberModule, TriStateCheckboxModule, ScrollerModule, ArrowDownIcon, ArrowUpIcon, SpinnerIcon, SortAltIcon, SortAmountUpAltIcon, SortAmountDownIcon, CheckIcon, FilterIcon, FilterSlashIcon],
  exports: [Table, SharedModule, SortableColumn, FrozenColumn, RowGroupHeader, SelectableRow, RowToggler, ContextMenuRow, ResizableColumn, ReorderableColumn, EditableColumn, CellEditor, SortIcon, TableRadioButton, TableCheckbox, TableHeaderCheckbox, ReorderableRowHandle, ReorderableRow, SelectableRowDblClick, EditableRow, InitEditableRow, SaveEditableRow, CancelEditableRow, ColumnFilter, ColumnFilterFormElement, ScrollerModule]
}));
__publicField(TableModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, PaginatorModule, InputTextModule, DropdownModule, FormsModule, ButtonModule, SelectButtonModule, CalendarModule, InputNumberModule, TriStateCheckboxModule, ScrollerModule, ArrowDownIcon, ArrowUpIcon, SpinnerIcon, SortAltIcon, SortAmountUpAltIcon, SortAmountDownIcon, CheckIcon, FilterIcon, FilterSlashIcon, SharedModule, ScrollerModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TableModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, PaginatorModule, InputTextModule, DropdownModule, FormsModule, ButtonModule, SelectButtonModule, CalendarModule, InputNumberModule, TriStateCheckboxModule, ScrollerModule, ArrowDownIcon, ArrowUpIcon, SpinnerIcon, SortAltIcon, SortAmountUpAltIcon, SortAmountDownIcon, CheckIcon, FilterIcon, FilterSlashIcon],
      exports: [Table, SharedModule, SortableColumn, FrozenColumn, RowGroupHeader, SelectableRow, RowToggler, ContextMenuRow, ResizableColumn, ReorderableColumn, EditableColumn, CellEditor, SortIcon, TableRadioButton, TableCheckbox, TableHeaderCheckbox, ReorderableRowHandle, ReorderableRow, SelectableRowDblClick, EditableRow, InitEditableRow, SaveEditableRow, CancelEditableRow, ColumnFilter, ColumnFilterFormElement, ScrollerModule],
      declarations: [Table, SortableColumn, FrozenColumn, RowGroupHeader, SelectableRow, RowToggler, ContextMenuRow, ResizableColumn, ReorderableColumn, EditableColumn, CellEditor, TableBody, SortIcon, TableRadioButton, TableCheckbox, TableHeaderCheckbox, ReorderableRowHandle, ReorderableRow, SelectableRowDblClick, EditableRow, InitEditableRow, SaveEditableRow, CancelEditableRow, ColumnFilter, ColumnFilterFormElement]
    }]
  }], null, null);
})();
export {
  CancelEditableRow,
  CellEditor,
  ColumnFilter,
  ColumnFilterFormElement,
  ContextMenuRow,
  EditableColumn,
  EditableRow,
  FrozenColumn,
  InitEditableRow,
  ReorderableColumn,
  ReorderableRow,
  ReorderableRowHandle,
  ResizableColumn,
  RowGroupHeader,
  RowToggler,
  SaveEditableRow,
  SelectableRow,
  SelectableRowDblClick,
  SortIcon,
  SortableColumn,
  Table,
  TableBody,
  TableCheckbox,
  TableHeaderCheckbox,
  TableModule,
  TableRadioButton,
  TableService
};
//# sourceMappingURL=primeng_table.js.map
