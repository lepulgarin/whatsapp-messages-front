import {
  CheckIcon
} from "./chunk-JYL5AXZN.js";
import {
  NG_VALUE_ACCESSOR
} from "./chunk-UKH2O2A3.js";
import "./chunk-TQCROI5M.js";
import {
  ObjectUtils,
  PrimeTemplate,
  SharedModule
} from "./chunk-X6HTJCNQ.js";
import {
  CommonModule,
  NgClass,
  NgIf,
  NgStyle,
  NgTemplateOutlet
} from "./chunk-MIRZRLCI.js";
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ContentChildren,
  EventEmitter,
  Input,
  NgModule,
  Output,
  ViewChild,
  ViewEncapsulation$1,
  forwardRef,
  setClassMetadata,
  ɵɵProvidersFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction3,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵviewQuery
} from "./chunk-SPBZRJHT.js";
import "./chunk-IXJD77KS.js";
import "./chunk-QCYGWUBY.js";
import "./chunk-37TWHRPH.js";
import "./chunk-4BJ7XQX3.js";
import {
  __publicField
} from "./chunk-GKWPUQBP.js";

// node_modules/primeng/fesm2022/primeng-checkbox.mjs
var _c0 = ["cb"];
function Checkbox_ng_container_5_ng_container_1_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 10);
  }
  if (rf & 2) {
    const ctx_r5 = ɵɵnextContext(3);
    ɵɵproperty("ngClass", ctx_r5.checkboxIcon);
  }
}
function Checkbox_ng_container_5_ng_container_1_CheckIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "CheckIcon", 11);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-checkbox-icon");
  }
}
function Checkbox_ng_container_5_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Checkbox_ng_container_5_ng_container_1_span_1_Template, 1, 1, "span", 8);
    ɵɵtemplate(2, Checkbox_ng_container_5_ng_container_1_CheckIcon_2_Template, 1, 1, "CheckIcon", 9);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r3.checkboxIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r3.checkboxIcon);
  }
}
function Checkbox_ng_container_5_span_2_1_ng_template_0_Template(rf, ctx) {
}
function Checkbox_ng_container_5_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Checkbox_ng_container_5_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function Checkbox_ng_container_5_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 12);
    ɵɵtemplate(1, Checkbox_ng_container_5_span_2_1_Template, 1, 0, null, 13);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r4.checkboxIconTemplate);
  }
}
function Checkbox_ng_container_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Checkbox_ng_container_5_ng_container_1_Template, 3, 2, "ng-container", 5);
    ɵɵtemplate(2, Checkbox_ng_container_5_span_2_Template, 2, 1, "span", 7);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r1.checkboxIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r1.checkboxIconTemplate);
  }
}
var _c1 = function(a1, a2, a3) {
  return {
    "p-checkbox-label": true,
    "p-checkbox-label-active": a1,
    "p-disabled": a2,
    "p-checkbox-label-focus": a3
  };
};
function Checkbox_label_6_Template(rf, ctx) {
  if (rf & 1) {
    const _r10 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "label", 14);
    ɵɵlistener("click", function Checkbox_label_6_Template_label_click_0_listener($event) {
      ɵɵrestoreView(_r10);
      const ctx_r9 = ɵɵnextContext();
      const _r0 = ɵɵreference(3);
      return ɵɵresetView(ctx_r9.onClick($event, _r0, true));
    });
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵclassMap(ctx_r2.labelStyleClass);
    ɵɵproperty("ngClass", ɵɵpureFunction3(5, _c1, ctx_r2.checked(), ctx_r2.disabled, ctx_r2.focused));
    ɵɵattribute("for", ctx_r2.inputId);
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r2.label);
  }
}
var _c2 = function(a1, a2, a3) {
  return {
    "p-checkbox p-component": true,
    "p-checkbox-checked": a1,
    "p-checkbox-disabled": a2,
    "p-checkbox-focused": a3
  };
};
var _c3 = function(a0, a1, a2) {
  return {
    "p-highlight": a0,
    "p-disabled": a1,
    "p-focus": a2
  };
};
var CHECKBOX_VALUE_ACCESSOR = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => Checkbox),
  multi: true
};
var _Checkbox = class {
  constructor(cd) {
    __publicField(this, "cd");
    /**
     * Value of the checkbox.
     * @group Props
     */
    __publicField(this, "value");
    /**
     * Name of the checkbox group.
     * @group Props
     */
    __publicField(this, "name");
    /**
     * When present, it specifies that the element should be disabled.
     * @group Props
     */
    __publicField(this, "disabled");
    /**
     * Allows to select a boolean value instead of multiple values.
     * @group Props
     */
    __publicField(this, "binary");
    /**
     * Label of the checkbox.
     * @group Props
     */
    __publicField(this, "label");
    /**
     * Establishes relationships between the component and label(s) where its value should be one or more element IDs.
     * @group Props
     */
    __publicField(this, "ariaLabelledBy");
    /**
     * Used to define a string that labels the input element.
     * @group Props
     */
    __publicField(this, "ariaLabel");
    /**
     * Index of the element in tabbing order.
     * @group Props
     */
    __publicField(this, "tabindex");
    /**
     * Identifier of the focus input to match a label defined for the component.
     * @group Props
     */
    __publicField(this, "inputId");
    /**
     * Inline style of the component.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Style class of the component.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Style class of the label.
     * @group Props
     */
    __publicField(this, "labelStyleClass");
    /**
     * Form control value.
     * @group Props
     */
    __publicField(this, "formControl");
    /**
     * Icon class of the checkbox icon.
     * @group Props
     */
    __publicField(this, "checkboxIcon");
    /**
     * When present, it specifies that the component cannot be edited.
     * @group Props
     */
    __publicField(this, "readonly");
    /**
     * When present, it specifies that checkbox must be checked before submitting the form.
     * @group Props
     */
    __publicField(this, "required");
    /**
     * Value in checked state.
     * @group Props
     */
    __publicField(this, "trueValue", true);
    /**
     * Value in unchecked state.
     * @group Props
     */
    __publicField(this, "falseValue", false);
    /**
     * Callback to invoke on value change.
     * @param {CheckboxChangeEvent} event - Custom value change event.
     * @group Emits
     */
    __publicField(this, "onChange", new EventEmitter());
    __publicField(this, "inputViewChild");
    __publicField(this, "templates");
    __publicField(this, "checkboxIconTemplate");
    __publicField(this, "model");
    __publicField(this, "onModelChange", () => {
    });
    __publicField(this, "onModelTouched", () => {
    });
    __publicField(this, "focused", false);
    this.cd = cd;
  }
  ngAfterContentInit() {
    this.templates.forEach((item) => {
      switch (item.getType()) {
        case "icon":
          this.checkboxIconTemplate = item.template;
          break;
      }
    });
  }
  onClick(event, checkbox, focus) {
    event.preventDefault();
    if (this.disabled || this.readonly) {
      return;
    }
    this.updateModel(event);
    if (focus) {
      checkbox.focus();
    }
  }
  updateModel(event) {
    let newModelValue;
    if (!this.binary) {
      if (this.checked())
        newModelValue = this.model.filter((val) => !ObjectUtils.equals(val, this.value));
      else
        newModelValue = this.model ? [...this.model, this.value] : [this.value];
      this.onModelChange(newModelValue);
      this.model = newModelValue;
      if (this.formControl) {
        this.formControl.setValue(newModelValue);
      }
    } else {
      newModelValue = this.checked() ? this.falseValue : this.trueValue;
      this.model = newModelValue;
      this.onModelChange(newModelValue);
    }
    this.onChange.emit({
      checked: newModelValue,
      originalEvent: event
    });
  }
  handleChange(event) {
    if (!this.readonly) {
      this.updateModel(event);
    }
  }
  onFocus() {
    this.focused = true;
  }
  onBlur() {
    this.focused = false;
    this.onModelTouched();
  }
  focus() {
    var _a;
    (_a = this.inputViewChild) == null ? void 0 : _a.nativeElement.focus();
  }
  writeValue(model) {
    this.model = model;
    this.cd.markForCheck();
  }
  registerOnChange(fn) {
    this.onModelChange = fn;
  }
  registerOnTouched(fn) {
    this.onModelTouched = fn;
  }
  setDisabledState(val) {
    this.disabled = val;
    this.cd.markForCheck();
  }
  checked() {
    return this.binary ? this.model === this.trueValue : ObjectUtils.contains(this.value, this.model);
  }
};
var Checkbox = _Checkbox;
__publicField(Checkbox, "ɵfac", function Checkbox_Factory(t) {
  return new (t || _Checkbox)(ɵɵdirectiveInject(ChangeDetectorRef));
});
__publicField(Checkbox, "ɵcmp", ɵɵdefineComponent({
  type: _Checkbox,
  selectors: [["p-checkbox"]],
  contentQueries: function Checkbox_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  viewQuery: function Checkbox_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c0, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.inputViewChild = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    value: "value",
    name: "name",
    disabled: "disabled",
    binary: "binary",
    label: "label",
    ariaLabelledBy: "ariaLabelledBy",
    ariaLabel: "ariaLabel",
    tabindex: "tabindex",
    inputId: "inputId",
    style: "style",
    styleClass: "styleClass",
    labelStyleClass: "labelStyleClass",
    formControl: "formControl",
    checkboxIcon: "checkboxIcon",
    readonly: "readonly",
    required: "required",
    trueValue: "trueValue",
    falseValue: "falseValue"
  },
  outputs: {
    onChange: "onChange"
  },
  features: [ɵɵProvidersFeature([CHECKBOX_VALUE_ACCESSOR])],
  decls: 7,
  vars: 26,
  consts: [[3, "ngStyle", "ngClass"], [1, "p-hidden-accessible"], ["type", "checkbox", 3, "readonly", "value", "checked", "disabled", "focus", "blur", "change"], ["cb", ""], [1, "p-checkbox-box", 3, "ngClass", "click"], [4, "ngIf"], [3, "class", "ngClass", "click", 4, "ngIf"], ["class", "p-checkbox-icon", 4, "ngIf"], ["class", "p-checkbox-icon", 3, "ngClass", 4, "ngIf"], [3, "styleClass", 4, "ngIf"], [1, "p-checkbox-icon", 3, "ngClass"], [3, "styleClass"], [1, "p-checkbox-icon"], [4, "ngTemplateOutlet"], [3, "ngClass", "click"]],
  template: function Checkbox_Template(rf, ctx) {
    if (rf & 1) {
      const _r11 = ɵɵgetCurrentView();
      ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "input", 2, 3);
      ɵɵlistener("focus", function Checkbox_Template_input_focus_2_listener() {
        return ctx.onFocus();
      })("blur", function Checkbox_Template_input_blur_2_listener() {
        return ctx.onBlur();
      })("change", function Checkbox_Template_input_change_2_listener($event) {
        return ctx.handleChange($event);
      });
      ɵɵelementEnd()();
      ɵɵelementStart(4, "div", 4);
      ɵɵlistener("click", function Checkbox_Template_div_click_4_listener($event) {
        ɵɵrestoreView(_r11);
        const _r0 = ɵɵreference(3);
        return ɵɵresetView(ctx.onClick($event, _r0, true));
      });
      ɵɵtemplate(5, Checkbox_ng_container_5_Template, 3, 2, "ng-container", 5);
      ɵɵelementEnd()();
      ɵɵtemplate(6, Checkbox_label_6_Template, 2, 9, "label", 6);
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.styleClass);
      ɵɵproperty("ngStyle", ctx.style)("ngClass", ɵɵpureFunction3(18, _c2, ctx.checked(), ctx.disabled, ctx.focused));
      ɵɵadvance(2);
      ɵɵproperty("readonly", ctx.readonly)("value", ctx.value)("checked", ctx.checked())("disabled", ctx.disabled);
      ɵɵattribute("id", ctx.inputId)("name", ctx.name)("tabindex", ctx.tabindex)("aria-labelledby", ctx.ariaLabelledBy)("aria-label", ctx.ariaLabel)("aria-checked", ctx.checked())("required", ctx.required);
      ɵɵadvance(2);
      ɵɵproperty("ngClass", ɵɵpureFunction3(22, _c3, ctx.checked(), ctx.disabled, ctx.focused));
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.checked());
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.label);
    }
  },
  dependencies: function() {
    return [NgClass, NgIf, NgTemplateOutlet, NgStyle, CheckIcon];
  },
  styles: [".p-checkbox{display:inline-flex;cursor:pointer;-webkit-user-select:none;user-select:none;vertical-align:bottom;position:relative}.p-checkbox-disabled{cursor:default!important;pointer-events:none}.p-checkbox-box{display:flex;justify-content:center;align-items:center}p-checkbox{display:inline-flex;vertical-align:bottom;align-items:center}.p-checkbox-label{line-height:1}\n"],
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Checkbox, [{
    type: Component,
    args: [{
      selector: "p-checkbox",
      template: `
        <div [ngStyle]="style" [ngClass]="{ 'p-checkbox p-component': true, 'p-checkbox-checked': checked(), 'p-checkbox-disabled': disabled, 'p-checkbox-focused': focused }" [class]="styleClass">
            <div class="p-hidden-accessible">
                <input
                    #cb
                    type="checkbox"
                    [attr.id]="inputId"
                    [attr.name]="name"
                    [readonly]="readonly"
                    [value]="value"
                    [checked]="checked()"
                    (focus)="onFocus()"
                    (blur)="onBlur()"
                    (change)="handleChange($event)"
                    [disabled]="disabled"
                    [attr.tabindex]="tabindex"
                    [attr.aria-labelledby]="ariaLabelledBy"
                    [attr.aria-label]="ariaLabel"
                    [attr.aria-checked]="checked()"
                    [attr.required]="required"
                />
            </div>
            <div class="p-checkbox-box" (click)="onClick($event, cb, true)" [ngClass]="{ 'p-highlight': checked(), 'p-disabled': disabled, 'p-focus': focused }">
                <ng-container *ngIf="checked()">
                    <ng-container *ngIf="!checkboxIconTemplate">
                        <span *ngIf="checkboxIcon" class="p-checkbox-icon" [ngClass]="checkboxIcon"></span>
                        <CheckIcon *ngIf="!checkboxIcon" [styleClass]="'p-checkbox-icon'" />
                    </ng-container>
                    <span *ngIf="checkboxIconTemplate" class="p-checkbox-icon">
                        <ng-template *ngTemplateOutlet="checkboxIconTemplate"></ng-template>
                    </span>
                </ng-container>
            </div>
        </div>
        <label
            (click)="onClick($event, cb, true)"
            [class]="labelStyleClass"
            [ngClass]="{ 'p-checkbox-label': true, 'p-checkbox-label-active': checked(), 'p-disabled': disabled, 'p-checkbox-label-focus': focused }"
            *ngIf="label"
            [attr.for]="inputId"
            >{{ label }}</label
        >
    `,
      providers: [CHECKBOX_VALUE_ACCESSOR],
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      },
      styles: [".p-checkbox{display:inline-flex;cursor:pointer;-webkit-user-select:none;user-select:none;vertical-align:bottom;position:relative}.p-checkbox-disabled{cursor:default!important;pointer-events:none}.p-checkbox-box{display:flex;justify-content:center;align-items:center}p-checkbox{display:inline-flex;vertical-align:bottom;align-items:center}.p-checkbox-label{line-height:1}\n"]
    }]
  }], function() {
    return [{
      type: ChangeDetectorRef
    }];
  }, {
    value: [{
      type: Input
    }],
    name: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    binary: [{
      type: Input
    }],
    label: [{
      type: Input
    }],
    ariaLabelledBy: [{
      type: Input
    }],
    ariaLabel: [{
      type: Input
    }],
    tabindex: [{
      type: Input
    }],
    inputId: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    labelStyleClass: [{
      type: Input
    }],
    formControl: [{
      type: Input
    }],
    checkboxIcon: [{
      type: Input
    }],
    readonly: [{
      type: Input
    }],
    required: [{
      type: Input
    }],
    trueValue: [{
      type: Input
    }],
    falseValue: [{
      type: Input
    }],
    onChange: [{
      type: Output
    }],
    inputViewChild: [{
      type: ViewChild,
      args: ["cb"]
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var _CheckboxModule = class {
};
var CheckboxModule = _CheckboxModule;
__publicField(CheckboxModule, "ɵfac", function CheckboxModule_Factory(t) {
  return new (t || _CheckboxModule)();
});
__publicField(CheckboxModule, "ɵmod", ɵɵdefineNgModule({
  type: _CheckboxModule,
  declarations: [Checkbox],
  imports: [CommonModule, CheckIcon],
  exports: [Checkbox, SharedModule]
}));
__publicField(CheckboxModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, CheckIcon, SharedModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CheckboxModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, CheckIcon],
      exports: [Checkbox, SharedModule],
      declarations: [Checkbox]
    }]
  }], null, null);
})();
export {
  CHECKBOX_VALUE_ACCESSOR,
  Checkbox,
  CheckboxModule
};
//# sourceMappingURL=primeng_checkbox.js.map
