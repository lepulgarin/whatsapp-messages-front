import {
  ExclamationTriangleIcon,
  InfoCircleIcon,
  TimesCircleIcon
} from "./chunk-7OXIODHI.js";
import {
  CheckIcon
} from "./chunk-JYL5AXZN.js";
import {
  Ripple,
  RippleModule
} from "./chunk-ZFEZZYMT.js";
import {
  TimesIcon
} from "./chunk-CYTHTHVV.js";
import "./chunk-TQCROI5M.js";
import "./chunk-N3XAYJ3A.js";
import {
  MessageService,
  ObjectUtils,
  PrimeNGConfig,
  PrimeTemplate,
  SharedModule,
  UniqueComponentId,
  zindexutils
} from "./chunk-X6HTJCNQ.js";
import {
  animate,
  animateChild,
  query,
  state,
  style,
  transition,
  trigger
} from "./chunk-GA7SZJ22.js";
import {
  CommonModule,
  DOCUMENT,
  NgClass,
  NgForOf,
  NgIf,
  NgStyle,
  NgTemplateOutlet
} from "./chunk-MIRZRLCI.js";
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ContentChildren,
  EventEmitter,
  Inject,
  Input,
  NgModule,
  NgZone,
  Output,
  Renderer2,
  ViewChild,
  ViewEncapsulation$1,
  setClassMetadata,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction1,
  ɵɵpureFunction4,
  ɵɵqueryRefresh,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵviewQuery
} from "./chunk-SPBZRJHT.js";
import "./chunk-IXJD77KS.js";
import "./chunk-QCYGWUBY.js";
import "./chunk-37TWHRPH.js";
import "./chunk-4BJ7XQX3.js";
import {
  __publicField
} from "./chunk-GKWPUQBP.js";

// node_modules/primeng/fesm2022/primeng-toast.mjs
var _c0 = ["container"];
function ToastItem_ng_container_3_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span");
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext(2);
    ɵɵclassMap("p-toast-message-icon pi " + ctx_r4.message.icon);
  }
}
function ToastItem_ng_container_3_span_2_CheckIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "CheckIcon");
  }
}
function ToastItem_ng_container_3_span_2_InfoCircleIcon_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "InfoCircleIcon");
  }
}
function ToastItem_ng_container_3_span_2_TimesCircleIcon_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "TimesCircleIcon");
  }
}
function ToastItem_ng_container_3_span_2_ExclamationTriangleIcon_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ExclamationTriangleIcon");
  }
}
function ToastItem_ng_container_3_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 11);
    ɵɵelementContainerStart(1);
    ɵɵtemplate(2, ToastItem_ng_container_3_span_2_CheckIcon_2_Template, 1, 0, "CheckIcon", 3);
    ɵɵtemplate(3, ToastItem_ng_container_3_span_2_InfoCircleIcon_3_Template, 1, 0, "InfoCircleIcon", 3);
    ɵɵtemplate(4, ToastItem_ng_container_3_span_2_TimesCircleIcon_4_Template, 1, 0, "TimesCircleIcon", 3);
    ɵɵtemplate(5, ToastItem_ng_container_3_span_2_ExclamationTriangleIcon_5_Template, 1, 0, "ExclamationTriangleIcon", 3);
    ɵɵelementContainerEnd();
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r5 = ɵɵnextContext(2);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r5.message.severity === "success");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.message.severity === "info");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.message.severity === "error");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.message.severity === "warn");
  }
}
function ToastItem_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, ToastItem_ng_container_3_span_1_Template, 1, 2, "span", 6);
    ɵɵtemplate(2, ToastItem_ng_container_3_span_2_Template, 6, 4, "span", 7);
    ɵɵelementStart(3, "div", 8)(4, "div", 9);
    ɵɵtext(5);
    ɵɵelementEnd();
    ɵɵelementStart(6, "div", 10);
    ɵɵtext(7);
    ɵɵelementEnd()();
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r1.message.icon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r1.message.icon);
    ɵɵadvance(3);
    ɵɵtextInterpolate(ctx_r1.message.summary);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ctx_r1.message.detail);
  }
}
function ToastItem_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function ToastItem_button_5_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span");
  }
  if (rf & 2) {
    const ctx_r10 = ɵɵnextContext(2);
    ɵɵclassMap("p-toast-message-icon pi " + ctx_r10.message.closeIcon);
  }
}
function ToastItem_button_5_TimesIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "TimesIcon", 14);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-toast-icon-close-icon");
  }
}
function ToastItem_button_5_Template(rf, ctx) {
  if (rf & 1) {
    const _r13 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 12);
    ɵɵlistener("click", function ToastItem_button_5_Template_button_click_0_listener($event) {
      ɵɵrestoreView(_r13);
      const ctx_r12 = ɵɵnextContext();
      return ɵɵresetView(ctx_r12.onCloseIconClick($event));
    })("keydown.enter", function ToastItem_button_5_Template_button_keydown_enter_0_listener($event) {
      ɵɵrestoreView(_r13);
      const ctx_r14 = ɵɵnextContext();
      return ɵɵresetView(ctx_r14.onCloseIconClick($event));
    });
    ɵɵtemplate(1, ToastItem_button_5_span_1_Template, 1, 2, "span", 6);
    ɵɵtemplate(2, ToastItem_button_5_TimesIcon_2_Template, 1, 1, "TimesIcon", 13);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r3.message.closeIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r3.message.closeIcon);
  }
}
var _c1 = function(a0) {
  return [a0, "p-toast-message"];
};
var _c2 = function(a0, a1, a2, a3) {
  return {
    showTransformParams: a0,
    hideTransformParams: a1,
    showTransitionParams: a2,
    hideTransitionParams: a3
  };
};
var _c3 = function(a1) {
  return {
    value: "visible",
    params: a1
  };
};
var _c4 = function(a0) {
  return {
    $implicit: a0
  };
};
function Toast_p_toastItem_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-toastItem", 3);
    ɵɵlistener("onClose", function Toast_p_toastItem_2_Template_p_toastItem_onClose_0_listener($event) {
      ɵɵrestoreView(_r5);
      const ctx_r4 = ɵɵnextContext();
      return ɵɵresetView(ctx_r4.onMessageClose($event));
    })("@toastAnimation.start", function Toast_p_toastItem_2_Template_p_toastItem_animation_toastAnimation_start_0_listener($event) {
      ɵɵrestoreView(_r5);
      const ctx_r6 = ɵɵnextContext();
      return ɵɵresetView(ctx_r6.onAnimationStart($event));
    })("@toastAnimation.done", function Toast_p_toastItem_2_Template_p_toastItem_animation_toastAnimation_done_0_listener($event) {
      ɵɵrestoreView(_r5);
      const ctx_r7 = ɵɵnextContext();
      return ɵɵresetView(ctx_r7.onAnimationEnd($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const msg_r2 = ctx.$implicit;
    const i_r3 = ctx.index;
    const ctx_r1 = ɵɵnextContext();
    ɵɵproperty("message", msg_r2)("index", i_r3)("template", ctx_r1.template)("@toastAnimation", void 0)("showTransformOptions", ctx_r1.showTransformOptions)("hideTransformOptions", ctx_r1.hideTransformOptions)("showTransitionOptions", ctx_r1.showTransitionOptions)("hideTransitionOptions", ctx_r1.hideTransitionOptions);
  }
}
var _ToastItem = class {
  constructor(zone) {
    __publicField(this, "zone");
    __publicField(this, "message");
    __publicField(this, "index");
    __publicField(this, "template");
    __publicField(this, "showTransformOptions");
    __publicField(this, "hideTransformOptions");
    __publicField(this, "showTransitionOptions");
    __publicField(this, "hideTransitionOptions");
    __publicField(this, "onClose", new EventEmitter());
    __publicField(this, "containerViewChild");
    __publicField(this, "timeout");
    this.zone = zone;
  }
  ngAfterViewInit() {
    this.initTimeout();
  }
  initTimeout() {
    var _a;
    if (!((_a = this.message) == null ? void 0 : _a.sticky)) {
      this.zone.runOutsideAngular(() => {
        var _a2;
        this.timeout = setTimeout(() => {
          this.onClose.emit({
            index: this.index,
            message: this.message
          });
        }, ((_a2 = this.message) == null ? void 0 : _a2.life) || 3e3);
      });
    }
  }
  clearTimeout() {
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
  }
  onMouseEnter() {
    this.clearTimeout();
  }
  onMouseLeave() {
    this.initTimeout();
  }
  onCloseIconClick(event) {
    this.clearTimeout();
    this.onClose.emit({
      index: this.index,
      message: this.message
    });
    event.preventDefault();
  }
  ngOnDestroy() {
    this.clearTimeout();
  }
};
var ToastItem = _ToastItem;
__publicField(ToastItem, "ɵfac", function ToastItem_Factory(t) {
  return new (t || _ToastItem)(ɵɵdirectiveInject(NgZone));
});
__publicField(ToastItem, "ɵcmp", ɵɵdefineComponent({
  type: _ToastItem,
  selectors: [["p-toastItem"]],
  viewQuery: function ToastItem_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c0, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.containerViewChild = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    message: "message",
    index: "index",
    template: "template",
    showTransformOptions: "showTransformOptions",
    hideTransformOptions: "hideTransformOptions",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions"
  },
  outputs: {
    onClose: "onClose"
  },
  decls: 6,
  vars: 21,
  consts: [[3, "ngClass", "mouseenter", "mouseleave"], ["container", ""], ["role", "alert", "aria-live", "assertive", "aria-atomic", "true", 1, "p-toast-message-content", 3, "ngClass"], [4, "ngIf"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], ["type", "button", "class", "p-toast-icon-close p-link", "pRipple", "", 3, "click", "keydown.enter", 4, "ngIf"], [3, "class", 4, "ngIf"], ["class", "p-toast-message-icon", 4, "ngIf"], [1, "p-toast-message-text"], [1, "p-toast-summary"], [1, "p-toast-detail"], [1, "p-toast-message-icon"], ["type", "button", "pRipple", "", 1, "p-toast-icon-close", "p-link", 3, "click", "keydown.enter"], [3, "styleClass", 4, "ngIf"], [3, "styleClass"]],
  template: function ToastItem_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0, 1);
      ɵɵlistener("mouseenter", function ToastItem_Template_div_mouseenter_0_listener() {
        return ctx.onMouseEnter();
      })("mouseleave", function ToastItem_Template_div_mouseleave_0_listener() {
        return ctx.onMouseLeave();
      });
      ɵɵelementStart(2, "div", 2);
      ɵɵtemplate(3, ToastItem_ng_container_3_Template, 8, 4, "ng-container", 3);
      ɵɵtemplate(4, ToastItem_ng_container_4_Template, 1, 0, "ng-container", 4);
      ɵɵtemplate(5, ToastItem_button_5_Template, 3, 2, "button", 5);
      ɵɵelementEnd()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.message == null ? null : ctx.message.styleClass);
      ɵɵproperty("ngClass", ɵɵpureFunction1(10, _c1, "p-toast-message-" + (ctx.message == null ? null : ctx.message.severity)))("@messageState", ɵɵpureFunction1(17, _c3, ɵɵpureFunction4(12, _c2, ctx.showTransformOptions, ctx.hideTransformOptions, ctx.showTransitionOptions, ctx.hideTransitionOptions)));
      ɵɵattribute("id", ctx.message == null ? null : ctx.message.id);
      ɵɵadvance(2);
      ɵɵproperty("ngClass", ctx.message == null ? null : ctx.message.contentStyleClass);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", !ctx.template);
      ɵɵadvance(1);
      ɵɵproperty("ngTemplateOutlet", ctx.template)("ngTemplateOutletContext", ɵɵpureFunction1(19, _c4, ctx.message));
      ɵɵadvance(1);
      ɵɵproperty("ngIf", (ctx.message == null ? null : ctx.message.closable) !== false);
    }
  },
  dependencies: function() {
    return [NgClass, NgIf, NgTemplateOutlet, Ripple, CheckIcon, InfoCircleIcon, TimesCircleIcon, ExclamationTriangleIcon, TimesIcon];
  },
  encapsulation: 2,
  data: {
    animation: [trigger("messageState", [state("visible", style({
      transform: "translateY(0)",
      opacity: 1
    })), transition("void => *", [style({
      transform: "{{showTransformParams}}",
      opacity: 0
    }), animate("{{showTransitionParams}}")]), transition("* => void", [animate("{{hideTransitionParams}}", style({
      height: 0,
      opacity: 0,
      transform: "{{hideTransformParams}}"
    }))])])]
  },
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ToastItem, [{
    type: Component,
    args: [{
      selector: "p-toastItem",
      template: `
        <div
            #container
            [attr.id]="message?.id"
            [class]="message?.styleClass"
            [ngClass]="['p-toast-message-' + message?.severity, 'p-toast-message']"
            [@messageState]="{ value: 'visible', params: { showTransformParams: showTransformOptions, hideTransformParams: hideTransformOptions, showTransitionParams: showTransitionOptions, hideTransitionParams: hideTransitionOptions } }"
            (mouseenter)="onMouseEnter()"
            (mouseleave)="onMouseLeave()"
        >
            <div class="p-toast-message-content" role="alert" aria-live="assertive" aria-atomic="true" [ngClass]="message?.contentStyleClass">
                <ng-container *ngIf="!template">
                    <span *ngIf="message.icon" [class]="'p-toast-message-icon pi ' + message.icon"></span>
                    <span class="p-toast-message-icon" *ngIf="!message.icon">
                        <ng-container>
                            <CheckIcon *ngIf="message.severity === 'success'" />
                            <InfoCircleIcon *ngIf="message.severity === 'info'" />
                            <TimesCircleIcon *ngIf="message.severity === 'error'" />
                            <ExclamationTriangleIcon *ngIf="message.severity === 'warn'" />
                        </ng-container>
                    </span>
                    <div class="p-toast-message-text">
                        <div class="p-toast-summary">{{ message.summary }}</div>
                        <div class="p-toast-detail">{{ message.detail }}</div>
                    </div>
                </ng-container>
                <ng-container *ngTemplateOutlet="template; context: { $implicit: message }"></ng-container>
                <button type="button" class="p-toast-icon-close p-link" (click)="onCloseIconClick($event)" (keydown.enter)="onCloseIconClick($event)" *ngIf="message?.closable !== false" pRipple>
                    <span *ngIf="message.closeIcon" [class]="'p-toast-message-icon pi ' + message.closeIcon"></span>
                    <TimesIcon *ngIf="!message.closeIcon" [styleClass]="'p-toast-icon-close-icon'" />
                </button>
            </div>
        </div>
    `,
      animations: [trigger("messageState", [state("visible", style({
        transform: "translateY(0)",
        opacity: 1
      })), transition("void => *", [style({
        transform: "{{showTransformParams}}",
        opacity: 0
      }), animate("{{showTransitionParams}}")]), transition("* => void", [animate("{{hideTransitionParams}}", style({
        height: 0,
        opacity: 0,
        transform: "{{hideTransformParams}}"
      }))])])],
      encapsulation: ViewEncapsulation$1.None,
      changeDetection: ChangeDetectionStrategy.OnPush,
      host: {
        class: "p-element"
      }
    }]
  }], function() {
    return [{
      type: NgZone
    }];
  }, {
    message: [{
      type: Input
    }],
    index: [{
      type: Input
    }],
    template: [{
      type: Input
    }],
    showTransformOptions: [{
      type: Input
    }],
    hideTransformOptions: [{
      type: Input
    }],
    showTransitionOptions: [{
      type: Input
    }],
    hideTransitionOptions: [{
      type: Input
    }],
    onClose: [{
      type: Output
    }],
    containerViewChild: [{
      type: ViewChild,
      args: ["container"]
    }]
  });
})();
var _Toast = class {
  constructor(document, renderer, messageService, cd, config) {
    __publicField(this, "document");
    __publicField(this, "renderer");
    __publicField(this, "messageService");
    __publicField(this, "cd");
    __publicField(this, "config");
    /**
     * Key of the message in case message is targeted to a specific toast component.
     * @group Props
     */
    __publicField(this, "key");
    /**
     * Whether to automatically manage layering.
     * @group Props
     */
    __publicField(this, "autoZIndex", true);
    /**
     * Base zIndex value to use in layering.
     * @group Props
     */
    __publicField(this, "baseZIndex", 0);
    /**
     * Inline style of the component.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Inline class of the component.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Position of the toast in viewport.
     * @group Props
     */
    __publicField(this, "position", "top-right");
    /**
     * It does not add the new message if there is already a toast displayed with the same content
     * @group Props
     */
    __publicField(this, "preventOpenDuplicates", false);
    /**
     * Displays only once a message with the same content.
     * @group Props
     */
    __publicField(this, "preventDuplicates", false);
    /**
     * Transform options of the show animation.
     * @group Props
     */
    __publicField(this, "showTransformOptions", "translateY(100%)");
    /**
     * Transform options of the hide animation.
     * @group Props
     */
    __publicField(this, "hideTransformOptions", "translateY(-100%)");
    /**
     * Transition options of the show animation.
     * @group Props
     */
    __publicField(this, "showTransitionOptions", "300ms ease-out");
    /**
     * Transition options of the hide animation.
     * @group Props
     */
    __publicField(this, "hideTransitionOptions", "250ms ease-in");
    /**
     * Object literal to define styles per screen size.
     * @group Props
     */
    __publicField(this, "breakpoints");
    /**
     * Callback to invoke when a message is closed.
     * @param {ToastCloseEvent} event - custom close event.
     * @group Emits
     */
    __publicField(this, "onClose", new EventEmitter());
    __publicField(this, "containerViewChild");
    __publicField(this, "templates");
    __publicField(this, "messageSubscription");
    __publicField(this, "clearSubscription");
    __publicField(this, "messages");
    __publicField(this, "messagesArchieve");
    __publicField(this, "template");
    __publicField(this, "styleElement");
    __publicField(this, "id", UniqueComponentId());
    this.document = document;
    this.renderer = renderer;
    this.messageService = messageService;
    this.cd = cd;
    this.config = config;
  }
  ngOnInit() {
    this.messageSubscription = this.messageService.messageObserver.subscribe((messages) => {
      if (messages) {
        if (Array.isArray(messages)) {
          const filteredMessages = messages.filter((m) => this.canAdd(m));
          this.add(filteredMessages);
        } else if (this.canAdd(messages)) {
          this.add([messages]);
        }
      }
    });
    this.clearSubscription = this.messageService.clearObserver.subscribe((key) => {
      if (key) {
        if (this.key === key) {
          this.messages = null;
        }
      } else {
        this.messages = null;
      }
      this.cd.markForCheck();
    });
  }
  ngAfterViewInit() {
    if (this.breakpoints) {
      this.createStyle();
    }
  }
  add(messages) {
    this.messages = this.messages ? [...this.messages, ...messages] : [...messages];
    if (this.preventDuplicates) {
      this.messagesArchieve = this.messagesArchieve ? [...this.messagesArchieve, ...messages] : [...messages];
    }
    this.cd.markForCheck();
  }
  canAdd(message) {
    let allow = this.key === message.key;
    if (allow && this.preventOpenDuplicates) {
      allow = !this.containsMessage(this.messages, message);
    }
    if (allow && this.preventDuplicates) {
      allow = !this.containsMessage(this.messagesArchieve, message);
    }
    return allow;
  }
  containsMessage(collection, message) {
    if (!collection) {
      return false;
    }
    return collection.find((m) => {
      return m.summary === message.summary && m.detail == message.detail && m.severity === message.severity;
    }) != null;
  }
  ngAfterContentInit() {
    var _a;
    (_a = this.templates) == null ? void 0 : _a.forEach((item) => {
      switch (item.getType()) {
        case "message":
          this.template = item.template;
          break;
        default:
          this.template = item.template;
          break;
      }
    });
  }
  onMessageClose(event) {
    var _a;
    (_a = this.messages) == null ? void 0 : _a.splice(event.index, 1);
    this.onClose.emit({
      message: event.message
    });
    this.cd.detectChanges();
  }
  onAnimationStart(event) {
    var _a, _b, _c;
    if (event.fromState === "void") {
      this.renderer.setAttribute((_a = this.containerViewChild) == null ? void 0 : _a.nativeElement, this.id, "");
      if (this.autoZIndex && ((_b = this.containerViewChild) == null ? void 0 : _b.nativeElement.style.zIndex) === "") {
        zindexutils.set("modal", (_c = this.containerViewChild) == null ? void 0 : _c.nativeElement, this.baseZIndex || this.config.zIndex.modal);
      }
    }
  }
  onAnimationEnd(event) {
    var _a;
    if (event.toState === "void") {
      if (this.autoZIndex && ObjectUtils.isEmpty(this.messages)) {
        zindexutils.clear((_a = this.containerViewChild) == null ? void 0 : _a.nativeElement);
      }
    }
  }
  createStyle() {
    if (!this.styleElement) {
      this.styleElement = this.renderer.createElement("style");
      this.styleElement.type = "text/css";
      this.renderer.appendChild(this.document.head, this.styleElement);
      let innerHTML = "";
      for (let breakpoint in this.breakpoints) {
        let breakpointStyle = "";
        for (let styleProp in this.breakpoints[breakpoint]) {
          breakpointStyle += styleProp + ":" + this.breakpoints[breakpoint][styleProp] + " !important;";
        }
        innerHTML += `
                    @media screen and (max-width: ${breakpoint}) {
                        .p-toast[${this.id}] {
                           ${breakpointStyle}
                        }
                    }
                `;
      }
      this.renderer.setProperty(this.styleElement, "innerHTML", innerHTML);
    }
  }
  destroyStyle() {
    if (this.styleElement) {
      this.renderer.removeChild(this.document.head, this.styleElement);
      this.styleElement = null;
    }
  }
  ngOnDestroy() {
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
    if (this.containerViewChild && this.autoZIndex) {
      zindexutils.clear(this.containerViewChild.nativeElement);
    }
    if (this.clearSubscription) {
      this.clearSubscription.unsubscribe();
    }
    this.destroyStyle();
  }
};
var Toast = _Toast;
__publicField(Toast, "ɵfac", function Toast_Factory(t) {
  return new (t || _Toast)(ɵɵdirectiveInject(DOCUMENT), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(MessageService), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(PrimeNGConfig));
});
__publicField(Toast, "ɵcmp", ɵɵdefineComponent({
  type: _Toast,
  selectors: [["p-toast"]],
  contentQueries: function Toast_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  viewQuery: function Toast_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c0, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.containerViewChild = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    key: "key",
    autoZIndex: "autoZIndex",
    baseZIndex: "baseZIndex",
    style: "style",
    styleClass: "styleClass",
    position: "position",
    preventOpenDuplicates: "preventOpenDuplicates",
    preventDuplicates: "preventDuplicates",
    showTransformOptions: "showTransformOptions",
    hideTransformOptions: "hideTransformOptions",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions",
    breakpoints: "breakpoints"
  },
  outputs: {
    onClose: "onClose"
  },
  decls: 3,
  vars: 5,
  consts: [[3, "ngClass", "ngStyle"], ["container", ""], [3, "message", "index", "template", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions", "onClose", 4, "ngFor", "ngForOf"], [3, "message", "index", "template", "showTransformOptions", "hideTransformOptions", "showTransitionOptions", "hideTransitionOptions", "onClose"]],
  template: function Toast_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0, 1);
      ɵɵtemplate(2, Toast_p_toastItem_2_Template, 1, 8, "p-toastItem", 2);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.styleClass);
      ɵɵproperty("ngClass", "p-toast p-component p-toast-" + ctx.position)("ngStyle", ctx.style);
      ɵɵadvance(2);
      ɵɵproperty("ngForOf", ctx.messages);
    }
  },
  dependencies: [NgClass, NgForOf, NgStyle, ToastItem],
  styles: [".p-toast{position:fixed;width:25rem}.p-toast-message{overflow:hidden}.p-toast-message-content{display:flex;align-items:flex-start}.p-toast-message-text{flex:1 1 auto}.p-toast-top-right{top:20px;right:20px}.p-toast-top-left{top:20px;left:20px}.p-toast-bottom-left{bottom:20px;left:20px}.p-toast-bottom-right{bottom:20px;right:20px}.p-toast-top-center{top:20px;left:50%;transform:translate(-50%)}.p-toast-bottom-center{bottom:20px;left:50%;transform:translate(-50%)}.p-toast-center{left:50%;top:50%;min-width:20vw;transform:translate(-50%,-50%)}.p-toast-icon-close{display:flex;align-items:center;justify-content:center;overflow:hidden;position:relative}.p-toast-icon-close.p-link{cursor:pointer}\n"],
  encapsulation: 2,
  data: {
    animation: [trigger("toastAnimation", [transition(":enter, :leave", [query("@*", animateChild())])])]
  },
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Toast, [{
    type: Component,
    args: [{
      selector: "p-toast",
      template: `
        <div #container [ngClass]="'p-toast p-component p-toast-' + position" [ngStyle]="style" [class]="styleClass">
            <p-toastItem
                *ngFor="let msg of messages; let i = index"
                [message]="msg"
                [index]="i"
                (onClose)="onMessageClose($event)"
                [template]="template"
                @toastAnimation
                (@toastAnimation.start)="onAnimationStart($event)"
                (@toastAnimation.done)="onAnimationEnd($event)"
                [showTransformOptions]="showTransformOptions"
                [hideTransformOptions]="hideTransformOptions"
                [showTransitionOptions]="showTransitionOptions"
                [hideTransitionOptions]="hideTransitionOptions"
            ></p-toastItem>
        </div>
    `,
      animations: [trigger("toastAnimation", [transition(":enter, :leave", [query("@*", animateChild())])])],
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      },
      styles: [".p-toast{position:fixed;width:25rem}.p-toast-message{overflow:hidden}.p-toast-message-content{display:flex;align-items:flex-start}.p-toast-message-text{flex:1 1 auto}.p-toast-top-right{top:20px;right:20px}.p-toast-top-left{top:20px;left:20px}.p-toast-bottom-left{bottom:20px;left:20px}.p-toast-bottom-right{bottom:20px;right:20px}.p-toast-top-center{top:20px;left:50%;transform:translate(-50%)}.p-toast-bottom-center{bottom:20px;left:50%;transform:translate(-50%)}.p-toast-center{left:50%;top:50%;min-width:20vw;transform:translate(-50%,-50%)}.p-toast-icon-close{display:flex;align-items:center;justify-content:center;overflow:hidden;position:relative}.p-toast-icon-close.p-link{cursor:pointer}\n"]
    }]
  }], function() {
    return [{
      type: Document,
      decorators: [{
        type: Inject,
        args: [DOCUMENT]
      }]
    }, {
      type: Renderer2
    }, {
      type: MessageService
    }, {
      type: ChangeDetectorRef
    }, {
      type: PrimeNGConfig
    }];
  }, {
    key: [{
      type: Input
    }],
    autoZIndex: [{
      type: Input
    }],
    baseZIndex: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    position: [{
      type: Input
    }],
    preventOpenDuplicates: [{
      type: Input
    }],
    preventDuplicates: [{
      type: Input
    }],
    showTransformOptions: [{
      type: Input
    }],
    hideTransformOptions: [{
      type: Input
    }],
    showTransitionOptions: [{
      type: Input
    }],
    hideTransitionOptions: [{
      type: Input
    }],
    breakpoints: [{
      type: Input
    }],
    onClose: [{
      type: Output
    }],
    containerViewChild: [{
      type: ViewChild,
      args: ["container"]
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var _ToastModule = class {
};
var ToastModule = _ToastModule;
__publicField(ToastModule, "ɵfac", function ToastModule_Factory(t) {
  return new (t || _ToastModule)();
});
__publicField(ToastModule, "ɵmod", ɵɵdefineNgModule({
  type: _ToastModule,
  declarations: [Toast, ToastItem],
  imports: [CommonModule, RippleModule, CheckIcon, InfoCircleIcon, TimesCircleIcon, ExclamationTriangleIcon, TimesIcon],
  exports: [Toast, SharedModule]
}));
__publicField(ToastModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, RippleModule, CheckIcon, InfoCircleIcon, TimesCircleIcon, ExclamationTriangleIcon, TimesIcon, SharedModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ToastModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RippleModule, CheckIcon, InfoCircleIcon, TimesCircleIcon, ExclamationTriangleIcon, TimesIcon],
      exports: [Toast, SharedModule],
      declarations: [Toast, ToastItem]
    }]
  }], null, null);
})();
export {
  Toast,
  ToastItem,
  ToastModule
};
//# sourceMappingURL=primeng_toast.js.map
