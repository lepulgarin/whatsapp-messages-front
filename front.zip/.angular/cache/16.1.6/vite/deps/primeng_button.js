import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-EVZ3PBLH.js";
import "./chunk-ZFEZZYMT.js";
import "./chunk-TQCROI5M.js";
import "./chunk-N3XAYJ3A.js";
import "./chunk-X6HTJCNQ.js";
import "./chunk-MIRZRLCI.js";
import "./chunk-SPBZRJHT.js";
import "./chunk-IXJD77KS.js";
import "./chunk-QCYGWUBY.js";
import "./chunk-37TWHRPH.js";
import "./chunk-4BJ7XQX3.js";
import "./chunk-GKWPUQBP.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
