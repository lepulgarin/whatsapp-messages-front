import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-EVZ3PBLH.js";
import {
  ExclamationTriangleIcon,
  InfoCircleIcon,
  TimesCircleIcon
} from "./chunk-7OXIODHI.js";
import {
  CheckIcon
} from "./chunk-JYL5AXZN.js";
import {
  DomSanitizer
} from "./chunk-AP5LVITY.js";
import {
  HttpClient,
  HttpClientModule,
  HttpEventType
} from "./chunk-RQIPLD6P.js";
import {
  Ripple,
  RippleModule
} from "./chunk-ZFEZZYMT.js";
import {
  TimesIcon
} from "./chunk-CYTHTHVV.js";
import {
  BaseIcon
} from "./chunk-TQCROI5M.js";
import {
  DomHandler
} from "./chunk-N3XAYJ3A.js";
import {
  MessageService,
  PrimeNGConfig,
  PrimeTemplate,
  SharedModule,
  TranslationKeys,
  UniqueComponentId
} from "./chunk-X6HTJCNQ.js";
import {
  animate,
  style,
  transition,
  trigger
} from "./chunk-GA7SZJ22.js";
import {
  CommonModule,
  DOCUMENT,
  NgClass,
  NgForOf,
  NgIf,
  NgStyle,
  NgTemplateOutlet,
  isPlatformBrowser
} from "./chunk-MIRZRLCI.js";
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  ContentChildren,
  ElementRef,
  EventEmitter,
  Inject,
  Input,
  NgModule,
  NgZone,
  Optional,
  Output,
  PLATFORM_ID,
  Renderer2,
  ViewChild,
  ViewEncapsulation$1,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵStandaloneFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassMap,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementContainerEnd,
  ɵɵelementContainerStart,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵgetInheritedFactory,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnamespaceSVG,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction1,
  ɵɵpureFunction2,
  ɵɵpureFunction4,
  ɵɵqueryRefresh,
  ɵɵreference,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeHtml,
  ɵɵsanitizeUrl,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtemplateRefExtractor,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵtextInterpolate2,
  ɵɵviewQuery
} from "./chunk-SPBZRJHT.js";
import "./chunk-IXJD77KS.js";
import "./chunk-QCYGWUBY.js";
import {
  timer
} from "./chunk-37TWHRPH.js";
import "./chunk-4BJ7XQX3.js";
import {
  __publicField
} from "./chunk-GKWPUQBP.js";

// node_modules/primeng/fesm2022/primeng-icons-plus.mjs
var _PlusIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var PlusIcon = _PlusIcon;
__publicField(PlusIcon, "ɵfac", function() {
  let ɵPlusIcon_BaseFactory;
  return function PlusIcon_Factory(t) {
    return (ɵPlusIcon_BaseFactory || (ɵPlusIcon_BaseFactory = ɵɵgetInheritedFactory(_PlusIcon)))(t || _PlusIcon);
  };
}());
__publicField(PlusIcon, "ɵcmp", ɵɵdefineComponent({
  type: _PlusIcon,
  selectors: [["PlusIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 6,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["d", "M7.67742 6.32258V0.677419C7.67742 0.497757 7.60605 0.325452 7.47901 0.198411C7.35197 0.0713707 7.17966 0 7 0C6.82034 0 6.64803 0.0713707 6.52099 0.198411C6.39395 0.325452 6.32258 0.497757 6.32258 0.677419V6.32258H0.677419C0.497757 6.32258 0.325452 6.39395 0.198411 6.52099C0.0713707 6.64803 0 6.82034 0 7C0 7.17966 0.0713707 7.35197 0.198411 7.47901C0.325452 7.60605 0.497757 7.67742 0.677419 7.67742H6.32258V13.3226C6.32492 13.5015 6.39704 13.6725 6.52358 13.799C6.65012 13.9255 6.82106 13.9977 7 14C7.17966 14 7.35197 13.9286 7.47901 13.8016C7.60605 13.6745 7.67742 13.5022 7.67742 13.3226V7.67742H13.3226C13.5022 7.67742 13.6745 7.60605 13.8016 7.47901C13.9286 7.35197 14 7.17966 14 7C13.9977 6.82106 13.9255 6.65012 13.799 6.52358C13.6725 6.39704 13.5015 6.32492 13.3226 6.32258H7.67742Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function PlusIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1);
      ɵɵelementEnd();
      ɵɵelementStart(3, "defs")(4, "clipPath", 2);
      ɵɵelement(5, "rect", 3);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(3);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(PlusIcon, [{
    type: Component,
    args: [{
      selector: "PlusIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    d="M7.67742 6.32258V0.677419C7.67742 0.497757 7.60605 0.325452 7.47901 0.198411C7.35197 0.0713707 7.17966 0 7 0C6.82034 0 6.64803 0.0713707 6.52099 0.198411C6.39395 0.325452 6.32258 0.497757 6.32258 0.677419V6.32258H0.677419C0.497757 6.32258 0.325452 6.39395 0.198411 6.52099C0.0713707 6.64803 0 6.82034 0 7C0 7.17966 0.0713707 7.35197 0.198411 7.47901C0.325452 7.60605 0.497757 7.67742 0.677419 7.67742H6.32258V13.3226C6.32492 13.5015 6.39704 13.6725 6.52358 13.799C6.65012 13.9255 6.82106 13.9977 7 14C7.17966 14 7.35197 13.9286 7.47901 13.8016C7.60605 13.6745 7.67742 13.5022 7.67742 13.3226V7.67742H13.3226C13.5022 7.67742 13.6745 7.60605 13.8016 7.47901C13.9286 7.35197 14 7.17966 14 7C13.9977 6.82106 13.9255 6.65012 13.799 6.52358C13.6725 6.39704 13.5015 6.32492 13.3226 6.32258H7.67742Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-icons-upload.mjs
var _UploadIcon = class extends BaseIcon {
  constructor() {
    super(...arguments);
    __publicField(this, "pathId");
  }
  ngOnInit() {
    this.pathId = "url(#" + UniqueComponentId() + ")";
  }
};
var UploadIcon = _UploadIcon;
__publicField(UploadIcon, "ɵfac", function() {
  let ɵUploadIcon_BaseFactory;
  return function UploadIcon_Factory(t) {
    return (ɵUploadIcon_BaseFactory || (ɵUploadIcon_BaseFactory = ɵɵgetInheritedFactory(_UploadIcon)))(t || _UploadIcon);
  };
}());
__publicField(UploadIcon, "ɵcmp", ɵɵdefineComponent({
  type: _UploadIcon,
  selectors: [["UploadIcon"]],
  standalone: true,
  features: [ɵɵInheritDefinitionFeature, ɵɵStandaloneFeature],
  decls: 6,
  vars: 7,
  consts: [["width", "14", "height", "14", "viewBox", "0 0 14 14", "fill", "none", "xmlns", "http://www.w3.org/2000/svg"], ["fill-rule", "evenodd", "clip-rule", "evenodd", "d", "M6.58942 9.82197C6.70165 9.93405 6.85328 9.99793 7.012 10C7.17071 9.99793 7.32234 9.93405 7.43458 9.82197C7.54681 9.7099 7.61079 9.55849 7.61286 9.4V2.04798L9.79204 4.22402C9.84752 4.28011 9.91365 4.32457 9.98657 4.35479C10.0595 4.38502 10.1377 4.40039 10.2167 4.40002C10.2956 4.40039 10.3738 4.38502 10.4467 4.35479C10.5197 4.32457 10.5858 4.28011 10.6413 4.22402C10.7538 4.11152 10.817 3.95902 10.817 3.80002C10.817 3.64102 10.7538 3.48852 10.6413 3.37602L7.45127 0.190618C7.44656 0.185584 7.44176 0.180622 7.43687 0.175736C7.32419 0.063214 7.17136 0 7.012 0C6.85264 0 6.69981 0.063214 6.58712 0.175736C6.58181 0.181045 6.5766 0.186443 6.5715 0.191927L3.38282 3.37602C3.27669 3.48976 3.2189 3.6402 3.22165 3.79564C3.2244 3.95108 3.28746 4.09939 3.39755 4.20932C3.50764 4.31925 3.65616 4.38222 3.81182 4.38496C3.96749 4.3877 4.11814 4.33001 4.23204 4.22402L6.41113 2.04807V9.4C6.41321 9.55849 6.47718 9.7099 6.58942 9.82197ZM11.9952 14H2.02883C1.751 13.9887 1.47813 13.9228 1.22584 13.8061C0.973545 13.6894 0.746779 13.5241 0.558517 13.3197C0.370254 13.1154 0.22419 12.876 0.128681 12.6152C0.0331723 12.3545 -0.00990605 12.0775 0.0019109 11.8V9.40005C0.0019109 9.24092 0.065216 9.08831 0.1779 8.97579C0.290584 8.86326 0.443416 8.80005 0.602775 8.80005C0.762134 8.80005 0.914966 8.86326 1.02765 8.97579C1.14033 9.08831 1.20364 9.24092 1.20364 9.40005V11.8C1.18295 12.0376 1.25463 12.274 1.40379 12.4602C1.55296 12.6463 1.76817 12.7681 2.00479 12.8H11.9952C12.2318 12.7681 12.447 12.6463 12.5962 12.4602C12.7453 12.274 12.817 12.0376 12.7963 11.8V9.40005C12.7963 9.24092 12.8596 9.08831 12.9723 8.97579C13.085 8.86326 13.2378 8.80005 13.3972 8.80005C13.5565 8.80005 13.7094 8.86326 13.8221 8.97579C13.9347 9.08831 13.998 9.24092 13.998 9.40005V11.8C14.022 12.3563 13.8251 12.8996 13.45 13.3116C13.0749 13.7236 12.552 13.971 11.9952 14Z", "fill", "currentColor"], [3, "id"], ["width", "14", "height", "14", "fill", "white"]],
  template: function UploadIcon_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵnamespaceSVG();
      ɵɵelementStart(0, "svg", 0)(1, "g");
      ɵɵelement(2, "path", 1);
      ɵɵelementEnd();
      ɵɵelementStart(3, "defs")(4, "clipPath", 2);
      ɵɵelement(5, "rect", 3);
      ɵɵelementEnd()()();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.getClassNames());
      ɵɵattribute("aria-label", ctx.ariaLabel)("aria-hidden", ctx.ariaHidden)("role", ctx.role);
      ɵɵadvance(1);
      ɵɵattribute("clip-path", ctx.pathId);
      ɵɵadvance(3);
      ɵɵproperty("id", ctx.pathId);
    }
  },
  encapsulation: 2
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(UploadIcon, [{
    type: Component,
    args: [{
      selector: "UploadIcon",
      standalone: true,
      imports: [BaseIcon],
      template: `
        <svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg" [attr.aria-label]="ariaLabel" [attr.aria-hidden]="ariaHidden" [attr.role]="role" [class]="getClassNames()">
            <g [attr.clip-path]="pathId">
                <path
                    fill-rule="evenodd"
                    clip-rule="evenodd"
                    d="M6.58942 9.82197C6.70165 9.93405 6.85328 9.99793 7.012 10C7.17071 9.99793 7.32234 9.93405 7.43458 9.82197C7.54681 9.7099 7.61079 9.55849 7.61286 9.4V2.04798L9.79204 4.22402C9.84752 4.28011 9.91365 4.32457 9.98657 4.35479C10.0595 4.38502 10.1377 4.40039 10.2167 4.40002C10.2956 4.40039 10.3738 4.38502 10.4467 4.35479C10.5197 4.32457 10.5858 4.28011 10.6413 4.22402C10.7538 4.11152 10.817 3.95902 10.817 3.80002C10.817 3.64102 10.7538 3.48852 10.6413 3.37602L7.45127 0.190618C7.44656 0.185584 7.44176 0.180622 7.43687 0.175736C7.32419 0.063214 7.17136 0 7.012 0C6.85264 0 6.69981 0.063214 6.58712 0.175736C6.58181 0.181045 6.5766 0.186443 6.5715 0.191927L3.38282 3.37602C3.27669 3.48976 3.2189 3.6402 3.22165 3.79564C3.2244 3.95108 3.28746 4.09939 3.39755 4.20932C3.50764 4.31925 3.65616 4.38222 3.81182 4.38496C3.96749 4.3877 4.11814 4.33001 4.23204 4.22402L6.41113 2.04807V9.4C6.41321 9.55849 6.47718 9.7099 6.58942 9.82197ZM11.9952 14H2.02883C1.751 13.9887 1.47813 13.9228 1.22584 13.8061C0.973545 13.6894 0.746779 13.5241 0.558517 13.3197C0.370254 13.1154 0.22419 12.876 0.128681 12.6152C0.0331723 12.3545 -0.00990605 12.0775 0.0019109 11.8V9.40005C0.0019109 9.24092 0.065216 9.08831 0.1779 8.97579C0.290584 8.86326 0.443416 8.80005 0.602775 8.80005C0.762134 8.80005 0.914966 8.86326 1.02765 8.97579C1.14033 9.08831 1.20364 9.24092 1.20364 9.40005V11.8C1.18295 12.0376 1.25463 12.274 1.40379 12.4602C1.55296 12.6463 1.76817 12.7681 2.00479 12.8H11.9952C12.2318 12.7681 12.447 12.6463 12.5962 12.4602C12.7453 12.274 12.817 12.0376 12.7963 11.8V9.40005C12.7963 9.24092 12.8596 9.08831 12.9723 8.97579C13.085 8.86326 13.2378 8.80005 13.3972 8.80005C13.5565 8.80005 13.7094 8.86326 13.8221 8.97579C13.9347 9.08831 13.998 9.24092 13.998 9.40005V11.8C14.022 12.3563 13.8251 12.8996 13.45 13.3116C13.0749 13.7236 12.552 13.971 11.9952 14Z"
                    fill="currentColor"
                />
            </g>
            <defs>
                <clipPath [id]="pathId">
                    <rect width="14" height="14" fill="white" />
                </clipPath>
            </defs>
        </svg>
    `
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-messages.mjs
function Messages_ng_container_1_div_1_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span");
  }
  if (rf & 2) {
    const msg_r4 = ɵɵnextContext().$implicit;
    ɵɵclassMap("p-message-icon pi " + msg_r4.icon);
  }
}
function Messages_ng_container_1_div_1_span_3_CheckIcon_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "CheckIcon");
  }
}
function Messages_ng_container_1_div_1_span_3_InfoCircleIcon_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "InfoCircleIcon");
  }
}
function Messages_ng_container_1_div_1_span_3_TimesCircleIcon_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "TimesCircleIcon");
  }
}
function Messages_ng_container_1_div_1_span_3_ExclamationTriangleIcon_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "ExclamationTriangleIcon");
  }
}
function Messages_ng_container_1_div_1_span_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 10);
    ɵɵelementContainerStart(1);
    ɵɵtemplate(2, Messages_ng_container_1_div_1_span_3_CheckIcon_2_Template, 1, 0, "CheckIcon", 11);
    ɵɵtemplate(3, Messages_ng_container_1_div_1_span_3_InfoCircleIcon_3_Template, 1, 0, "InfoCircleIcon", 11);
    ɵɵtemplate(4, Messages_ng_container_1_div_1_span_3_TimesCircleIcon_4_Template, 1, 0, "TimesCircleIcon", 11);
    ɵɵtemplate(5, Messages_ng_container_1_div_1_span_3_ExclamationTriangleIcon_5_Template, 1, 0, "ExclamationTriangleIcon", 11);
    ɵɵelementContainerEnd();
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const msg_r4 = ɵɵnextContext().$implicit;
    ɵɵadvance(2);
    ɵɵproperty("ngIf", msg_r4.severity === "success");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", msg_r4.severity === "info");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", msg_r4.severity === "error");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", msg_r4.severity === "warn");
  }
}
function Messages_ng_container_1_div_1_ng_container_4_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 14);
  }
  if (rf & 2) {
    const msg_r4 = ɵɵnextContext(2).$implicit;
    ɵɵproperty("innerHTML", msg_r4.summary, ɵɵsanitizeHtml);
  }
}
function Messages_ng_container_1_div_1_ng_container_4_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 15);
  }
  if (rf & 2) {
    const msg_r4 = ɵɵnextContext(2).$implicit;
    ɵɵproperty("innerHTML", msg_r4.detail, ɵɵsanitizeHtml);
  }
}
function Messages_ng_container_1_div_1_ng_container_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Messages_ng_container_1_div_1_ng_container_4_span_1_Template, 1, 1, "span", 12);
    ɵɵtemplate(2, Messages_ng_container_1_div_1_ng_container_4_span_2_Template, 1, 1, "span", 13);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const msg_r4 = ɵɵnextContext().$implicit;
    ɵɵadvance(1);
    ɵɵproperty("ngIf", msg_r4.summary);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", msg_r4.detail);
  }
}
function Messages_ng_container_1_div_1_ng_template_5_span_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 18);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const msg_r4 = ɵɵnextContext(2).$implicit;
    ɵɵadvance(1);
    ɵɵtextInterpolate(msg_r4.summary);
  }
}
function Messages_ng_container_1_div_1_ng_template_5_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 19);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const msg_r4 = ɵɵnextContext(2).$implicit;
    ɵɵadvance(1);
    ɵɵtextInterpolate(msg_r4.detail);
  }
}
function Messages_ng_container_1_div_1_ng_template_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, Messages_ng_container_1_div_1_ng_template_5_span_0_Template, 2, 1, "span", 16);
    ɵɵtemplate(1, Messages_ng_container_1_div_1_ng_template_5_span_1_Template, 2, 1, "span", 17);
  }
  if (rf & 2) {
    const msg_r4 = ɵɵnextContext().$implicit;
    ɵɵproperty("ngIf", msg_r4.summary);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", msg_r4.detail);
  }
}
function Messages_ng_container_1_div_1_button_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r30 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "button", 20);
    ɵɵlistener("click", function Messages_ng_container_1_div_1_button_7_Template_button_click_0_listener() {
      ɵɵrestoreView(_r30);
      const i_r5 = ɵɵnextContext().index;
      const ctx_r28 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r28.removeMessage(i_r5));
    });
    ɵɵelement(1, "TimesIcon", 21);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    ɵɵadvance(1);
    ɵɵproperty("styleClass", "p-message-close-icon");
  }
}
var _c0 = function(a0, a1) {
  return {
    showTransitionParams: a0,
    hideTransitionParams: a1
  };
};
var _c1 = function(a1) {
  return {
    value: "visible",
    params: a1
  };
};
function Messages_ng_container_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 4)(1, "div", 5);
    ɵɵtemplate(2, Messages_ng_container_1_div_1_span_2_Template, 1, 2, "span", 6);
    ɵɵtemplate(3, Messages_ng_container_1_div_1_span_3_Template, 6, 4, "span", 7);
    ɵɵtemplate(4, Messages_ng_container_1_div_1_ng_container_4_Template, 3, 2, "ng-container", 1);
    ɵɵtemplate(5, Messages_ng_container_1_div_1_ng_template_5_Template, 2, 2, "ng-template", null, 8, ɵɵtemplateRefExtractor);
    ɵɵtemplate(7, Messages_ng_container_1_div_1_button_7_Template, 2, 1, "button", 9);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const msg_r4 = ctx.$implicit;
    const _r9 = ɵɵreference(6);
    const ctx_r3 = ɵɵnextContext(2);
    ɵɵclassMap("p-message p-message-" + msg_r4.severity);
    ɵɵproperty("@messageAnimation", ɵɵpureFunction1(11, _c1, ɵɵpureFunction2(8, _c0, ctx_r3.showTransitionOptions, ctx_r3.hideTransitionOptions)));
    ɵɵadvance(2);
    ɵɵproperty("ngIf", msg_r4.icon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !msg_r4.icon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r3.escape)("ngIfElse", _r9);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ctx_r3.closable);
  }
}
function Messages_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, Messages_ng_container_1_div_1_Template, 8, 13, "div", 3);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r0.messages);
  }
}
function Messages_ng_template_2_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function Messages_ng_template_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 22)(1, "div", 5);
    ɵɵtemplate(2, Messages_ng_template_2_ng_container_2_Template, 1, 0, "ng-container", 23);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext();
    ɵɵproperty("ngClass", "p-message p-message-" + ctx_r2.severity);
    ɵɵadvance(2);
    ɵɵproperty("ngTemplateOutlet", ctx_r2.contentTemplate);
  }
}
var _Messages = class {
  constructor(messageService, el, cd) {
    __publicField(this, "messageService");
    __publicField(this, "el");
    __publicField(this, "cd");
    /**
     * Defines if message box can be closed by the click icon.
     * @group Props
     */
    __publicField(this, "closable", true);
    /**
     * Inline style of the component.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Style class of the component.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Whether displaying services messages are enabled.
     * @group Props
     */
    __publicField(this, "enableService", true);
    /**
     * Id to match the key of the message to enable scoping in service based messaging.
     * @group Props
     */
    __publicField(this, "key");
    /**
     * Whether displaying messages would be escaped or not.
     * @group Props
     */
    __publicField(this, "escape", true);
    /**
     * Severity level of the message.
     * @group Props
     */
    __publicField(this, "severity");
    /**
     * Transition options of the show animation.
     * @group Props
     */
    __publicField(this, "showTransitionOptions", "300ms ease-out");
    /**
     * Transition options of the hide animation.
     * @group Props
     */
    __publicField(this, "hideTransitionOptions", "200ms cubic-bezier(0.86, 0, 0.07, 1)");
    /**
     * This function is executed when the value changes.
     * @param {Message[]} value - messages value.
     * @group Emits
     */
    __publicField(this, "valueChange", new EventEmitter());
    __publicField(this, "templates");
    __publicField(this, "messages");
    __publicField(this, "messageSubscription");
    __publicField(this, "clearSubscription");
    __publicField(this, "timerSubscriptions", []);
    __publicField(this, "contentTemplate");
    this.messageService = messageService;
    this.el = el;
    this.cd = cd;
  }
  /**
   * An array of messages to display.
   * @group Props
   */
  set value(messages) {
    this.messages = messages;
    this.startMessageLifes(this.messages);
  }
  ngAfterContentInit() {
    var _a;
    (_a = this.templates) == null ? void 0 : _a.forEach((item) => {
      switch (item.getType()) {
        case "content":
          this.contentTemplate = item.template;
          break;
        default:
          this.contentTemplate = item.template;
          break;
      }
    });
    if (this.messageService && this.enableService && !this.contentTemplate) {
      this.messageSubscription = this.messageService.messageObserver.subscribe((messages) => {
        if (messages) {
          if (!Array.isArray(messages)) {
            messages = [messages];
          }
          const filteredMessages = messages.filter((m) => this.key === m.key);
          this.messages = this.messages ? [...this.messages, ...filteredMessages] : [...filteredMessages];
          this.startMessageLifes(filteredMessages);
          this.cd.markForCheck();
        }
      });
      this.clearSubscription = this.messageService.clearObserver.subscribe((key) => {
        if (key) {
          if (this.key === key) {
            this.messages = null;
          }
        } else {
          this.messages = null;
        }
        this.cd.markForCheck();
      });
    }
  }
  hasMessages() {
    let parentEl = this.el.nativeElement.parentElement;
    if (parentEl && parentEl.offsetParent) {
      return this.contentTemplate != null || this.messages && this.messages.length > 0;
    }
    return false;
  }
  clear() {
    this.messages = [];
    this.valueChange.emit(this.messages);
  }
  removeMessage(i) {
    var _a;
    this.messages = (_a = this.messages) == null ? void 0 : _a.filter((msg, index) => index !== i);
    this.valueChange.emit(this.messages);
  }
  get icon() {
    const severity = this.severity || (this.hasMessages() ? this.messages[0].severity : null);
    if (this.hasMessages()) {
      switch (severity) {
        case "success":
          return "pi-check";
        case "info":
          return "pi-info-circle";
        case "error":
          return "pi-times";
        case "warn":
          return "pi-exclamation-triangle";
        default:
          return "pi-info-circle";
      }
    }
    return null;
  }
  ngOnDestroy() {
    var _a;
    if (this.messageSubscription) {
      this.messageSubscription.unsubscribe();
    }
    if (this.clearSubscription) {
      this.clearSubscription.unsubscribe();
    }
    (_a = this.timerSubscriptions) == null ? void 0 : _a.forEach((subscription) => subscription.unsubscribe());
  }
  startMessageLifes(messages) {
    messages == null ? void 0 : messages.forEach((message) => message.life && this.startMessageLife(message));
  }
  startMessageLife(message) {
    const timerSubsctiption = timer(message.life).subscribe(() => {
      var _a, _b;
      this.messages = (_a = this.messages) == null ? void 0 : _a.filter((msgEl) => msgEl !== message);
      this.timerSubscriptions = (_b = this.timerSubscriptions) == null ? void 0 : _b.filter((timerEl) => timerEl !== timerSubsctiption);
      this.valueChange.emit(this.messages);
      this.cd.markForCheck();
    });
    this.timerSubscriptions.push(timerSubsctiption);
  }
};
var Messages = _Messages;
__publicField(Messages, "ɵfac", function Messages_Factory(t) {
  return new (t || _Messages)(ɵɵdirectiveInject(MessageService, 8), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(ChangeDetectorRef));
});
__publicField(Messages, "ɵcmp", ɵɵdefineComponent({
  type: _Messages,
  selectors: [["p-messages"]],
  contentQueries: function Messages_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    value: "value",
    closable: "closable",
    style: "style",
    styleClass: "styleClass",
    enableService: "enableService",
    key: "key",
    escape: "escape",
    severity: "severity",
    showTransitionOptions: "showTransitionOptions",
    hideTransitionOptions: "hideTransitionOptions"
  },
  outputs: {
    valueChange: "valueChange"
  },
  decls: 4,
  vars: 5,
  consts: [["role", "alert", 1, "p-messages", "p-component", 3, "ngStyle"], [4, "ngIf", "ngIfElse"], ["staticMessage", ""], ["role", "alert", 3, "class", 4, "ngFor", "ngForOf"], ["role", "alert"], [1, "p-message-wrapper"], [3, "class", 4, "ngIf"], ["class", "p-message-icon", 4, "ngIf"], ["escapeOut", ""], ["class", "p-message-close p-link", "type", "button", "pRipple", "", 3, "click", 4, "ngIf"], [1, "p-message-icon"], [4, "ngIf"], ["class", "p-message-summary", 3, "innerHTML", 4, "ngIf"], ["class", "p-message-detail", 3, "innerHTML", 4, "ngIf"], [1, "p-message-summary", 3, "innerHTML"], [1, "p-message-detail", 3, "innerHTML"], ["class", "p-message-summary", 4, "ngIf"], ["class", "p-message-detail", 4, "ngIf"], [1, "p-message-summary"], [1, "p-message-detail"], ["type", "button", "pRipple", "", 1, "p-message-close", "p-link", 3, "click"], [3, "styleClass"], ["role", "alert", 3, "ngClass"], [4, "ngTemplateOutlet"]],
  template: function Messages_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0);
      ɵɵtemplate(1, Messages_ng_container_1_Template, 2, 1, "ng-container", 1);
      ɵɵtemplate(2, Messages_ng_template_2_Template, 3, 2, "ng-template", null, 2, ɵɵtemplateRefExtractor);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      const _r1 = ɵɵreference(3);
      ɵɵclassMap(ctx.styleClass);
      ɵɵproperty("ngStyle", ctx.style);
      ɵɵadvance(1);
      ɵɵproperty("ngIf", !ctx.contentTemplate)("ngIfElse", _r1);
    }
  },
  dependencies: function() {
    return [NgClass, NgForOf, NgIf, NgTemplateOutlet, NgStyle, Ripple, CheckIcon, InfoCircleIcon, TimesCircleIcon, ExclamationTriangleIcon, TimesIcon];
  },
  styles: [".p-message-wrapper{display:flex;align-items:center}.p-message-close{display:flex;align-items:center;justify-content:center}.p-message-close.p-link{margin-left:auto;overflow:hidden;position:relative}.p-messages .p-message.ng-animating{overflow:hidden}\n"],
  encapsulation: 2,
  data: {
    animation: [trigger("messageAnimation", [transition(":enter", [style({
      opacity: 0,
      transform: "translateY(-25%)"
    }), animate("{{showTransitionParams}}")]), transition(":leave", [animate("{{hideTransitionParams}}", style({
      height: 0,
      marginTop: 0,
      marginBottom: 0,
      marginLeft: 0,
      marginRight: 0,
      opacity: 0
    }))])])]
  },
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(Messages, [{
    type: Component,
    args: [{
      selector: "p-messages",
      template: `
        <div class="p-messages p-component" role="alert" [ngStyle]="style" [class]="styleClass">
            <ng-container *ngIf="!contentTemplate; else staticMessage">
                <div
                    *ngFor="let msg of messages; let i = index"
                    [class]="'p-message p-message-' + msg.severity"
                    role="alert"
                    [@messageAnimation]="{ value: 'visible', params: { showTransitionParams: showTransitionOptions, hideTransitionParams: hideTransitionOptions } }"
                >
                    <div class="p-message-wrapper">
                        <span *ngIf="msg.icon" [class]="'p-message-icon pi ' + msg.icon"> </span>
                        <span class="p-message-icon" *ngIf="!msg.icon">
                            <ng-container>
                                <CheckIcon *ngIf="msg.severity === 'success'" />
                                <InfoCircleIcon *ngIf="msg.severity === 'info'" />
                                <TimesCircleIcon *ngIf="msg.severity === 'error'" />
                                <ExclamationTriangleIcon *ngIf="msg.severity === 'warn'" />
                            </ng-container>
                        </span>
                        <ng-container *ngIf="!escape; else escapeOut">
                            <span *ngIf="msg.summary" class="p-message-summary" [innerHTML]="msg.summary"></span>
                            <span *ngIf="msg.detail" class="p-message-detail" [innerHTML]="msg.detail"></span>
                        </ng-container>
                        <ng-template #escapeOut>
                            <span *ngIf="msg.summary" class="p-message-summary">{{ msg.summary }}</span>
                            <span *ngIf="msg.detail" class="p-message-detail">{{ msg.detail }}</span>
                        </ng-template>
                        <button class="p-message-close p-link" (click)="removeMessage(i)" *ngIf="closable" type="button" pRipple>
                            <TimesIcon [styleClass]="'p-message-close-icon'" />
                        </button>
                    </div>
                </div>
            </ng-container>
            <ng-template #staticMessage>
                <div [ngClass]="'p-message p-message-' + severity" role="alert">
                    <div class="p-message-wrapper">
                        <ng-container *ngTemplateOutlet="contentTemplate"></ng-container>
                    </div>
                </div>
            </ng-template>
        </div>
    `,
      animations: [trigger("messageAnimation", [transition(":enter", [style({
        opacity: 0,
        transform: "translateY(-25%)"
      }), animate("{{showTransitionParams}}")]), transition(":leave", [animate("{{hideTransitionParams}}", style({
        height: 0,
        marginTop: 0,
        marginBottom: 0,
        marginLeft: 0,
        marginRight: 0,
        opacity: 0
      }))])])],
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      },
      styles: [".p-message-wrapper{display:flex;align-items:center}.p-message-close{display:flex;align-items:center;justify-content:center}.p-message-close.p-link{margin-left:auto;overflow:hidden;position:relative}.p-messages .p-message.ng-animating{overflow:hidden}\n"]
    }]
  }], function() {
    return [{
      type: MessageService,
      decorators: [{
        type: Optional
      }]
    }, {
      type: ElementRef
    }, {
      type: ChangeDetectorRef
    }];
  }, {
    value: [{
      type: Input
    }],
    closable: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    enableService: [{
      type: Input
    }],
    key: [{
      type: Input
    }],
    escape: [{
      type: Input
    }],
    severity: [{
      type: Input
    }],
    showTransitionOptions: [{
      type: Input
    }],
    hideTransitionOptions: [{
      type: Input
    }],
    valueChange: [{
      type: Output
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }]
  });
})();
var _MessagesModule = class {
};
var MessagesModule = _MessagesModule;
__publicField(MessagesModule, "ɵfac", function MessagesModule_Factory(t) {
  return new (t || _MessagesModule)();
});
__publicField(MessagesModule, "ɵmod", ɵɵdefineNgModule({
  type: _MessagesModule,
  declarations: [Messages],
  imports: [CommonModule, RippleModule, CheckIcon, InfoCircleIcon, TimesCircleIcon, ExclamationTriangleIcon, TimesIcon],
  exports: [Messages]
}));
__publicField(MessagesModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, RippleModule, CheckIcon, InfoCircleIcon, TimesCircleIcon, ExclamationTriangleIcon, TimesIcon]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(MessagesModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, RippleModule, CheckIcon, InfoCircleIcon, TimesCircleIcon, ExclamationTriangleIcon, TimesIcon],
      exports: [Messages],
      declarations: [Messages]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-progressbar.mjs
function ProgressBar_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 5);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r2 = ɵɵnextContext(2);
    ɵɵstyleProp("display", ctx_r2.value != null && ctx_r2.value !== 0 ? "flex" : "none");
    ɵɵattribute("data-pc-section", "label");
    ɵɵadvance(1);
    ɵɵtextInterpolate2("", ctx_r2.value, "", ctx_r2.unit, "");
  }
}
function ProgressBar_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 3);
    ɵɵtemplate(1, ProgressBar_div_1_div_1_Template, 2, 5, "div", 4);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵstyleProp("width", ctx_r0.value + "%")("background", ctx_r0.color);
    ɵɵattribute("data-pc-section", "value");
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.showValue);
  }
}
function ProgressBar_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 6);
    ɵɵelement(1, "div", 7);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵattribute("data-pc-section", "container");
    ɵɵadvance(1);
    ɵɵstyleProp("background", ctx_r1.color);
    ɵɵattribute("data-pc-section", "value");
  }
}
var _c02 = function(a1, a2) {
  return {
    "p-progressbar p-component": true,
    "p-progressbar-determinate": a1,
    "p-progressbar-indeterminate": a2
  };
};
var _ProgressBar = class {
  constructor() {
    /**
     * Current value of the progress.
     * @group Props
     */
    __publicField(this, "value");
    /**
     * Whether to display the progress bar value.
     * @group Props
     */
    __publicField(this, "showValue", true);
    /**
     * Class of the element.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Inline style of the element.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Unit sign appended to the value.
     * @group Props
     */
    __publicField(this, "unit", "%");
    /**
     * Defines the mode of the progress
     * @group Props
     */
    __publicField(this, "mode", "determinate");
    /**
     * Color for the background of the progress.
     * @group Props
     */
    __publicField(this, "color");
  }
};
var ProgressBar = _ProgressBar;
__publicField(ProgressBar, "ɵfac", function ProgressBar_Factory(t) {
  return new (t || _ProgressBar)();
});
__publicField(ProgressBar, "ɵcmp", ɵɵdefineComponent({
  type: _ProgressBar,
  selectors: [["p-progressBar"]],
  hostAttrs: [1, "p-element"],
  inputs: {
    value: "value",
    showValue: "showValue",
    styleClass: "styleClass",
    style: "style",
    unit: "unit",
    mode: "mode",
    color: "color"
  },
  decls: 3,
  vars: 14,
  consts: [["role", "progressbar", 3, "ngStyle", "ngClass"], ["class", "p-progressbar-value p-progressbar-value-animate", "style", "display:flex", 3, "width", "background", 4, "ngIf"], ["class", "p-progressbar-indeterminate-container", 4, "ngIf"], [1, "p-progressbar-value", "p-progressbar-value-animate", 2, "display", "flex"], ["class", "p-progressbar-label", 3, "display", 4, "ngIf"], [1, "p-progressbar-label"], [1, "p-progressbar-indeterminate-container"], [1, "p-progressbar-value", "p-progressbar-value-animate"]],
  template: function ProgressBar_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵelementStart(0, "div", 0);
      ɵɵtemplate(1, ProgressBar_div_1_Template, 2, 6, "div", 1);
      ɵɵtemplate(2, ProgressBar_div_2_Template, 2, 4, "div", 2);
      ɵɵelementEnd();
    }
    if (rf & 2) {
      ɵɵclassMap(ctx.styleClass);
      ɵɵproperty("ngStyle", ctx.style)("ngClass", ɵɵpureFunction2(11, _c02, ctx.mode === "determinate", ctx.mode === "indeterminate"));
      ɵɵattribute("aria-valuemin", 0)("aria-valuenow", ctx.value)("aria-valuemax", 100)("data-pc-name", "progressbar")("data-pc-section", "root");
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.mode === "determinate");
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.mode === "indeterminate");
    }
  },
  dependencies: [NgClass, NgIf, NgStyle],
  styles: ['.p-progressbar{position:relative;overflow:hidden}.p-progressbar-determinate .p-progressbar-value{height:100%;width:0%;position:absolute;display:none;border:0 none;display:flex;align-items:center;justify-content:center;overflow:hidden}.p-progressbar-determinate .p-progressbar-label{display:inline-flex}.p-progressbar-determinate .p-progressbar-value-animate{transition:width 1s ease-in-out}.p-progressbar-indeterminate .p-progressbar-value:before{content:"";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim 2.1s cubic-bezier(.65,.815,.735,.395) infinite}.p-progressbar-indeterminate .p-progressbar-value:after{content:"";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim-short 2.1s cubic-bezier(.165,.84,.44,1) infinite;animation-delay:1.15s}@keyframes p-progressbar-indeterminate-anim{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}@keyframes p-progressbar-indeterminate-anim-short{0%{left:-200%;right:100%}60%{left:107%;right:-8%}to{left:107%;right:-8%}}\n'],
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ProgressBar, [{
    type: Component,
    args: [{
      selector: "p-progressBar",
      template: `
        <div
            role="progressbar"
            [class]="styleClass"
            [ngStyle]="style"
            [attr.aria-valuemin]="0"
            [attr.aria-valuenow]="value"
            [attr.aria-valuemax]="100"
            [attr.data-pc-name]="'progressbar'"
            [attr.data-pc-section]="'root'"
            [ngClass]="{ 'p-progressbar p-component': true, 'p-progressbar-determinate': mode === 'determinate', 'p-progressbar-indeterminate': mode === 'indeterminate' }"
        >
            <div *ngIf="mode === 'determinate'" class="p-progressbar-value p-progressbar-value-animate" [style.width]="value + '%'" style="display:flex" [style.background]="color" [attr.data-pc-section]="'value'">
                <div *ngIf="showValue" class="p-progressbar-label" [style.display]="value != null && value !== 0 ? 'flex' : 'none'" [attr.data-pc-section]="'label'">{{ value }}{{ unit }}</div>
            </div>
            <div *ngIf="mode === 'indeterminate'" class="p-progressbar-indeterminate-container" [attr.data-pc-section]="'container'">
                <div class="p-progressbar-value p-progressbar-value-animate" [style.background]="color" [attr.data-pc-section]="'value'"></div>
            </div>
        </div>
    `,
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      },
      styles: ['.p-progressbar{position:relative;overflow:hidden}.p-progressbar-determinate .p-progressbar-value{height:100%;width:0%;position:absolute;display:none;border:0 none;display:flex;align-items:center;justify-content:center;overflow:hidden}.p-progressbar-determinate .p-progressbar-label{display:inline-flex}.p-progressbar-determinate .p-progressbar-value-animate{transition:width 1s ease-in-out}.p-progressbar-indeterminate .p-progressbar-value:before{content:"";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim 2.1s cubic-bezier(.65,.815,.735,.395) infinite}.p-progressbar-indeterminate .p-progressbar-value:after{content:"";position:absolute;background-color:inherit;top:0;left:0;bottom:0;will-change:left,right;animation:p-progressbar-indeterminate-anim-short 2.1s cubic-bezier(.165,.84,.44,1) infinite;animation-delay:1.15s}@keyframes p-progressbar-indeterminate-anim{0%{left:-35%;right:100%}60%{left:100%;right:-90%}to{left:100%;right:-90%}}@keyframes p-progressbar-indeterminate-anim-short{0%{left:-200%;right:100%}60%{left:107%;right:-8%}to{left:107%;right:-8%}}\n']
    }]
  }], null, {
    value: [{
      type: Input
    }],
    showValue: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    unit: [{
      type: Input
    }],
    mode: [{
      type: Input
    }],
    color: [{
      type: Input
    }]
  });
})();
var _ProgressBarModule = class {
};
var ProgressBarModule = _ProgressBarModule;
__publicField(ProgressBarModule, "ɵfac", function ProgressBarModule_Factory(t) {
  return new (t || _ProgressBarModule)();
});
__publicField(ProgressBarModule, "ɵmod", ɵɵdefineNgModule({
  type: _ProgressBarModule,
  declarations: [ProgressBar],
  imports: [CommonModule],
  exports: [ProgressBar]
}));
__publicField(ProgressBarModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ProgressBarModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule],
      exports: [ProgressBar],
      declarations: [ProgressBar]
    }]
  }], null, null);
})();

// node_modules/primeng/fesm2022/primeng-fileupload.mjs
var _c03 = ["advancedfileinput"];
var _c12 = ["basicfileinput"];
var _c2 = ["content"];
function FileUpload_div_0_span_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 18);
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext(2);
    ɵɵclassMap(ctx_r3.chooseIcon);
    ɵɵproperty("ngClass", "p-button-icon p-button-icon-left");
  }
}
function FileUpload_div_0_ng_container_6_PlusIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "PlusIcon", 21);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-button-icon p-button-icon-left");
  }
}
function FileUpload_div_0_ng_container_6_span_2_1_ng_template_0_Template(rf, ctx) {
}
function FileUpload_div_0_ng_container_6_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FileUpload_div_0_ng_container_6_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function FileUpload_div_0_ng_container_6_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 22);
    ɵɵtemplate(1, FileUpload_div_0_ng_container_6_span_2_1_Template, 1, 0, null, 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r13 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r13.chooseIconTemplate);
  }
}
function FileUpload_div_0_ng_container_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FileUpload_div_0_ng_container_6_PlusIcon_1_Template, 1, 1, "PlusIcon", 19);
    ɵɵtemplate(2, FileUpload_div_0_ng_container_6_span_2_Template, 2, 1, "span", 20);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r4 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r4.chooseIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r4.chooseIconTemplate);
  }
}
function FileUpload_div_0_p_button_9_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 18);
  }
  if (rf & 2) {
    const ctx_r16 = ɵɵnextContext(3);
    ɵɵproperty("ngClass", ctx_r16.uploadIcon);
  }
}
function FileUpload_div_0_p_button_9_ng_container_2_UploadIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "UploadIcon", 21);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-button-icon p-button-icon-left");
  }
}
function FileUpload_div_0_p_button_9_ng_container_2_span_2_1_ng_template_0_Template(rf, ctx) {
}
function FileUpload_div_0_p_button_9_ng_container_2_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FileUpload_div_0_p_button_9_ng_container_2_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function FileUpload_div_0_p_button_9_ng_container_2_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 22);
    ɵɵtemplate(1, FileUpload_div_0_p_button_9_ng_container_2_span_2_1_Template, 1, 0, null, 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r19 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r19.uploadIconTemplate);
  }
}
function FileUpload_div_0_p_button_9_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FileUpload_div_0_p_button_9_ng_container_2_UploadIcon_1_Template, 1, 1, "UploadIcon", 19);
    ɵɵtemplate(2, FileUpload_div_0_p_button_9_ng_container_2_span_2_Template, 2, 1, "span", 20);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r17 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r17.uploadIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r17.uploadIconTemplate);
  }
}
function FileUpload_div_0_p_button_9_Template(rf, ctx) {
  if (rf & 1) {
    const _r23 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-button", 23);
    ɵɵlistener("onClick", function FileUpload_div_0_p_button_9_Template_p_button_onClick_0_listener() {
      ɵɵrestoreView(_r23);
      const ctx_r22 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r22.upload());
    });
    ɵɵtemplate(1, FileUpload_div_0_p_button_9_span_1_Template, 1, 1, "span", 24);
    ɵɵtemplate(2, FileUpload_div_0_p_button_9_ng_container_2_Template, 3, 2, "ng-container", 8);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r5 = ɵɵnextContext(2);
    ɵɵproperty("label", ctx_r5.uploadButtonLabel)("disabled", !ctx_r5.hasFiles() || ctx_r5.isFileLimitExceeded())("styleClass", ctx_r5.uploadStyleClass);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r5.uploadIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r5.uploadIcon);
  }
}
function FileUpload_div_0_p_button_10_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 18);
  }
  if (rf & 2) {
    const ctx_r24 = ɵɵnextContext(3);
    ɵɵproperty("ngClass", ctx_r24.cancelIcon);
  }
}
function FileUpload_div_0_p_button_10_ng_container_2_TimesIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "TimesIcon", 21);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-button-icon p-button-icon-left");
  }
}
function FileUpload_div_0_p_button_10_ng_container_2_span_2_1_ng_template_0_Template(rf, ctx) {
}
function FileUpload_div_0_p_button_10_ng_container_2_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FileUpload_div_0_p_button_10_ng_container_2_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function FileUpload_div_0_p_button_10_ng_container_2_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 22);
    ɵɵtemplate(1, FileUpload_div_0_p_button_10_ng_container_2_span_2_1_Template, 1, 0, null, 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r27 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r27.cancelIconTemplate);
  }
}
function FileUpload_div_0_p_button_10_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FileUpload_div_0_p_button_10_ng_container_2_TimesIcon_1_Template, 1, 1, "TimesIcon", 19);
    ɵɵtemplate(2, FileUpload_div_0_p_button_10_ng_container_2_span_2_Template, 2, 1, "span", 20);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r25 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r25.cancelIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r25.cancelIconTemplate);
  }
}
function FileUpload_div_0_p_button_10_Template(rf, ctx) {
  if (rf & 1) {
    const _r31 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "p-button", 23);
    ɵɵlistener("onClick", function FileUpload_div_0_p_button_10_Template_p_button_onClick_0_listener() {
      ɵɵrestoreView(_r31);
      const ctx_r30 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r30.clear());
    });
    ɵɵtemplate(1, FileUpload_div_0_p_button_10_span_1_Template, 1, 1, "span", 24);
    ɵɵtemplate(2, FileUpload_div_0_p_button_10_ng_container_2_Template, 3, 2, "ng-container", 8);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r6 = ɵɵnextContext(2);
    ɵɵproperty("label", ctx_r6.cancelButtonLabel)("disabled", !ctx_r6.hasFiles() || ctx_r6.uploading)("styleClass", ctx_r6.cancelStyleClass);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r6.cancelIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r6.cancelIcon);
  }
}
function FileUpload_div_0_ng_container_11_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function FileUpload_div_0_p_progressBar_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "p-progressBar", 25);
  }
  if (rf & 2) {
    const ctx_r9 = ɵɵnextContext(2);
    ɵɵproperty("value", ctx_r9.progress)("showValue", false);
  }
}
function FileUpload_div_0_div_16_div_1_div_1_img_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r41 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "img", 32);
    ɵɵlistener("error", function FileUpload_div_0_div_16_div_1_div_1_img_2_Template_img_error_0_listener($event) {
      ɵɵrestoreView(_r41);
      const ctx_r40 = ɵɵnextContext(5);
      return ɵɵresetView(ctx_r40.imageError($event));
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const file_r35 = ɵɵnextContext().$implicit;
    const ctx_r37 = ɵɵnextContext(4);
    ɵɵproperty("src", file_r35.objectURL, ɵɵsanitizeUrl)("width", ctx_r37.previewWidth);
  }
}
function FileUpload_div_0_div_16_div_1_div_1_TimesIcon_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "TimesIcon");
  }
}
function FileUpload_div_0_div_16_div_1_div_1_10_ng_template_0_Template(rf, ctx) {
}
function FileUpload_div_0_div_16_div_1_div_1_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FileUpload_div_0_div_16_div_1_div_1_10_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function FileUpload_div_0_div_16_div_1_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r45 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 28)(1, "div");
    ɵɵtemplate(2, FileUpload_div_0_div_16_div_1_div_1_img_2_Template, 1, 2, "img", 29);
    ɵɵelementEnd();
    ɵɵelementStart(3, "div", 30);
    ɵɵtext(4);
    ɵɵelementEnd();
    ɵɵelementStart(5, "div");
    ɵɵtext(6);
    ɵɵelementEnd();
    ɵɵelementStart(7, "div")(8, "button", 31);
    ɵɵlistener("click", function FileUpload_div_0_div_16_div_1_div_1_Template_button_click_8_listener($event) {
      const restoredCtx = ɵɵrestoreView(_r45);
      const i_r36 = restoredCtx.index;
      const ctx_r44 = ɵɵnextContext(4);
      return ɵɵresetView(ctx_r44.remove($event, i_r36));
    });
    ɵɵtemplate(9, FileUpload_div_0_div_16_div_1_div_1_TimesIcon_9_Template, 1, 0, "TimesIcon", 8);
    ɵɵtemplate(10, FileUpload_div_0_div_16_div_1_div_1_10_Template, 1, 0, null, 11);
    ɵɵelementEnd()()();
  }
  if (rf & 2) {
    const file_r35 = ctx.$implicit;
    const ctx_r34 = ɵɵnextContext(4);
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r34.isImage(file_r35));
    ɵɵadvance(2);
    ɵɵtextInterpolate(file_r35.name);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ctx_r34.formatSize(file_r35.size));
    ɵɵadvance(2);
    ɵɵclassMap(ctx_r34.removeStyleClass);
    ɵɵproperty("disabled", ctx_r34.uploading);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r34.cancelIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r34.cancelIconTemplate);
  }
}
function FileUpload_div_0_div_16_div_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtemplate(1, FileUpload_div_0_div_16_div_1_div_1_Template, 11, 8, "div", 27);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r32 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r32.files);
  }
}
function FileUpload_div_0_div_16_div_2_ng_template_1_Template(rf, ctx) {
}
function FileUpload_div_0_div_16_div_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div");
    ɵɵtemplate(1, FileUpload_div_0_div_16_div_2_ng_template_1_Template, 0, 0, "ng-template", 33);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r33 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngForOf", ctx_r33.files)("ngForTemplate", ctx_r33.fileTemplate);
  }
}
function FileUpload_div_0_div_16_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "div", 26);
    ɵɵtemplate(1, FileUpload_div_0_div_16_div_1_Template, 2, 1, "div", 8);
    ɵɵtemplate(2, FileUpload_div_0_div_16_div_2_Template, 2, 2, "div", 8);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r10 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r10.fileTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r10.fileTemplate);
  }
}
function FileUpload_div_0_ng_container_17_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c3 = function(a0, a1) {
  return {
    "p-focus": a0,
    "p-disabled": a1
  };
};
var _c4 = function(a0) {
  return {
    $implicit: a0
  };
};
function FileUpload_div_0_Template(rf, ctx) {
  if (rf & 1) {
    const _r48 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 2)(1, "div", 3)(2, "span", 4);
    ɵɵlistener("focus", function FileUpload_div_0_Template_span_focus_2_listener() {
      ɵɵrestoreView(_r48);
      const ctx_r47 = ɵɵnextContext();
      return ɵɵresetView(ctx_r47.onFocus());
    })("blur", function FileUpload_div_0_Template_span_blur_2_listener() {
      ɵɵrestoreView(_r48);
      const ctx_r49 = ɵɵnextContext();
      return ɵɵresetView(ctx_r49.onBlur());
    })("click", function FileUpload_div_0_Template_span_click_2_listener() {
      ɵɵrestoreView(_r48);
      const ctx_r50 = ɵɵnextContext();
      return ɵɵresetView(ctx_r50.choose());
    })("keydown.enter", function FileUpload_div_0_Template_span_keydown_enter_2_listener() {
      ɵɵrestoreView(_r48);
      const ctx_r51 = ɵɵnextContext();
      return ɵɵresetView(ctx_r51.choose());
    });
    ɵɵelementStart(3, "input", 5, 6);
    ɵɵlistener("change", function FileUpload_div_0_Template_input_change_3_listener($event) {
      ɵɵrestoreView(_r48);
      const ctx_r52 = ɵɵnextContext();
      return ɵɵresetView(ctx_r52.onFileSelect($event));
    });
    ɵɵelementEnd();
    ɵɵtemplate(5, FileUpload_div_0_span_5_Template, 1, 3, "span", 7);
    ɵɵtemplate(6, FileUpload_div_0_ng_container_6_Template, 3, 2, "ng-container", 8);
    ɵɵelementStart(7, "span", 9);
    ɵɵtext(8);
    ɵɵelementEnd()();
    ɵɵtemplate(9, FileUpload_div_0_p_button_9_Template, 3, 5, "p-button", 10);
    ɵɵtemplate(10, FileUpload_div_0_p_button_10_Template, 3, 5, "p-button", 10);
    ɵɵtemplate(11, FileUpload_div_0_ng_container_11_Template, 1, 0, "ng-container", 11);
    ɵɵelementEnd();
    ɵɵelementStart(12, "div", 12, 13);
    ɵɵlistener("dragenter", function FileUpload_div_0_Template_div_dragenter_12_listener($event) {
      ɵɵrestoreView(_r48);
      const ctx_r53 = ɵɵnextContext();
      return ɵɵresetView(ctx_r53.onDragEnter($event));
    })("dragleave", function FileUpload_div_0_Template_div_dragleave_12_listener($event) {
      ɵɵrestoreView(_r48);
      const ctx_r54 = ɵɵnextContext();
      return ɵɵresetView(ctx_r54.onDragLeave($event));
    })("drop", function FileUpload_div_0_Template_div_drop_12_listener($event) {
      ɵɵrestoreView(_r48);
      const ctx_r55 = ɵɵnextContext();
      return ɵɵresetView(ctx_r55.onDrop($event));
    });
    ɵɵtemplate(14, FileUpload_div_0_p_progressBar_14_Template, 1, 2, "p-progressBar", 14);
    ɵɵelement(15, "p-messages", 15);
    ɵɵtemplate(16, FileUpload_div_0_div_16_Template, 3, 2, "div", 16);
    ɵɵtemplate(17, FileUpload_div_0_ng_container_17_Template, 1, 0, "ng-container", 17);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵclassMap(ctx_r0.styleClass);
    ɵɵproperty("ngClass", "p-fileupload p-fileupload-advanced p-component")("ngStyle", ctx_r0.style);
    ɵɵadvance(2);
    ɵɵclassMap(ctx_r0.chooseStyleClass);
    ɵɵproperty("ngClass", ɵɵpureFunction2(23, _c3, ctx_r0.focus, ctx_r0.disabled || ctx_r0.isChooseDisabled()));
    ɵɵadvance(1);
    ɵɵproperty("multiple", ctx_r0.multiple)("accept", ctx_r0.accept)("disabled", ctx_r0.disabled || ctx_r0.isChooseDisabled());
    ɵɵattribute("title", "");
    ɵɵadvance(2);
    ɵɵproperty("ngIf", ctx_r0.chooseIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r0.chooseIcon);
    ɵɵadvance(2);
    ɵɵtextInterpolate(ctx_r0.chooseButtonLabel);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r0.auto && ctx_r0.showUploadButton);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r0.auto && ctx_r0.showCancelButton);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r0.toolbarTemplate);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ctx_r0.hasFiles());
    ɵɵadvance(1);
    ɵɵproperty("value", ctx_r0.msgs)("enableService", false);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r0.hasFiles());
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r0.contentTemplate)("ngTemplateOutletContext", ɵɵpureFunction1(26, _c4, ctx_r0.files));
  }
}
function FileUpload_div_1_ng_container_3_span_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 41);
  }
  if (rf & 2) {
    const ctx_r61 = ɵɵnextContext(3);
    ɵɵproperty("ngClass", ctx_r61.uploadIcon);
  }
}
function FileUpload_div_1_ng_container_3_ng_container_2_UploadIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "UploadIcon", 21);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-button-icon p-button-icon-left");
  }
}
function FileUpload_div_1_ng_container_3_ng_container_2_span_2_1_ng_template_0_Template(rf, ctx) {
}
function FileUpload_div_1_ng_container_3_ng_container_2_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FileUpload_div_1_ng_container_3_ng_container_2_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function FileUpload_div_1_ng_container_3_ng_container_2_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 22);
    ɵɵtemplate(1, FileUpload_div_1_ng_container_3_ng_container_2_span_2_1_Template, 1, 0, null, 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r64 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r64.uploadIconTemplate);
  }
}
function FileUpload_div_1_ng_container_3_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FileUpload_div_1_ng_container_3_ng_container_2_UploadIcon_1_Template, 1, 1, "UploadIcon", 19);
    ɵɵtemplate(2, FileUpload_div_1_ng_container_3_ng_container_2_span_2_Template, 2, 1, "span", 20);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r62 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r62.uploadIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r62.uploadIconTemplate);
  }
}
function FileUpload_div_1_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FileUpload_div_1_ng_container_3_span_1_Template, 1, 1, "span", 40);
    ɵɵtemplate(2, FileUpload_div_1_ng_container_3_ng_container_2_Template, 3, 2, "ng-container", 8);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r56 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r56.uploadIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r56.uploadIcon);
  }
}
function FileUpload_div_1_ng_template_4_span_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "span", 43);
  }
  if (rf & 2) {
    const ctx_r67 = ɵɵnextContext(3);
    ɵɵproperty("ngClass", ctx_r67.chooseIcon);
  }
}
function FileUpload_div_1_ng_template_4_ng_container_1_PlusIcon_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelement(0, "PlusIcon", 21);
  }
  if (rf & 2) {
    ɵɵproperty("styleClass", "p-button-icon p-button-icon-left pi");
  }
}
function FileUpload_div_1_ng_template_4_ng_container_1_span_2_1_ng_template_0_Template(rf, ctx) {
}
function FileUpload_div_1_ng_template_4_ng_container_1_span_2_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FileUpload_div_1_ng_template_4_ng_container_1_span_2_1_ng_template_0_Template, 0, 0, "ng-template");
  }
}
function FileUpload_div_1_ng_template_4_ng_container_1_span_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 45);
    ɵɵtemplate(1, FileUpload_div_1_ng_template_4_ng_container_1_span_2_1_Template, 1, 0, null, 11);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r70 = ɵɵnextContext(4);
    ɵɵadvance(1);
    ɵɵproperty("ngTemplateOutlet", ctx_r70.chooseIconTemplate);
  }
}
function FileUpload_div_1_ng_template_4_ng_container_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainerStart(0);
    ɵɵtemplate(1, FileUpload_div_1_ng_template_4_ng_container_1_PlusIcon_1_Template, 1, 1, "PlusIcon", 19);
    ɵɵtemplate(2, FileUpload_div_1_ng_template_4_ng_container_1_span_2_Template, 2, 1, "span", 44);
    ɵɵelementContainerEnd();
  }
  if (rf & 2) {
    const ctx_r68 = ɵɵnextContext(3);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r68.chooseIconTemplate);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r68.chooseIconTemplate);
  }
}
function FileUpload_div_1_ng_template_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtemplate(0, FileUpload_div_1_ng_template_4_span_0_Template, 1, 1, "span", 42);
    ɵɵtemplate(1, FileUpload_div_1_ng_template_4_ng_container_1_Template, 3, 2, "ng-container", 8);
  }
  if (rf & 2) {
    const ctx_r58 = ɵɵnextContext(2);
    ɵɵproperty("ngIf", ctx_r58.chooseIcon);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r58.chooseIcon);
  }
}
function FileUpload_div_1_span_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementStart(0, "span", 9);
    ɵɵtext(1);
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r59 = ɵɵnextContext(2);
    ɵɵadvance(1);
    ɵɵtextInterpolate(ctx_r59.basicButtonLabel);
  }
}
function FileUpload_div_1_input_7_Template(rf, ctx) {
  if (rf & 1) {
    const _r75 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "input", 46, 47);
    ɵɵlistener("change", function FileUpload_div_1_input_7_Template_input_change_0_listener($event) {
      ɵɵrestoreView(_r75);
      const ctx_r74 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r74.onFileSelect($event));
    })("focus", function FileUpload_div_1_input_7_Template_input_focus_0_listener() {
      ɵɵrestoreView(_r75);
      const ctx_r76 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r76.onFocus());
    })("blur", function FileUpload_div_1_input_7_Template_input_blur_0_listener() {
      ɵɵrestoreView(_r75);
      const ctx_r77 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r77.onBlur());
    });
    ɵɵelementEnd();
  }
  if (rf & 2) {
    const ctx_r60 = ɵɵnextContext(2);
    ɵɵproperty("accept", ctx_r60.accept)("multiple", ctx_r60.multiple)("disabled", ctx_r60.disabled);
  }
}
var _c5 = function(a1, a2, a3, a4) {
  return {
    "p-button p-component p-fileupload-choose": true,
    "p-button-icon-only": a1,
    "p-fileupload-choose-selected": a2,
    "p-focus": a3,
    "p-disabled": a4
  };
};
function FileUpload_div_1_Template(rf, ctx) {
  if (rf & 1) {
    const _r79 = ɵɵgetCurrentView();
    ɵɵelementStart(0, "div", 34);
    ɵɵelement(1, "p-messages", 15);
    ɵɵelementStart(2, "span", 35);
    ɵɵlistener("mouseup", function FileUpload_div_1_Template_span_mouseup_2_listener() {
      ɵɵrestoreView(_r79);
      const ctx_r78 = ɵɵnextContext();
      return ɵɵresetView(ctx_r78.onBasicUploaderClick());
    })("keydown", function FileUpload_div_1_Template_span_keydown_2_listener($event) {
      ɵɵrestoreView(_r79);
      const ctx_r80 = ɵɵnextContext();
      return ɵɵresetView(ctx_r80.onBasicKeydown($event));
    });
    ɵɵtemplate(3, FileUpload_div_1_ng_container_3_Template, 3, 2, "ng-container", 36);
    ɵɵtemplate(4, FileUpload_div_1_ng_template_4_Template, 2, 2, "ng-template", null, 37, ɵɵtemplateRefExtractor);
    ɵɵtemplate(6, FileUpload_div_1_span_6_Template, 2, 1, "span", 38);
    ɵɵtemplate(7, FileUpload_div_1_input_7_Template, 2, 3, "input", 39);
    ɵɵelementEnd()();
  }
  if (rf & 2) {
    const _r57 = ɵɵreference(5);
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance(1);
    ɵɵproperty("value", ctx_r1.msgs)("enableService", false);
    ɵɵadvance(1);
    ɵɵclassMap(ctx_r1.styleClass);
    ɵɵproperty("ngClass", ɵɵpureFunction4(10, _c5, !ctx_r1.basicButtonLabel, ctx_r1.hasFiles(), ctx_r1.focus, ctx_r1.disabled))("ngStyle", ctx_r1.style);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", ctx_r1.hasFiles() && !ctx_r1.auto)("ngIfElse", _r57);
    ɵɵadvance(3);
    ɵɵproperty("ngIf", ctx_r1.basicButtonLabel);
    ɵɵadvance(1);
    ɵɵproperty("ngIf", !ctx_r1.hasFiles());
  }
}
var _FileUpload = class {
  constructor(document, platformId, renderer, el, sanitizer, zone, http, cd, config) {
    __publicField(this, "document");
    __publicField(this, "platformId");
    __publicField(this, "renderer");
    __publicField(this, "el");
    __publicField(this, "sanitizer");
    __publicField(this, "zone");
    __publicField(this, "http");
    __publicField(this, "cd");
    __publicField(this, "config");
    /**
     * Name of the request parameter to identify the files at backend.
     * @group Props
     */
    __publicField(this, "name");
    /**
     * Remote url to upload the files.
     * @group Props
     */
    __publicField(this, "url");
    /**
     * HTTP method to send the files to the url such as "post" and "put".
     * @group Props
     */
    __publicField(this, "method", "post");
    /**
     * Used to select multiple files at once from file dialog.
     * @group Props
     */
    __publicField(this, "multiple");
    /**
     * Comma-separated list of pattern to restrict the allowed file types. Can be any combination of either the MIME types (such as "image/*") or the file extensions (such as ".jpg").
     * @group Props
     */
    __publicField(this, "accept");
    /**
     * Disables the upload functionality.
     * @group Props
     */
    __publicField(this, "disabled");
    /**
     * When enabled, upload begins automatically after selection is completed.
     * @group Props
     */
    __publicField(this, "auto");
    /**
     * Cross-site Access-Control requests should be made using credentials such as cookies, authorization headers or TLS client certificates.
     * @group Props
     */
    __publicField(this, "withCredentials");
    /**
     * Maximum file size allowed in bytes.
     * @group Props
     */
    __publicField(this, "maxFileSize");
    /**
     * Summary message of the invalid file size.
     * @group Props
     */
    __publicField(this, "invalidFileSizeMessageSummary", "{0}: Invalid file size, ");
    /**
     * Detail message of the invalid file size.
     * @group Props
     */
    __publicField(this, "invalidFileSizeMessageDetail", "maximum upload size is {0}.");
    /**
     * Summary message of the invalid file type.
     * @group Props
     */
    __publicField(this, "invalidFileTypeMessageSummary", "{0}: Invalid file type, ");
    /**
     * Detail message of the invalid file type.
     * @group Props
     */
    __publicField(this, "invalidFileTypeMessageDetail", "allowed file types: {0}.");
    /**
     * Detail message of the invalid file type.
     * @group Props
     */
    __publicField(this, "invalidFileLimitMessageDetail", "limit is {0} at most.");
    /**
     * Summary message of the invalid file type.
     * @group Props
     */
    __publicField(this, "invalidFileLimitMessageSummary", "Maximum number of files exceeded, ");
    /**
     * Inline style of the element.
     * @group Props
     */
    __publicField(this, "style");
    /**
     * Class of the element.
     * @group Props
     */
    __publicField(this, "styleClass");
    /**
     * Width of the image thumbnail in pixels.
     * @group Props
     */
    __publicField(this, "previewWidth", 50);
    /**
     * Label of the choose button. Defaults to PrimeVue Locale configuration.
     * @group Props
     */
    __publicField(this, "chooseLabel");
    /**
     * Label of the upload button. Defaults to PrimeVue Locale configuration.
     * @group Props
     */
    __publicField(this, "uploadLabel");
    /**
     * Label of the cancel button. Defaults to PrimeVue Locale configuration.
     * @group Props
     */
    __publicField(this, "cancelLabel");
    /**
     * Icon of the choose button.
     * @group Props
     */
    __publicField(this, "chooseIcon");
    /**
     * Icon of the upload button.
     * @group Props
     */
    __publicField(this, "uploadIcon");
    /**
     * Icon of the cancel button.
     * @group Props
     */
    __publicField(this, "cancelIcon");
    /**
     * Whether to show the upload button.
     * @group Props
     */
    __publicField(this, "showUploadButton", true);
    /**
     * Whether to show the cancel button.
     * @group Props
     */
    __publicField(this, "showCancelButton", true);
    /**
     * Defines the UI of the component.
     * @group Props
     */
    __publicField(this, "mode", "advanced");
    /**
     * HttpHeaders class represents the header configuration options for an HTTP request.
     * @group Props
     */
    __publicField(this, "headers");
    /**
     * Whether to use the default upload or a manual implementation defined in uploadHandler callback. Defaults to PrimeNG Locale configuration.
     * @group Props
     */
    __publicField(this, "customUpload");
    /**
     * Maximum number of files that can be uploaded.
     * @group Props
     */
    __publicField(this, "fileLimit");
    /**
     * Style class of the upload button.
     * @group Props
     */
    __publicField(this, "uploadStyleClass");
    /**
     * Style class of the cancel button.
     * @group Props
     */
    __publicField(this, "cancelStyleClass");
    /**
     * Style class of the remove button.
     * @group Props
     */
    __publicField(this, "removeStyleClass");
    /**
     * Style class of the choose button.
     * @group Props
     */
    __publicField(this, "chooseStyleClass");
    /**
     * Callback to invoke before file upload is initialized.
     * @param {FileBeforeUploadEvent} event - Custom upload event.
     * @group Emits
     */
    __publicField(this, "onBeforeUpload", new EventEmitter());
    /**
     * An event indicating that the request was sent to the server. Useful when a request may be retried multiple times, to distinguish between retries on the final event stream.
     * @param {FileSendEvent} event - Custom send event.
     * @group Emits
     */
    __publicField(this, "onSend", new EventEmitter());
    /**
     * Callback to invoke when file upload is complete.
     * @param {FileUploadEvent} event - Custom upload event.
     * @group Emits
     */
    __publicField(this, "onUpload", new EventEmitter());
    /**
     * Callback to invoke if file upload fails.
     * @param {FileUploadErrorEvent} event - Custom error event.
     * @group Emits
     */
    __publicField(this, "onError", new EventEmitter());
    /**
     * Callback to invoke when files in queue are removed without uploading using clear all button.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    __publicField(this, "onClear", new EventEmitter());
    /**
     * Callback to invoke when a file is removed without uploading using clear button of a file.
     * @param {FileRemoveEvent} event - Remove event.
     * @group Emits
     */
    __publicField(this, "onRemove", new EventEmitter());
    /**
     * Callback to invoke when files are selected.
     * @param {FileSelectEvent} event - Select event.
     * @group Emits
     */
    __publicField(this, "onSelect", new EventEmitter());
    /**
     * Callback to invoke when files are being uploaded.
     * @param {FileProgressEvent} event - Progress event.
     * @group Emits
     */
    __publicField(this, "onProgress", new EventEmitter());
    /**
     * Callback to invoke in custom upload mode to upload the files manually.
     * @param {FileUploadHandlerEvent} event - Upload handler event.
     * @group Emits
     */
    __publicField(this, "uploadHandler", new EventEmitter());
    /**
     * This event is triggered if an error occurs while loading an image file.
     * @param {Event} event - Browser event.
     * @group Emits
     */
    __publicField(this, "onImageError", new EventEmitter());
    __publicField(this, "templates");
    __publicField(this, "advancedFileInput");
    __publicField(this, "basicFileInput");
    __publicField(this, "content");
    __publicField(this, "_files", []);
    __publicField(this, "progress", 0);
    __publicField(this, "dragHighlight");
    __publicField(this, "msgs");
    __publicField(this, "fileTemplate");
    __publicField(this, "contentTemplate");
    __publicField(this, "toolbarTemplate");
    __publicField(this, "chooseIconTemplate");
    __publicField(this, "uploadIconTemplate");
    __publicField(this, "cancelIconTemplate");
    __publicField(this, "uploadedFileCount", 0);
    __publicField(this, "focus");
    __publicField(this, "uploading");
    __publicField(this, "duplicateIEEvent");
    // flag to recognize duplicate onchange event for file input
    __publicField(this, "translationSubscription");
    __publicField(this, "dragOverListener");
    this.document = document;
    this.platformId = platformId;
    this.renderer = renderer;
    this.el = el;
    this.sanitizer = sanitizer;
    this.zone = zone;
    this.http = http;
    this.cd = cd;
    this.config = config;
  }
  set files(files) {
    this._files = [];
    for (let i = 0; i < files.length; i++) {
      let file = files[i];
      if (this.validate(file)) {
        if (this.isImage(file)) {
          file.objectURL = this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(files[i]));
        }
        this._files.push(files[i]);
      }
    }
  }
  get files() {
    return this._files;
  }
  get basicButtonLabel() {
    if (this.auto || !this.hasFiles()) {
      return this.chooseLabel;
    }
    return this.uploadLabel ?? this.files[0].name;
  }
  ngAfterContentInit() {
    var _a;
    (_a = this.templates) == null ? void 0 : _a.forEach((item) => {
      switch (item.getType()) {
        case "file":
          this.fileTemplate = item.template;
          break;
        case "content":
          this.contentTemplate = item.template;
          break;
        case "toolbar":
          this.toolbarTemplate = item.template;
          break;
        case "chooseicon":
          this.chooseIconTemplate = item.template;
          break;
        case "uploadicon":
          this.uploadIconTemplate = item.template;
          break;
        case "cancelicon":
          this.cancelIconTemplate = item.template;
          break;
        default:
          this.fileTemplate = item.template;
          break;
      }
    });
  }
  ngOnInit() {
    this.translationSubscription = this.config.translationObserver.subscribe(() => {
      this.cd.markForCheck();
    });
  }
  ngAfterViewInit() {
    if (isPlatformBrowser(this.platformId)) {
      if (this.mode === "advanced") {
        this.zone.runOutsideAngular(() => {
          if (this.content) {
            this.dragOverListener = this.renderer.listen(this.content.nativeElement, "dragover", this.onDragOver.bind(this));
          }
        });
      }
    }
  }
  choose() {
    var _a;
    (_a = this.advancedFileInput) == null ? void 0 : _a.nativeElement.click();
  }
  onFileSelect(event) {
    if (event.type !== "drop" && this.isIE11() && this.duplicateIEEvent) {
      this.duplicateIEEvent = false;
      return;
    }
    this.msgs = [];
    if (!this.multiple) {
      this.files = [];
    }
    let files = event.dataTransfer ? event.dataTransfer.files : event.target.files;
    for (let i = 0; i < files.length; i++) {
      let file = files[i];
      if (!this.isFileSelected(file)) {
        if (this.validate(file)) {
          if (this.isImage(file)) {
            file.objectURL = this.sanitizer.bypassSecurityTrustUrl(window.URL.createObjectURL(files[i]));
          }
          this.files.push(files[i]);
        }
      }
    }
    this.onSelect.emit({
      originalEvent: event,
      files,
      currentFiles: this.files
    });
    if (this.fileLimit) {
      this.checkFileLimit();
    }
    if (this.hasFiles() && this.auto && (!(this.mode === "advanced") || !this.isFileLimitExceeded())) {
      this.upload();
    }
    if (event.type !== "drop" && this.isIE11()) {
      this.clearIEInput();
    } else {
      this.clearInputElement();
    }
  }
  isFileSelected(file) {
    for (let sFile of this.files) {
      if (sFile.name + sFile.type + sFile.size === file.name + file.type + file.size) {
        return true;
      }
    }
    return false;
  }
  isIE11() {
    if (isPlatformBrowser(this.platformId)) {
      return !!this.document.defaultView["MSInputMethodContext"] && !!this.document["documentMode"];
    }
  }
  validate(file) {
    this.msgs = [];
    if (this.accept && !this.isFileTypeValid(file)) {
      this.msgs.push({
        severity: "error",
        summary: this.invalidFileTypeMessageSummary.replace("{0}", file.name),
        detail: this.invalidFileTypeMessageDetail.replace("{0}", this.accept)
      });
      return false;
    }
    if (this.maxFileSize && file.size > this.maxFileSize) {
      this.msgs.push({
        severity: "error",
        summary: this.invalidFileSizeMessageSummary.replace("{0}", file.name),
        detail: this.invalidFileSizeMessageDetail.replace("{0}", this.formatSize(this.maxFileSize))
      });
      return false;
    }
    return true;
  }
  isFileTypeValid(file) {
    var _a;
    let acceptableTypes = (_a = this.accept) == null ? void 0 : _a.split(",").map((type) => type.trim());
    for (let type of acceptableTypes) {
      let acceptable = this.isWildcard(type) ? this.getTypeClass(file.type) === this.getTypeClass(type) : file.type == type || this.getFileExtension(file).toLowerCase() === type.toLowerCase();
      if (acceptable) {
        return true;
      }
    }
    return false;
  }
  getTypeClass(fileType) {
    return fileType.substring(0, fileType.indexOf("/"));
  }
  isWildcard(fileType) {
    return fileType.indexOf("*") !== -1;
  }
  getFileExtension(file) {
    return "." + file.name.split(".").pop();
  }
  isImage(file) {
    return /^image\//.test(file.type);
  }
  onImageLoad(img) {
    window.URL.revokeObjectURL(img.src);
  }
  /**
   * Uploads the selected files.
   * @group Method
   */
  upload() {
    if (this.customUpload) {
      if (this.fileLimit) {
        this.uploadedFileCount += this.files.length;
      }
      this.uploadHandler.emit({
        files: this.files
      });
      this.cd.markForCheck();
    } else {
      this.uploading = true;
      this.msgs = [];
      let formData = new FormData();
      this.onBeforeUpload.emit({
        formData
      });
      for (let i = 0; i < this.files.length; i++) {
        formData.append(this.name, this.files[i], this.files[i].name);
      }
      this.http.request(this.method, this.url, {
        body: formData,
        headers: this.headers,
        reportProgress: true,
        observe: "events",
        withCredentials: this.withCredentials
      }).subscribe((event) => {
        switch (event.type) {
          case HttpEventType.Sent:
            this.onSend.emit({
              originalEvent: event,
              formData
            });
            break;
          case HttpEventType.Response:
            this.uploading = false;
            this.progress = 0;
            if (event["status"] >= 200 && event["status"] < 300) {
              if (this.fileLimit) {
                this.uploadedFileCount += this.files.length;
              }
              this.onUpload.emit({
                originalEvent: event,
                files: this.files
              });
            } else {
              this.onError.emit({
                files: this.files
              });
            }
            this.clear();
            break;
          case HttpEventType.UploadProgress: {
            if (event["loaded"]) {
              this.progress = Math.round(event["loaded"] * 100 / event["total"]);
            }
            this.onProgress.emit({
              originalEvent: event,
              progress: this.progress
            });
            break;
          }
        }
        this.cd.markForCheck();
      }, (error) => {
        this.uploading = false;
        this.onError.emit({
          files: this.files,
          error
        });
      });
    }
  }
  /**
   * Clears the files list.
   * @group Method
   */
  clear() {
    this.files = [];
    this.onClear.emit();
    this.clearInputElement();
    this.cd.markForCheck();
  }
  remove(event, index) {
    this.clearInputElement();
    this.onRemove.emit({
      originalEvent: event,
      file: this.files[index]
    });
    this.files.splice(index, 1);
    this.checkFileLimit();
  }
  isFileLimitExceeded() {
    if (this.fileLimit && this.fileLimit <= this.files.length + this.uploadedFileCount && this.focus) {
      this.focus = false;
    }
    return this.fileLimit && this.fileLimit < this.files.length + this.uploadedFileCount;
  }
  isChooseDisabled() {
    return this.fileLimit && this.fileLimit <= this.files.length + this.uploadedFileCount;
  }
  checkFileLimit() {
    this.msgs ?? (this.msgs = []);
    if (this.isFileLimitExceeded()) {
      this.msgs.push({
        severity: "error",
        summary: this.invalidFileLimitMessageSummary.replace("{0}", this.fileLimit.toString()),
        detail: this.invalidFileLimitMessageDetail.replace("{0}", this.fileLimit.toString())
      });
    }
  }
  clearInputElement() {
    if (this.advancedFileInput && this.advancedFileInput.nativeElement) {
      this.advancedFileInput.nativeElement.value = "";
    }
    if (this.basicFileInput && this.basicFileInput.nativeElement) {
      this.basicFileInput.nativeElement.value = "";
    }
  }
  clearIEInput() {
    if (this.advancedFileInput && this.advancedFileInput.nativeElement) {
      this.duplicateIEEvent = true;
      this.advancedFileInput.nativeElement.value = "";
    }
  }
  hasFiles() {
    return this.files && this.files.length > 0;
  }
  onDragEnter(e) {
    if (!this.disabled) {
      e.stopPropagation();
      e.preventDefault();
    }
  }
  onDragOver(e) {
    var _a;
    if (!this.disabled) {
      DomHandler.addClass((_a = this.content) == null ? void 0 : _a.nativeElement, "p-fileupload-highlight");
      this.dragHighlight = true;
      e.stopPropagation();
      e.preventDefault();
    }
  }
  onDragLeave(event) {
    var _a;
    if (!this.disabled) {
      DomHandler.removeClass((_a = this.content) == null ? void 0 : _a.nativeElement, "p-fileupload-highlight");
    }
  }
  onDrop(event) {
    var _a;
    if (!this.disabled) {
      DomHandler.removeClass((_a = this.content) == null ? void 0 : _a.nativeElement, "p-fileupload-highlight");
      event.stopPropagation();
      event.preventDefault();
      let files = event.dataTransfer ? event.dataTransfer.files : event.target.files;
      let allowDrop = this.multiple || files && files.length === 1;
      if (allowDrop) {
        this.onFileSelect(event);
      }
    }
  }
  onFocus() {
    this.focus = true;
  }
  onBlur() {
    this.focus = false;
  }
  formatSize(bytes) {
    if (bytes == 0) {
      return "0 B";
    }
    let k = 1e3, dm = 3, sizes = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"], i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
  }
  onBasicUploaderClick() {
    var _a;
    if (this.hasFiles())
      this.upload();
    else
      (_a = this.basicFileInput) == null ? void 0 : _a.nativeElement.click();
  }
  onBasicKeydown(event) {
    switch (event.code) {
      case "Space":
      case "Enter":
        this.onBasicUploaderClick();
        event.preventDefault();
        break;
    }
  }
  imageError(event) {
    this.onImageError.emit(event);
  }
  getBlockableElement() {
    return this.el.nativeElement.children[0];
  }
  get chooseButtonLabel() {
    return this.chooseLabel || this.config.getTranslation(TranslationKeys.CHOOSE);
  }
  get uploadButtonLabel() {
    return this.uploadLabel || this.config.getTranslation(TranslationKeys.UPLOAD);
  }
  get cancelButtonLabel() {
    return this.cancelLabel || this.config.getTranslation(TranslationKeys.CANCEL);
  }
  ngOnDestroy() {
    if (this.content && this.content.nativeElement) {
      if (this.dragOverListener) {
        this.dragOverListener();
        this.dragOverListener = null;
      }
    }
    if (this.translationSubscription) {
      this.translationSubscription.unsubscribe();
    }
  }
};
var FileUpload = _FileUpload;
__publicField(FileUpload, "ɵfac", function FileUpload_Factory(t) {
  return new (t || _FileUpload)(ɵɵdirectiveInject(DOCUMENT), ɵɵdirectiveInject(PLATFORM_ID), ɵɵdirectiveInject(Renderer2), ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(DomSanitizer), ɵɵdirectiveInject(NgZone), ɵɵdirectiveInject(HttpClient), ɵɵdirectiveInject(ChangeDetectorRef), ɵɵdirectiveInject(PrimeNGConfig));
});
__publicField(FileUpload, "ɵcmp", ɵɵdefineComponent({
  type: _FileUpload,
  selectors: [["p-fileUpload"]],
  contentQueries: function FileUpload_ContentQueries(rf, ctx, dirIndex) {
    if (rf & 1) {
      ɵɵcontentQuery(dirIndex, PrimeTemplate, 4);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.templates = _t);
    }
  },
  viewQuery: function FileUpload_Query(rf, ctx) {
    if (rf & 1) {
      ɵɵviewQuery(_c03, 5);
      ɵɵviewQuery(_c12, 5);
      ɵɵviewQuery(_c2, 5);
    }
    if (rf & 2) {
      let _t;
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.advancedFileInput = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.basicFileInput = _t.first);
      ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.content = _t.first);
    }
  },
  hostAttrs: [1, "p-element"],
  inputs: {
    name: "name",
    url: "url",
    method: "method",
    multiple: "multiple",
    accept: "accept",
    disabled: "disabled",
    auto: "auto",
    withCredentials: "withCredentials",
    maxFileSize: "maxFileSize",
    invalidFileSizeMessageSummary: "invalidFileSizeMessageSummary",
    invalidFileSizeMessageDetail: "invalidFileSizeMessageDetail",
    invalidFileTypeMessageSummary: "invalidFileTypeMessageSummary",
    invalidFileTypeMessageDetail: "invalidFileTypeMessageDetail",
    invalidFileLimitMessageDetail: "invalidFileLimitMessageDetail",
    invalidFileLimitMessageSummary: "invalidFileLimitMessageSummary",
    style: "style",
    styleClass: "styleClass",
    previewWidth: "previewWidth",
    chooseLabel: "chooseLabel",
    uploadLabel: "uploadLabel",
    cancelLabel: "cancelLabel",
    chooseIcon: "chooseIcon",
    uploadIcon: "uploadIcon",
    cancelIcon: "cancelIcon",
    showUploadButton: "showUploadButton",
    showCancelButton: "showCancelButton",
    mode: "mode",
    headers: "headers",
    customUpload: "customUpload",
    fileLimit: "fileLimit",
    uploadStyleClass: "uploadStyleClass",
    cancelStyleClass: "cancelStyleClass",
    removeStyleClass: "removeStyleClass",
    chooseStyleClass: "chooseStyleClass",
    files: "files"
  },
  outputs: {
    onBeforeUpload: "onBeforeUpload",
    onSend: "onSend",
    onUpload: "onUpload",
    onError: "onError",
    onClear: "onClear",
    onRemove: "onRemove",
    onSelect: "onSelect",
    onProgress: "onProgress",
    uploadHandler: "uploadHandler",
    onImageError: "onImageError"
  },
  decls: 2,
  vars: 2,
  consts: [[3, "ngClass", "ngStyle", "class", 4, "ngIf"], ["class", "p-fileupload p-fileupload-basic p-component", 4, "ngIf"], [3, "ngClass", "ngStyle"], [1, "p-fileupload-buttonbar"], ["pRipple", "", "tabindex", "0", 1, "p-button", "p-component", "p-fileupload-choose", 3, "ngClass", "focus", "blur", "click", "keydown.enter"], ["type", "file", 3, "multiple", "accept", "disabled", "change"], ["advancedfileinput", ""], [3, "ngClass", "class", 4, "ngIf"], [4, "ngIf"], [1, "p-button-label"], ["type", "button", 3, "label", "disabled", "styleClass", "onClick", 4, "ngIf"], [4, "ngTemplateOutlet"], [1, "p-fileupload-content", 3, "dragenter", "dragleave", "drop"], ["content", ""], [3, "value", "showValue", 4, "ngIf"], [3, "value", "enableService"], ["class", "p-fileupload-files", 4, "ngIf"], [4, "ngTemplateOutlet", "ngTemplateOutletContext"], [3, "ngClass"], [3, "styleClass", 4, "ngIf"], ["class", "p-button-icon p-button-icon-left", 4, "ngIf"], [3, "styleClass"], [1, "p-button-icon", "p-button-icon-left"], ["type", "button", 3, "label", "disabled", "styleClass", "onClick"], [3, "ngClass", 4, "ngIf"], [3, "value", "showValue"], [1, "p-fileupload-files"], ["class", "p-fileupload-row", 4, "ngFor", "ngForOf"], [1, "p-fileupload-row"], [3, "src", "width", "error", 4, "ngIf"], [1, "p-fileupload-filename"], ["type", "button", "pButton", "", 1, "p-button-icon-only", 3, "disabled", "click"], [3, "src", "width", "error"], ["ngFor", "", 3, "ngForOf", "ngForTemplate"], [1, "p-fileupload", "p-fileupload-basic", "p-component"], ["tabindex", "0", "pRipple", "", 3, "ngClass", "ngStyle", "mouseup", "keydown"], [4, "ngIf", "ngIfElse"], ["chooseSection", ""], ["class", "p-button-label", 4, "ngIf"], ["type", "file", 3, "accept", "multiple", "disabled", "change", "focus", "blur", 4, "ngIf"], ["class", "p-button-icon p-button-icon-left", 3, "ngClass", 4, "ngIf"], [1, "p-button-icon", "p-button-icon-left", 3, "ngClass"], ["class", "p-button-icon p-button-icon-left pi", 3, "ngClass", 4, "ngIf"], [1, "p-button-icon", "p-button-icon-left", "pi", 3, "ngClass"], ["class", "p-button-icon p-button-icon-left pi", 4, "ngIf"], [1, "p-button-icon", "p-button-icon-left", "pi"], ["type", "file", 3, "accept", "multiple", "disabled", "change", "focus", "blur"], ["basicfileinput", ""]],
  template: function FileUpload_Template(rf, ctx) {
    if (rf & 1) {
      ɵɵtemplate(0, FileUpload_div_0_Template, 18, 28, "div", 0);
      ɵɵtemplate(1, FileUpload_div_1_Template, 8, 15, "div", 1);
    }
    if (rf & 2) {
      ɵɵproperty("ngIf", ctx.mode === "advanced");
      ɵɵadvance(1);
      ɵɵproperty("ngIf", ctx.mode === "basic");
    }
  },
  dependencies: function() {
    return [NgClass, NgForOf, NgIf, NgTemplateOutlet, NgStyle, ButtonDirective, Button, ProgressBar, Messages, Ripple, PlusIcon, UploadIcon, TimesIcon];
  },
  styles: [".p-fileupload-content{position:relative}.p-fileupload-row{display:flex;align-items:center}.p-fileupload-row>div{flex:1 1 auto;width:25%}.p-fileupload-row>div:last-child{text-align:right}.p-fileupload-content .p-progressbar{width:100%;position:absolute;top:0;left:0}.p-button.p-fileupload-choose{position:relative;overflow:hidden}.p-button.p-fileupload-choose input[type=file],.p-fileupload-choose.p-fileupload-choose-selected input[type=file]{display:none}.p-fluid .p-fileupload .p-button{width:auto}.p-fileupload-filename{word-break:break-all}\n"],
  encapsulation: 2,
  changeDetection: 0
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FileUpload, [{
    type: Component,
    args: [{
      selector: "p-fileUpload",
      template: `
        <div [ngClass]="'p-fileupload p-fileupload-advanced p-component'" [ngStyle]="style" [class]="styleClass" *ngIf="mode === 'advanced'">
            <div class="p-fileupload-buttonbar">
                <span
                    class="p-button p-component p-fileupload-choose"
                    [ngClass]="{ 'p-focus': focus, 'p-disabled': disabled || isChooseDisabled() }"
                    (focus)="onFocus()"
                    (blur)="onBlur()"
                    pRipple
                    (click)="choose()"
                    (keydown.enter)="choose()"
                    tabindex="0"
                    [class]="chooseStyleClass"
                >
                    <input #advancedfileinput type="file" (change)="onFileSelect($event)" [multiple]="multiple" [accept]="accept" [disabled]="disabled || isChooseDisabled()" [attr.title]="''" />
                    <span *ngIf="chooseIcon" [ngClass]="'p-button-icon p-button-icon-left'" [class]="chooseIcon"></span>
                    <ng-container *ngIf="!chooseIcon">
                        <PlusIcon *ngIf="!chooseIconTemplate" [styleClass]="'p-button-icon p-button-icon-left'" />
                        <span *ngIf="chooseIconTemplate" class="p-button-icon p-button-icon-left">
                            <ng-template *ngTemplateOutlet="chooseIconTemplate"></ng-template>
                        </span>
                    </ng-container>
                    <span class="p-button-label">{{ chooseButtonLabel }}</span>
                </span>

                <p-button *ngIf="!auto && showUploadButton" type="button" [label]="uploadButtonLabel" (onClick)="upload()" [disabled]="!hasFiles() || isFileLimitExceeded()" [styleClass]="uploadStyleClass">
                    <span *ngIf="uploadIcon" [ngClass]="uploadIcon"></span>
                    <ng-container *ngIf="!uploadIcon">
                        <UploadIcon *ngIf="!uploadIconTemplate" [styleClass]="'p-button-icon p-button-icon-left'" />
                        <span *ngIf="uploadIconTemplate" class="p-button-icon p-button-icon-left">
                            <ng-template *ngTemplateOutlet="uploadIconTemplate"></ng-template>
                        </span>
                    </ng-container>
                </p-button>
                <p-button *ngIf="!auto && showCancelButton" type="button" [label]="cancelButtonLabel" (onClick)="clear()" [disabled]="!hasFiles() || uploading" [styleClass]="cancelStyleClass">
                    <span *ngIf="cancelIcon" [ngClass]="cancelIcon"></span>
                    <ng-container *ngIf="!cancelIcon">
                        <TimesIcon *ngIf="!cancelIconTemplate" [styleClass]="'p-button-icon p-button-icon-left'" />
                        <span *ngIf="cancelIconTemplate" class="p-button-icon p-button-icon-left">
                            <ng-template *ngTemplateOutlet="cancelIconTemplate"></ng-template>
                        </span>
                    </ng-container>
                </p-button>

                <ng-container *ngTemplateOutlet="toolbarTemplate"></ng-container>
            </div>
            <div #content class="p-fileupload-content" (dragenter)="onDragEnter($event)" (dragleave)="onDragLeave($event)" (drop)="onDrop($event)">
                <p-progressBar [value]="progress" [showValue]="false" *ngIf="hasFiles()"></p-progressBar>

                <p-messages [value]="msgs" [enableService]="false"></p-messages>

                <div class="p-fileupload-files" *ngIf="hasFiles()">
                    <div *ngIf="!fileTemplate">
                        <div class="p-fileupload-row" *ngFor="let file of files; let i = index">
                            <div><img [src]="file.objectURL" *ngIf="isImage(file)" [width]="previewWidth" (error)="imageError($event)" /></div>
                            <div class="p-fileupload-filename">{{ file.name }}</div>
                            <div>{{ formatSize(file.size) }}</div>
                            <div>
                                <button type="button" pButton (click)="remove($event, i)" [disabled]="uploading" class="p-button-icon-only" [class]="removeStyleClass">
                                    <TimesIcon *ngIf="!cancelIconTemplate" />
                                    <ng-template *ngTemplateOutlet="cancelIconTemplate"></ng-template>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div *ngIf="fileTemplate">
                        <ng-template ngFor [ngForOf]="files" [ngForTemplate]="fileTemplate"></ng-template>
                    </div>
                </div>
                <ng-container *ngTemplateOutlet="contentTemplate; context: { $implicit: files }"></ng-container>
            </div>
        </div>
        <div class="p-fileupload p-fileupload-basic p-component" *ngIf="mode === 'basic'">
            <p-messages [value]="msgs" [enableService]="false"></p-messages>
            <span
                [ngClass]="{ 'p-button p-component p-fileupload-choose': true, 'p-button-icon-only': !basicButtonLabel, 'p-fileupload-choose-selected': hasFiles(), 'p-focus': focus, 'p-disabled': disabled }"
                [ngStyle]="style"
                [class]="styleClass"
                (mouseup)="onBasicUploaderClick()"
                (keydown)="onBasicKeydown($event)"
                tabindex="0"
                pRipple
            >
                <ng-container *ngIf="hasFiles() && !auto; else chooseSection">
                    <span *ngIf="uploadIcon" class="p-button-icon p-button-icon-left" [ngClass]="uploadIcon"></span>
                    <ng-container *ngIf="!uploadIcon">
                        <UploadIcon *ngIf="!uploadIconTemplate" [styleClass]="'p-button-icon p-button-icon-left'" />
                        <span *ngIf="uploadIconTemplate" class="p-button-icon p-button-icon-left">
                            <ng-template *ngTemplateOutlet="uploadIconTemplate"></ng-template>
                        </span>
                    </ng-container>
                </ng-container>
                <ng-template #chooseSection>
                    <span *ngIf="chooseIcon" class="p-button-icon p-button-icon-left pi" [ngClass]="chooseIcon"></span>
                    <ng-container *ngIf="!chooseIcon">
                        <PlusIcon [styleClass]="'p-button-icon p-button-icon-left pi'" *ngIf="!chooseIconTemplate" />
                        <span *ngIf="chooseIconTemplate" class="p-button-icon p-button-icon-left pi">
                            <ng-template *ngTemplateOutlet="chooseIconTemplate"></ng-template>
                        </span>
                    </ng-container>
                </ng-template>
                <span *ngIf="basicButtonLabel" class="p-button-label">{{ basicButtonLabel }}</span>
                <input #basicfileinput type="file" [accept]="accept" [multiple]="multiple" [disabled]="disabled" (change)="onFileSelect($event)" *ngIf="!hasFiles()" (focus)="onFocus()" (blur)="onBlur()" />
            </span>
        </div>
    `,
      changeDetection: ChangeDetectionStrategy.OnPush,
      encapsulation: ViewEncapsulation$1.None,
      host: {
        class: "p-element"
      },
      styles: [".p-fileupload-content{position:relative}.p-fileupload-row{display:flex;align-items:center}.p-fileupload-row>div{flex:1 1 auto;width:25%}.p-fileupload-row>div:last-child{text-align:right}.p-fileupload-content .p-progressbar{width:100%;position:absolute;top:0;left:0}.p-button.p-fileupload-choose{position:relative;overflow:hidden}.p-button.p-fileupload-choose input[type=file],.p-fileupload-choose.p-fileupload-choose-selected input[type=file]{display:none}.p-fluid .p-fileupload .p-button{width:auto}.p-fileupload-filename{word-break:break-all}\n"]
    }]
  }], function() {
    return [{
      type: Document,
      decorators: [{
        type: Inject,
        args: [DOCUMENT]
      }]
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }, {
      type: Renderer2
    }, {
      type: ElementRef
    }, {
      type: DomSanitizer
    }, {
      type: NgZone
    }, {
      type: HttpClient
    }, {
      type: ChangeDetectorRef
    }, {
      type: PrimeNGConfig
    }];
  }, {
    name: [{
      type: Input
    }],
    url: [{
      type: Input
    }],
    method: [{
      type: Input
    }],
    multiple: [{
      type: Input
    }],
    accept: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    auto: [{
      type: Input
    }],
    withCredentials: [{
      type: Input
    }],
    maxFileSize: [{
      type: Input
    }],
    invalidFileSizeMessageSummary: [{
      type: Input
    }],
    invalidFileSizeMessageDetail: [{
      type: Input
    }],
    invalidFileTypeMessageSummary: [{
      type: Input
    }],
    invalidFileTypeMessageDetail: [{
      type: Input
    }],
    invalidFileLimitMessageDetail: [{
      type: Input
    }],
    invalidFileLimitMessageSummary: [{
      type: Input
    }],
    style: [{
      type: Input
    }],
    styleClass: [{
      type: Input
    }],
    previewWidth: [{
      type: Input
    }],
    chooseLabel: [{
      type: Input
    }],
    uploadLabel: [{
      type: Input
    }],
    cancelLabel: [{
      type: Input
    }],
    chooseIcon: [{
      type: Input
    }],
    uploadIcon: [{
      type: Input
    }],
    cancelIcon: [{
      type: Input
    }],
    showUploadButton: [{
      type: Input
    }],
    showCancelButton: [{
      type: Input
    }],
    mode: [{
      type: Input
    }],
    headers: [{
      type: Input
    }],
    customUpload: [{
      type: Input
    }],
    fileLimit: [{
      type: Input
    }],
    uploadStyleClass: [{
      type: Input
    }],
    cancelStyleClass: [{
      type: Input
    }],
    removeStyleClass: [{
      type: Input
    }],
    chooseStyleClass: [{
      type: Input
    }],
    onBeforeUpload: [{
      type: Output
    }],
    onSend: [{
      type: Output
    }],
    onUpload: [{
      type: Output
    }],
    onError: [{
      type: Output
    }],
    onClear: [{
      type: Output
    }],
    onRemove: [{
      type: Output
    }],
    onSelect: [{
      type: Output
    }],
    onProgress: [{
      type: Output
    }],
    uploadHandler: [{
      type: Output
    }],
    onImageError: [{
      type: Output
    }],
    templates: [{
      type: ContentChildren,
      args: [PrimeTemplate]
    }],
    advancedFileInput: [{
      type: ViewChild,
      args: ["advancedfileinput"]
    }],
    basicFileInput: [{
      type: ViewChild,
      args: ["basicfileinput"]
    }],
    content: [{
      type: ViewChild,
      args: ["content"]
    }],
    files: [{
      type: Input
    }]
  });
})();
var _FileUploadModule = class {
};
var FileUploadModule = _FileUploadModule;
__publicField(FileUploadModule, "ɵfac", function FileUploadModule_Factory(t) {
  return new (t || _FileUploadModule)();
});
__publicField(FileUploadModule, "ɵmod", ɵɵdefineNgModule({
  type: _FileUploadModule,
  declarations: [FileUpload],
  imports: [CommonModule, HttpClientModule, SharedModule, ButtonModule, ProgressBarModule, MessagesModule, RippleModule, PlusIcon, UploadIcon, TimesIcon],
  exports: [FileUpload, SharedModule, ButtonModule, ProgressBarModule, MessagesModule]
}));
__publicField(FileUploadModule, "ɵinj", ɵɵdefineInjector({
  imports: [CommonModule, HttpClientModule, SharedModule, ButtonModule, ProgressBarModule, MessagesModule, RippleModule, PlusIcon, UploadIcon, TimesIcon, SharedModule, ButtonModule, ProgressBarModule, MessagesModule]
}));
(function() {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(FileUploadModule, [{
    type: NgModule,
    args: [{
      imports: [CommonModule, HttpClientModule, SharedModule, ButtonModule, ProgressBarModule, MessagesModule, RippleModule, PlusIcon, UploadIcon, TimesIcon],
      exports: [FileUpload, SharedModule, ButtonModule, ProgressBarModule, MessagesModule],
      declarations: [FileUpload]
    }]
  }], null, null);
})();
export {
  FileUpload,
  FileUploadModule
};
//# sourceMappingURL=primeng_fileupload.js.map
