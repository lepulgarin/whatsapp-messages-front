import {
  InputText,
  InputTextModule
} from "./chunk-KHRDRQSF.js";
import "./chunk-UKH2O2A3.js";
import "./chunk-MIRZRLCI.js";
import "./chunk-SPBZRJHT.js";
import "./chunk-IXJD77KS.js";
import "./chunk-QCYGWUBY.js";
import "./chunk-37TWHRPH.js";
import "./chunk-4BJ7XQX3.js";
import "./chunk-GKWPUQBP.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
