import {
  Tooltip,
  TooltipModule
} from "./chunk-EXFNDU4R.js";
import "./chunk-N3XAYJ3A.js";
import "./chunk-X6HTJCNQ.js";
import "./chunk-MIRZRLCI.js";
import "./chunk-SPBZRJHT.js";
import "./chunk-IXJD77KS.js";
import "./chunk-QCYGWUBY.js";
import "./chunk-37TWHRPH.js";
import "./chunk-4BJ7XQX3.js";
import "./chunk-GKWPUQBP.js";
export {
  Tooltip,
  TooltipModule
};
//# sourceMappingURL=primeng_tooltip.js.map
